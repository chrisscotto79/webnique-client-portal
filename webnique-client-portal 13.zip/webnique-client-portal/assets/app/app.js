(async function () {
  const root = document.getElementById("wnq-portal-root");
  if (!root) return;

  const clientId = root.getAttribute("data-client-id") || "";
  const mode = root.getAttribute("data-mode") || "";

  const restBase = window.WNQ_PORTAL?.restUrl || "";
  const nonce = window.WNQ_PORTAL?.nonce || "";
  const isAdmin = !!window.WNQ_PORTAL?.isAdmin;

  // --- UI helpers ---
  function el(tag, props = {}, children = []) {
    const node = document.createElement(tag);
    Object.entries(props).forEach(([k, v]) => {
      if (k === "style" && v && typeof v === "object") Object.assign(node.style, v);
      else if (k === "className") node.className = v;
      else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === "html") node.innerHTML = v;
      else node.setAttribute(k, v);
    });
    (Array.isArray(children) ? children : [children]).forEach((c) => {
      if (c == null) return;
      node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return node;
  }

  function code(v) {
    return el("code", { style: { background: "rgba(0,0,0,0.04)", padding: "2px 6px", borderRadius: "8px" } }, String(v));
  }

  function setStatus(text, kind = "neutral") {
    const map = {
      neutral: { bg: "rgba(0,0,0,0.04)", brd: "#e5e7eb" },
      ok: { bg: "rgba(16,185,129,0.12)", brd: "rgba(16,185,129,0.35)" },
      warn: { bg: "rgba(245,158,11,0.12)", brd: "rgba(245,158,11,0.35)" },
      err: { bg: "rgba(239,68,68,0.12)", brd: "rgba(239,68,68,0.35)" },
    };
    const s = map[kind] || map.neutral;
    statusPill.textContent = text;
    Object.assign(statusPill.style, {
      background: s.bg,
      border: `1px solid ${s.brd}`,
    });
  }

  function renderJson(json) {
    result.innerHTML = "";
    result.appendChild(
      el("pre", {
        style: {
          whiteSpace: "pre-wrap",
          background: "rgba(0,0,0,0.04)",
          padding: "10px",
          borderRadius: "12px",
          maxHeight: "420px",
          overflow: "auto",
          border: "1px solid #e5e7eb",
        },
      }, JSON.stringify(json, null, 2))
    );
  }

  async function api(path, { method = "GET", body = null } = {}) {
    if (!restBase || !nonce) {
      return { ok: false, error: "Missing restUrl/nonce (WNQ_PORTAL not localized or user not logged in)." };
    }

    const opts = {
      method,
      credentials: "same-origin",
      headers: {
        "X-WP-Nonce": nonce,
      },
    };

    if (body != null) {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }

    try {
      const res = await fetch(`${restBase}${path}`, opts);
      const data = await res.json().catch(() => ({}));
      return { http_ok: res.ok, status: res.status, data };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  }

  // --- Layout ---
  const card = el("div", {
    style: {
      padding: "12px",
      marginTop: "12px",
      border: "1px solid #e5e7eb",
      borderRadius: "12px",
      fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Arial",
      background: "white",
    },
  });

  const header = el("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: "10px" } }, [
    el("div", {}, [
      el("div", { style: { fontWeight: "700", fontSize: "16px" } }, "WNQ App.js Loaded ✅"),
      el("div", { style: { marginTop: "6px", display: "grid", gap: "6px" } }, [
        el("div", {}, ["Client ID: ", code(clientId || "(none)")]),
        el("div", {}, ["Mode: ", code(mode || "(none)")]),
        el("div", {}, ["Ping: ", (function () {
          const span = el("span", { id: "wnq-ping-text" }, "checking...");
          return span;
        })()]),
      ]),
    ]),
  ]);

  const statusPill = el("span", {
    style: {
      padding: "6px 10px",
      borderRadius: "999px",
      fontSize: "12px",
      lineHeight: "1",
      border: "1px solid #e5e7eb",
      background: "rgba(0,0,0,0.04)",
      whiteSpace: "nowrap",
    },
  }, "ready");

  header.appendChild(statusPill);

  const actions = el("div", {
    id: "wnq-actions",
    style: { marginTop: "12px", display: "flex", gap: "10px", flexWrap: "wrap" },
  });

  const result = el("div", { id: "wnq-result", style: { marginTop: "10px" } });

  const proof = el("div", { style: { marginTop: "10px", color: "#374151" } });

  card.appendChild(header);
  card.appendChild(actions);
  card.appendChild(result);
  card.appendChild(proof);

  root.appendChild(card);

  function makeButton(label, onClick, variant = "default") {
    const base = {
      padding: "10px 12px",
      borderRadius: "12px",
      border: "1px solid #d1d5db",
      background: "white",
      cursor: "pointer",
      fontWeight: "600",
    };

    const variants = {
      default: {},
      primary: { border: "1px solid rgba(37,99,235,0.45)", background: "rgba(37,99,235,0.08)" },
      danger: { border: "1px solid rgba(239,68,68,0.45)", background: "rgba(239,68,68,0.08)" },
    };

    return el("button", {
      type: "button",
      style: Object.assign({}, base, variants[variant] || {}),
      onclick: onClick,
    }, label);
  }

  // --- Actions ---
  actions.appendChild(
    makeButton("Load Client Doc", async () => {
      setStatus("loading client…", "neutral");
      result.textContent = "Loading client…";

      const r = await api("/client", { method: "GET" });

      if (r.ok === false) {
        setStatus("client load failed", "err");
        renderJson(r);
        return;
      }

      if (!r.http_ok) {
        setStatus(`client error (${r.status})`, "err");
        renderJson(r.data);
        return;
      }

      setStatus("client loaded", "ok");
      renderJson(r.data);
    }, "primary")
  );

  if (isAdmin) {
    actions.appendChild(
      makeButton("Bootstrap Firestore Client", async () => {
        setStatus("bootstrapping…", "neutral");
        result.textContent = "Bootstrapping…";

        const r = await api("/clients/bootstrap", { method: "POST", body: { client_id: clientId } });

        if (r.ok === false) {
          setStatus("bootstrap failed", "err");
          renderJson(r);
          return;
        }

        if (!r.http_ok) {
          setStatus(`bootstrap error (${r.status})`, "err");
          renderJson(r.data);
          return;
        }

        // created:true on first run, created:false on repeat = OK
        const created = !!r.data?.created;
        setStatus(created ? "created client doc" : "client doc exists", "ok");
        renderJson(r.data);
      }, "default")
    );
  }

  actions.appendChild(
    makeButton("Ping (REST)", async () => {
      setStatus("pinging…", "neutral");
      result.textContent = "Pinging…";

      const r = await api("/ping", { method: "GET" });

      if (r.ok === false) {
        setStatus("ping failed", "err");
        renderJson(r);
        return;
      }

      if (!r.http_ok) {
        setStatus(`ping error (${r.status})`, "err");
        renderJson(r.data);
        return;
      }

      setStatus("ping ok", "ok");
      renderJson(r.data);

      // update proof line
      const uid = r.data?.wp?.user_id ?? "(none)";
      const cid = r.data?.wp?.client_id ?? "(null)";
      proof.innerHTML = `REST user_id: ${code(uid).outerHTML}, client_id: ${code(cid).outerHTML}`;
    }, "default")
  );

  // --- Auto Ping on load ---
  (async function autoPing() {
    const pingText = document.getElementById("wnq-ping-text");
    if (!restBase || !nonce) {
      if (pingText) pingText.textContent = "missing restUrl/nonce";
      setStatus("missing restUrl/nonce", "warn");
      return;
    }

    const r = await api("/ping", { method: "GET" });

    if (r.ok === false) {
      if (pingText) pingText.textContent = "error";
      setStatus("ping failed", "err");
      renderJson(r);
      return;
    }

    if (!r.http_ok) {
      if (pingText) pingText.textContent = `error (${r.status})`;
      setStatus(`ping error (${r.status})`, "err");
      renderJson(r.data);
      return;
    }

    if (pingText) pingText.textContent = r.data?.ok ? "ok" : "not ok";
    setStatus("ready", "ok");

    const uid = r.data?.wp?.user_id ?? "(none)";
    const cid = r.data?.wp?.client_id ?? "(null)";
    proof.innerHTML = `REST user_id: ${code(uid).outerHTML}, client_id: ${code(cid).outerHTML}`;
  })();
})();
