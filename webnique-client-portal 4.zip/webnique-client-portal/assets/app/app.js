(function () {
  const root = document.getElementById("wnq-portal-root");
  if (!root) return;

  const clientId = root.getAttribute("data-client-id") || "";
  const mode = root.getAttribute("data-mode") || "";

  console.log("[WNQ] Portal booted", { clientId, mode });

  // Temporary UI so you SEE JS mounted (we’ll remove later)
  const el = document.createElement("div");
  el.style.padding = "12px";
  el.style.marginTop = "12px";
  el.style.border = "1px solid #e5e7eb";
  el.style.borderRadius = "10px";
  el.style.fontFamily = "system-ui";
  el.innerHTML = `
    <strong>WNQ App.js Loaded ✅</strong><br/>
    Client ID: <code>${clientId || "(none)"}</code><br/>
    Mode: <code>${mode || "(none)"}</code>
  `;

  root.appendChild(el);
})();
