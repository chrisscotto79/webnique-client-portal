<?php

namespace WNQ\Core;

if (!defined('ABSPATH')) {
  exit;
}

final class Router
{
  public static function register(): void
  {
    // v1 bootstrap only.
    // REST endpoints come after we confirm shortcode + permissions.
  }
}
