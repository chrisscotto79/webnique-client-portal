<?php

namespace WNQ\PublicSite;

use WNQ\Core\Permissions;

if (!defined('ABSPATH')) {
  exit;
}

final class Shortcode
{
  public static function register(): void
  {
    add_shortcode('wnq_portal', [self::class, 'render']);
  }

  public static function render($atts = []): string
  {
    if (!Permissions::isLoggedIn()) {
      return '<p>You must be logged in to view this portal.</p>';
    }

    $clientId = Permissions::currentUserClientId();

    // Admins can view shell even without a client_id set (for testing).
    if ($clientId === null && !Permissions::currentUserCanManagePortal()) {
      return '<p>Your account is not linked to a client yet. Please contact WebNique.</p>';
    }

    // Enqueue assets ONLY when shortcode is used.
    self::enqueueAssets();

    $args = [
      'client_id' => $clientId ?? '',
      'mode' => Permissions::currentUserCanManagePortal() ? 'admin' : 'client',
    ];

    return \wnq_portal_shell_html($args);
  }

  private static function enqueueAssets(): void
  {
    $ver = defined('WNQ_PORTAL_VERSION') ? WNQ_PORTAL_VERSION : time();

    wp_enqueue_style(
      'wnq-portal-app',
      WNQ_PORTAL_URL . 'assets/app/app.css',
      [],
      $ver
    );

    wp_enqueue_script(
      'wnq-portal-app',
      WNQ_PORTAL_URL . 'assets/app/app.js',
      [],
      $ver,
      true
    );
  }
}
