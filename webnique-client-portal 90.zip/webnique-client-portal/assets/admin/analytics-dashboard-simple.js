/**
 * WebNique Analytics Dashboard - SIMPLE VERSION (NO CHARTS)
 * 
 * Just displays data in tables - no fancy charts
 * 
 * @package WebNique Portal
 */

(function($) {
    'use strict';

    console.log('=== Simple Analytics Dashboard Loading ===');

    /**
     * Initialize dashboard
     */
    function initDashboard() {
        console.log('Initializing simple dashboard...');
        
        // Bind event handlers
        bindEvents();

        // Load initial data
        loadAnalyticsData(30);
    }

    /**
     * Bind event handlers
     */
    function bindEvents() {
        // Date range selector
        $('#wnq-date-range').on('change', function() {
            var dateRange = parseInt($(this).val());
            loadAnalyticsData(dateRange);
        });

        // Refresh button
        $('#wnq-refresh-data').on('click', function() {
            $(this).prop('disabled', true).text('🔄 Refreshing...');
            loadAnalyticsData(parseInt($('#wnq-date-range').val()));
        });
    }

    /**
     * Load analytics data via AJAX
     */
    function loadAnalyticsData(dateRange) {
        console.log('Loading analytics data for ' + dateRange + ' days...');
        
        // Check if wnqAnalytics exists
        if (typeof wnqAnalytics === 'undefined') {
            console.error('ERROR: wnqAnalytics not defined!');
            showError('Configuration error: wnqAnalytics object not found');
            return;
        }
        
        console.log('Using AJAX URL:', wnqAnalytics.ajaxUrl);
        console.log('Client ID:', wnqAnalytics.clientId);
        
        showLoading();

        $.ajax({
            url: wnqAnalytics.ajaxUrl,
            type: 'POST',
            data: {
                action: 'wnq_get_analytics_data',
                nonce: wnqAnalytics.nonce,
                client_id: wnqAnalytics.clientId,
                date_range: dateRange
            },
            success: function(response) {
                console.log('AJAX Response:', response);
                
                if (response.success) {
                    console.log('Success! Rendering data...');
                    renderSimpleDashboard(response.data);
                    hideLoading();
                } else {
                    console.error('Error response:', response);
                    showError(response.data || 'Failed to load analytics data');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                console.error('Status:', status);
                console.error('Response:', xhr.responseText);
                showError('Network error: ' + error);
            },
            complete: function() {
                $('#wnq-refresh-data').prop('disabled', false).text('🔄 Refresh Data');
            }
        });
    }

    /**
     * Render simple dashboard (no charts, just tables)
     */
    function renderSimpleDashboard(data) {
        console.log('Rendering dashboard with data:', data);
        
        var html = '<div style="padding: 20px;">';
        
        // Overview Stats
        if (data.overview) {
            html += '<h2>📊 Overview Stats (Last ' + $('#wnq-date-range').val() + ' Days)</h2>';
            html += '<table class="wp-list-table widefat fixed striped" style="margin-bottom: 30px;">';
            html += '<thead><tr><th>Metric</th><th>Value</th><th>Change</th></tr></thead>';
            html += '<tbody>';
            
            html += '<tr><td><strong>Total Visitors</strong></td><td>' + formatNumber(data.overview.total_users.value) + '</td><td>' + formatChange(data.overview.total_users.change) + '</td></tr>';
            html += '<tr><td><strong>Page Views</strong></td><td>' + formatNumber(data.overview.page_views.value) + '</td><td>' + formatChange(data.overview.page_views.change) + '</td></tr>';
            html += '<tr><td><strong>Avg Session Duration</strong></td><td>' + data.overview.avg_session_duration.value + '</td><td>' + formatChange(data.overview.avg_session_duration.change) + '</td></tr>';
            html += '<tr><td><strong>Bounce Rate</strong></td><td>' + data.overview.bounce_rate.value + '%</td><td>' + formatChange(data.overview.bounce_rate.change) + '</td></tr>';
            
            html += '</tbody></table>';
        }
        
        // Traffic Sources
        if (data.traffic_sources && data.traffic_sources.length > 0) {
            html += '<h2>🌐 Traffic Sources</h2>';
            html += '<table class="wp-list-table widefat fixed striped" style="margin-bottom: 30px;">';
            html += '<thead><tr><th>Source</th><th>Sessions</th><th>Users</th><th>Bounce Rate</th></tr></thead>';
            html += '<tbody>';
            
            data.traffic_sources.forEach(function(source) {
                html += '<tr>';
                html += '<td><strong>' + escapeHtml(source.source) + '</strong> <span style="color: #666;">(' + source.percentage + '%)</span></td>';
                html += '<td>' + formatNumber(source.sessions) + '</td>';
                html += '<td>' + formatNumber(source.users) + '</td>';
                html += '<td>' + source.bounce_rate + '%</td>';
                html += '</tr>';
            });
            
            html += '</tbody></table>';
        }
        
        // Devices
        if (data.devices && data.devices.length > 0) {
            html += '<h2>📱 Device Breakdown</h2>';
            html += '<table class="wp-list-table widefat fixed striped" style="margin-bottom: 30px;">';
            html += '<thead><tr><th>Device</th><th>Sessions</th><th>Percentage</th></tr></thead>';
            html += '<tbody>';
            
            data.devices.forEach(function(device) {
                html += '<tr>';
                html += '<td><strong>' + escapeHtml(device.device) + '</strong></td>';
                html += '<td>' + formatNumber(device.sessions) + '</td>';
                html += '<td>' + device.percentage + '%</td>';
                html += '</tr>';
            });
            
            html += '</tbody></table>';
        }
        
        // Top Pages
        if (data.top_pages && data.top_pages.length > 0) {
            html += '<h2>📄 Top Pages</h2>';
            html += '<table class="wp-list-table widefat fixed striped" style="margin-bottom: 30px;">';
            html += '<thead><tr><th>Page</th><th>Views</th><th>Users</th><th>Avg Time</th><th>Bounce Rate</th></tr></thead>';
            html += '<tbody>';
            
            data.top_pages.forEach(function(page) {
                html += '<tr>';
                html += '<td><strong>' + escapeHtml(page.path) + '</strong><br><small style="color: #666;">' + escapeHtml(page.title) + '</small></td>';
                html += '<td>' + formatNumber(page.views) + '</td>';
                html += '<td>' + formatNumber(page.users) + '</td>';
                html += '<td>' + page.avg_time + '</td>';
                html += '<td>' + page.bounce_rate + '%</td>';
                html += '</tr>';
            });
            
            html += '</tbody></table>';
        }
        
        // Search Console
        if (data.search_console && !data.search_console.error) {
            html += '<h2>🔍 Search Console</h2>';
            html += '<table class="wp-list-table widefat fixed striped" style="margin-bottom: 30px;">';
            html += '<thead><tr><th>Metric</th><th>Value</th><th>Change</th></tr></thead>';
            html += '<tbody>';
            
            var sc = data.search_console.overview;
            html += '<tr><td><strong>Average Position</strong></td><td>' + sc.position.value + '</td><td>' + formatPositionChange(sc.position.change) + '</td></tr>';
            html += '<tr><td><strong>Total Clicks</strong></td><td>' + formatNumber(sc.clicks.value) + '</td><td>' + formatChange(sc.clicks.change) + '</td></tr>';
            html += '<tr><td><strong>Impressions</strong></td><td>' + formatNumber(sc.impressions.value) + '</td><td>' + formatChange(sc.impressions.change) + '</td></tr>';
            html += '<tr><td><strong>CTR</strong></td><td>' + sc.ctr.value + '%</td><td>' + formatChange(sc.ctr.change) + '</td></tr>';
            
            html += '</tbody></table>';
        } else if (data.search_console && data.search_console.error) {
            html += '<div class="notice notice-warning" style="padding: 10px; margin: 20px 0;"><p><strong>Search Console:</strong> ' + data.search_console.error + '</p></div>';
        }
        
        html += '</div>';
        
        // Display the content
        $('#wnq-analytics-content').html(html);
    }

    /**
     * Format change indicator
     */
    function formatChange(change) {
        if (!change || change.percentage === 0) {
            return '<span style="color: #666;">→ 0%</span>';
        }

        var arrow = change.direction === 'up' ? '↑' : '↓';
        var color = change.direction === 'up' ? 'green' : 'red';
        
        return '<span style="color: ' + color + ';">' + arrow + ' ' + change.percentage + '%</span>';
    }

    /**
     * Format position change (lower is better for SEO)
     */
    function formatPositionChange(change) {
        if (!change || change.difference === 0) {
            return '<span style="color: #666;">→ 0</span>';
        }

        var arrow = change.direction === 'up' ? '↑' : '↓';
        var color = change.direction === 'up' ? 'green' : 'red';
        
        return '<span style="color: ' + color + ';">' + arrow + ' ' + change.difference + '</span>';
    }

    /**
     * Format number with commas
     */
    function formatNumber(num) {
        if (num === null || num === undefined) return '0';
        return parseInt(num).toLocaleString();
    }

    /**
     * Escape HTML
     */
    function escapeHtml(text) {
        if (!text) return '';
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Show loading state
     */
    function showLoading() {
        $('#wnq-analytics-loading').show();
        $('#wnq-analytics-content').hide();
    }

    /**
     * Hide loading state
     */
    function hideLoading() {
        $('#wnq-analytics-loading').hide();
        $('#wnq-analytics-content').show();
    }

    /**
     * Show error message
     */
    function showError(message) {
        console.error('Showing error:', message);
        $('#wnq-analytics-loading').hide();
        $('#wnq-analytics-content').html(
            '<div class="notice notice-error" style="padding: 20px; margin: 20px;"><p><strong>Error:</strong> ' + escapeHtml(message) + '</p></div>'
        ).show();
    }

    /**
     * Initialize on document ready
     */
    $(document).ready(function() {
        console.log('Document ready!');
        console.log('Looking for #wnq-analytics-content...');
        
        if ($('#wnq-analytics-content').length) {
            console.log('Found analytics content div!');
            
            // Wait a moment for wnqAnalytics to be available
            setTimeout(function() {
                if (typeof wnqAnalytics !== 'undefined') {
                    console.log('wnqAnalytics is available:', wnqAnalytics);
                    initDashboard();
                } else {
                    console.error('wnqAnalytics still not available!');
                    showError('Configuration error: wnqAnalytics object not found');
                }
            }, 200);
        } else {
            console.log('Analytics content div not found - not on analytics page');
        }
    });

})(jQuery);