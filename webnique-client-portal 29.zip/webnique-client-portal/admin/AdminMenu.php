<?php

namespace WNQ\Admin;

if (!defined('ABSPATH')) { exit; }

final class AdminMenu
{
  public static function register(): void
  {
    add_action('admin_menu', [self::class, 'addMenu']);
  }

  public static function addMenu(): void
  {
    $cap = (current_user_can('wnq_manage_portal')) ? 'wnq_manage_portal' : 'manage_options';

    add_menu_page(
      'WebNique Portal',
      'WebNique Portal',
      $cap,
      'wnq-portal',
      [AdminSettings::class, 'render'],
      'dashicons-chart-area',
      58
    );

    add_submenu_page(
      'wnq-portal',
      'Settings',
      'Settings',
      $cap,
      'wnq-portal',
      [AdminSettings::class, 'render']
    );
  }
}
