// assets/app/modules/ui.js

export function el(tag, props = {}, children = []) {
  const node = document.createElement(tag);
  Object.entries(props).forEach(([k, v]) => {
    if (k === "class") node.className = v;
    else if (k === "html") node.innerHTML = v;
    else if (k === "text") node.textContent = v;
    else if (k === "style") Object.assign(node.style, v);
    else node.setAttribute(k, v);
  });
  children.forEach((c) => node.appendChild(c));
  return node;
}

export function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

export function pill(text, tone = "neutral") {
  const bg =
    tone === "good" ? "rgba(16,185,129,0.12)" :
    tone === "warn" ? "rgba(245,158,11,0.14)" :
    tone === "bad"  ? "rgba(239,68,68,0.12)" :
    "rgba(2,6,23,0.06)";

  const border =
    tone === "good" ? "rgba(16,185,129,0.28)" :
    tone === "warn" ? "rgba(245,158,11,0.28)" :
    tone === "bad"  ? "rgba(239,68,68,0.28)" :
    "rgba(2,6,23,0.10)";

  return el("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      padding: "6px 10px",
      borderRadius: "999px",
      background: bg,
      border: `1px solid ${border}`,
      fontSize: "12px",
      lineHeight: "12px",
      whiteSpace: "nowrap",
    },
    html: text,
  });
}

export function button(state, label, onClick, variant = "outline", disabled = false) {
  const base = {
    padding: "10px 14px",
    borderRadius: "12px",
    border: "1px solid rgba(2,6,23,0.12)",
    background: "white",
    cursor: disabled ? "not-allowed" : "pointer",
    fontWeight: 800,
    opacity: disabled ? 0.55 : 1,
    userSelect: "none",
  };

  const primaryOutline = {
    border: `1px solid rgba(13,83,158,0.30)`,
    color: state.primary,
  };

  const solid = {
    background: state.primary,
    border: `1px solid ${state.primary}`,
    color: "white",
  };

  const style =
    variant === "solid" ? { ...base, ...solid } :
    variant === "primary" ? { ...base, ...primaryOutline } :
    base;

  const btn = el("button", { type: "button", style });
  btn.textContent = label;

  if (disabled) btn.disabled = true;
  else btn.addEventListener("click", onClick);

  return btn;
}

function navButton(state, label, onClick) {
  // Sidebar nav item (full width, softer than your primary buttons)
  const btn = el("button", {
    type: "button",
    style: {
      width: "100%",
      textAlign: "left",
      padding: "10px 12px",
      borderRadius: "12px",
      border: "1px solid rgba(2,6,23,0.10)",
      background: "white",
      cursor: "pointer",
      fontWeight: 900,
      color: "#0f172a",
      userSelect: "none",
    },
    text: label,
  });

  btn.addEventListener("click", onClick);
  return btn;
}

export function renderJson(outEl, json) {
  outEl.innerHTML = "";
  outEl.appendChild(
    el("pre", {
      style: {
        whiteSpace: "pre-wrap",
        background: "rgba(2,6,23,0.04)",
        padding: "12px",
        borderRadius: "12px",
        maxHeight: "520px",
        overflow: "auto",
        border: "1px solid rgba(2,6,23,0.08)",
      },
      html: escapeHtml(JSON.stringify(json, null, 2)),
    })
  );
}

export function mountShell(root, state, { onTabChange }) {
  root.innerHTML = "";

  const wrap = el("div", {
    style: {
      fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif",
      color: "#0f172a",
      maxWidth: "1200px",
      margin: "0 auto",
      padding: "18px 14px",
    },
  });


  // ====== NEW: SHELL GRID (LEFT NAV + CONTENT) ======
  const shell = el("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "260px 1fr",
      gap: "14px",
      alignItems: "start",
    },
  });

  // Sidebar
  const sidebar = el("aside", {
    style: {
      border: "1px solid rgba(2,6,23,0.10)",
      borderRadius: "16px",
      background: "white",
      padding: "14px",
      position: "sticky",
      top: "14px",
    },
  });

  const sideTop = el("div", { style: { marginBottom: "12px" } });
  sideTop.appendChild(
    el("div", { text: "Navigation", style: { fontSize: "12px", letterSpacing: "0.08em", fontWeight: 900, color: "#64748b" } })
  );
  sideTop.appendChild(
    el("div", { text: "Portal", style: { fontSize: "18px", fontWeight: 900, marginTop: "6px" } })
  );
  sidebar.appendChild(sideTop);

  const nav = el("div", { style: { display: "flex", flexDirection: "column", gap: "10px" } });

  const tabs = [
    ["dashboard", "Dashboard"],
    ["subscription", "Subscription"],
    ["analytics", "Analytics"],
    ["requests", "Web Requests"],
    ["settings", "Settings"],
  ];

  const tabButtons = new Map();

  function setActiveTab(key) {
    tabButtons.forEach((btn, k) => {
      const active = k === key;

      btn.style.borderColor = active ? `rgba(13,83,158,0.35)` : "rgba(2,6,23,0.10)";
      btn.style.background = active ? "rgba(13,83,158,0.08)" : "white";
      btn.style.color = active ? state.primary : "#0f172a";
      btn.style.boxShadow = active ? "0 0 0 3px rgba(13,83,158,0.10)" : "none";
    });
  }

  tabs.forEach(([key, label]) => {
    const btn = navButton(state, label, () => onTabChange(key));
    tabButtons.set(key, btn);
    nav.appendChild(btn);
  });

  sidebar.appendChild(nav);

  // Optional: quick context in sidebar
  const sideMeta = el("div", { style: { marginTop: "14px", paddingTop: "14px", borderTop: "1px solid rgba(2,6,23,0.08)" } });
  sideMeta.appendChild(pill(`Client: <b>${state.clientId || "(none)"}</b>`));
  sideMeta.appendChild(el("div", { style: { height: "8px" } }));
  sideMeta.appendChild(pill(`Mode: <b>${state.mode || "(none)"}</b>`));
  sidebar.appendChild(sideMeta);

  // Content (main + side)
  const content = el("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(12, 1fr)",
      gap: "14px",
    },
  });

  const main = el("div", { style: { gridColumn: "span 8" } });
  const side = el("div", { style: { gridColumn: "span 4" } });

  const mainCard = el("div", {
    style: {
      border: "1px solid rgba(2,6,23,0.10)",
      borderRadius: "16px",
      padding: "16px",
      background: "white",
      minHeight: "520px",
    },
  });

  const sideCard = el("div", {
    style: {
      border: "1px solid rgba(2,6,23,0.10)",
      borderRadius: "16px",
      padding: "16px",
      background: "white",
    },
  });

  main.appendChild(mainCard);
  side.appendChild(sideCard);

  content.appendChild(main);
  content.appendChild(side);

  shell.appendChild(sidebar);
  shell.appendChild(content);
  wrap.appendChild(shell);
  root.appendChild(wrap);

  // Basic responsive behavior (no CSS file required)
  // - stack sidebar above content on small screens
  if (window && window.matchMedia) {
    const mq = window.matchMedia("(max-width: 960px)");
    const apply = () => {
      shell.style.gridTemplateColumns = mq.matches ? "1fr" : "260px 1fr";
      sidebar.style.position = mq.matches ? "relative" : "sticky";
      sidebar.style.top = mq.matches ? "auto" : "14px";
      main.style.gridColumn = mq.matches ? "span 12" : "span 8";
      side.style.gridColumn = mq.matches ? "span 12" : "span 4";
    };
    apply();
    mq.addEventListener?.("change", apply);
  }

  return {
    main: mainCard,
    side: sideCard,
    setActiveTab,
    statusPill,
  };
}
