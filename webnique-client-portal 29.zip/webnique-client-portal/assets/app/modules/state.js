// assets/app/modules/state.js
export function initAppState(root) {
  const clientId =
    root.getAttribute("data-client-id") ||
    window.WNQ_PORTAL?.clientId ||
    "";

  const mode =
    root.getAttribute("data-mode") ||
    (window.WNQ_PORTAL?.isAdmin ? "admin" : "client") ||
    "client";

  const restUrl = window.WNQ_PORTAL?.restUrl || "";
  const nonce = window.WNQ_PORTAL?.nonce || "";
  const isAdmin = !!window.WNQ_PORTAL?.isAdmin;

  return {
    // branding
    primary: "#0d539e",

    // wp context
    clientId,
    mode,
    isAdmin,

    // api
    restUrl,
    nonce,

    // client meta (sidebar)
    client: {
      name: "—",
      domain: "—",
      tier: "—",
    },
  };
}
