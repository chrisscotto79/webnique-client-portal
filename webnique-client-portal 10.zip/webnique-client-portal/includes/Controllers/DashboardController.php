<?php

namespace WNQ\Controllers;

use WNQ\Core\Permissions;
use WNQ\Services\FirebaseStore;

if (!defined('ABSPATH')) {
  exit;
}

final class DashboardController
{
  public static function registerRoutes(): void
  {
    /**
     * System ping (v1): proves REST + permissions + Firebase constants are working.
     * GET /wp-json/wnq/v1/ping
     */
    register_rest_route('wnq/v1', '/ping', [
      'methods'  => 'GET',
      'callback' => [self::class, 'ping'],
      'permission_callback' => function () {
        return is_user_logged_in();
       },

    ]);

    // Later we’ll add:
    // GET /wnq/v1/dashboard
    // GET /wnq/v1/dashboard/summary
    // etc.
  }

  public static function ping(\WP_REST_Request $request): \WP_REST_Response
  {
    $userId   = get_current_user_id();
    $clientId = Permissions::currentUserClientId();

    $firebase = new FirebaseStore();
    $firebasePing = $firebase->ping();

    return new \WP_REST_Response([
      'ok' => true,
      'wp' => [
        'user_id' => $userId,
        'is_logged_in' => true,
        'can_manage_portal' => Permissions::currentUserCanManagePortal(),
        'client_id' => $clientId,
      ],
      'firebase' => $firebasePing,
    ], 200);
  }
}
