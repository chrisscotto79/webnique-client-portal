<?php
/**
 * FirebaseStore (v1)
 *
 * This is intentionally minimal for v1 baby-steps.
 * It does NOT connect to Firebase yet.
 * It only validates that required credentials exist in wp-config.php and
 * normalizes the private key formatting for later use.
 */

namespace WNQ\Services;

if (!defined('ABSPATH')) {
  exit;
}

final class FirebaseStore
{
  private string $projectId;
  private string $clientEmail;
  private string $privateKey;

  public function __construct()
  {
    $this->projectId   = defined('WNQ_FIREBASE_PROJECT_ID') ? (string) WNQ_FIREBASE_PROJECT_ID : '';
    $this->clientEmail = defined('WNQ_FIREBASE_CLIENT_EMAIL') ? (string) WNQ_FIREBASE_CLIENT_EMAIL : '';
    $this->privateKey  = defined('WNQ_FIREBASE_PRIVATE_KEY') ? (string) WNQ_FIREBASE_PRIVATE_KEY : '';

    // Normalize private key formatting:
    // Sometimes the key is pasted with literal "\n" sequences.
    // Firebase libraries expect real newlines.
    if (strpos($this->privateKey, "\\n") !== false) {
      $this->privateKey = str_replace("\\n", "\n", $this->privateKey);
    }
  }

  /**
   * Returns true if the required Firebase constants exist and look sane.
   * This is NOT a network call.
   */
  public function ping(): array
  {
    $errors = [];

    if ($this->projectId === '') {
      $errors[] = 'Missing WNQ_FIREBASE_PROJECT_ID';
    }

    if ($this->clientEmail === '' || strpos($this->clientEmail, '@') === false) {
      $errors[] = 'Missing/invalid WNQ_FIREBASE_CLIENT_EMAIL';
    }

    if ($this->privateKey === '' || strpos($this->privateKey, 'BEGIN PRIVATE KEY') === false) {
      $errors[] = 'Missing/invalid WNQ_FIREBASE_PRIVATE_KEY';
    }

    return [
      'ok' => empty($errors),
      'errors' => $errors,
      'meta' => [
        'project_id_set' => ($this->projectId !== ''),
        'client_email_set' => ($this->clientEmail !== ''),
        'private_key_set' => ($this->privateKey !== ''),
      ],
    ];
  }

  /**
   * Returns the service account payload (for later Firebase SDK use).
   * Do not expose this to the browser.
   */
  public function getServiceAccount(): array
  {
    return [
      'type' => 'service_account',
      'project_id' => $this->projectId,
      'client_email' => $this->clientEmail,
      'private_key' => $this->privateKey,
    ];
  }

  public function getProjectId(): string
  {
    return $this->projectId;
  }
}
