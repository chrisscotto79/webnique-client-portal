<?php

namespace WNQ\Admin;

if (!defined('ABSPATH')) {
  exit;
}

final class AdminMenu
{
  public static function register(): void
  {
    add_menu_page(
      'WebNique Portal',
      'WebNique Portal',
      'wnq_manage_portal',
      'wnq-portal',
      [self::class, 'render'],
      'dashicons-chart-area',
      58
    );

    add_submenu_page(
      'wnq-portal',
      'Settings',
      'Settings',
      'wnq_manage_portal',
      'wnq-portal-settings',
      [AdminSettings::class, 'render']
    );
  }

  public static function render(): void
  {
    echo '<div class="wrap"><h1>WebNique Client Portal</h1><p>v1 bootstrap is active.</p></div>';
  }
}
