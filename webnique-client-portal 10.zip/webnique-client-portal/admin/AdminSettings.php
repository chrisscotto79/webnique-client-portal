<?php

namespace WNQ\Admin;

if (!defined('ABSPATH')) {
  exit;
}

final class AdminSettings
{
  public static function render(): void
  {
    echo '<div class="wrap"><h1>WebNique Portal Settings</h1>';
    echo '<p>v1 uses wp-config.php constants for Firebase. No settings here yet.</p>';
    echo '</div>';
  }
}
