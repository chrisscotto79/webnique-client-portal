<?php

namespace WNQ\PublicSite;

use WNQ\Core\Permissions;

if (!defined('ABSPATH')) {
  exit;
}

final class Shortcode
{
  public static function register(): void
  {
    add_shortcode('wnq_portal', [self::class, 'render']);
  }

  public static function render($atts = []): string
  {
    if (!Permissions::isLoggedIn()) {
      return '<p>You must be logged in to view this portal.</p>';
    }

    $clientId = Permissions::currentUserClientId();

    if ($clientId === null && !Permissions::currentUserCanManagePortal()) {
      return '<p>Your account is not linked to a client yet. Please contact WebNique.</p>';
    }

    self::enqueueAssets($clientId ?? '');

    $args = [
      'client_id' => $clientId ?? '',
      'mode' => Permissions::currentUserCanManagePortal() ? 'admin' : 'client',
    ];

    return \wnq_portal_shell_html($args);
  }

  private static function enqueueAssets(string $clientId): void
{
  $cssPath = WNQ_PORTAL_PATH . 'assets/app/app.css';
  $jsPath  = WNQ_PORTAL_PATH . 'assets/app/app.js';

  $cssVer = file_exists($cssPath) ? (string) filemtime($cssPath) : (defined('WNQ_PORTAL_VERSION') ? WNQ_PORTAL_VERSION : time());
  $jsVer  = file_exists($jsPath)  ? (string) filemtime($jsPath)  : (defined('WNQ_PORTAL_VERSION') ? WNQ_PORTAL_VERSION : time());

  wp_enqueue_style(
    'wnq-portal-app',
    WNQ_PORTAL_URL . 'assets/app/app.css',
    [],
    $cssVer
  );

  wp_enqueue_script(
    'wnq-portal-app',
    WNQ_PORTAL_URL . 'assets/app/app.js',
    [],
    $jsVer,
    true
  );

  wp_localize_script('wnq-portal-app', 'WNQ_PORTAL', [
    'restUrl'   => esc_url_raw(rest_url('wnq/v1')),
    'nonce'     => wp_create_nonce('wp_rest'),
    'clientId'  => $clientId,
    'isAdmin'   => current_user_can('wnq_manage_portal') || current_user_can('manage_options'),
  ]);
}

}
