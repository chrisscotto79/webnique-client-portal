<?php
/**
 * Plugin Name: WebNique Client Portal
 * Description: Private client dashboard portal for WebNique (SEO / Analytics / Subscription / Messaging).
 * Version: 0.1.0
 * Author: WebNique
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) {
  exit;
}

define('WNQ_PORTAL_VERSION', '0.1.0');
define('WNQ_PORTAL_PATH', plugin_dir_path(__FILE__));
define('WNQ_PORTAL_URL', plugin_dir_url(__FILE__));

require_once WNQ_PORTAL_PATH . 'includes/Core/Plugin.php';

register_activation_hook(__FILE__, ['WNQ\\Core\\Plugin', 'activate']);

add_action('plugins_loaded', function () {
  WNQ\Core\Plugin::init();
});
