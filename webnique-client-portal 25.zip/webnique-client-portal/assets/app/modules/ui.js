// assets/app/modules/ui.js

export function mountShell(root, state, { onTabChange }) {
  root.innerHTML = `
    <div class="wnq-shell">
      <aside class="wnq-sidebar">
        <div class="wnq-brand">
          <strong>WebNique</strong>
          <span class="wnq-client">${state.clientId}</span>
        </div>

        <nav class="wnq-nav">
          ${renderNavItem("dashboard", "Dashboard")}
          ${renderNavItem("subscription", "Subscription")}
          ${renderNavItem("analytics", "Analytics")}
          ${renderNavItem("requests", "Web Requests")}
          ${renderNavItem("settings", "Settings")}
        </nav>
      </aside>

      <main class="wnq-main">
        <div class="wnq-main-inner"></div>
      </main>
    </div>
  `;

  const main = root.querySelector(".wnq-main-inner");
  const navItems = root.querySelectorAll(".wnq-nav-item");

  navItems.forEach((item) => {
    item.addEventListener("click", () => {
      const key = item.dataset.key;
      onTabChange(key);
    });
  });

  return {
    main,
    setActiveTab(key) {
      navItems.forEach((el) =>
        el.classList.toggle("active", el.dataset.key === key)
      );
    },
  };
}

function renderNavItem(key, label) {
  return `
    <button class="wnq-nav-item" data-key="${key}">
      ${label}
    </button>
  `;
}
