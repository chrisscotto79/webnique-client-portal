<?php
/**
 * Plugin Name: WNQ Client Debug
 * Description: Debug helper - check status and create table
 * Version: 1.0
 */

// Show status in admin
add_action('admin_notices', function() {
    if (!current_user_can('manage_options')) return;
    
    global $wpdb;
    $table = $wpdb->prefix . 'wnq_clients';
    
    // Check if table exists
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
    
    echo '<div class="notice notice-info" style="padding: 20px;">';
    echo '<h2>WNQ Client System Status</h2>';
    
    // Table status
    if ($table_exists) {
        echo '<p>✅ Table exists: <code>' . $table . '</code></p>';
        
        // Count clients
        $count = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        echo '<p>📊 Total clients: <strong>' . $count . '</strong></p>';
        
        // Show clients
        if ($count > 0) {
            $clients = $wpdb->get_results("SELECT client_id, name, email, status FROM $table");
            echo '<table class="wp-list-table widefat" style="max-width: 800px;">';
            echo '<tr><th>Client ID</th><th>Name</th><th>Email</th><th>Status</th></tr>';
            foreach ($clients as $client) {
                echo '<tr>';
                echo '<td>' . esc_html($client->client_id) . '</td>';
                echo '<td>' . esc_html($client->name) . '</td>';
                echo '<td>' . esc_html($client->email) . '</td>';
                echo '<td>' . esc_html($client->status) . '</td>';
                echo '</tr>';
            }
            echo '</table>';
        }
    } else {
        echo '<p>❌ Table does NOT exist: <code>' . $table . '</code></p>';
        
        // Create table button
        if (isset($_GET['wnq_create_table'])) {
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            
            $sql = "CREATE TABLE $table (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                client_id varchar(100) NOT NULL,
                name varchar(255) NOT NULL,
                email varchar(255) NOT NULL,
                phone varchar(50) DEFAULT NULL,
                company varchar(255) DEFAULT NULL,
                website varchar(255) DEFAULT NULL,
                status varchar(50) DEFAULT 'active',
                tier varchar(50) DEFAULT 'website',
                google_analytics_property_id varchar(255) DEFAULT NULL,
                google_search_console_site_url varchar(255) DEFAULT NULL,
                google_api_credentials longtext DEFAULT NULL,
                facebook_access_token text DEFAULT NULL,
                other_api_keys longtext DEFAULT NULL,
                billing_email varchar(255) DEFAULT NULL,
                billing_cycle varchar(50) DEFAULT 'monthly',
                monthly_rate decimal(10,2) DEFAULT 0.00,
                active_services longtext DEFAULT NULL,
                notes longtext DEFAULT NULL,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY client_id (client_id),
                UNIQUE KEY email (email),
                KEY status (status)
            ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
            
            dbDelta($sql);
            
            echo '<p>✅ Table created! <a href="' . admin_url('admin.php?page=wnq-clients') . '">Refresh page</a></p>';
        } else {
            echo '<p><a href="' . add_query_arg('wnq_create_table', '1') . '" class="button button-primary">Create Table Now</a></p>';
        }
    }
    
    // Check form handlers
    echo '<hr>';
    echo '<h3>Form Handler Status</h3>';
    
    $save_handler = has_action('admin_post_wnq_save_client');
    $delete_handler = has_action('admin_post_wnq_delete_client');
    
    echo $save_handler ? '✅' : '❌';
    echo ' Save handler: <code>admin_post_wnq_save_client</code><br>';
    
    echo $delete_handler ? '✅' : '❌';
    echo ' Delete handler: <code>admin_post_wnq_delete_client</code><br>';
    
    echo '</div>';
});