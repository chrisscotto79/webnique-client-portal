<?php
/**
 * Clients Admin Page
 * 
 * Manage client accounts, API keys, and settings
 * 
 * @package WebNique Portal
 */

namespace WNQ\Admin;

use WNQ\Models\Client;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class ClientsAdmin
 * Admin interface for managing clients
 */
final class ClientsAdmin
{
    /**
     * Register admin page
     */
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addSubmenu'], 5);
        add_action('admin_post_wnq_save_client', [self::class, 'handleSaveClient']);
        add_action('admin_post_wnq_delete_client', [self::class, 'handleDeleteClient']);
    }

    /**
     * Add submenu page
     */
    public static function addSubmenu(): void
    {
        $capability = current_user_can('wnq_manage_portal') 
            ? 'wnq_manage_portal' 
            : 'manage_options';

        add_submenu_page(
            'wnq-portal',
            'Clients',
            'Clients',
            $capability,
            'wnq-clients',
            [self::class, 'render']
        );
    }

    /**
     * Render admin page
     */
    public static function render(): void
    {
        if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        // Handle actions
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';
        $client_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

        if ($action === 'edit' && $client_id) {
            self::renderEditForm($client_id);
            return;
        }

        if ($action === 'add') {
            self::renderAddForm();
            return;
        }

        // Default: Show clients list
        self::renderClientsList();
    }

    /**
     * Render clients list
     */
    private static function renderClientsList(): void
    {
        $clients = Client::getAll();
        $total_count = Client::getCount();
        $active_count = Client::getCountByStatus('active');
        $inactive_count = Client::getCountByStatus('inactive');

        ?>
        <div class="wrap wnq-clients-admin">
            <div class="wnq-header">
                <div>
                    <h1 class="wp-heading-inline">Clients</h1>
                    <p class="subtitle">Manage client accounts, API keys, and settings</p>
                </div>
                <a href="<?php echo admin_url('admin.php?page=wnq-clients&action=add'); ?>" class="page-title-action">
                    Add New Client
                </a>
            </div>

            <!-- Stats -->
            <div class="wnq-stats">
                <div class="stat-card">
                    <span class="stat-label">Total Clients</span>
                    <span class="stat-value"><?php echo $total_count; ?></span>
                </div>
                <div class="stat-card stat-success">
                    <span class="stat-label">Active</span>
                    <span class="stat-value"><?php echo $active_count; ?></span>
                </div>
                <div class="stat-card stat-warning">
                    <span class="stat-label">Inactive</span>
                    <span class="stat-value"><?php echo $inactive_count; ?></span>
                </div>
            </div>

            <!-- Clients Table -->
            <?php if (empty($clients)): ?>
                <div class="wnq-empty-state">
                    <div class="empty-icon">👥</div>
                    <h3>No Clients Yet</h3>
                    <p>Get started by adding your first client.</p>
                    <a href="<?php echo admin_url('admin.php?page=wnq-clients&action=add'); ?>" class="button button-primary button-hero">
                        Add Your First Client
                    </a>
                </div>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Client ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Company</th>
                            <th>Status</th>
                            <th>Tier</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($clients as $client): ?>
                            <tr>
                                <td><code><?php echo esc_html($client['client_id']); ?></code></td>
                                <td><strong><?php echo esc_html($client['name']); ?></strong></td>
                                <td><?php echo esc_html($client['email']); ?></td>
                                <td><?php echo esc_html($client['company'] ?: '—'); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo esc_attr($client['status']); ?>">
                                        <?php echo esc_html(ucfirst($client['status'])); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html(ucfirst($client['tier'])); ?></td>
                                <td><?php echo esc_html(date('M j, Y', strtotime($client['created_at']))); ?></td>
                                <td class="actions">
                                    <a href="<?php echo admin_url('admin.php?page=wnq-clients&action=edit&id=' . $client['id']); ?>" class="button button-small">
                                        Edit
                                    </a>
                                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                                        <?php wp_nonce_field('wnq_delete_client'); ?>
                                        <input type="hidden" name="action" value="wnq_delete_client">
                                        <input type="hidden" name="id" value="<?php echo esc_attr($client['id']); ?>">
                                        <button type="submit" class="button button-small button-link-delete" onclick="return confirm('Are you sure you want to delete this client?');">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <style>
        .wnq-clients-admin .wnq-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .wnq-clients-admin .subtitle {
            color: #646970;
            font-size: 14px;
            margin: 5px 0 0;
        }
        .wnq-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border: 1px solid #c3c4c7;
            border-radius: 4px;
            border-left: 4px solid #0d539e;
        }
        .stat-card.stat-success {
            border-left-color: #10b981;
        }
        .stat-card.stat-warning {
            border-left-color: #f59e0b;
        }
        .stat-label {
            display: block;
            font-size: 13px;
            color: #646970;
            margin-bottom: 8px;
        }
        .stat-value {
            display: block;
            font-size: 32px;
            font-weight: 700;
            color: #1e293b;
        }
        .status-badge {
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-badge.status-active {
            background: #d1fae5;
            color: #065f46;
        }
        .status-badge.status-inactive {
            background: #fee2e2;
            color: #991b1b;
        }
        .status-badge.status-pending {
            background: #fef3c7;
            color: #92400e;
        }
        .wnq-empty-state {
            background: white;
            padding: 60px 40px;
            text-align: center;
            border: 1px solid #c3c4c7;
            border-radius: 4px;
        }
        .empty-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        .wnq-empty-state h3 {
            font-size: 24px;
            margin-bottom: 10px;
        }
        .wnq-empty-state p {
            color: #646970;
            margin-bottom: 30px;
        }
        .actions {
            white-space: nowrap;
        }
        </style>
        <?php
    }

    /**
     * Render add form
     */
    private static function renderAddForm(): void
    {
        ?>
        <div class="wrap">
            <h1>Add New Client</h1>
            <?php self::renderClientForm(null); ?>
        </div>
        <?php
    }

    /**
     * Render edit form
     */
    private static function renderEditForm(int $id): void
    {
        $client = Client::getById($id);

        if (!$client) {
            wp_die('Client not found.');
        }

        ?>
        <div class="wrap">
            <h1>Edit Client: <?php echo esc_html($client['name']); ?></h1>
            <?php self::renderClientForm($client); ?>
        </div>
        <?php
    }

    /**
     * Render client form
     */
    private static function renderClientForm(?array $client): void
    {
        $is_edit = !empty($client);
        
        ?>
        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" class="wnq-client-form">
            <?php wp_nonce_field('wnq_save_client'); ?>
            <input type="hidden" name="action" value="wnq_save_client">
            <?php if ($is_edit): ?>
                <input type="hidden" name="id" value="<?php echo esc_attr($client['id']); ?>">
            <?php endif; ?>

            <div class="form-section">
                <h2>General Information</h2>
                <table class="form-table">
                    <tr>
                        <th><label for="client_id">Client ID *</label></th>
                        <td>
                            <?php if ($is_edit): ?>
                                <input type="text" name="client_id" id="client_id" value="<?php echo esc_attr($client['client_id']); ?>" class="regular-text" readonly>
                                <p class="description">Client ID cannot be changed after creation.</p>
                            <?php else: ?>
                                <input type="text" name="client_id" id="client_id" value="" class="regular-text" required placeholder="e.g., acme-corp">
                                <p class="description">Unique identifier for this client (lowercase, no spaces).</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="name">Name *</label></th>
                        <td>
                            <input type="text" name="name" id="name" value="<?php echo esc_attr($client['name'] ?? ''); ?>" class="regular-text" required>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="email">Email *</label></th>
                        <td>
                            <input type="email" name="email" id="email" value="<?php echo esc_attr($client['email'] ?? ''); ?>" class="regular-text" required>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="phone">Phone</label></th>
                        <td>
                            <input type="text" name="phone" id="phone" value="<?php echo esc_attr($client['phone'] ?? ''); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="company">Company</label></th>
                        <td>
                            <input type="text" name="company" id="company" value="<?php echo esc_attr($client['company'] ?? ''); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="website">Website</label></th>
                        <td>
                            <input type="url" name="website" id="website" value="<?php echo esc_attr($client['website'] ?? ''); ?>" class="regular-text" placeholder="https://example.com">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="status">Status</label></th>
                        <td>
                            <select name="status" id="status">
                                <option value="active" <?php selected($client['status'] ?? 'active', 'active'); ?>>Active</option>
                                <option value="inactive" <?php selected($client['status'] ?? '', 'inactive'); ?>>Inactive</option>
                                <option value="pending" <?php selected($client['status'] ?? '', 'pending'); ?>>Pending</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="tier">Tier</label></th>
                        <td>
                            <select name="tier" id="tier">
                                <option value="website" <?php selected($client['tier'] ?? 'website', 'website'); ?>>Website</option>
                                <option value="website-seo" <?php selected($client['tier'] ?? '', 'website-seo'); ?>>Website + SEO</option>
                                <option value="website-ppc" <?php selected($client['tier'] ?? '', 'website-ppc'); ?>>Website + PPC</option>
                                <option value="website-seo-ppc" <?php selected($client['tier'] ?? '', 'website-seo-ppc'); ?>>Website + SEO + PPC</option>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="form-section">
                <h2>Google Analytics</h2>
                <table class="form-table">
                    <tr>
                        <th><label for="google_analytics_property_id">Property ID</label></th>
                        <td>
                            <input type="text" name="google_analytics_property_id" id="google_analytics_property_id" value="<?php echo esc_attr($client['google_analytics_property_id'] ?? ''); ?>" class="regular-text" placeholder="123456789">
                            <p class="description">GA4 Property ID (found in Admin → Property Settings)</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="google_api_credentials">Google API Credentials (JSON)</label></th>
                        <td>
                            <textarea name="google_api_credentials" id="google_api_credentials" rows="6" class="large-text code" placeholder='{"type": "service_account", ...}'><?php echo esc_textarea($client['google_api_credentials'] ?? ''); ?></textarea>
                            <p class="description">Paste the entire service account JSON from Google Cloud Console</p>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="form-section">
                <h2>Google Search Console</h2>
                <table class="form-table">
                    <tr>
                        <th><label for="google_search_console_site_url">Site URL</label></th>
                        <td>
                            <input type="url" name="google_search_console_site_url" id="google_search_console_site_url" value="<?php echo esc_attr($client['google_search_console_site_url'] ?? ''); ?>" class="regular-text" placeholder="https://example.com">
                        </td>
                    </tr>
                </table>
            </div>

            <div class="form-section">
                <h2>Facebook/Meta</h2>
                <table class="form-table">
                    <tr>
                        <th><label for="facebook_access_token">Access Token</label></th>
                        <td>
                            <input type="text" name="facebook_access_token" id="facebook_access_token" value="<?php echo esc_attr($client['facebook_access_token'] ?? ''); ?>" class="large-text">
                        </td>
                    </tr>
                </table>
            </div>

            <div class="form-section">
                <h2>Billing</h2>
                <table class="form-table">
                    <tr>
                        <th><label for="billing_email">Billing Email</label></th>
                        <td>
                            <input type="email" name="billing_email" id="billing_email" value="<?php echo esc_attr($client['billing_email'] ?? ''); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="billing_cycle">Billing Cycle</label></th>
                        <td>
                            <select name="billing_cycle" id="billing_cycle">
                                <option value="monthly" <?php selected($client['billing_cycle'] ?? 'monthly', 'monthly'); ?>>Monthly</option>
                                <option value="quarterly" <?php selected($client['billing_cycle'] ?? '', 'quarterly'); ?>>Quarterly</option>
                                <option value="annually" <?php selected($client['billing_cycle'] ?? '', 'annually'); ?>>Annually</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="monthly_rate">Monthly Rate</label></th>
                        <td>
                            $<input type="number" name="monthly_rate" id="monthly_rate" value="<?php echo esc_attr($client['monthly_rate'] ?? '0.00'); ?>" step="0.01" min="0" class="small-text">
                        </td>
                    </tr>
                </table>
            </div>

            <div class="form-section">
                <h2>Notes</h2>
                <table class="form-table">
                    <tr>
                        <th><label for="notes">Internal Notes</label></th>
                        <td>
                            <textarea name="notes" id="notes" rows="5" class="large-text"><?php echo esc_textarea($client['notes'] ?? ''); ?></textarea>
                            <p class="description">Internal notes (not visible to client)</p>
                        </td>
                    </tr>
                </table>
            </div>

            <p class="submit">
                <button type="submit" class="button button-primary button-large">
                    <?php echo $is_edit ? 'Update Client' : 'Create Client'; ?>
                </button>
                <a href="<?php echo admin_url('admin.php?page=wnq-clients'); ?>" class="button button-large">Cancel</a>
            </p>
        </form>

        <style>
        .wnq-client-form .form-section {
            background: white;
            padding: 20px;
            margin-bottom: 20px;
            border: 1px solid #c3c4c7;
            border-radius: 4px;
        }
        .wnq-client-form .form-section h2 {
            margin-top: 0;
            padding-bottom: 10px;
            border-bottom: 1px solid #dcdcde;
        }
        </style>
        <?php
    }

    /**
     * Handle save client
     */
    public static function handleSaveClient(): void
    {
        check_admin_referer('wnq_save_client');

        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;

        $data = [
            'name' => sanitize_text_field($_POST['name'] ?? ''),
            'email' => sanitize_email($_POST['email'] ?? ''),
            'phone' => sanitize_text_field($_POST['phone'] ?? ''),
            'company' => sanitize_text_field($_POST['company'] ?? ''),
            'website' => esc_url_raw($_POST['website'] ?? ''),
            'status' => sanitize_text_field($_POST['status'] ?? 'active'),
            'tier' => sanitize_text_field($_POST['tier'] ?? 'standard'),
            'google_analytics_property_id' => sanitize_text_field($_POST['google_analytics_property_id'] ?? ''),
            'google_search_console_site_url' => esc_url_raw($_POST['google_search_console_site_url'] ?? ''),
            'google_api_credentials' => sanitize_textarea_field($_POST['google_api_credentials'] ?? ''),
            'facebook_access_token' => sanitize_text_field($_POST['facebook_access_token'] ?? ''),
            'billing_email' => sanitize_email($_POST['billing_email'] ?? ''),
            'billing_cycle' => sanitize_text_field($_POST['billing_cycle'] ?? 'monthly'),
            'monthly_rate' => floatval($_POST['monthly_rate'] ?? 0),
            'notes' => wp_kses_post($_POST['notes'] ?? ''),
        ];

        if ($id) {
            // Update
            $success = Client::update($id, $data);
            $message = $success ? 'Client updated successfully' : 'Failed to update client';
        } else {
            // Create
            $data['client_id'] = sanitize_text_field($_POST['client_id'] ?? '');
            $success = Client::create($data);
            $message = $success ? 'Client created successfully' : 'Failed to create client';
        }

        wp_redirect(add_query_arg([
            'page' => 'wnq-clients',
            'message' => $success ? 'success' : 'error'
        ], admin_url('admin.php')));
        exit;
    }

    /**
     * Handle delete client
     */
    public static function handleDeleteClient(): void
    {
        check_admin_referer('wnq_delete_client');

        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;

        $success = Client::delete($id);

        wp_redirect(add_query_arg([
            'page' => 'wnq-clients',
            'message' => $success ? 'deleted' : 'error'
        ], admin_url('admin.php')));
        exit;
    }
}