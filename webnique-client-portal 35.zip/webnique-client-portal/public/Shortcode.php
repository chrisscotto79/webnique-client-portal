<?php
/**
 * Public Shortcode Handler
 *
 * @package WebNique Portal
 */

namespace WNQ\PublicSite;

use WNQ\Core\Permissions;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Shortcode
 * Handles the [wnq_portal] shortcode rendering
 */
final class Shortcode
{
    /**
     * Register the shortcode
     */
    public static function register(): void
    {
        add_shortcode('wnq_portal', [self::class, 'render']);
    }

    /**
     * Render the portal shortcode
     *
     * @param array $atts Shortcode attributes
     * @return string Rendered HTML output
     */
    public static function render($atts = []): string
    {
        // Check if user is logged in
        if (!Permissions::isLoggedIn()) {
            return self::renderLoginMessage();
        }

        // Get current user's client ID
        $clientId  = Permissions::currentUserClientId();
        $canManage = Permissions::currentUserCanManagePortal();

        // Check if user has access
        if ($clientId === null && !$canManage) {
            return self::renderNoAccessMessage();
        }

        // Enqueue frontend assets
        self::enqueueAssets($clientId ?? '');

        // Prepare shell args
        $args = [
            'client_id' => $clientId ?? '',
            'mode'      => $canManage ? 'admin' : 'client',
            'user_id'   => get_current_user_id(),
        ];

        // Render portal shell
        return self::renderPortalShell($args);
    }

    /**
     * Render login required message
     */
    private static function renderLoginMessage(): string
    {
        $loginUrl = wp_login_url(get_permalink());

        return sprintf(
            '<div class="wnq-portal-notice wnq-portal-notice--info">
                <p>%s <a href="%s">%s</a></p>
            </div>',
            esc_html__('You must be logged in to view this portal.', 'webnique-portal'),
            esc_url($loginUrl),
            esc_html__('Log in here', 'webnique-portal')
        );
    }

    /**
     * Render no access message
     */
    private static function renderNoAccessMessage(): string
    {
        return sprintf(
            '<div class="wnq-portal-notice wnq-portal-notice--warning">
                <p>%s</p>
            </div>',
            esc_html__('Your account is not linked to a client yet. Please contact WebNique for access.', 'webnique-portal')
        );
    }

    /**
     * Enqueue frontend assets and localize config
     */
    private static function enqueueAssets(string $clientId): void
    {
        $version = defined('WNQ_PORTAL_VERSION') ? WNQ_PORTAL_VERSION : time();

        // CSS
        wp_enqueue_style(
            'wnq-portal-app',
            WNQ_PORTAL_URL . 'assets/app/app.css',
            [],
            $version
        );

        // JS (ES module)
        wp_enqueue_script(
            'wnq-portal-app',
            WNQ_PORTAL_URL . 'assets/app/app.js',
            [],
            $version,
            true
        );

        // Mark script as ES module
        add_filter('script_loader_tag', function ($tag, $handle, $src) {
            if ($handle !== 'wnq-portal-app') {
                return $tag;
            }
            return '<script type="module" src="' . esc_url($src) . '"></script>';
        }, 10, 3);

        // Portal config
        wp_localize_script('wnq-portal-app', 'WNQ_PORTAL', [
            'restUrl'  => esc_url_raw(rest_url('wnq/v1')),
            'nonce'    => wp_create_nonce('wp_rest'),
            'clientId' => $clientId,
            'isAdmin'  => current_user_can('wnq_manage_portal') || current_user_can('manage_options'),
            'userId'   => get_current_user_id(),
            'ajaxUrl'  => admin_url('admin-ajax.php'),
        ]);

        /**
         * 🔥 Firebase Configuration
         * Option A: Pull from wp_options (recommended for prod)
         */
        wp_localize_script('wnq-portal-app', 'WNQ_FIREBASE_CONFIG', [
            'apiKey'            => get_option('wnq_firebase_api_key', ''),
            'authDomain'        => get_option('wnq_firebase_auth_domain', ''),
            'projectId'         => get_option('wnq_firebase_project_id', ''),
            'storageBucket'     => get_option('wnq_firebase_storage_bucket', ''),
            'messagingSenderId' => get_option('wnq_firebase_messaging_sender_id', ''),
            'appId'             => get_option('wnq_firebase_app_id', ''),
        ]);

        /**
         * Option B (DEV ONLY): Hardcode Firebase config
         * Uncomment to use
         */
        /*
        wp_localize_script('wnq-portal-app', 'WNQ_FIREBASE_CONFIG', [
            'apiKey'            => 'YOUR_API_KEY',
            'authDomain'        => 'your-project.firebaseapp.com',
            'projectId'         => 'your-project-id',
            'storageBucket'     => 'your-project.appspot.com',
            'messagingSenderId' => '123456789',
            'appId'             => '1:123456789:web:abc123',
        ]);
        */
    }

    /**
     * Render portal shell HTML
     */
    private static function renderPortalShell(array $args): string
    {
        if (!function_exists('wnq_portal_shell_html')) {
            return '<div class="wnq-portal-notice wnq-portal-notice--error">
                <p>' . esc_html__('Portal shell function not found.', 'webnique-portal') . '</p>
            </div>';
        }

        return wnq_portal_shell_html($args);
    }
}
