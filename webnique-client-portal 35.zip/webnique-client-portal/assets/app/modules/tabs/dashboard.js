// assets/app/modules/tabs/dashboard.js
/**
 * Dashboard Tab - Executive Summary
 * 
 * Shows: Account status, KPIs, Recent activity, Quick actions
 * Data: Firestore via REST API
 */

import { el, pill, button, escapeHtml } from "../ui.js";

export function renderDashboard(main, side, state, shell) {
  main.innerHTML = "";
  side.innerHTML = "";

  // Update shell status
  if (shell?.setStatus) {
    shell.setStatus("Loading dashboard...", "neutral");
  }

  // ========================================
  // HEADER
  // ========================================
  const header = createHeader();
  main.appendChild(header);

  // ========================================
  // LOAD DATA
  // ========================================
  loadDashboardData(state).then((data) => {
    if (!data.success) {
      showError(main, data.error || "Failed to load dashboard");
      if (shell?.setStatus) {
        shell.setStatus("Error", "bad");
      }
      return;
    }

    // Update status
    if (shell?.setStatus) {
      shell.setStatus("Ready", "good");
    }

    // Render KPI cards
    main.appendChild(createKPICards(data.kpis || {}));

    // Render recent activity
    main.appendChild(createRecentActivity(data.activity || []));

    // Render quick actions
    main.appendChild(createQuickActions(state));

    // Render sidebar widgets
    renderSidebar(side, state, data.client || {});
  });
}

/**
 * Create header section
 */
function createHeader() {
  const header = el("div", {
    style: {
      marginBottom: "32px",
      paddingBottom: "20px",
      borderBottom: "2px solid rgba(2,6,23,0.08)",
    },
  });

  header.appendChild(
    el("h1", {
      text: "Dashboard",
      style: {
        fontSize: "32px",
        fontWeight: "900",
        color: "#111827",
        marginBottom: "8px",
        letterSpacing: "-0.02em",
      },
    })
  );

  header.appendChild(
    el("p", {
      text: "Welcome back! Here's an overview of your account.",
      style: {
        fontSize: "16px",
        color: "#6b7280",
        margin: "0",
      },
    })
  );

  return header;
}

/**
 * Load dashboard data from API
 */
async function loadDashboardData(state) {
  try {
    // Parallel requests for better performance
    const [clientRes, activityRes] = await Promise.all([
      state.actions?.get?.("/client") || Promise.resolve({ ok: false }),
      state.actions?.get?.("/activity") || Promise.resolve({ ok: false }),
    ]);

    if (!clientRes.ok) {
      return { success: false, error: "Failed to load client data" };
    }

    return {
      success: true,
      client: clientRes.data || {},
      kpis: {
        activeServices: clientRes.data?.active_services || 0,
        openRequests: clientRes.data?.open_requests || 0,
        visits: clientRes.data?.visits_30d || "0",
        conversionTrend: clientRes.data?.conversion_trend || "+0%",
      },
      activity: activityRes.ok ? activityRes.data || [] : [],
    };
  } catch (error) {
    console.error("[Dashboard] Load error:", error);
    return { success: false, error: error.message };
  }
}

/**
 * Create KPI cards section
 */
function createKPICards(kpis) {
  const section = el("div", { style: { marginBottom: "32px" } });

  const grid = el("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
      gap: "16px",
    },
  });

  const cards = [
    {
      label: "Active Services",
      value: kpis.activeServices?.toString() || "0",
      change: "+2 this month",
      icon: "🚀",
      color: "#10b981",
    },
    {
      label: "Open Requests",
      value: kpis.openRequests?.toString() || "0",
      change: "Pending review",
      icon: "📝",
      color: "#f59e0b",
    },
    {
      label: "Visits (30d)",
      value: kpis.visits || "0",
      change: kpis.conversionTrend || "+0%",
      icon: "📊",
      color: "#0d539e",
    },
  ];

  cards.forEach((card) => {
    grid.appendChild(createKPICard(card));
  });

  section.appendChild(grid);
  return section;
}

/**
 * Create individual KPI card
 */
function createKPICard({ label, value, change, icon, color }) {
  const card = el("div", {
    class: "wnq-card",
    style: {
      padding: "24px",
      cursor: "default",
      transition: "all 0.2s ease",
    },
  });

  // Hover effect
  card.addEventListener("mouseenter", () => {
    card.style.transform = "translateY(-2px)";
    card.style.boxShadow = "0 8px 16px rgba(0,0,0,0.1)";
  });
  card.addEventListener("mouseleave", () => {
    card.style.transform = "translateY(0)";
    card.style.boxShadow = "";
  });

  // Icon
  card.appendChild(
    el("div", {
      text: icon,
      style: {
        fontSize: "32px",
        marginBottom: "12px",
      },
    })
  );

  // Label
  card.appendChild(
    el("div", {
      text: label,
      style: {
        fontSize: "13px",
        fontWeight: "600",
        color: "#6b7280",
        textTransform: "uppercase",
        letterSpacing: "0.05em",
        marginBottom: "8px",
      },
    })
  );

  // Value
  card.appendChild(
    el("div", {
      text: value,
      style: {
        fontSize: "36px",
        fontWeight: "900",
        color: "#111827",
        marginBottom: "8px",
        lineHeight: "1",
      },
    })
  );

  // Change indicator
  card.appendChild(
    el("div", {
      text: change,
      style: {
        fontSize: "14px",
        color: color,
        fontWeight: "600",
      },
    })
  );

  return card;
}

/**
 * Create recent activity section
 */
function createRecentActivity(activities) {
  const section = el("div", { style: { marginBottom: "32px" } });

  section.appendChild(
    el("h2", {
      text: "Recent Activity",
      style: {
        fontSize: "20px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "16px",
      },
    })
  );

  const card = el("div", { class: "wnq-card" });

  if (!activities || activities.length === 0) {
    card.appendChild(
      el("p", {
        text: "No recent activity to display.",
        style: { color: "#6b7280", textAlign: "center", padding: "20px 0" },
      })
    );
  } else {
    activities.slice(0, 5).forEach((activity, index) => {
      card.appendChild(createActivityItem(activity, index < activities.length - 1));
    });
  }

  section.appendChild(card);
  return section;
}

/**
 * Create activity item
 */
function createActivityItem(activity, showBorder) {
  const item = el("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "16px",
      padding: "16px 0",
      borderBottom: showBorder ? "1px solid #e5e7eb" : "none",
    },
  });

  // Icon
  const iconMap = {
    report: "📊",
    request: "💬",
    invoice: "💳",
    subscription: "🔄",
    default: "📌",
  };

  item.appendChild(
    el("div", {
      text: iconMap[activity.type] || iconMap.default,
      style: {
        fontSize: "24px",
        width: "48px",
        height: "48px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#f3f4f6",
        borderRadius: "12px",
      },
    })
  );

  // Content
  const content = el("div", { style: { flex: "1" } });
  
  content.appendChild(
    el("div", {
      text: escapeHtml(activity.title || "Activity"),
      style: {
        fontSize: "15px",
        fontWeight: "600",
        color: "#111827",
        marginBottom: "4px",
      },
    })
  );

  content.appendChild(
    el("div", {
      text: formatActivityTime(activity.timestamp),
      style: {
        fontSize: "13px",
        color: "#6b7280",
      },
    })
  );

  item.appendChild(content);

  // Status
  if (activity.status) {
    item.appendChild(
      pill(
        escapeHtml(activity.status),
        activity.status === "completed" ? "good" : "neutral"
      )
    );
  }

  return item;
}

/**
 * Format activity timestamp
 */
function formatActivityTime(timestamp) {
  if (!timestamp) return "Recently";
  
  try {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    
    if (diffHours < 1) return "Just now";
    if (diffHours < 24) return `${diffHours} hours ago`;
    if (diffHours < 48) return "Yesterday";
    
    return date.toLocaleDateString();
  } catch (e) {
    return "Recently";
  }
}

/**
 * Create quick actions section
 */
function createQuickActions(state) {
  const section = el("div", {});

  section.appendChild(
    el("h2", {
      text: "Quick Actions",
      style: {
        fontSize: "20px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "16px",
      },
    })
  );

  const grid = el("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
      gap: "12px",
    },
  });

  const actions = [
    { label: "View Reports", icon: "📈", tab: "analytics" },
    { label: "New Request", icon: "➕", tab: "requests" },
    { label: "View Invoices", icon: "🧾", tab: "subscription" },
    { label: "Settings", icon: "⚙️", tab: "settings" },
  ];

  actions.forEach((action) => {
    const btn = button(
      state,
      `${action.icon} ${action.label}`,
      () => {
        // TODO: Navigate to tab when routing is implemented
        console.log(`Navigate to ${action.tab}`);
      },
      "outline"
    );

    btn.style.padding = "16px";
    btn.style.fontSize = "14px";
    btn.style.textAlign = "center";
    btn.style.justifyContent = "center";

    grid.appendChild(btn);
  });

  section.appendChild(grid);
  return section;
}

/**
 * Render sidebar content
 */
function renderSidebar(side, state, client) {
  // Account overview card
  const accountCard = el("div", {
    style: {
      background: "linear-gradient(135deg, #0d539e 0%, #0a4380 100%)",
      borderRadius: "16px",
      padding: "24px",
      color: "white",
      marginBottom: "20px",
    },
  });

  accountCard.appendChild(
    el("div", {
      text: "ACCOUNT STATUS",
      style: {
        fontSize: "11px",
        fontWeight: "700",
        letterSpacing: "0.1em",
        opacity: "0.8",
        marginBottom: "12px",
      },
    })
  );

  accountCard.appendChild(
    el("div", {
      text: escapeHtml(client.status || "Active"),
      style: {
        fontSize: "28px",
        fontWeight: "900",
        marginBottom: "16px",
      },
    })
  );

  const details = [
    { label: "Plan", value: client.tier || "Standard" },
    { label: "Support", value: client.support_level || "Standard" },
    { label: "Since", value: formatJoinDate(client.created_at) },
  ];

  details.forEach((detail) => {
    const row = el("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        padding: "8px 0",
        borderTop: "1px solid rgba(255,255,255,0.1)",
        fontSize: "13px",
      },
    });

    row.appendChild(
      el("span", { text: detail.label, style: { opacity: "0.8" } })
    );
    row.appendChild(
      el("span", { 
        text: escapeHtml(detail.value), 
        style: { fontWeight: "600" } 
      })
    );

    accountCard.appendChild(row);
  });

  side.appendChild(accountCard);

  // Support widget
  side.appendChild(createSupportWidget(state));
}

/**
 * Create support widget
 */
function createSupportWidget(state) {
  const card = el("div", {
    style: {
      background: "#fef3c7",
      border: "1px solid #fde047",
      borderRadius: "16px",
      padding: "20px",
    },
  });

  card.appendChild(
    el("div", {
      text: "💬",
      style: { fontSize: "32px", marginBottom: "12px" },
    })
  );

  card.appendChild(
    el("h3", {
      text: "Need Help?",
      style: {
        fontSize: "16px",
        fontWeight: "800",
        color: "#78350f",
        marginBottom: "8px",
      },
    })
  );

  card.appendChild(
    el("p", {
      text: "Our support team is here to help you.",
      style: {
        fontSize: "13px",
        color: "#92400e",
        marginBottom: "12px",
        lineHeight: "1.5",
      },
    })
  );

  const btn = button(
    state,
    "Contact Support",
    () => {
      // TODO: Navigate to requests tab
      console.log("Opening support...");
    },
    "solid"
  );

  btn.style.width = "100%";
  btn.style.background = "#f59e0b";
  btn.style.borderColor = "#f59e0b";

  card.appendChild(btn);
  return card;
}

/**
 * Format join date
 */
function formatJoinDate(timestamp) {
  if (!timestamp) return "N/A";
  
  try {
    const date = new Date(timestamp);
    return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
  } catch (e) {
    return "N/A";
  }
}

/**
 * Show error message
 */
function showError(container, message) {
  container.innerHTML = "";
  container.appendChild(
    el("div", {
      class: "wnq-alert wnq-alert-danger",
      html: `<strong>Error:</strong> ${escapeHtml(message)}`,
    })
  );
}