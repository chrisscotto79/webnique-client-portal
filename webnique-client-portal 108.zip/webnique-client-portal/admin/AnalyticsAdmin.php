<?php
/**
 * Analytics Admin - WITH GOOGLE SEARCH CONSOLE - FIXED
 * 
 * Features:
 * - GA4 Analytics (visitors, sessions, traffic sources)
 * - Google Search Console (impressions, clicks, CTR, position)
 * - Multi-client management
 * - Edit client settings
 * 
 * FIX: Changed esc_url_raw to sanitize_text_field for search_console_url
 */

namespace WNQ\Admin;

use WNQ\Models\AnalyticsConfig;

if (!defined('ABSPATH')) exit;

final class AnalyticsAdmin
{
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addSubmenu'], 20);
        add_action('admin_enqueue_scripts', [self::class, 'enqueueAssets'], 999);
    }

    public static function addSubmenu(): void
    {
        $capability = current_user_can('wnq_manage_portal') ? 'wnq_manage_portal' : 'manage_options';
        add_submenu_page('wnq-portal', 'Analytics', 'Analytics', $capability, 'wnq-analytics', [self::class, 'render']);
    }

    public static function enqueueAssets($hook): void
    {
        if (!isset($_GET['page']) || $_GET['page'] !== 'wnq-analytics') return;
        wp_enqueue_script('jquery');
    }

    public static function render(): void
    {
        if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions.'));
        }

        $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : 'dashboard';
        
        switch ($view) {
            case 'settings':
                self::renderSettings();
                break;
            case 'clients':
                self::renderClientsManager();
                break;
            case 'edit-client':
                self::renderEditClient();
                break;
            default:
                self::renderDashboard();
                break;
        }
    }

    // ============================================
    // DASHBOARD
    // ============================================
    
    private static function renderDashboard(): void
    {
        $all_clients = AnalyticsConfig::getAllClients();
        $current_client_id = isset($_GET['client']) ? sanitize_text_field($_GET['client']) : '';
        
        if (empty($current_client_id) && !empty($all_clients)) {
            $current_client_id = $all_clients[0]['client_id'];
        }
        
        $config = $current_client_id ? AnalyticsConfig::getClientConfig($current_client_id) : null;
        $credentials = AnalyticsConfig::getCredentials();

        ?>
        <div class="wrap wnq-analytics-wrap">
            <h1>📊 Analytics Dashboard</h1>
            
            <?php if (empty($all_clients)): ?>
                <div class="notice notice-warning"><p><strong>No clients configured.</strong> <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=clients'); ?>">Add your first client →</a></p></div>
                <?php return; ?>
            <?php endif; ?>

            <?php if (!$credentials): ?>
                <div class="notice notice-error"><p><strong>⚠️ Service account not configured.</strong> <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=settings'); ?>">Configure now →</a></p></div>
                <?php return; ?>
            <?php endif; ?>

            <div class="wnq-analytics-header">
                <div class="wnq-client-selector">
                    <label><strong>Select Client:</strong></label>
                    <select id="client-selector">
                        <?php foreach ($all_clients as $client): ?>
                            <option value="<?php echo esc_attr($client['client_id']); ?>" <?php selected($client['client_id'], $current_client_id); ?>>
                                <?php echo esc_html($client['client_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=clients'); ?>" class="button">👥 Manage Clients</a>
                    <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=settings'); ?>" class="button">⚙️ Settings</a>
                </div>
            </div>

            <?php if ($config): ?>
                <div class="wnq-client-info">
                    <h3>📍 <?php echo esc_html($config['client_name']); ?></h3>
                    <ul>
                        <li><strong>Website:</strong> <?php echo esc_html($config['website_url']); ?></li>
                        <li><strong>GA4:</strong> <code><?php echo esc_html($config['ga4_property_id']); ?></code></li>
                        <?php if (!empty($config['search_console_url'])): ?>
                            <li><strong>Search Console:</strong> <code><?php echo esc_html($config['search_console_url']); ?></code></li>
                        <?php endif; ?>
                    </ul>
                </div>

                <div class="wnq-data-controls">
                    <button type="button" id="wnq-refresh-data" class="button button-primary">🔄 Refresh Data</button>
                    <select id="wnq-date-range">
                        <option value="7">Last 7 Days</option>
                        <option value="30" selected>Last 30 Days</option>
                        <option value="90">Last 90 Days</option>
                    </select>
                </div>

                <div id="wnq-analytics-loading" class="wnq-loading"><p>⏳ Loading analytics data...</p></div>
                <div id="wnq-analytics-content" style="display: none;"></div>
            <?php endif; ?>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
        
        <script>
        window.wnqAnalytics = {
            ajaxUrl: '<?php echo admin_url('admin-ajax.php'); ?>',
            nonce: '<?php echo wp_create_nonce('wnq_analytics_nonce'); ?>',
            clientId: '<?php echo esc_js($current_client_id); ?>'
        };

        (function($) {
            let currentChart = null;

            $('#client-selector').on('change', function() {
                window.location.href = '<?php echo admin_url('admin.php?page=wnq-analytics'); ?>&client=' + $(this).val();
            });

            function loadData(days) {
                $('#wnq-analytics-loading').show();
                $('#wnq-analytics-content').hide();

                $.ajax({
                    url: wnqAnalytics.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'wnq_get_analytics_data',
                        nonce: wnqAnalytics.nonce,
                        client_id: wnqAnalytics.clientId,
                        date_range: days
                    },
                    success: function(resp) {
                        console.log('Response:', resp);
                        if (resp.success) {
                            renderData(resp.data);
                        } else {
                            showError(resp.data?.message || 'Failed to load data');
                        }
                    },
                    error: function(xhr) {
                        console.error('Error:', xhr);
                        showError('Error loading data');
                    },
                    complete: function() {
                        $('#wnq-refresh-data').prop('disabled', false).text('🔄 Refresh Data');
                    }
                });
            }

            function renderData(data) {
                let html = '<div class="wnq-analytics-dashboard">';
                
                // GA4 Overview
                html += '<h2>📊 Website Analytics (GA4)</h2>';
                html += '<div class="wnq-stats-grid">';
                html += '<div class="wnq-stat-card"><h3>Visitors</h3><div class="stat-value">' + (data.overview.total_users || 0).toLocaleString() + '</div></div>';
                html += '<div class="wnq-stat-card"><h3>Page Views</h3><div class="stat-value">' + (data.overview.page_views || 0).toLocaleString() + '</div></div>';
                html += '<div class="wnq-stat-card"><h3>Sessions</h3><div class="stat-value">' + (data.overview.sessions || 0).toLocaleString() + '</div></div>';
                html += '<div class="wnq-stat-card"><h3>Bounce Rate</h3><div class="stat-value">' + (data.overview.bounce_rate || 0).toFixed(1) + '%</div></div>';
                html += '</div>';
                
                // Search Console Overview
                if (data.search_console && data.search_console.total_impressions > 0) {
                    html += '<h2 style="margin-top: 40px;">🔍 Search Performance (Google Search Console)</h2>';
                    html += '<div class="wnq-stats-grid">';
                    html += '<div class="wnq-stat-card search"><h3>Impressions</h3><div class="stat-value">' + (data.search_console.total_impressions || 0).toLocaleString() + '</div></div>';
                    html += '<div class="wnq-stat-card search"><h3>Clicks</h3><div class="stat-value">' + (data.search_console.total_clicks || 0).toLocaleString() + '</div></div>';
                    html += '<div class="wnq-stat-card search"><h3>CTR</h3><div class="stat-value">' + (data.search_console.avg_ctr || 0).toFixed(2) + '%</div></div>';
                    html += '<div class="wnq-stat-card search"><h3>Avg Position</h3><div class="stat-value">' + (data.search_console.avg_position || 0).toFixed(1) + '</div></div>';
                    html += '</div>';
                    
                    // Top Queries
                    if (data.search_console.top_queries && data.search_console.top_queries.length > 0) {
                        html += '<div class="wnq-table-container">';
                        html += '<h2>Top Search Queries</h2>';
                        html += '<table class="wp-list-table widefat fixed striped">';
                        html += '<thead><tr><th>Query</th><th>Clicks</th><th>Impressions</th><th>CTR</th><th>Position</th></tr></thead>';
                        html += '<tbody>';
                        data.search_console.top_queries.forEach(q => {
                            html += '<tr>';
                            html += '<td><strong>' + q.query + '</strong></td>';
                            html += '<td>' + q.clicks.toLocaleString() + '</td>';
                            html += '<td>' + q.impressions.toLocaleString() + '</td>';
                            html += '<td>' + q.ctr.toFixed(2) + '%</td>';
                            html += '<td>' + q.position.toFixed(1) + '</td>';
                            html += '</tr>';
                        });
                        html += '</tbody></table>';
                        html += '</div>';
                    }
                }
                
                // Visitors Chart
                if (data.visitors_over_time && data.visitors_over_time.length > 0) {
                    html += '<div class="wnq-chart-container">';
                    html += '<h2>Visitors Over Time</h2>';
                    html += '<canvas id="visitors-chart"></canvas>';
                    html += '</div>';
                }
                
                // Traffic Sources
                if (data.traffic_sources && data.traffic_sources.length > 0) {
                    html += '<div class="wnq-table-container">';
                    html += '<h2>Traffic Sources</h2>';
                    html += '<table class="wp-list-table widefat fixed striped">';
                    html += '<thead><tr><th>Channel</th><th>Sessions</th><th>Users</th><th>%</th></tr></thead>';
                    html += '<tbody>';
                    data.traffic_sources.forEach(s => {
                        html += '<tr><td>' + s.channel + '</td><td>' + s.sessions.toLocaleString() + '</td><td>' + s.users.toLocaleString() + '</td><td>' + s.percentage + '%</td></tr>';
                    });
                    html += '</tbody></table>';
                    html += '</div>';
                }
                
                // Top Pages
                if (data.top_pages && data.top_pages.length > 0) {
                    html += '<div class="wnq-table-container">';
                    html += '<h2>Top Pages</h2>';
                    html += '<table class="wp-list-table widefat fixed striped">';
                    html += '<thead><tr><th>Page</th><th>Views</th><th>Bounce Rate</th></tr></thead>';
                    html += '<tbody>';
                    data.top_pages.forEach(p => {
                        html += '<tr><td><code>' + p.path + '</code></td><td>' + p.views.toLocaleString() + '</td><td>' + p.bounce_rate.toFixed(1) + '%</td></tr>';
                    });
                    html += '</tbody></table>';
                    html += '</div>';
                }
                if (data.search_console && data.search_console.error) {
                    html += '<div class="notice notice-error" style="margin: 20px 0; padding: 15px;">';
                    html += '<h3 style="margin-top:0;">🔍 Search Console Error</h3>';
                    html += '<p><strong>Error:</strong> ' + data.search_console.error + '</p>';
                    html += '<p><strong>URL:</strong> <code>' + (data.search_console.url || '') + '</code></p>';
                    html += '</div>';
                }
                
                html += '</div>';
                
                $('#wnq-analytics-content').html(html).show();
                $('#wnq-analytics-loading').hide();
                
                // Render chart
                if (data.visitors_over_time && data.visitors_over_time.length > 0 && typeof Chart !== 'undefined') {
                    const ctx = document.getElementById('visitors-chart');
                    if (ctx) {
                        if (currentChart) currentChart.destroy();
                        currentChart = new Chart(ctx, {
                            type: 'line',
                            data: {
                                labels: data.visitors_over_time.map(d => d.date),
                                datasets: [{
                                    label: 'Visitors',
                                    data: data.visitors_over_time.map(d => d.users),
                                    borderColor: '#0d539e',
                                    backgroundColor: 'rgba(13, 83, 158, 0.1)',
                                    tension: 0.4,
                                    fill: true,
                                    borderWidth: 3
                                }]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: true,
                                aspectRatio: 3,
                                plugins: { legend: { display: false } },
                                scales: { y: { beginAtZero: true } }
                            }
                        });
                    }
                }
            }

            function showError(msg) {
                $('#wnq-analytics-content').html('<div class="notice notice-error"><p>' + msg + '</p></div>').show();
                $('#wnq-analytics-loading').hide();
            }

            $('#wnq-refresh-data').on('click', function() {
                $(this).prop('disabled', true).text('⏳ Loading...');
                loadData(parseInt($('#wnq-date-range').val()));
            });

            $('#wnq-date-range').on('change', function() {
                loadData(parseInt($(this).val()));
            });

            $(document).ready(function() {
                if (wnqAnalytics.clientId) loadData(30);
            });
        })(jQuery);
        </script>

        <style>
        .wnq-analytics-wrap { max-width: 1400px; }
        .wnq-analytics-header { display: flex; justify-content: space-between; align-items: center; background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ddd; border-radius: 4px; }
        .wnq-client-selector { display: flex; align-items: center; gap: 10px; }
        .wnq-client-selector select { padding: 8px; font-size: 14px; min-width: 250px; }
        .wnq-client-info { background: #e7f3ff; padding: 20px; margin: 20px 0; border-left: 4px solid #0d539e; border-radius: 4px; }
        .wnq-client-info h3 { margin: 0 0 10px; color: #0d539e; }
        .wnq-client-info ul { margin: 0; padding: 0; list-style: none; }
        .wnq-client-info li { padding: 5px 0; }
        .wnq-data-controls { background: #fff; padding: 15px; margin: 20px 0; border: 1px solid #ddd; border-radius: 4px; display: flex; gap: 10px; }
        .wnq-loading { background: #fff; padding: 40px; text-align: center; border: 1px solid #ddd; border-radius: 4px; }
        .wnq-stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin: 20px 0; }
        .wnq-stat-card { background: #fff; padding: 24px; border: 1px solid #ddd; border-left: 4px solid #0d539e; border-radius: 4px; }
        .wnq-stat-card.search { border-left-color: #34a853; }
        .wnq-stat-card h3 { margin: 0 0 10px; font-size: 12px; text-transform: uppercase; color: #666; }
        .wnq-stat-card .stat-value { font-size: 32px; font-weight: bold; color: #0d539e; }
        .wnq-stat-card.search .stat-value { color: #34a853; }
        .wnq-chart-container, .wnq-table-container { background: #fff; padding: 24px; margin: 20px 0; border: 1px solid #ddd; border-radius: 4px; }
        .wnq-chart-container h2, .wnq-table-container h2 { margin: 0 0 20px; font-size: 18px; }
        @media (max-width: 1024px) { .wnq-stats-grid { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 640px) { .wnq-stats-grid { grid-template-columns: 1fr; } }
        </style>
        <?php
    }
    

    // ============================================
    // CLIENTS MANAGER
    // ============================================
    
    private static function renderClientsManager(): void
    {
        $clients = AnalyticsConfig::getAllClients();
        $message = isset($_GET['msg']) ? sanitize_text_field($_GET['msg']) : '';
        
        ?>
        <div class="wrap">
            <h1>👥 Manage Analytics Clients</h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-analytics'); ?>" class="button">← Back to Dashboard</a>

            <?php if ($message === 'added'): ?>
                <div class="notice notice-success is-dismissible"><p>✅ Client added!</p></div>
            <?php elseif ($message === 'updated'): ?>
                <div class="notice notice-success is-dismissible"><p>✅ Client updated!</p></div>
            <?php elseif ($message === 'deleted'): ?>
                <div class="notice notice-success is-dismissible"><p>✅ Client deleted!</p></div>
            <?php elseif ($message === 'error'): ?>
                <div class="notice notice-error is-dismissible"><p>❌ An error occurred.</p></div>
            <?php endif; ?>

            <div class="wnq-form-card">
                <h2>➕ Add New Client</h2>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                    <?php wp_nonce_field('wnq_add_analytics_client'); ?>
                    <input type="hidden" name="action" value="wnq_add_analytics_client">
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="client_id">Client ID *</label></th>
                            <td>
                                <input type="text" name="client_id" id="client_id" class="regular-text" required placeholder="my-client-name">
                                <p class="description">Unique identifier (lowercase, no spaces)</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="client_name">Client Name *</label></th>
                            <td><input type="text" name="client_name" id="client_name" class="regular-text" required placeholder="My Client Name"></td>
                        </tr>
                        <tr>
                            <th><label for="ga4_property_id">GA4 Property ID *</label></th>
                            <td>
                                <input type="text" name="ga4_property_id" id="ga4_property_id" class="regular-text" required placeholder="properties/123456789">
                                <p class="description">Must start with "properties/"</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="website_url">Website URL *</label></th>
                            <td><input type="url" name="website_url" id="website_url" class="regular-text" required placeholder="https://example.com"></td>
                        </tr>
                        <tr>
                            <th><label for="search_console_url">Search Console URL</label></th>
                            <td>
                                <input type="text" name="search_console_url" id="search_console_url" class="regular-text" placeholder="sc-domain:example.com">
                                <p class="description">Format: <code>sc-domain:example.com</code> or <code>https://example.com</code></p>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit"><button type="submit" class="button button-primary">Add Client</button></p>
                </form>
            </div>

            <div class="wnq-form-card">
                <h2>📋 Existing Clients (<?php echo count($clients); ?>)</h2>
                
                <?php if (empty($clients)): ?>
                    <p>No clients yet.</p>
                <?php else: ?>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Client Name</th>
                                <th>Website</th>
                                <th>GA4 Property</th>
                                <th>Search Console</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($clients as $client): ?>
                                <tr>
                                    <td><strong><?php echo esc_html($client['client_name']); ?></strong></td>
                                    <td><?php echo esc_html($client['website_url']); ?></td>
                                    <td><code><?php echo esc_html($client['ga4_property_id']); ?></code></td>
                                    <td>
                                        <?php if (!empty($client['search_console_url'])): ?>
                                            <code><?php echo esc_html($client['search_console_url']); ?></code>
                                        <?php else: ?>
                                            <span style="color: #999;">Not configured</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo admin_url('admin.php?page=wnq-analytics&client=' . urlencode($client['client_id'])); ?>" class="button button-small">View Analytics</a>
                                        <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=edit-client&id=' . urlencode($client['client_id'])); ?>" class="button button-small">Edit</a>
                                        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                                            <?php wp_nonce_field('wnq_delete_analytics_client'); ?>
                                            <input type="hidden" name="action" value="wnq_delete_analytics_client">
                                            <input type="hidden" name="client_id" value="<?php echo esc_attr($client['client_id']); ?>">
                                            <button type="submit" class="button button-small" onclick="return confirm('Delete this client?');">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <style>
        .wnq-form-card { background: #fff; padding: 24px; border: 1px solid #ddd; border-radius: 4px; margin: 20px 0; }
        .wnq-form-card h2 { margin-top: 0; padding-bottom: 15px; border-bottom: 1px solid #ddd; }
        </style>
        <?php
    }

    // ============================================
    // EDIT CLIENT
    // ============================================
    
    private static function renderEditClient(): void
    {
        $client_id = isset($_GET['id']) ? sanitize_text_field($_GET['id']) : '';
        $client = AnalyticsConfig::getClientConfig($client_id);
        
        if (!$client) {
            wp_die('Client not found');
        }
        
        ?>
        <div class="wrap">
            <h1>✏️ Edit Client: <?php echo esc_html($client['client_name']); ?></h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=clients'); ?>" class="button">← Back to Clients</a>

            <div class="wnq-form-card">
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                    <?php wp_nonce_field('wnq_update_analytics_client'); ?>
                    <input type="hidden" name="action" value="wnq_update_analytics_client">
                    <input type="hidden" name="client_id" value="<?php echo esc_attr($client['client_id']); ?>">
                    
                    <table class="form-table">
                        <tr>
                            <th><label>Client ID</label></th>
                            <td>
                                <input type="text" value="<?php echo esc_attr($client['client_id']); ?>" class="regular-text" readonly>
                                <p class="description">Cannot be changed</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="client_name">Client Name *</label></th>
                            <td><input type="text" name="client_name" id="client_name" value="<?php echo esc_attr($client['client_name']); ?>" class="regular-text" required></td>
                        </tr>
                        <tr>
                            <th><label for="ga4_property_id">GA4 Property ID *</label></th>
                            <td>
                                <input type="text" name="ga4_property_id" id="ga4_property_id" value="<?php echo esc_attr($client['ga4_property_id']); ?>" class="regular-text" required>
                                <p class="description">Must start with "properties/"</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="website_url">Website URL *</label></th>
                            <td><input type="url" name="website_url" id="website_url" value="<?php echo esc_attr($client['website_url']); ?>" class="regular-text" required></td>
                        </tr>
                        <tr>
                            <th><label for="search_console_url">Search Console URL</label></th>
                            <td>
                                <input type="text" name="search_console_url" id="search_console_url" value="<?php echo esc_attr($client['search_console_url']); ?>" class="regular-text">
                                <p class="description">Format: <code>sc-domain:parrishwelldrillingfl.com</code> (for domain property) OR <code>https://parrishwelldrillingfl.com</code> (for URL prefix)</p>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary">Update Client</button>
                        <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=clients'); ?>" class="button">Cancel</a>
                    </p>
                </form>
            </div>
        </div>

        <style>
        .wnq-form-card { background: #fff; padding: 24px; border: 1px solid #ddd; border-radius: 4px; margin: 20px 0; }
        </style>
        <?php
    }

    // ============================================
    // SETTINGS
    // ============================================
    
    private static function renderSettings(): void
    {
        $credentials = AnalyticsConfig::getCredentials();
        $message = isset($_GET['msg']) ? sanitize_text_field($_GET['msg']) : '';
        
        ?>
        <div class="wrap">
            <h1>⚙️ Global Analytics Settings</h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-analytics'); ?>" class="button">← Back to Dashboard</a>

            <?php if ($message === 'saved'): ?>
                <div class="notice notice-success is-dismissible"><p>✅ Settings saved!</p></div>
            <?php endif; ?>

            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" enctype="multipart/form-data">
                <?php wp_nonce_field('wnq_save_analytics_settings'); ?>
                <input type="hidden" name="action" value="wnq_save_analytics_settings">
                
                <div class="wnq-form-card">
                    <h2>🔐 Service Account (Shared)</h2>
                    <p>Upload your Google Cloud service account JSON file.</p>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="credentials_file">Service Account JSON</label></th>
                            <td>
                                <input type="file" name="credentials_file" id="credentials_file" accept=".json">
                                <?php if ($credentials): ?>
                                    <p class="description" style="color: #0d8a00;">✅ Current: <?php echo esc_html($credentials['email']); ?></p>
                                <?php else: ?>
                                    <p class="description" style="color: #dc3232;">⚠️ No credentials uploaded</p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit"><button type="submit" class="button button-primary">💾 Save Settings</button></p>
                </div>
            </form>

            <div class="wnq-form-card">
                <h2>📋 Setup Instructions</h2>
                <ol style="line-height: 2;">
                    <li><strong>Create Service Account:</strong> Google Cloud Console → Create service account → Download JSON</li>
                    <li><strong>Enable APIs:</strong> Enable "Google Analytics Data API" and "Search Console API"</li>
                    <li><strong>Upload Credentials:</strong> Upload JSON file above</li>
                    <li><strong>Grant Access:</strong>
                        <ul style="margin-left: 30px;">
                            <li>GA4: Admin → Property Access → Add <?php echo $credentials ? '<code>' . esc_html($credentials['email']) . '</code>' : 'service account'; ?> as Viewer</li>
                            <li>Search Console: Settings → Users → Add <?php echo $credentials ? '<code>' . esc_html($credentials['email']) . '</code>' : 'service account'; ?> with Full permission</li>
                        </ul>
                    </li>
                    <li><strong>Add Clients:</strong> Go to <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=clients'); ?>">Manage Clients</a></li>
                </ol>
            </div>
        </div>

        <style>
        .wnq-form-card { background: #fff; padding: 24px; border: 1px solid #ddd; border-radius: 4px; margin: 20px 0; }
        .wnq-form-card h2 { margin-top: 0; padding-bottom: 15px; border-bottom: 1px solid #ddd; }
        </style>
        <?php
    }

    // ============================================
    // AJAX & DATA FETCHING
    // ============================================
    
    public static function ajaxGetAnalyticsData(): void
    {
        try {
            check_ajax_referer('wnq_analytics_nonce', 'nonce');

            if (!current_user_can('manage_options') && !current_user_can('wnq_manage_portal')) {
                wp_send_json_error(['message' => 'Permission denied']);
            }

            $client_id = sanitize_text_field($_POST['client_id'] ?? '');
            $date_range = intval($_POST['date_range'] ?? 30);

            $config = AnalyticsConfig::getClientConfig($client_id);
            $credentials = AnalyticsConfig::getCredentials();

            if (!$config || !$credentials) {
                wp_send_json_error(['message' => 'Not configured']);
            }

            $token = self::getGoogleAccessToken($credentials['credentials']);
            $end_date = date('Y-m-d');
            $start_date = date('Y-m-d', strtotime("-{$date_range} days"));

            $data = [];

            // GA4 Data
            try {
                $data['overview'] = self::fetchOverviewStats($token, $config['ga4_property_id'], $start_date, $end_date);
                $data['visitors_over_time'] = self::fetchVisitorsOverTime($token, $config['ga4_property_id'], $start_date, $end_date);
                $data['traffic_sources'] = self::fetchTrafficSources($token, $config['ga4_property_id'], $start_date, $end_date);
                $data['top_pages'] = self::fetchTopPages($token, $config['ga4_property_id'], $start_date, $end_date);
            } catch (\Exception $e) {
                $data['overview'] = ['total_users' => 0, 'page_views' => 0, 'sessions' => 0, 'bounce_rate' => 0];
                $data['visitors_over_time'] = [];
                $data['traffic_sources'] = [];
                $data['top_pages'] = [];
            }

            // Search Console Data
            // Search Console Data
            if (!empty($config['search_console_url'])) {
                try {
                    $data['search_console'] = self::fetchSearchConsoleData($token, $config['search_console_url'], $start_date, $end_date);
                } catch (\Exception $e) {
                    $data['search_console'] = [
                        'error' => $e->getMessage(),
                        'url' => $config['search_console_url']
                    ];
                    error_log('Search Console Error: ' . $e->getMessage());
                }
            }

            wp_send_json_success($data);

        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }

    public static function ajaxGetClientAnalytics(): void
    {
        try {
            check_ajax_referer('wnq_client_analytics_nonce', 'nonce');

            $user_id = get_current_user_id();
            $client_id = get_user_meta($user_id, 'wnq_client_id', true);

            if (empty($client_id)) {
                wp_send_json_error(['message' => 'No client assigned']);
            }

            $date_range = intval($_POST['date_range'] ?? 30);
            $config = AnalyticsConfig::getClientConfig($client_id);
            $credentials = AnalyticsConfig::getCredentials();

            if (!$config || !$credentials) {
                wp_send_json_error(['message' => 'Not configured']);
            }

            $token = self::getGoogleAccessToken($credentials['credentials']);
            $end_date = date('Y-m-d');
            $start_date = date('Y-m-d', strtotime("-{$date_range} days"));

            $data = [];

            try {
                $data['overview'] = self::fetchOverviewStats($token, $config['ga4_property_id'], $start_date, $end_date);
                $data['visitors_over_time'] = self::fetchVisitorsOverTime($token, $config['ga4_property_id'], $start_date, $end_date);
                $data['traffic_sources'] = self::fetchTrafficSources($token, $config['ga4_property_id'], $start_date, $end_date);
                $data['top_pages'] = self::fetchTopPages($token, $config['ga4_property_id'], $start_date, $end_date);
            } catch (\Exception $e) {
                $data['overview'] = ['total_users' => 0, 'page_views' => 0, 'sessions' => 0, 'bounce_rate' => 0];
                $data['visitors_over_time'] = [];
                $data['traffic_sources'] = [];
                $data['top_pages'] = [];
            }

            if (!empty($config['search_console_url'])) {
                try {
                    $data['search_console'] = self::fetchSearchConsoleData($token, $config['search_console_url'], $start_date, $end_date);
                } catch (\Exception $e) {
                    $data['search_console'] = null;
                }
            }

            wp_send_json_success($data);

        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }

    // Form Handlers

    public static function handleSaveSettings(): void
    {
        check_admin_referer('wnq_save_analytics_settings');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        if (isset($_FILES['credentials_file']) && $_FILES['credentials_file']['size'] > 0) {
            $file = $_FILES['credentials_file'];
            $json = file_get_contents($file['tmp_name']);
            $creds = json_decode($json, true);

            if ($creds && isset($creds['client_email']) && isset($creds['private_key'])) {
                AnalyticsConfig::saveCredentials($creds);
            }
        }

        delete_transient('wnq_ga_access_token');
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&msg=saved'));
        exit;
    }

    public static function handleAddClient(): void
    {
        check_admin_referer('wnq_add_analytics_client');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        // FIXED: Use sanitize_text_field instead of esc_url_raw for search_console_url
        $search_console_url = sanitize_text_field($_POST['search_console_url'] ?? '');

        $config = [
            'client_id' => sanitize_text_field($_POST['client_id']),
            'client_name' => sanitize_text_field($_POST['client_name']),
            'ga4_property_id' => sanitize_text_field($_POST['ga4_property_id']),
            'website_url' => esc_url_raw($_POST['website_url']),
            'search_console_url' => $search_console_url,
            'timezone' => 'America/New_York'
        ];

        $result = AnalyticsConfig::saveClientConfig($config);
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=clients&msg=' . ($result ? 'added' : 'error')));
        exit;
    }

    public static function handleUpdateClient(): void
    {
        check_admin_referer('wnq_update_analytics_client');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        // FIXED: Use sanitize_text_field instead of esc_url_raw for search_console_url
        $search_console_url = sanitize_text_field($_POST['search_console_url'] ?? '');

        $config = [
            'client_id' => sanitize_text_field($_POST['client_id']),
            'client_name' => sanitize_text_field($_POST['client_name']),
            'ga4_property_id' => sanitize_text_field($_POST['ga4_property_id']),
            'website_url' => esc_url_raw($_POST['website_url']),
            'search_console_url' => $search_console_url,
            'timezone' => 'America/New_York'
        ];

        $result = AnalyticsConfig::saveClientConfig($config);
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=clients&msg=' . ($result ? 'updated' : 'error')));
        exit;
    }

    public static function handleDeleteClient(): void
    {
        check_admin_referer('wnq_delete_analytics_client');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $client_id = sanitize_text_field($_POST['client_id']);
        $result = AnalyticsConfig::deleteClient($client_id);
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=clients&msg=' . ($result ? 'deleted' : 'error')));
        exit;
    }

    // Data Fetching Methods

    private static function getGoogleAccessToken(array $credentials): string
    {
        $cached = get_transient('wnq_ga_access_token');
        if ($cached) return $cached;

        $now = time();
        $header = ['alg' => 'RS256', 'typ' => 'JWT'];
        $claim = [
            'iss' => $credentials['client_email'],
            'scope' => 'https://www.googleapis.com/auth/analytics.readonly https://www.googleapis.com/auth/webmasters.readonly',
            'aud' => 'https://oauth2.googleapis.com/token',
            'exp' => $now + 3600,
            'iat' => $now
        ];

        $segments = [
            self::base64UrlEncode(wp_json_encode($header)),
            self::base64UrlEncode(wp_json_encode($claim))
        ];
        $signing_input = implode('.', $segments);

        $signature = '';
        if (!openssl_sign($signing_input, $signature, $credentials['private_key'], 'SHA256')) {
            throw new \Exception('JWT signing failed');
        }

        $segments[] = self::base64UrlEncode($signature);
        $jwt = implode('.', $segments);

        $response = wp_remote_post('https://oauth2.googleapis.com/token', [
            'body' => ['grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion' => $jwt],
            'timeout' => 30
        ]);

        if (is_wp_error($response)) throw new \Exception('Token request failed');

        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!isset($body['access_token'])) {
            throw new \Exception('Token failed: ' . ($body['error_description'] ?? 'Unknown'));
        }

        $token = $body['access_token'];
        set_transient('wnq_ga_access_token', $token, 3000);
        return $token;
    }

    private static function fetchSearchConsoleData(string $token, string $site_url, string $start, string $end): array
    {
        $url = 'https://searchconsole.googleapis.com/v1/urlSearchAnalytics/query';
        
        // Normalize site URL format
        if (!str_starts_with($site_url, 'sc-domain:') && !str_starts_with($site_url, 'http')) {
            $site_url = 'sc-domain:' . str_replace(['https://', 'http://', 'www.'], '', $site_url);
        }
        
        // Fetch overview
        $overview_body = [
            'startDate' => $start,
            'endDate' => $end,
            'dimensions' => [],
            'rowLimit' => 1
        ];

        $response = wp_remote_post($url . '?siteUrl=' . urlencode($site_url), [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
            'body' => wp_json_encode($overview_body),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            throw new \Exception('Search Console API failed: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body_text = wp_remote_retrieve_body($response);
        $data = json_decode($body_text, true);
        
        if ($code !== 200) {
            throw new \Exception('Search Console API error: ' . ($data['error']['message'] ?? $body_text));
        }
        
        $total_clicks = 0;
        $total_impressions = 0;
        $total_ctr = 0;
        $total_position = 0;
        
        if (isset($data['rows'][0])) {
            $total_clicks = floatval($data['rows'][0]['clicks']);
            $total_impressions = floatval($data['rows'][0]['impressions']);
            $total_ctr = floatval($data['rows'][0]['ctr']) * 100;
            $total_position = floatval($data['rows'][0]['position']);
        }

        // Fetch top queries
        $queries_body = [
            'startDate' => $start,
            'endDate' => $end,
            'dimensions' => ['query'],
            'rowLimit' => 10
        ];

        $response2 = wp_remote_post($url . '?siteUrl=' . urlencode($site_url), [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
            'body' => wp_json_encode($queries_body),
            'timeout' => 30
        ]);

        $queries_data = json_decode(wp_remote_retrieve_body($response2), true);
        $top_queries = [];

        if (isset($queries_data['rows'])) {
            foreach ($queries_data['rows'] as $row) {
                $top_queries[] = [
                    'query' => $row['keys'][0],
                    'clicks' => intval($row['clicks']),
                    'impressions' => intval($row['impressions']),
                    'ctr' => floatval($row['ctr']) * 100,
                    'position' => floatval($row['position'])
                ];
            }
        }

        return [
            'total_clicks' => $total_clicks,
            'total_impressions' => $total_impressions,
            'avg_ctr' => $total_ctr,
            'avg_position' => $total_position,
            'top_queries' => $top_queries
        ];
    }

    private static function fetchOverviewStats(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'metrics' => [
                ['name' => 'totalUsers'],
                ['name' => 'screenPageViews'],
                ['name' => 'sessions'],
                ['name' => 'bounceRate']
            ]
        ]);
        
        $m = $data['rows'][0]['metricValues'] ?? [];
        return [
            'total_users' => isset($m[0]) ? intval($m[0]['value']) : 0,
            'page_views' => isset($m[1]) ? intval($m[1]['value']) : 0,
            'sessions' => isset($m[2]) ? intval($m[2]['value']) : 0,
            'bounce_rate' => isset($m[3]) ? floatval($m[3]['value']) * 100 : 0
        ];
    }

    private static function fetchVisitorsOverTime(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'date']],
            'metrics' => [['name' => 'totalUsers'], ['name' => 'sessions']],
            'orderBys' => [['dimension' => ['dimensionName' => 'date']]]
        ]);
        
        $trends = [];
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $date = $row['dimensionValues'][0]['value'];
                $trends[] = [
                    'date' => substr($date, 0, 4) . '-' . substr($date, 4, 2) . '-' . substr($date, 6, 2),
                    'users' => intval($row['metricValues'][0]['value']),
                    'sessions' => intval($row['metricValues'][1]['value'])
                ];
            }
        }
        return $trends;
    }

    private static function fetchTrafficSources(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'sessionDefaultChannelGroup']],
            'metrics' => [['name' => 'sessions'], ['name' => 'totalUsers']],
            'orderBys' => [['metric' => ['metricName' => 'sessions'], 'desc' => true]],
            'limit' => 10
        ]);
        
        $sources = [];
        $total = 0;
        
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $total += intval($row['metricValues'][0]['value']);
            }
            foreach ($data['rows'] as $row) {
                $sessions = intval($row['metricValues'][0]['value']);
                $sources[] = [
                    'channel' => $row['dimensionValues'][0]['value'],
                    'sessions' => $sessions,
                    'users' => intval($row['metricValues'][1]['value']),
                    'percentage' => $total > 0 ? round(($sessions / $total) * 100, 1) : 0
                ];
            }
        }
        return $sources;
    }

    private static function fetchTopPages(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'pagePath'], ['name' => 'pageTitle']],
            'metrics' => [['name' => 'screenPageViews'], ['name' => 'bounceRate']],
            'orderBys' => [['metric' => ['metricName' => 'screenPageViews'], 'desc' => true]],
            'limit' => 10
        ]);
        
        $pages = [];
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $pages[] = [
                    'path' => $row['dimensionValues'][0]['value'],
                    'title' => $row['dimensionValues'][1]['value'] ?? 'Untitled',
                    'views' => intval($row['metricValues'][0]['value']),
                    'bounce_rate' => floatval($row['metricValues'][1]['value'] ?? 0) * 100
                ];
            }
        }
        return $pages;
    }

    private static function makeGARequest(string $token, string $property_id, array $body): array
    {
        $url = "https://analyticsdata.googleapis.com/v1beta/{$property_id}:runReport";
        
        $response = wp_remote_post($url, [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
            'body' => wp_json_encode($body),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) throw new \Exception('GA API failed');

        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);

        if ($code !== 200) {
            throw new \Exception('GA API error: ' . ($data['error']['message'] ?? 'Unknown'));
        }

        return $data;
    }

    private static function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
}