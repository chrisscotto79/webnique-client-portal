<?php
/**
 * SEO Model
 * 
 * Manages SEO tracking data for clients
 * 
 * @package WebNique Portal
 */

namespace WNQ\Models;

if (!defined('ABSPATH')) {
    exit;
}

final class SEO
{
    public static function createTables(): void
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        // Main SEO tasks table
        $table_seo = $wpdb->prefix . 'wnq_seo_tasks';
        $sql_seo = "CREATE TABLE IF NOT EXISTS $table_seo (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            client_id varchar(100) NOT NULL,
            month_year varchar(7) NOT NULL,
            service_type varchar(50) NOT NULL,
            task_name varchar(255) NOT NULL,
            task_description text,
            status varchar(20) DEFAULT 'pending',
            completed_date datetime,
            notes text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY client_month (client_id, month_year),
            KEY service_type (service_type),
            KEY status (status)
        ) $charset_collate;";

        // Monthly SEO reports table
        $table_reports = $wpdb->prefix . 'wnq_seo_reports';
        $sql_reports = "CREATE TABLE IF NOT EXISTS $table_reports (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            client_id varchar(100) NOT NULL,
            month_year varchar(7) NOT NULL,
            report_url varchar(500),
            keywords_tracked int DEFAULT 0,
            avg_position decimal(5,2),
            organic_traffic int DEFAULT 0,
            backlinks_added int DEFAULT 0,
            summary text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY client_month (client_id, month_year)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_seo);
        dbDelta($sql_reports);
    }

    // SEO Task Methods
    public static function createTask(array $data): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        return (bool) $wpdb->insert($table, [
            'client_id' => $data['client_id'],
            'month_year' => $data['month_year'],
            'service_type' => $data['service_type'],
            'task_name' => $data['task_name'],
            'task_description' => $data['task_description'] ?? '',
            'status' => $data['status'] ?? 'pending',
            'notes' => $data['notes'] ?? '',
        ]);
    }

    public static function updateTask(int $id, array $data): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        $update_data = [];
        $allowed_fields = ['task_name', 'task_description', 'status', 'notes', 'completed_date'];
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                $update_data[$field] = $data[$field];
            }
        }
        
        if (empty($update_data)) {
            return false;
        }
        
        return (bool) $wpdb->update($table, $update_data, ['id' => $id]);
    }

    public static function completeTask(int $id): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        return (bool) $wpdb->update($table, [
            'status' => 'completed',
            'completed_date' => current_time('mysql')
        ], ['id' => $id]);
    }

    public static function getTasksByClient(string $client_id, ?string $month_year = null): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        if ($month_year) {
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table WHERE client_id = %s AND month_year = %s ORDER BY service_type, id",
                $client_id,
                $month_year
            ), ARRAY_A);
        } else {
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table WHERE client_id = %s ORDER BY month_year DESC, service_type, id",
                $client_id
            ), ARRAY_A);
        }
        
        return $results ?: [];
    }

    public static function getTasksByMonth(string $month_year): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE month_year = %s ORDER BY client_id, service_type",
            $month_year
        ), ARRAY_A);
        
        return $results ?: [];
    }

    public static function deleteTask(int $id): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        return (bool) $wpdb->delete($table, ['id' => $id]);
    }

    // Monthly Report Methods
    public static function saveReport(array $data): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_reports';
        
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE client_id = %s AND month_year = %s",
            $data['client_id'],
            $data['month_year']
        ));
        
        if ($existing) {
            return (bool) $wpdb->update($table, [
                'report_url' => $data['report_url'] ?? '',
                'keywords_tracked' => $data['keywords_tracked'] ?? 0,
                'avg_position' => $data['avg_position'] ?? 0,
                'organic_traffic' => $data['organic_traffic'] ?? 0,
                'backlinks_added' => $data['backlinks_added'] ?? 0,
                'summary' => $data['summary'] ?? '',
            ], [
                'client_id' => $data['client_id'],
                'month_year' => $data['month_year']
            ]);
        } else {
            return (bool) $wpdb->insert($table, [
                'client_id' => $data['client_id'],
                'month_year' => $data['month_year'],
                'report_url' => $data['report_url'] ?? '',
                'keywords_tracked' => $data['keywords_tracked'] ?? 0,
                'avg_position' => $data['avg_position'] ?? 0,
                'organic_traffic' => $data['organic_traffic'] ?? 0,
                'backlinks_added' => $data['backlinks_added'] ?? 0,
                'summary' => $data['summary'] ?? '',
            ]);
        }
    }

    public static function getReport(string $client_id, string $month_year): ?array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_reports';
        
        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE client_id = %s AND month_year = %s",
            $client_id,
            $month_year
        ), ARRAY_A);
        
        return $result ?: null;
    }

    public static function getClientReports(string $client_id): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_reports';
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE client_id = %s ORDER BY month_year DESC",
            $client_id
        ), ARRAY_A);
        
        return $results ?: [];
    }

    // Statistics
    public static function getMonthlyProgress(string $client_id, string $month_year): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(*) as total_tasks,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_tasks,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_tasks,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_tasks
            FROM $table 
            WHERE client_id = %s AND month_year = %s",
            $client_id,
            $month_year
        ), ARRAY_A);
        
        $stats = $stats ?: ['total_tasks' => 0, 'completed_tasks' => 0, 'in_progress_tasks' => 0, 'pending_tasks' => 0];
        
        $stats['completion_percentage'] = $stats['total_tasks'] > 0 
            ? round(($stats['completed_tasks'] / $stats['total_tasks']) * 100, 1)
            : 0;
        
        return $stats;
    }

    public static function getServiceTypeProgress(string $client_id, string $month_year): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT 
                service_type,
                COUNT(*) as total,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
            FROM $table 
            WHERE client_id = %s AND month_year = %s
            GROUP BY service_type",
            $client_id,
            $month_year
        ), ARRAY_A);
        
        return $results ?: [];
    }

    // Utility
    public static function initializeMonthlyTasks(string $client_id, string $month_year): bool
    {
        $service_types = [
            'onpage' => [
                'Meta Tags Optimization',
                'Content Optimization',
                'Header Tags Review',
                'Image Alt Text Update',
                'Internal Linking Review',
            ],
            'technical' => [
                'Site Speed Analysis',
                'Mobile Optimization Check',
                'XML Sitemap Update',
                'Robots.txt Review',
                'Schema Markup Implementation',
            ],
            'local' => [
                'GMB Profile Update',
                'NAP Consistency Check',
                'Local Citations Review',
                'Google Posts Creation',
                'Review Management',
            ],
            'offpage' => [
                'Backlink Acquisition',
                'Guest Post Outreach',
                'Directory Submissions',
                'Social Bookmarking',
                'Brand Mentions Tracking',
            ],
            'monthly' => [
                'Keyword Rankings Report',
                'Traffic Analysis',
                'Competitor Analysis',
                'Content Calendar Planning',
                'Monthly SEO Report',
            ],
        ];

        $success = true;
        foreach ($service_types as $service_type => $tasks) {
            foreach ($tasks as $task_name) {
                $result = self::createTask([
                    'client_id' => $client_id,
                    'month_year' => $month_year,
                    'service_type' => $service_type,
                    'task_name' => $task_name,
                    'status' => 'pending',
                ]);
                if (!$result) {
                    $success = false;
                }
            }
        }
        
        return $success;
    }
}