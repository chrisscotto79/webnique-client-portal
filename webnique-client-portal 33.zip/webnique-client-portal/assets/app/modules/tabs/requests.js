// assets/app/modules/tabs/requests.js
/**
 * Web Requests Tab - Client ↔ WebNique Communication
 * 
 * Shows: Thread list, message view, thread metadata
 * Data: Firestore threads and messages
 * 
 * v1: View-only
 * v1.5+: Client replies, status changes, notifications
 */

import { el, pill, button, escapeHtml } from "../ui.js";

export function renderRequests(main, side, state, shell) {
  main.innerHTML = "";
  side.innerHTML = "";

  if (shell?.setStatus) {
    shell.setStatus("Loading requests...", "neutral");
  }

  // ========================================
  // HEADER
  // ========================================
  main.appendChild(createHeader(state));

  // ========================================
  // CREATE LAYOUT (2-COLUMN)
  // ========================================
  const layout = el("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "350px 1fr",
      gap: "20px",
      minHeight: "600px",
    },
  });

  // Thread list (left)
  const threadList = el("div", {
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "12px",
      overflow: "hidden",
    },
  });

  // Message view (center)
  const messageView = el("div", {
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "12px",
      overflow: "hidden",
    },
  });

  layout.appendChild(threadList);
  layout.appendChild(messageView);
  main.appendChild(layout);

  // ========================================
  // LOAD DATA
  // ========================================
  loadThreads(threadList, messageView, side, state, shell);
}

/**
 * Create header
 */
function createHeader(state) {
  const header = el("div", {
    style: {
      marginBottom: "24px",
      paddingBottom: "20px",
      borderBottom: "2px solid rgba(2,6,23,0.08)",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
    },
  });

  const titleSection = el("div");
  
  titleSection.appendChild(
    el("h1", {
      text: "Web Requests",
      style: {
        fontSize: "32px",
        fontWeight: "900",
        color: "#111827",
        marginBottom: "8px",
      },
    })
  );

  titleSection.appendChild(
    el("p", {
      text: "View your support requests and communication with the WebNique team.",
      style: {
        fontSize: "16px",
        color: "#6b7280",
        margin: "0",
      },
    })
  );

  header.appendChild(titleSection);

  // New request button (v1.5+)
  const newRequestBtn = button(
    state,
    "+ New Request",
    () => {
      alert("New request feature coming in v1.5!");
    },
    "solid"
  );
  newRequestBtn.disabled = true;
  newRequestBtn.style.opacity = "0.5";
  header.appendChild(newRequestBtn);

  return header;
}

/**
 * Load threads
 */
async function loadThreads(threadList, messageView, side, state, shell) {
  try {
    const result = await state.actions?.get?.("/threads");

    if (!result?.ok) {
      showError(threadList, "Failed to load requests");
      if (shell?.setStatus) {
        shell.setStatus("Error", "bad");
      }
      return;
    }

    if (shell?.setStatus) {
      shell.setStatus("Ready", "good");
    }

    const threads = result.data || [];

    if (threads.length === 0) {
      renderEmptyState(threadList, messageView);
      return;
    }

    // Render thread list
    renderThreadList(threadList, threads, (thread) => {
      loadMessages(messageView, side, state, thread);
    });

    // Load first thread automatically
    loadMessages(messageView, side, state, threads[0]);

  } catch (error) {
    console.error("[Requests] Load error:", error);
    showError(threadList, error.message);
    if (shell?.setStatus) {
      shell.setStatus("Error", "bad");
    }
  }
}

/**
 * Render thread list
 */
function renderThreadList(container, threads, onThreadClick) {
  container.innerHTML = "";

  // Header
  const header = el("div", {
    style: {
      padding: "16px 20px",
      borderBottom: "1px solid #e5e7eb",
      background: "#f9fafb",
    },
  });

  header.appendChild(
    el("h3", {
      text: "All Requests",
      style: {
        fontSize: "14px",
        fontWeight: "700",
        color: "#374151",
        margin: "0",
      },
    })
  );

  container.appendChild(header);

  // Thread items
  const listContainer = el("div", {
    style: {
      maxHeight: "calc(100vh - 400px)",
      overflowY: "auto",
    },
  });

  let activeThreadId = threads[0]?.id;

  threads.forEach((thread) => {
    const item = createThreadItem(thread, thread.id === activeThreadId);
    
    item.addEventListener("click", () => {
      // Update active state
      activeThreadId = thread.id;
      
      // Update all items
      listContainer.querySelectorAll("[data-thread-item]").forEach((el) => {
        el.style.background = "white";
        el.style.borderLeft = "3px solid transparent";
      });
      
      item.style.background = "#f0f9ff";
      item.style.borderLeft = "3px solid #0d539e";

      // Load messages
      onThreadClick(thread);
    });

    listContainer.appendChild(item);
  });

  container.appendChild(listContainer);
}

/**
 * Create thread item
 */
function createThreadItem(thread, isActive) {
  const item = el("div", {
    "data-thread-item": "true",
    style: {
      padding: "16px 20px",
      borderBottom: "1px solid #f3f4f6",
      borderLeft: isActive ? "3px solid #0d539e" : "3px solid transparent",
      background: isActive ? "#f0f9ff" : "white",
      cursor: "pointer",
      transition: "all 0.2s ease",
    },
  });

  item.addEventListener("mouseenter", () => {
    if (!isActive) {
      item.style.background = "#f9fafb";
    }
  });

  item.addEventListener("mouseleave", () => {
    if (!isActive) {
      item.style.background = "white";
    }
  });

  // Subject
  item.appendChild(
    el("div", {
      text: escapeHtml(thread.subject || "Untitled Request"),
      style: {
        fontSize: "15px",
        fontWeight: "600",
        color: "#111827",
        marginBottom: "6px",
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
      },
    })
  );

  // Meta row (status + time)
  const meta = el("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      marginBottom: "6px",
    },
  });

  meta.appendChild(
    pill(
      escapeHtml(thread.status || "open"),
      thread.status === "closed" ? "neutral" :
      thread.status === "pending" ? "warn" : "good"
    )
  );

  if (thread.priority === "high") {
    meta.appendChild(
      el("span", {
        text: "🔥",
        style: { fontSize: "14px" },
      })
    );
  }

  item.appendChild(meta);

  // Last update
  item.appendChild(
    el("div", {
      text: formatTimestamp(thread.last_updated),
      style: {
        fontSize: "12px",
        color: "#9ca3af",
      },
    })
  );

  // Unread indicator
  if (thread.unread) {
    item.appendChild(
      el("div", {
        style: {
          position: "absolute",
          top: "20px",
          right: "20px",
          width: "8px",
          height: "8px",
          borderRadius: "50%",
          background: "#0d539e",
        },
      })
    );
    item.style.position = "relative";
  }

  return item;
}

/**
 * Load and render messages
 */
async function loadMessages(container, side, state, thread) {
  container.innerHTML = "";

  // Loading state
  const loading = el("div", {
    style: {
      padding: "40px",
      textAlign: "center",
    },
  });
  loading.appendChild(el("div", { class: "wnq-spinner" }));
  container.appendChild(loading);

  try {
    const result = await state.actions?.get?.(`/threads/${thread.id}/messages`);

    container.innerHTML = "";

    if (!result?.ok) {
      showError(container, "Failed to load messages");
      return;
    }

    const messages = result.data || [];

    // Render message view
    renderMessageView(container, thread, messages);

    // Render sidebar metadata
    renderThreadMetadata(side, thread);

  } catch (error) {
    container.innerHTML = "";
    console.error("[Requests] Message load error:", error);
    showError(container, error.message);
  }
}

/**
 * Render message view
 */
function renderMessageView(container, thread, messages) {
  // Header
  const header = el("div", {
    style: {
      padding: "20px 24px",
      borderBottom: "1px solid #e5e7eb",
      background: "#f9fafb",
    },
  });

  header.appendChild(
    el("h2", {
      text: escapeHtml(thread.subject || "Untitled Request"),
      style: {
        fontSize: "20px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "8px",
      },
    })
  );

  const metaRow = el("div", {
    style: {
      display: "flex",
      gap: "12px",
      alignItems: "center",
    },
  });

  metaRow.appendChild(
    pill(escapeHtml(thread.status || "open"), "neutral")
  );

  if (thread.priority) {
    metaRow.appendChild(
      el("span", {
        text: `Priority: ${escapeHtml(thread.priority)}`,
        style: {
          fontSize: "13px",
          color: "#6b7280",
          fontWeight: "600",
        },
      })
    );
  }

  header.appendChild(metaRow);
  container.appendChild(header);

  // Messages container
  const messagesContainer = el("div", {
    style: {
      padding: "24px",
      maxHeight: "calc(100vh - 500px)",
      overflowY: "auto",
    },
  });

  if (messages.length === 0) {
    messagesContainer.appendChild(
      el("p", {
        text: "No messages yet.",
        style: {
          color: "#9ca3af",
          textAlign: "center",
          padding: "40px 0",
        },
      })
    );
  } else {
    messages.forEach((message) => {
      messagesContainer.appendChild(createMessageBubble(message));
    });
  }

  container.appendChild(messagesContainer);

  // Reply area (disabled in v1)
  const replyArea = el("div", {
    style: {
      padding: "20px 24px",
      borderTop: "1px solid #e5e7eb",
      background: "#f9fafb",
    },
  });

  replyArea.appendChild(
    el("p", {
      text: "💬 Reply feature coming in v1.5",
      style: {
        fontSize: "14px",
        color: "#9ca3af",
        textAlign: "center",
        fontStyle: "italic",
      },
    })
  );

  container.appendChild(replyArea);
}

/**
 * Create message bubble
 */
function createMessageBubble(message) {
  const isClient = message.author_type === "client";

  const bubble = el("div", {
    style: {
      display: "flex",
      justifyContent: isClient ? "flex-end" : "flex-start",
      marginBottom: "16px",
    },
  });

  const content = el("div", {
    style: {
      maxWidth: "70%",
      padding: "12px 16px",
      borderRadius: "12px",
      background: isClient ? "#0d539e" : "#f3f4f6",
      color: isClient ? "white" : "#111827",
    },
  });

  // Author
  content.appendChild(
    el("div", {
      text: escapeHtml(message.author_name || (isClient ? "You" : "WebNique Team")),
      style: {
        fontSize: "12px",
        fontWeight: "700",
        opacity: isClient ? "0.9" : "1",
        marginBottom: "4px",
        color: isClient ? "white" : "#6b7280",
      },
    })
  );

  // Message text
  content.appendChild(
    el("div", {
      text: escapeHtml(message.content || ""),
      style: {
        fontSize: "14px",
        lineHeight: "1.6",
        marginBottom: "6px",
        whiteSpace: "pre-wrap",
      },
    })
  );

  // Timestamp
  content.appendChild(
    el("div", {
      text: formatTimestamp(message.timestamp),
      style: {
        fontSize: "11px",
        opacity: "0.7",
      },
    })
  );

  bubble.appendChild(content);
  return bubble;
}

/**
 * Render thread metadata sidebar
 */
function renderThreadMetadata(side, thread) {
  side.innerHTML = "";

  const card = el("div", {
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "16px",
      padding: "20px",
    },
  });

  card.appendChild(
    el("h3", {
      text: "Request Details",
      style: {
        fontSize: "16px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "16px",
      },
    })
  );

  const details = [
    { label: "Status", value: thread.status || "open" },
    { label: "Priority", value: thread.priority || "normal" },
    { label: "Assigned To", value: thread.assigned_to || "WebNique Team" },
    { label: "Created", value: formatTimestamp(thread.created_at) },
    { label: "Last Updated", value: formatTimestamp(thread.last_updated) },
  ];

  if (thread.related_service) {
    details.push({ 
      label: "Related Service", 
      value: thread.related_service 
    });
  }

  details.forEach((detail, index) => {
    const row = el("div", {
      style: {
        padding: "12px 0",
        borderTop: index > 0 ? "1px solid #f3f4f6" : "none",
      },
    });

    row.appendChild(
      el("div", {
        text: detail.label,
        style: {
          fontSize: "12px",
          color: "#6b7280",
          fontWeight: "600",
          marginBottom: "4px",
        },
      })
    );

    row.appendChild(
      el("div", {
        text: escapeHtml(detail.value),
        style: {
          fontSize: "14px",
          color: "#111827",
          fontWeight: "600",
        },
      })
    );

    card.appendChild(row);
  });

  side.appendChild(card);
}

/**
 * Render empty state
 */
function renderEmptyState(threadList, messageView) {
  threadList.innerHTML = "";
  messageView.innerHTML = "";

  const empty = el("div", {
    style: {
      textAlign: "center",
      padding: "60px 40px",
    },
  });

  empty.appendChild(
    el("div", {
      text: "📭",
      style: {
        fontSize: "64px",
        marginBottom: "20px",
      },
    })
  );

  empty.appendChild(
    el("h3", {
      text: "No Requests Yet",
      style: {
        fontSize: "20px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "12px",
      },
    })
  );

  empty.appendChild(
    el("p", {
      text: "You don't have any support requests at the moment.",
      style: {
        fontSize: "14px",
        color: "#6b7280",
        lineHeight: "1.6",
      },
    })
  );

  messageView.appendChild(empty);
}

/**
 * Format timestamp
 */
function formatTimestamp(timestamp) {
  if (!timestamp) return "Unknown";

  try {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / (1000 * 60));

    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
    if (diffMins < 2880) return "Yesterday";

    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
    });
  } catch (e) {
    return "Unknown";
  }
}

/**
 * Show error
 */
function showError(container, message) {
  container.innerHTML = "";
  container.appendChild(
    el("div", {
      class: "wnq-alert wnq-alert-danger",
      style: { margin: "20px" },
      html: `<strong>Error:</strong> ${escapeHtml(message)}`,
    })
  );
}