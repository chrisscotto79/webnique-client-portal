<?php
/**
 * Analytics Admin - DIAGNOSTIC VERSION
 * 
 * This version includes extensive logging to diagnose why data is returning as 0
 */

namespace WNQ\Admin;

use WNQ\Models\AnalyticsConfig;

if (!defined('ABSPATH')) exit;

final class AnalyticsAdmin
{
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addSubmenu'], 20);
        add_action('admin_enqueue_scripts', [self::class, 'enqueueAssets'], 999);
        add_action('admin_post_wnq_save_analytics_settings', [self::class, 'handleSaveSettings']);
        add_action('wp_ajax_wnq_get_analytics_data', [self::class, 'ajaxGetAnalyticsData']);
    }

    public static function addSubmenu(): void
    {
        $capability = current_user_can('wnq_manage_portal') ? 'wnq_manage_portal' : 'manage_options';
        add_submenu_page('wnq-portal', 'Analytics', 'Analytics', $capability, 'wnq-analytics', [self::class, 'render']);
    }

    public static function enqueueAssets($hook): void
    {
        if (!isset($_GET['page']) || $_GET['page'] !== 'wnq-analytics') return;
        wp_enqueue_script('jquery');
        wp_enqueue_style('wnq-analytics', plugin_dir_url(dirname(__FILE__)) . 'assets/admin/analytics-dashboard.css', [], time());
    }

    public static function render(): void
    {
        if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions.'));
        }

        $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : 'dashboard';
        
        if ($view === 'settings') {
            self::renderSettings();
        } else {
            self::renderDashboard();
        }
    }

    private static function renderDashboard(): void
    {
        $client_id = self::getCurrentClientId();
        $config = AnalyticsConfig::getClientConfig($client_id);
        $credentials = AnalyticsConfig::getCredentials();

        if (!$credentials || !$config) {
            echo '<div class="wrap"><h1>📊 Analytics Dashboard</h1>';
            echo '<div class="notice notice-warning"><p>Analytics not configured. <a href="' . admin_url('admin.php?page=wnq-analytics&view=settings') . '">Go to Settings →</a></p></div>';
            echo '</div>';
            return;
        }
        
        // Show current config for debugging
        echo '<div class="wrap">';
        echo '<h1>📊 Analytics Dashboard</h1>';
        echo '<div class="notice notice-info" style="padding: 15px; margin-bottom: 20px;">';
        echo '<p><strong>Configuration Status:</strong></p>';
        echo '<ul style="list-style: disc; margin-left: 20px;">';
        echo '<li>✅ Service Account: ' . esc_html($credentials['email'] ?? 'Unknown') . '</li>';
        echo '<li>✅ GA4 Property ID: <code>' . esc_html($config['ga4_property_id'] ?? 'Not set') . '</code></li>';
        echo '<li>✅ Website: ' . esc_html($config['website_url'] ?? 'Not set') . '</li>';
        echo '</ul>';
        echo '<p><small><strong>Note:</strong> If data shows as 0, check PHP error logs for detailed diagnostics.</small></p>';
        echo '</div>';
        ?>
        
        <div class="header-actions" style="margin-bottom: 20px;">
            <button type="button" id="wnq-refresh-data" class="button">🔄 Refresh Data</button>
            <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=settings'); ?>" class="button">⚙️ Settings</a>
            <select id="wnq-date-range" class="button">
                <option value="7">Last 7 Days</option>
                <option value="30" selected>Last 30 Days</option>
                <option value="90">Last 90 Days</option>
            </select>
        </div>

        <div id="wnq-analytics-loading" style="padding: 40px; text-align: center; background: #fff; border: 1px solid #ddd;">
            <p>⏳ Loading analytics data...</p>
        </div>

        <div id="wnq-analytics-content" style="display: none;"></div>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
        
        <script>
        window.wnqAnalytics = {
            ajaxUrl: '<?php echo admin_url('admin-ajax.php'); ?>',
            nonce: '<?php echo wp_create_nonce('wnq_analytics_nonce'); ?>',
            clientId: '<?php echo self::getCurrentClientId(); ?>'
        };

        (function($) {
            function loadData(days) {
                console.log('Loading', days, 'days of data...');
                $('#wnq-analytics-loading').show();
                $('#wnq-analytics-content').hide();

                $.ajax({
                    url: wnqAnalytics.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'wnq_get_analytics_data',
                        nonce: wnqAnalytics.nonce,
                        client_id: wnqAnalytics.clientId,
                        date_range: days
                    },
                    success: function(resp) {
                        console.log('Response:', resp);
                        if (resp.success) {
                            renderData(resp.data);
                        } else {
                            showError(resp.data?.message || 'Failed to load data');
                        }
                    },
                    error: function(xhr) {
                        console.error('AJAX Error:', xhr);
                        showError('Error: ' + (xhr.responseText || 'Unknown error'));
                    },
                    complete: function() {
                        $('#wnq-refresh-data').prop('disabled', false).text('🔄 Refresh Data');
                    }
                });
            }

            function renderData(data) {
                let html = '<div style="padding: 20px; background: #fff; border: 1px solid #ddd;">';
                
                html += '<h2>📊 Overview</h2>';
                html += '<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin: 20px 0;">';
                html += '<div style="padding: 20px; background: #f0f0f0; border-radius: 4px;"><h3>Visitors</h3><div style="font-size: 32px; font-weight: bold;">' + (data.overview.total_users || 0) + '</div></div>';
                html += '<div style="padding: 20px; background: #f0f0f0; border-radius: 4px;"><h3>Page Views</h3><div style="font-size: 32px; font-weight: bold;">' + (data.overview.page_views || 0) + '</div></div>';
                html += '<div style="padding: 20px; background: #f0f0f0; border-radius: 4px;"><h3>Sessions</h3><div style="font-size: 32px; font-weight: bold;">' + (data.overview.sessions || 0) + '</div></div>';
                html += '<div style="padding: 20px; background: #f0f0f0; border-radius: 4px;"><h3>Bounce Rate</h3><div style="font-size: 32px; font-weight: bold;">' + (data.overview.bounce_rate || 0).toFixed(1) + '%</div></div>';
                html += '</div>';
                
                // Debug info
                html += '<div style="margin-top: 20px; padding: 15px; background: #fffbcc; border: 1px solid #e6db55; border-radius: 4px;">';
                html += '<h4>🔍 Debug Information</h4>';
                html += '<p><strong>Data received:</strong></p>';
                html += '<pre style="background: #fff; padding: 10px; overflow: auto;">' + JSON.stringify(data, null, 2) + '</pre>';
                html += '<p><strong>Troubleshooting:</strong></p>';
                html += '<ul style="margin-left: 20px;">';
                html += '<li>If all values are 0, check PHP error logs for API errors</li>';
                html += '<li>Verify service account has Viewer access to GA4 property</li>';
                html += '<li>Confirm GA4 Property ID format: properties/123456789</li>';
                html += '</ul>';
                html += '</div>';
                
                html += '</div>';
                
                $('#wnq-analytics-content').html(html).show();
                $('#wnq-analytics-loading').hide();
            }

            function showError(msg) {
                $('#wnq-analytics-content').html('<div class="notice notice-error" style="padding: 20px;"><p><strong>Error:</strong> ' + msg + '</p></div>').show();
                $('#wnq-analytics-loading').hide();
            }

            $('#wnq-refresh-data').on('click', function() {
                $(this).prop('disabled', true).text('⏳ Loading...');
                loadData(parseInt($('#wnq-date-range').val()));
            });

            $('#wnq-date-range').on('change', function() {
                loadData(parseInt($(this).val()));
            });

            $(document).ready(function() {
                loadData(30);
            });
        })(jQuery);
        </script>
        <?php
    }

    private static function renderSettings(): void
    {
        $client_id = self::getCurrentClientId();
        $config = AnalyticsConfig::getClientConfig($client_id);
        $credentials = AnalyticsConfig::getCredentials();
        ?>
        <div class="wrap">
            <h1>Analytics Settings</h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-analytics'); ?>" class="button">← Back to Dashboard</a>

            <?php if (isset($_GET['saved'])): ?><div class="notice notice-success"><p>✅ Settings saved!</p></div><?php endif; ?>
            <?php if (isset($_GET['error'])): ?><div class="notice notice-error"><p>❌ Error: <?php echo esc_html($_GET['message'] ?? 'Unknown'); ?></p></div><?php endif; ?>

            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" enctype="multipart/form-data" style="margin-top: 20px;">
                <?php wp_nonce_field('wnq_save_analytics_settings'); ?>
                <input type="hidden" name="action" value="wnq_save_analytics_settings">
                
                <table class="form-table">
                    <tr>
                        <th>Service Account JSON</th>
                        <td>
                            <input type="file" name="credentials_file" accept=".json">
                            <?php if ($credentials): ?>
                                <p class="description">✅ Current: <?php echo esc_html($credentials['email']); ?></p>
                            <?php else: ?>
                                <p class="description">⚠️ No credentials uploaded</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Client Name</th>
                        <td><input type="text" name="client_name" value="<?php echo esc_attr($config['client_name'] ?? 'WebNique'); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>GA4 Property ID</th>
                        <td>
                            <input type="text" name="ga4_property_id" value="<?php echo esc_attr($config['ga4_property_id'] ?? ''); ?>" class="regular-text" placeholder="properties/123456789">
                            <p class="description"><strong>IMPORTANT:</strong> Must start with "properties/" - Get from GA4 Admin → Property Settings → Property Details</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Website URL</th>
                        <td><input type="url" name="website_url" value="<?php echo esc_attr($config['website_url'] ?? ''); ?>" class="regular-text" placeholder="https://example.com"></td>
                    </tr>
                </table>

                <p class="submit"><button type="submit" class="button button-primary">💾 Save Settings</button></p>
            </form>

            <hr>
            
            <h2>📋 Setup Instructions</h2>
            <ol style="line-height: 2;">
                <li><strong>Service Account:</strong> Upload the JSON file from Google Cloud Console</li>
                <li><strong>Add Service Account to GA4:</strong>
                    <ul style="margin-left: 30px;">
                        <li>Go to GA4 → Admin → Property Access Management</li>
                        <li>Click "+" and add the service account email: <code><?php echo esc_html($credentials['email'] ?? 'Upload credentials first'); ?></code></li>
                        <li>Give it "Viewer" role</li>
                    </ul>
                </li>
                <li><strong>Get Property ID:</strong> GA4 → Admin → Property Settings → Property Details → Copy Property ID</li>
                <li><strong>Save & Test:</strong> Save settings and refresh the dashboard</li>
            </ol>
        </div>
        <?php
    }

    public static function ajaxGetAnalyticsData(): void
    {
        error_log('========================================');
        error_log('WNQ ANALYTICS AJAX REQUEST STARTED');
        error_log('========================================');
        
        try {
            if (!check_ajax_referer('wnq_analytics_nonce', 'nonce', false)) {
                error_log('❌ Nonce verification failed');
                wp_send_json_error(['message' => 'Security check failed']);
                return;
            }

            if (!current_user_can('manage_options') && !current_user_can('wnq_manage_portal')) {
                error_log('❌ Permission denied');
                wp_send_json_error(['message' => 'Permission denied']);
                return;
            }

            $client_id = sanitize_text_field($_POST['client_id'] ?? '');
            $date_range = intval($_POST['date_range'] ?? 30);

            error_log('✓ Client ID: ' . $client_id);
            error_log('✓ Date Range: ' . $date_range . ' days');

            $config = AnalyticsConfig::getClientConfig($client_id);
            $credentials = AnalyticsConfig::getCredentials();

            if (!$config || !$credentials) {
                error_log('❌ Missing configuration or credentials');
                wp_send_json_error(['message' => 'Not configured']);
                return;
            }

            error_log('✓ Config loaded');
            error_log('✓ Service Account: ' . ($credentials['email'] ?? 'unknown'));
            error_log('✓ GA4 Property: ' . ($config['ga4_property_id'] ?? 'not set'));

            $data = self::fetchAnalyticsData($credentials['credentials'], $config['ga4_property_id'], $date_range);

            error_log('✅ SUCCESS - Data fetched');
            error_log('========================================');
            wp_send_json_success($data);

        } catch (\Exception $e) {
            error_log('❌ EXCEPTION: ' . $e->getMessage());
            error_log('Stack trace: ' . $e->getTraceAsString());
            error_log('========================================');
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }

    private static function fetchAnalyticsData(array $credentials, string $property_id, int $date_range): array
    {
        error_log('--- Fetching Analytics Data ---');
        
        $token = self::getGoogleAccessToken($credentials);
        error_log('✓ Access token obtained');

        $end_date = date('Y-m-d');
        $start_date = date('Y-m-d', strtotime("-{$date_range} days"));
        error_log('✓ Date range: ' . $start_date . ' to ' . $end_date);

        $data = ['overview' => [], 'visitors_over_time' => [], 'traffic_sources' => [], 'top_pages' => []];

        // Test with a simple request first
        try {
            error_log('--- Testing Basic Request ---');
            $test_req = [
                'dateRanges' => [['startDate' => $start_date, 'endDate' => $end_date]],
                'metrics' => [['name' => 'totalUsers']]
            ];
            
            $test_resp = self::makeGARequest($token, $property_id, $test_req);
            error_log('RAW API Response: ' . print_r($test_resp, true));
            
            if (isset($test_resp['rowCount'])) {
                error_log('✓ Row count: ' . $test_resp['rowCount']);
            }
            
            if (isset($test_resp['rows'])) {
                error_log('✓ Has rows: ' . count($test_resp['rows']));
                error_log('✓ First row: ' . print_r($test_resp['rows'][0] ?? 'none', true));
            } else {
                error_log('⚠️ NO ROWS in response - this is why data is 0');
            }
            
        } catch (\Exception $e) {
            error_log('❌ Test request failed: ' . $e->getMessage());
        }

        // Fetch overview
        try {
            $data['overview'] = self::fetchOverviewStats($token, $property_id, $start_date, $end_date);
            error_log('✓ Overview: Users=' . $data['overview']['total_users'] . ', Views=' . $data['overview']['page_views']);
        } catch (\Exception $e) {
            error_log('❌ Overview failed: ' . $e->getMessage());
            $data['overview'] = ['total_users' => 0, 'page_views' => 0, 'sessions' => 0, 'bounce_rate' => 0];
        }

        // Fetch visitors over time
        try {
            $data['visitors_over_time'] = self::fetchVisitorsOverTime($token, $property_id, $start_date, $end_date);
            error_log('✓ Visitors over time: ' . count($data['visitors_over_time']) . ' days');
        } catch (\Exception $e) {
            error_log('❌ Visitors over time failed: ' . $e->getMessage());
            $data['visitors_over_time'] = [];
        }

        // Fetch traffic sources
        try {
            $data['traffic_sources'] = self::fetchTrafficSources($token, $property_id, $start_date, $end_date);
            error_log('✓ Traffic sources: ' . count($data['traffic_sources']) . ' channels');
        } catch (\Exception $e) {
            error_log('❌ Traffic sources failed: ' . $e->getMessage());
            $data['traffic_sources'] = [];
        }

        // Fetch top pages
        try {
            $data['top_pages'] = self::fetchTopPages($token, $property_id, $start_date, $end_date);
            error_log('✓ Top pages: ' . count($data['top_pages']) . ' pages');
        } catch (\Exception $e) {
            error_log('❌ Top pages failed: ' . $e->getMessage());
            $data['top_pages'] = [];
        }

        return $data;
    }

    private static function getGoogleAccessToken(array $credentials): string
    {
        $cached = get_transient('wnq_ga_access_token');
        if ($cached) {
            error_log('✓ Using cached token');
            return $cached;
        }

        error_log('--- Generating New Access Token ---');
        
        $now = time();
        $header = ['alg' => 'RS256', 'typ' => 'JWT'];
        $claim = [
            'iss' => $credentials['client_email'],
            'scope' => 'https://www.googleapis.com/auth/analytics.readonly',
            'aud' => 'https://oauth2.googleapis.com/token',
            'exp' => $now + 3600,
            'iat' => $now
        ];

        $segments = [
            self::base64UrlEncode(wp_json_encode($header)),
            self::base64UrlEncode(wp_json_encode($claim))
        ];
        $signing_input = implode('.', $segments);

        $signature = '';
        if (!openssl_sign($signing_input, $signature, $credentials['private_key'], 'SHA256')) {
            throw new \Exception('JWT signing failed');
        }

        $segments[] = self::base64UrlEncode($signature);
        $jwt = implode('.', $segments);

        error_log('✓ JWT created, requesting token...');

        $response = wp_remote_post('https://oauth2.googleapis.com/token', [
            'body' => [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $jwt
            ],
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            throw new \Exception('Token request failed: ' . $response->get_error_message());
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!isset($body['access_token'])) {
            $error = $body['error_description'] ?? $body['error'] ?? 'Unknown error';
            error_log('❌ Token request response: ' . print_r($body, true));
            throw new \Exception('Token failed: ' . $error);
        }

        $token = $body['access_token'];
        set_transient('wnq_ga_access_token', $token, 3000);
        error_log('✓ New token obtained and cached');
        
        return $token;
    }

    private static function fetchOverviewStats(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'metrics' => [
                ['name' => 'totalUsers'],
                ['name' => 'screenPageViews'],
                ['name' => 'sessions'],
                ['name' => 'bounceRate']
            ]
        ]);
        
        $m = $data['rows'][0]['metricValues'] ?? [];
        return [
            'total_users' => isset($m[0]) ? intval($m[0]['value']) : 0,
            'page_views' => isset($m[1]) ? intval($m[1]['value']) : 0,
            'sessions' => isset($m[2]) ? intval($m[2]['value']) : 0,
            'bounce_rate' => isset($m[3]) ? floatval($m[3]['value']) * 100 : 0
        ];
    }

    private static function fetchVisitorsOverTime(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'date']],
            'metrics' => [['name' => 'totalUsers'], ['name' => 'sessions']],
            'orderBys' => [['dimension' => ['dimensionName' => 'date']]]
        ]);
        
        $trends = [];
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $date = $row['dimensionValues'][0]['value'];
                $trends[] = [
                    'date' => substr($date, 0, 4) . '-' . substr($date, 4, 2) . '-' . substr($date, 6, 2),
                    'users' => intval($row['metricValues'][0]['value']),
                    'sessions' => intval($row['metricValues'][1]['value'])
                ];
            }
        }
        return $trends;
    }

    private static function fetchTrafficSources(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'sessionDefaultChannelGroup']],
            'metrics' => [['name' => 'sessions'], ['name' => 'totalUsers']],
            'orderBys' => [['metric' => ['metricName' => 'sessions'], 'desc' => true]],
            'limit' => 10
        ]);
        
        $sources = [];
        $total = 0;
        
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $total += intval($row['metricValues'][0]['value']);
            }
            foreach ($data['rows'] as $row) {
                $sessions = intval($row['metricValues'][0]['value']);
                $sources[] = [
                    'channel' => $row['dimensionValues'][0]['value'],
                    'sessions' => $sessions,
                    'users' => intval($row['metricValues'][1]['value']),
                    'percentage' => $total > 0 ? round(($sessions / $total) * 100, 1) : 0
                ];
            }
        }
        return $sources;
    }

    private static function fetchTopPages(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'pagePath'], ['name' => 'pageTitle']],
            'metrics' => [['name' => 'screenPageViews'], ['name' => 'bounceRate']],
            'orderBys' => [['metric' => ['metricName' => 'screenPageViews'], 'desc' => true]],
            'limit' => 10
        ]);
        
        $pages = [];
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $pages[] = [
                    'path' => $row['dimensionValues'][0]['value'],
                    'title' => $row['dimensionValues'][1]['value'] ?? 'Untitled',
                    'views' => intval($row['metricValues'][0]['value']),
                    'bounce_rate' => floatval($row['metricValues'][1]['value'] ?? 0) * 100
                ];
            }
        }
        return $pages;
    }

    private static function makeGARequest(string $token, string $property_id, array $body): array
    {
        $url = "https://analyticsdata.googleapis.com/v1beta/{$property_id}:runReport";
        
        error_log('Making GA request to: ' . $url);
        error_log('Request body: ' . json_encode($body));
        
        $response = wp_remote_post($url, [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
            'body' => wp_json_encode($body),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            throw new \Exception('GA API failed: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        error_log('GA Response code: ' . $code);
        error_log('GA Response body: ' . substr($response_body, 0, 500));
        
        $data = json_decode($response_body, true);

        if ($code !== 200) {
            $error = $data['error']['message'] ?? "HTTP {$code}";
            error_log('❌ GA API Error: ' . $error);
            throw new \Exception('GA API error: ' . $error);
        }

        if (!$data) throw new \Exception('Invalid GA response');
        return $data;
    }

    private static function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    public static function handleSaveSettings(): void
    {
        check_admin_referer('wnq_save_analytics_settings');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $client_id = self::getCurrentClientId();

        if (isset($_FILES['credentials_file']) && $_FILES['credentials_file']['size'] > 0) {
            $file = $_FILES['credentials_file'];
            
            if (!str_ends_with($file['name'], '.json')) {
                wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&error=1&message=' . urlencode('Must be .json file')));
                exit;
            }

            $json = file_get_contents($file['tmp_name']);
            $creds = json_decode($json, true);

            if (!$creds || !isset($creds['client_email']) || !isset($creds['private_key'])) {
                wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&error=1&message=' . urlencode('Invalid JSON')));
                exit;
            }

            AnalyticsConfig::saveCredentials($creds);
        }

        $config = [
            'client_id' => $client_id,
            'client_name' => sanitize_text_field($_POST['client_name'] ?? 'WebNique'),
            'ga4_property_id' => sanitize_text_field($_POST['ga4_property_id'] ?? ''),
            'website_url' => esc_url_raw($_POST['website_url'] ?? ''),
            'timezone' => 'America/New_York'
        ];

        AnalyticsConfig::saveClientConfig($config);
        
        // Clear token cache when settings change
        delete_transient('wnq_ga_access_token');
        
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&saved=1'));
        exit;
    }

    private static function getCurrentClientId(): string
    {
        return 'web-nique';
    }
}