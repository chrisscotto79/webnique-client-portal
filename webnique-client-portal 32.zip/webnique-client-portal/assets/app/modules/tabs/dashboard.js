// assets/app/modules/tabs/dashboard.js
// Enhanced Dashboard Tab with Beautiful UI

import { el, pill, button, renderJson } from "../ui.js";

export function renderDashboard(main, side, state, shell) {
  main.innerHTML = "";
  side.innerHTML = "";

  // ========================================
  // MAIN CONTENT
  // ========================================

  // Header
  const header = el("div", {
    style: {
      marginBottom: "32px",
      paddingBottom: "20px",
      borderBottom: "2px solid rgba(2,6,23,0.08)",
    },
  });

  header.appendChild(
    el("h1", {
      text: "Dashboard",
      style: {
        fontSize: "32px",
        fontWeight: "900",
        color: "#111827",
        marginBottom: "8px",
        letterSpacing: "-0.02em",
      },
    })
  );

  header.appendChild(
    el("p", {
      text: "Welcome back! Here's an overview of your account.",
      style: {
        fontSize: "16px",
        color: "#6b7280",
        margin: "0",
      },
    })
  );

  main.appendChild(header);

  // Stats Grid
  const statsGrid = el("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
      gap: "16px",
      marginBottom: "32px",
    },
  });

  const stats = [
    {
      label: "Active Services",
      value: "3",
      change: "+2 this month",
      color: "#10b981",
    },
    {
      label: "Open Requests",
      value: "2",
      change: "1 pending",
      color: "#f59e0b",
    },
    {
      label: "Total Visits",
      value: "12.4K",
      change: "+18% vs last month",
      color: "#0d539e",
    },
  ];

  stats.forEach((stat) => {
    const card = el("div", {
      style: {
        background: "white",
        border: "1px solid #e5e7eb",
        borderRadius: "12px",
        padding: "20px",
        transition: "all 0.2s ease",
      },
    });

    // Add hover effect
    card.addEventListener("mouseenter", () => {
      card.style.transform = "translateY(-2px)";
      card.style.boxShadow = "0 4px 6px rgba(0,0,0,0.1)";
    });
    card.addEventListener("mouseleave", () => {
      card.style.transform = "translateY(0)";
      card.style.boxShadow = "none";
    });

    card.appendChild(
      el("div", {
        text: stat.label,
        style: {
          fontSize: "13px",
          fontWeight: "600",
          color: "#6b7280",
          textTransform: "uppercase",
          letterSpacing: "0.05em",
          marginBottom: "8px",
        },
      })
    );

    card.appendChild(
      el("div", {
        text: stat.value,
        style: {
          fontSize: "32px",
          fontWeight: "900",
          color: "#111827",
          marginBottom: "4px",
          lineHeight: "1",
        },
      })
    );

    card.appendChild(
      el("div", {
        text: stat.change,
        style: {
          fontSize: "13px",
          color: stat.color,
          fontWeight: "600",
        },
      })
    );

    statsGrid.appendChild(card);
  });

  main.appendChild(statsGrid);

  // Recent Activity Section
  const activitySection = el("div", {
    style: {
      marginBottom: "32px",
    },
  });

  activitySection.appendChild(
    el("h2", {
      text: "Recent Activity",
      style: {
        fontSize: "20px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "16px",
      },
    })
  );

  const activityCard = el("div", {
    class: "wnq-card",
  });

  const activities = [
    {
      title: "SEO Report Generated",
      time: "2 hours ago",
      icon: "📊",
      status: "completed",
    },
    {
      title: "New Support Ticket",
      time: "5 hours ago",
      icon: "💬",
      status: "pending",
    },
    {
      title: "Monthly Invoice Paid",
      time: "Yesterday",
      icon: "✅",
      status: "completed",
    },
  ];

  activities.forEach((activity, index) => {
    const item = el("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: "16px",
        padding: "16px 0",
        borderBottom:
          index < activities.length - 1 ? "1px solid #e5e7eb" : "none",
      },
    });

    // Icon
    item.appendChild(
      el("div", {
        text: activity.icon,
        style: {
          fontSize: "24px",
          width: "48px",
          height: "48px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#f3f4f6",
          borderRadius: "12px",
        },
      })
    );

    // Content
    const content = el("div", { style: { flex: "1" } });
    content.appendChild(
      el("div", {
        text: activity.title,
        style: {
          fontSize: "15px",
          fontWeight: "600",
          color: "#111827",
          marginBottom: "4px",
        },
      })
    );
    content.appendChild(
      el("div", {
        text: activity.time,
        style: {
          fontSize: "13px",
          color: "#6b7280",
        },
      })
    );

    item.appendChild(content);

    // Status
    item.appendChild(
      pill(
        activity.status === "completed" ? "Completed" : "Pending",
        activity.status === "completed" ? "good" : "warn"
      )
    );

    activityCard.appendChild(item);
  });

  activitySection.appendChild(activityCard);
  main.appendChild(activitySection);

  // Quick Actions
  const actionsSection = el("div", {});

  actionsSection.appendChild(
    el("h2", {
      text: "Quick Actions",
      style: {
        fontSize: "20px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "16px",
      },
    })
  );

  const actionsGrid = el("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
      gap: "12px",
    },
  });

  const actions = [
    { label: "View Reports", icon: "📈" },
    { label: "New Request", icon: "➕" },
    { label: "Contact Support", icon: "💬" },
    { label: "View Invoices", icon: "🧾" },
  ];

  actions.forEach((action) => {
    const actionBtn = button(
      state,
      `${action.icon} ${action.label}`,
      () => {
        alert(`${action.label} clicked!`);
      },
      "outline"
    );

    actionBtn.style.padding = "16px";
    actionBtn.style.fontSize = "14px";
    actionBtn.style.textAlign = "center";

    actionsGrid.appendChild(actionBtn);
  });

  actionsSection.appendChild(actionsGrid);
  main.appendChild(actionsSection);

  // ========================================
  // SIDEBAR CONTENT
  // ========================================

  // Account Overview
  const accountCard = el("div", {
    style: {
      background: "linear-gradient(135deg, #0d539e 0%, #0a4380 100%)",
      borderRadius: "16px",
      padding: "24px",
      color: "white",
      marginBottom: "20px",
    },
  });

  accountCard.appendChild(
    el("div", {
      text: "ACCOUNT STATUS",
      style: {
        fontSize: "11px",
        fontWeight: "700",
        letterSpacing: "0.1em",
        opacity: "0.8",
        marginBottom: "12px",
      },
    })
  );

  accountCard.appendChild(
    el("div", {
      text: "Active",
      style: {
        fontSize: "28px",
        fontWeight: "900",
        marginBottom: "16px",
      },
    })
  );

  const statusDetails = [
    { label: "Subscription", value: "Pro Plan" },
    { label: "Renewal", value: "Mar 15, 2026" },
    { label: "Support", value: "Priority" },
  ];

  statusDetails.forEach((detail) => {
    const row = el("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        padding: "8px 0",
        borderTop: "1px solid rgba(255,255,255,0.1)",
        fontSize: "13px",
      },
    });

    row.appendChild(
      el("span", { text: detail.label, style: { opacity: "0.8" } })
    );
    row.appendChild(
      el("span", { text: detail.value, style: { fontWeight: "600" } })
    );

    accountCard.appendChild(row);
  });

  side.appendChild(accountCard);

  // Quick Links
  const linksCard = el("div", {
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "16px",
      padding: "20px",
      marginBottom: "20px",
    },
  });

  linksCard.appendChild(
    el("h3", {
      text: "Quick Links",
      style: {
        fontSize: "16px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "16px",
      },
    })
  );

  const links = [
    "📄 Documentation",
    "💳 Billing Portal",
    "🎓 Learning Center",
    "📞 Contact Us",
  ];

  links.forEach((link, index) => {
    const linkEl = el("div", {
      text: link,
      style: {
        padding: "12px",
        borderRadius: "8px",
        cursor: "pointer",
        fontSize: "14px",
        fontWeight: "600",
        color: "#374151",
        marginBottom: index < links.length - 1 ? "8px" : "0",
        transition: "all 0.2s ease",
      },
    });

    linkEl.addEventListener("mouseenter", () => {
      linkEl.style.background = "#f3f4f6";
      linkEl.style.color = "#0d539e";
    });

    linkEl.addEventListener("mouseleave", () => {
      linkEl.style.background = "transparent";
      linkEl.style.color = "#374151";
    });

    linksCard.appendChild(linkEl);
  });

  side.appendChild(linksCard);

  // Support Widget
  const supportCard = el("div", {
    style: {
      background: "#fef3c7",
      border: "1px solid #fde047",
      borderRadius: "16px",
      padding: "20px",
    },
  });

  supportCard.appendChild(
    el("div", {
      text: "💡",
      style: {
        fontSize: "32px",
        marginBottom: "12px",
      },
    })
  );

  supportCard.appendChild(
    el("h3", {
      text: "Need Help?",
      style: {
        fontSize: "16px",
        fontWeight: "800",
        color: "#78350f",
        marginBottom: "8px",
      },
    })
  );

  supportCard.appendChild(
    el("p", {
      text: "Our support team is here to help you 24/7.",
      style: {
        fontSize: "13px",
        color: "#92400e",
        marginBottom: "12px",
        lineHeight: "1.5",
      },
    })
  );

  const supportBtn = button(
    state,
    "Contact Support",
    () => {
      alert("Opening support chat...");
    },
    "solid"
  );

  supportBtn.style.width = "100%";
  supportBtn.style.background = "#f59e0b";
  supportBtn.style.borderColor = "#f59e0b";

  supportCard.appendChild(supportBtn);
  side.appendChild(supportCard);
}