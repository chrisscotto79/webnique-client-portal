<?php

namespace WNQ\Core;

if (!defined('ABSPATH')) {
  exit;
}

final class Router
{
  public static function register(): void
  {
    add_action('rest_api_init', function () {
      // v1: only ping lives in DashboardController
      \WNQ\Controllers\DashboardController::registerRoutes();

      // Later:
      // \WNQ\Controllers\ThreadsController::registerRoutes();
      // \WNQ\Controllers\MessagesController::registerRoutes();
      // \WNQ\Controllers\SubscriptionController::registerRoutes();
      // \WNQ\Controllers\AnalyticsController::registerRoutes();
      // \WNQ\Controllers\SettingsController::registerRoutes();
    });
  }
}
