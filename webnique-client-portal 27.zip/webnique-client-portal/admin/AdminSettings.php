<?php

namespace WNQ\Admin;

use WNQ\Services\FirebaseStore;

if (!defined('ABSPATH')) {
  exit;
}

final class AdminSettings
{
  private const NONCE_ACTION = 'wnq_create_client';
  private const NONCE_FIELD  = 'wnq_create_client_nonce';

  public static function render(): void
  {
    if (!current_user_can('manage_options') && !current_user_can('wnq_manage_portal')) {
      wp_die('Sorry, you are not allowed to access this page.');
    }

    $notice = null; // ['type' => 'success|error|warning', 'message' => '...']

    // Handle form submit
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['wnq_action']) && $_POST['wnq_action'] === 'create_client') {
      $notice = self::handleCreateClientPost();
    }

    echo '<div class="wrap">';
    echo '<h1>WebNique Portal Settings</h1>';
    echo '<p>Create a client (Firestore doc + WP user + meta link).</p>';

    if (is_array($notice)) {
      $class = $notice['type'] === 'success' ? 'notice notice-success' : ($notice['type'] === 'warning' ? 'notice notice-warning' : 'notice notice-error');
      echo '<div class="' . esc_attr($class) . '"><p>' . esc_html($notice['message']) . '</p></div>';
    }

    // Render form
    echo '<hr/>';

    echo '<h2>Create Client</h2>';
    echo '<form method="post" action="">';

    wp_nonce_field(self::NONCE_ACTION, self::NONCE_FIELD);

    echo '<input type="hidden" name="wnq_action" value="create_client" />';

    echo '<table class="form-table" role="presentation"><tbody>';

    self::rowText('client_name', 'Client Name', 'Primary contact name (optional).');
    self::rowText('client_business', 'Client Business', 'Business name (required).', true);
    self::rowText('client_domain', 'Client Domain', 'Example: example.com (required).', true);
    self::rowSelect('client_tier', 'Client Tier', [
      'starter'   => 'Starter',
      'seo_growth'=> 'SEO Growth',
      'ads_growth'=> 'Google Ads Growth',
      'ecom'      => 'E-Commerce',
      'custom'    => 'Custom',
    ], 'starter');

    self::rowText('client_address', 'Client Address', 'Optional.');
    self::rowText('client_phone', 'Client Phone Number', 'Optional.');
    self::rowText('client_email', 'Client Email Address', 'This becomes the WP login (required).', true);
    self::rowPassword('client_password', 'Client Password', 'Leave blank to auto-generate. (We do NOT store this in Firestore)');

    echo '</tbody></table>';

    submit_button('Create Client');

    echo '</form>';

    echo '<hr/>';
    echo '<p style="color:#64748b;">v1 uses wp-config.php constants for Firebase. This page only creates clients and links WP users.</p>';

    echo '</div>';
  }

  private static function handleCreateClientPost(): array
  {
    // Nonce
    if (!isset($_POST[self::NONCE_FIELD]) || !wp_verify_nonce(sanitize_text_field($_POST[self::NONCE_FIELD]), self::NONCE_ACTION)) {
      return ['type' => 'error', 'message' => 'Security check failed (nonce). Please try again.'];
    }

    // Sanitize inputs
    $clientName     = isset($_POST['client_name']) ? sanitize_text_field($_POST['client_name']) : '';
    $clientBusiness = isset($_POST['client_business']) ? sanitize_text_field($_POST['client_business']) : '';
    $clientDomain   = isset($_POST['client_domain']) ? sanitize_text_field($_POST['client_domain']) : '';
    $clientTier     = isset($_POST['client_tier']) ? sanitize_text_field($_POST['client_tier']) : 'starter';
    $clientAddress  = isset($_POST['client_address']) ? sanitize_text_field($_POST['client_address']) : '';
    $clientPhone    = isset($_POST['client_phone']) ? sanitize_text_field($_POST['client_phone']) : '';
    $clientEmail    = isset($_POST['client_email']) ? sanitize_email($_POST['client_email']) : '';
    $clientPassword = isset($_POST['client_password']) ? (string) $_POST['client_password'] : '';

    // Validate required
    if ($clientBusiness === '' || $clientDomain === '' || $clientEmail === '') {
      return ['type' => 'error', 'message' => 'Please fill in Client Business, Client Domain, and Client Email Address.'];
    }

    if (!is_email($clientEmail)) {
      return ['type' => 'error', 'message' => 'Client Email Address is not valid.'];
    }

    // Normalize domain
    $clientDomain = self::normalizeDomain($clientDomain);
    if ($clientDomain === '') {
      return ['type' => 'error', 'message' => 'Client Domain is invalid. Example: example.com'];
    }

    // Generate client_id (slug-like, stable)
    $clientId = self::generateClientId($clientBusiness, $clientDomain);

    // Create or link WP user
    $userId = email_exists($clientEmail);
    $createdNewUser = false;

    if (!$userId) {
      $username = self::generateUniqueUsernameFromEmail($clientEmail);

      // Auto-generate password if blank
      if (trim($clientPassword) === '') {
        $clientPassword = wp_generate_password(14, true, true);
      }

      $userId = wp_create_user($username, $clientPassword, $clientEmail);

      if (is_wp_error($userId)) {
        return ['type' => 'error', 'message' => 'WP user creation failed: ' . $userId->get_error_message()];
      }

      $createdNewUser = true;

      // Optional: set role
      $wpUser = get_user_by('id', (int) $userId);
      if ($wpUser) {
        // Change this if you have a custom role later. For now "subscriber" is fine.
        $wpUser->set_role('subscriber');
      }
    }

    // Link user to client
    update_user_meta((int) $userId, 'wnq_client_id', $clientId);
    if ($clientName !== '') {
      update_user_meta((int) $userId, 'wnq_contact_name', $clientName);
    }

    // Create Firestore client doc
    $firebase = new FirebaseStore();

    $now = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));

    $payload = [
      'client_id'   => $clientId,
      'status'      => 'active',
      'name'        => $clientBusiness,
      'business'    => $clientBusiness,
      'contact_name'=> $clientName,
      'domain'      => $clientDomain,
      'tier_key'    => $clientTier,
      'address'     => $clientAddress,
      'phone'       => $clientPhone,
      'email'       => $clientEmail,
      'wp_user_id'  => (int) $userId,
      'created_at'  => $now,
      'updated_at'  => $now,
      'created_by_wp_user_id' => get_current_user_id(),
    ];

    $res = $firebase->createClientDocIfMissing($clientId, $payload);

    if (!is_array($res) || empty($res['ok'])) {
      // If Firestore failed, keep WP user but warn (you can add rollback later if you want)
      $msg = 'Firestore create failed.';
      if (is_array($res)) {
        $msg .= ' ' . ($res['error'] ?? '');
      }
      return ['type' => 'error', 'message' => $msg];
    }

    // Success message
    $baseMsg = $createdNewUser
      ? 'Client created successfully. WP user created + linked + Firestore doc created.'
      : 'Client linked successfully. Existing WP user linked + Firestore doc ensured.';

    // If we auto-generated a password, you need to show it once (only if user was created and password was blank)
    if ($createdNewUser && (!isset($_POST['client_password']) || trim((string)$_POST['client_password']) === '')) {
      $baseMsg .= ' Generated password: ' . $clientPassword . ' (copy now; it is not stored).';
      return ['type' => 'warning', 'message' => $baseMsg];
    }

    return ['type' => 'success', 'message' => $baseMsg];
  }

  private static function normalizeDomain(string $domain): string
  {
    $d = strtolower(trim($domain));
    $d = preg_replace('#^https?://#', '', $d);
    $d = preg_replace('#^www\.#', '', $d);
    $d = rtrim($d, "/");
    // Basic allowlist
    if (!preg_match('/^[a-z0-9.-]+\.[a-z]{2,}$/', $d)) {
      return '';
    }
    return $d;
  }

  private static function generateClientId(string $business, string $domain): string
  {
    // Prefer business slug; add domain hash suffix for uniqueness
    $base = sanitize_title($business);
    if ($base === '') $base = 'client';

    $suffix = substr(md5($domain . '|' . $business), 0, 6);
    return $base . '_' . $suffix; // ex: "parrish-well-drilling_a1b2c3"
  }

  private static function generateUniqueUsernameFromEmail(string $email): string
  {
    $local = strtolower(trim(strtok($email, '@')));
    $local = preg_replace('/[^a-z0-9._-]/', '', $local);
    if ($local === '') $local = 'client';

    $username = $local;
    $i = 1;
    while (username_exists($username)) {
      $i++;
      $username = $local . $i;
      if ($i > 50) {
        // fallback
        $username = 'client' . wp_rand(1000, 9999);
        if (!username_exists($username)) break;
      }
    }
    return $username;
  }

  private static function rowText(string $name, string $label, string $desc = '', bool $required = false): void
  {
    echo '<tr>';
    echo '<th scope="row"><label for="' . esc_attr($name) . '">' . esc_html($label) . ($required ? ' <span style="color:#dc2626">*</span>' : '') . '</label></th>';
    echo '<td>';
    echo '<input name="' . esc_attr($name) . '" id="' . esc_attr($name) . '" type="text" class="regular-text" value="" />';
    if ($desc) echo '<p class="description">' . esc_html($desc) . '</p>';
    echo '</td>';
    echo '</tr>';
  }

  private static function rowPassword(string $name, string $label, string $desc = ''): void
  {
    echo '<tr>';
    echo '<th scope="row"><label for="' . esc_attr($name) . '">' . esc_html($label) . '</label></th>';
    echo '<td>';
    echo '<input name="' . esc_attr($name) . '" id="' . esc_attr($name) . '" type="password" class="regular-text" value="" autocomplete="new-password" />';
    if ($desc) echo '<p class="description">' . esc_html($desc) . '</p>';
    echo '</td>';
    echo '</tr>';
  }

  private static function rowSelect(string $name, string $label, array $options, string $default = ''): void
  {
    echo '<tr>';
    echo '<th scope="row"><label for="' . esc_attr($name) . '">' . esc_html($label) . '</label></th>';
    echo '<td>';
    echo '<select name="' . esc_attr($name) . '" id="' . esc_attr($name) . '">';
    foreach ($options as $value => $text) {
      $selected = selected($default, $value, false);
      echo '<option value="' . esc_attr($value) . '" ' . $selected . '>' . esc_html($text) . '</option>';
    }
    echo '</select>';
    echo '</td>';
    echo '</tr>';
  }
}
