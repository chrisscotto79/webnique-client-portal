<?php

namespace WNQ\Admin;

if (!defined('ABSPATH')) {
  exit;
}

final class AdminMenu
{
  public static function register(): void
  {
    add_action('admin_menu', [self::class, 'addMenu']);
  }

  public static function addMenu(): void
  {
    // Main menu
    add_menu_page(
      'WebNique Portal',
      'WebNique Portal',
      'manage_options', // or wnq_manage_portal later
      'wnq-portal',
      [self::class, 'renderRoot'],
      'dashicons-chart-area',
      58
    );

    // Settings submenu (this is where your Create Client form lives)
    add_submenu_page(
      'wnq-portal',
      'Portal Settings',
      'Settings',
      'manage_options',
      'wnq-portal-settings',
      [AdminSettings::class, 'render']
    );
  }

  public static function renderRoot(): void
  {
    echo '<div class="wrap">';
    echo '<h1>WebNique Portal</h1>';
    echo '<p>Use the Settings tab to create and manage clients.</p>';
    echo '</div>';
  }
}
