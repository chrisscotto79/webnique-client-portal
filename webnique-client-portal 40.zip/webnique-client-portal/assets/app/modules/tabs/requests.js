// assets/app/modules/tabs/requests.js
/**
 * Web Requests Tab - Clean & Spacious
 * 
 * Features:
 * - Single render (no duplicates)
 * - No right sidebar
 * - More space for conversation
 * - Open/Completed stats at top
 */

import { el, pill, button, escapeHtml } from "../ui.js";
import {
  initFirebase,
  getThreads,
  getMessages,
  sendMessage,
  createThread,
  subscribeToThreads,
  subscribeToMessages,
  markThreadAsRead,
} from "../services/firebase.js";

// State
let currentThreadId = null;
let threadsUnsubscribe = null;
let messagesUnsubscribe = null;
let allThreads = [];
let isInitialized = false;
let sidebarHidden = false;

export function renderRequests(main, side, state, shell) {
  // Prevent double render
  if (isInitialized) {
    console.log("[Requests] Already initialized, skipping");
    return;
  }
  
  isInitialized = true;
  main.innerHTML = "";
  side.innerHTML = "";

  // HIDE THE SHELL'S RIGHT SIDEBAR FOR THIS TAB
  if (side && side.parentElement && !sidebarHidden) {
    side.parentElement.style.display = "none";
    sidebarHidden = true;
  }
  
  // EXPAND MAIN AREA TO FULL WIDTH
  if (main && main.parentElement) {
    main.parentElement.style.gridColumn = "span 12";
  }

  if (shell?.setStatus) {
    shell.setStatus("Loading requests...", "neutral");
  }

  // Initialize Firebase & load
  initFirebase().then((success) => {
    if (!success) {
      showError(main, "Failed to initialize messaging system.");
      if (shell?.setStatus) {
        shell.setStatus("Error", "bad");
      }
      isInitialized = false;
      return;
    }

    loadAndRender(main, side, state, shell);
  });
}

/**
 * Main load and render function
 */
async function loadAndRender(main, side, state, shell) {
  try {
    // Unsubscribe previous
    if (threadsUnsubscribe) threadsUnsubscribe();

    // Show loading
    main.innerHTML = "";
    main.appendChild(
      el("div", {
        style: { padding: "40px", textAlign: "center" },
        html: '<div class="wnq-spinner"></div>',
      })
    );

    // Get threads
    const threads = await getThreads(state.clientId);
    allThreads = threads;

    if (shell?.setStatus) {
      shell.setStatus("Ready", "good");
    }

    // Render full interface
    main.innerHTML = "";
    renderInterface(main, side, state, threads, shell);

    // Subscribe to real-time updates
    threadsUnsubscribe = subscribeToThreads(state.clientId, (updated) => {
      allThreads = updated;
      console.log("[Requests] Updated:", updated.length, "threads");
      
      // Only update the stats and thread list, keep message view if open
      updateStatsAndList(main, updated, state, shell);
    });

  } catch (error) {
    console.error("[Requests] Load error:", error);
    showError(main, error.message);
    if (shell?.setStatus) {
      shell.setStatus("Error", "bad");
    }
    isInitialized = false;
  }
}

/**
 * Render complete interface
 */
function renderInterface(main, side, state, threads, shell) {
  // Header
  main.appendChild(createHeader(state, shell));

  // Stats cards
  const statsContainer = el("div", { id: "stats-container" });
  statsContainer.appendChild(createStatsCards(threads));
  main.appendChild(statsContainer);

  // Main layout (thread list + messages) - NO RIGHT SIDEBAR
  const layout = el("div", {
    id: "main-layout",
    style: {
      display: "grid",
      gridTemplateColumns: "340px 1fr", // Just 2 columns now
      gap: "20px",
      marginTop: "24px",
    },
  });

  // Thread list
  const threadList = el("div", {
    id: "thread-list-container",
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "12px",
      overflow: "hidden",
    },
  });

  // Message view (more space now!)
  const messageView = el("div", {
    id: "message-view-container",
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "12px",
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      minHeight: "600px",
    },
  });

  layout.appendChild(threadList);
  layout.appendChild(messageView);
  main.appendChild(layout);

  // Render threads
  if (threads.length === 0) {
    renderEmptyState(threadList, messageView);
  } else {
    renderThreadList(threadList, threads, (thread) => {
      loadMessagesForThread(messageView, state, thread);
    });
    
    // Auto-select first thread
    if (!currentThreadId || !threads.find(t => t.id === currentThreadId)) {
      loadMessagesForThread(messageView, state, threads[0]);
    }
  }
}

/**
 * Update stats and list without re-rendering everything
 */
function updateStatsAndList(main, threads, state, shell) {
  // Update stats
  const statsContainer = document.getElementById("stats-container");
  if (statsContainer) {
    statsContainer.innerHTML = "";
    statsContainer.appendChild(createStatsCards(threads));
  }

  // Update thread list
  const threadListContainer = document.getElementById("thread-list-container");
  if (threadListContainer) {
    const messageView = document.getElementById("message-view-container");
    renderThreadList(threadListContainer, threads, (thread) => {
      loadMessagesForThread(messageView, state, thread);
    });
  }
}

/**
 * Create header
 */
function createHeader(state, shell) {
  const header = el("div", {
    style: {
      marginBottom: "24px",
      paddingBottom: "20px",
      borderBottom: "2px solid #e5e7eb",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
    },
  });

  const titleSection = el("div");

  titleSection.appendChild(
    el("h1", {
      text: "Web Requests",
      style: {
        fontSize: "32px",
        fontWeight: "900",
        color: "#111827",
        marginBottom: "8px",
        letterSpacing: "-0.02em",
      },
    })
  );

  titleSection.appendChild(
    el("p", {
      text: "Communicate with the WebNique team about your website.",
      style: {
        fontSize: "16px",
        color: "#6b7280",
        margin: "0",
      },
    })
  );

  header.appendChild(titleSection);

  // New request button
  const newBtn = button(state, "+ New Request", () => {
    showNewThreadModal(state, shell);
  }, "solid");
  
  newBtn.style.background = "#0d539e";
  newBtn.style.borderColor = "#0d539e";
  header.appendChild(newBtn);

  return header;
}

/**
 * Create stats cards
 */
function createStatsCards(threads) {
  const container = el("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(2, 1fr)",
      gap: "20px",
      marginBottom: "24px",
    },
  });

  // Count open and completed
  const openCount = threads.filter(t => t.status === "open").length;
  const completedCount = threads.filter(t => t.status === "closed").length;

  // Open requests card
  const openCard = createStatCard({
    label: "OPEN REQUESTS",
    value: openCount,
    icon: "📝",
    color: "#0d539e",
  });

  // Completed requests card
  const completedCard = createStatCard({
    label: "COMPLETED REQUESTS",
    value: completedCount,
    icon: "✅",
    color: "#10b981",
  });

  container.appendChild(openCard);
  container.appendChild(completedCard);

  return container;
}

/**
 * Create stat card
 */
function createStatCard({ label, value, icon, color }) {
  const card = el("div", {
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "12px",
      padding: "24px",
      boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
      transition: "all 0.2s ease",
      cursor: "default",
    },
  });

  card.addEventListener("mouseenter", () => {
    card.style.transform = "translateY(-2px)";
    card.style.boxShadow = "0 4px 6px rgba(0,0,0,0.1)";
  });

  card.addEventListener("mouseleave", () => {
    card.style.transform = "translateY(0)";
    card.style.boxShadow = "0 1px 3px rgba(0,0,0,0.1)";
  });

  card.appendChild(
    el("div", {
      text: icon,
      style: { fontSize: "32px", marginBottom: "12px" },
    })
  );

  card.appendChild(
    el("div", {
      text: label,
      style: {
        fontSize: "12px",
        fontWeight: "700",
        color: "#6b7280",
        letterSpacing: "0.05em",
        marginBottom: "8px",
      },
    })
  );

  card.appendChild(
    el("div", {
      text: value.toString(),
      style: {
        fontSize: "48px",
        fontWeight: "900",
        color: color,
        lineHeight: "1",
      },
    })
  );

  return card;
}

/**
 * Render thread list
 */
function renderThreadList(container, threads, onThreadClick) {
  container.innerHTML = "";

  // Header
  const header = el("div", {
    style: {
      padding: "20px",
      borderBottom: "1px solid #e5e7eb",
      background: "#f9fafb",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
    },
  });

  header.appendChild(
    el("h3", {
      text: "All Requests",
      style: {
        fontSize: "16px",
        fontWeight: "800",
        color: "#111827",
        margin: "0",
      },
    })
  );

  header.appendChild(pill(`${threads.length}`, "neutral"));

  container.appendChild(header);

  // List
  const listContainer = el("div", {
    style: {
      maxHeight: "calc(100vh - 500px)",
      overflowY: "auto",
    },
  });

  const activeThreadId = currentThreadId || threads[0]?.id;

  threads.forEach((thread) => {
    const item = createThreadItem(thread, thread.id === activeThreadId);

    item.addEventListener("click", () => {
      currentThreadId = thread.id;

      // Update UI
      listContainer.querySelectorAll("[data-thread-item]").forEach((el) => {
        el.style.background = "white";
        el.style.borderLeft = "4px solid transparent";
      });

      item.style.background = "#f0f9ff";
      item.style.borderLeft = "4px solid #0d539e";

      markThreadAsRead(thread.id);
      onThreadClick(thread);
    });

    listContainer.appendChild(item);
  });

  container.appendChild(listContainer);
}

/**
 * Create thread item
 */
function createThreadItem(thread, isActive) {
  const item = el("div", {
    "data-thread-item": "true",
    style: {
      padding: "20px",
      borderBottom: "1px solid #f3f4f6",
      borderLeft: isActive ? "4px solid #0d539e" : "4px solid transparent",
      background: isActive ? "#f0f9ff" : "white",
      cursor: "pointer",
      transition: "all 0.2s ease",
      position: "relative",
    },
  });

  item.addEventListener("mouseenter", () => {
    if (!isActive) item.style.background = "#f9fafb";
  });

  item.addEventListener("mouseleave", () => {
    if (!isActive) item.style.background = "white";
  });

  // Subject
  item.appendChild(
    el("div", {
      text: escapeHtml(thread.subject || "Untitled"),
      style: {
        fontSize: "15px",
        fontWeight: "700",
        color: "#111827",
        marginBottom: "8px",
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
      },
    })
  );

  // Status
  item.appendChild(
    pill(
      escapeHtml(thread.status || "open"),
      thread.status === "closed" ? "neutral" : "good"
    )
  );

  // Time
  item.appendChild(
    el("div", {
      text: formatTimestamp(thread.last_updated),
      style: {
        fontSize: "12px",
        color: "#9ca3af",
        marginTop: "8px",
      },
    })
  );

  // Unread dot
  if (thread.unread) {
    item.appendChild(
      el("div", {
        style: {
          position: "absolute",
          top: "24px",
          right: "20px",
          width: "10px",
          height: "10px",
          borderRadius: "50%",
          background: "#0d539e",
        },
      })
    );
  }

  return item;
}

/**
 * Load messages for thread
 */
async function loadMessagesForThread(container, state, thread) {
  container.innerHTML = "";
  currentThreadId = thread.id;

  if (messagesUnsubscribe) messagesUnsubscribe();

  // Loading
  const loading = el("div", {
    style: {
      padding: "40px",
      textAlign: "center",
      flex: "1",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    },
  });
  loading.appendChild(el("div", { class: "wnq-spinner" }));
  container.appendChild(loading);

  try {
    const messages = await getMessages(thread.id);

    container.innerHTML = "";
    renderMessageView(container, thread, messages, state);

    // Real-time updates
    messagesUnsubscribe = subscribeToMessages(thread.id, (updated) => {
      const msgContainer = container.querySelector('[data-messages-container]');
      if (msgContainer) {
        const wasAtBottom = 
          msgContainer.scrollHeight - msgContainer.scrollTop - msgContainer.clientHeight < 50;

        msgContainer.innerHTML = "";
        updated.forEach((msg) => {
          msgContainer.appendChild(createMessageBubble(msg, state));
        });

        if (wasAtBottom) {
          msgContainer.scrollTop = msgContainer.scrollHeight;
        }
      }
    });

  } catch (error) {
    container.innerHTML = "";
    console.error("[Requests] Message load error:", error);
    showError(container, error.message);
  }
}

/**
 * Render message view - MORE SPACIOUS
 */
function renderMessageView(container, thread, messages, state) {
  // Header
  const header = el("div", {
    style: {
      padding: "24px 32px", // More padding
      borderBottom: "1px solid #e5e7eb",
      background: "#f9fafb",
    },
  });

  header.appendChild(
    el("h2", {
      text: escapeHtml(thread.subject || "Untitled"),
      style: {
        fontSize: "22px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "8px",
      },
    })
  );

  const meta = el("div", {
    style: { display: "flex", gap: "12px", alignItems: "center" },
  });

  meta.appendChild(
    pill(
      escapeHtml(thread.status || "open"),
      thread.status === "closed" ? "neutral" : "good"
    )
  );

  header.appendChild(meta);
  container.appendChild(header);

  // Messages - MORE SPACE
  const msgContainer = el("div", {
    "data-messages-container": "true",
    style: {
      padding: "32px", // More padding
      flex: "1",
      overflowY: "auto",
      maxHeight: "calc(100vh - 550px)",
      minHeight: "400px", // Taller
    },
  });

  if (messages.length === 0) {
    msgContainer.appendChild(
      el("p", {
        text: "No messages yet. Start the conversation!",
        style: {
          color: "#9ca3af",
          textAlign: "center",
          padding: "40px 0",
        },
      })
    );
  } else {
    messages.forEach((msg) => {
      msgContainer.appendChild(createMessageBubble(msg, state));
    });

    setTimeout(() => {
      msgContainer.scrollTop = msgContainer.scrollHeight;
    }, 100);
  }

  container.appendChild(msgContainer);

  // Reply area
  container.appendChild(createReplyArea(thread.id, state));
}

/**
 * Create message bubble
 */
function createMessageBubble(message, state) {
  const isClient = message.author_type === "client";

  const bubble = el("div", {
    style: {
      display: "flex",
      justifyContent: isClient ? "flex-end" : "flex-start",
      marginBottom: "20px", // More space between messages
    },
  });

  const content = el("div", {
    style: {
      maxWidth: "70%",
      padding: "16px 20px", // More padding
      borderRadius: "16px",
      background: isClient ? "#0d539e" : "#f3f4f6",
      color: isClient ? "white" : "#111827",
    },
  });

  // Author
  content.appendChild(
    el("div", {
      text: escapeHtml(message.author_name || (isClient ? "You" : "WebNique Team")),
      style: {
        fontSize: "13px",
        fontWeight: "700",
        opacity: isClient ? "0.9" : "1",
        marginBottom: "6px",
        color: isClient ? "white" : "#6b7280",
      },
    })
  );

  // Content
  content.appendChild(
    el("div", {
      text: escapeHtml(message.content || ""),
      style: {
        fontSize: "15px",
        lineHeight: "1.7", // More line height
        marginBottom: "8px",
        whiteSpace: "pre-wrap",
      },
    })
  );

  // Time
  content.appendChild(
    el("div", {
      text: formatTimestamp(message.timestamp),
      style: {
        fontSize: "12px",
        opacity: "0.7",
      },
    })
  );

  bubble.appendChild(content);
  return bubble;
}

/**
 * Create reply area
 */
function createReplyArea(threadId, state) {
  const area = el("div", {
    style: {
      padding: "24px 32px", // More padding
      borderTop: "1px solid #e5e7eb",
      background: "#f9fafb",
    },
  });

  const form = el("form", {
    style: { display: "flex", gap: "12px" },
  });

  const textarea = el("textarea", {
    placeholder: "Type your message...",
    rows: "3", // Taller textarea
    style: {
      flex: "1",
      padding: "14px", // More padding
      borderRadius: "8px",
      border: "1px solid #d1d5db",
      fontSize: "15px",
      resize: "none",
      fontFamily: "inherit",
    },
  });

  form.appendChild(textarea);

  const sendBtn = button(
    state,
    "Send",
    async (e) => {
      e.preventDefault();

      const content = textarea.value.trim();
      if (!content) return;

      sendBtn.disabled = true;
      sendBtn.textContent = "Sending...";

      try {
        await sendMessage(
          threadId,
          content,
          "client",
          state.user?.name || "Client"
        );

        textarea.value = "";
        textarea.focus();
      } catch (error) {
        console.error("[Requests] Send error:", error);
        alert("Failed to send message. Please try again.");
      } finally {
        sendBtn.disabled = false;
        sendBtn.textContent = "Send";
      }
    },
    "solid"
  );

  sendBtn.style.background = "#0d539e";
  sendBtn.style.borderColor = "#0d539e";

  form.appendChild(sendBtn);

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    sendBtn.click();
  });

  textarea.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendBtn.click();
    }
  });

  area.appendChild(form);
  return area;
}

/**
 * Show new thread modal
 */
function showNewThreadModal(state, shell) {
  const overlay = el("div", {
    style: {
      position: "fixed",
      top: "0",
      left: "0",
      right: "0",
      bottom: "0",
      background: "rgba(0,0,0,0.5)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: "9999",
    },
  });

  const modal = el("div", {
    style: {
      background: "white",
      borderRadius: "16px",
      padding: "32px",
      maxWidth: "500px",
      width: "90%",
    },
  });

  modal.appendChild(
    el("h2", {
      text: "New Request",
      style: {
        fontSize: "24px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "20px",
      },
    })
  );

  // Subject
  const subjectGroup = el("div", { style: { marginBottom: "20px" } });
  subjectGroup.appendChild(
    el("label", { class: "wnq-label", text: "Subject" })
  );

  const subjectInput = el("input", {
    class: "wnq-input",
    type: "text",
    placeholder: "What do you need help with?",
    required: true,
  });
  subjectGroup.appendChild(subjectInput);
  modal.appendChild(subjectGroup);

  // Message
  const msgGroup = el("div", { style: { marginBottom: "20px" } });
  msgGroup.appendChild(
    el("label", { class: "wnq-label", text: "Message" })
  );

  const msgInput = el("textarea", {
    class: "wnq-textarea",
    rows: "6",
    placeholder: "Describe your request...",
  });
  msgGroup.appendChild(msgInput);
  modal.appendChild(msgGroup);

  // Buttons
  const btnRow = el("div", {
    style: {
      display: "flex",
      gap: "12px",
      justifyContent: "flex-end",
    },
  });

  const cancelBtn = button(
    state,
    "Cancel",
    () => {
      document.body.removeChild(overlay);
    },
    "outline"
  );

  const createBtn = button(
    state,
    "Create Request",
    async () => {
      const subject = subjectInput.value.trim();
      const message = msgInput.value.trim();

      if (!subject) {
        alert("Please enter a subject");
        return;
      }

      createBtn.disabled = true;
      createBtn.textContent = "Creating...";

      try {
        await createThread(
          state.clientId,
          subject,
          message,
          state.user?.name || "Client"
        );

        document.body.removeChild(overlay);
      } catch (error) {
        console.error("[Requests] Create error:", error);
        alert("Failed to create request. Please try again.");
        createBtn.disabled = false;
        createBtn.textContent = "Create Request";
      }
    },
    "solid"
  );

  createBtn.style.background = "#0d539e";
  createBtn.style.borderColor = "#0d539e";

  btnRow.appendChild(cancelBtn);
  btnRow.appendChild(createBtn);
  modal.appendChild(btnRow);

  overlay.appendChild(modal);

  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) {
      document.body.removeChild(overlay);
    }
  });

  document.body.appendChild(overlay);
  subjectInput.focus();
}

/**
 * Empty state
 */
function renderEmptyState(threadList, messageView) {
  threadList.innerHTML = "";
  messageView.innerHTML = "";

  const empty = el("div", {
    style: {
      textAlign: "center",
      padding: "80px 40px",
    },
  });

  empty.appendChild(
    el("div", {
      text: "📭",
      style: { fontSize: "64px", marginBottom: "20px" },
    })
  );

  empty.appendChild(
    el("h3", {
      text: "No Requests Yet",
      style: {
        fontSize: "20px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "12px",
      },
    })
  );

  empty.appendChild(
    el("p", {
      text: 'Click "+ New Request" to start a conversation.',
      style: {
        fontSize: "15px",
        color: "#6b7280",
      },
    })
  );

  messageView.appendChild(empty);
}

/**
 * Format timestamp
 */
function formatTimestamp(timestamp) {
  if (!timestamp) return "Unknown";

  try {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / (1000 * 60));

    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
    if (diffMins < 2880) return "Yesterday";

    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    });
  } catch (e) {
    return "Unknown";
  }
}

/**
 * Show error
 */
function showError(container, message) {
  container.innerHTML = "";
  container.appendChild(
    el("div", {
      class: "wnq-alert wnq-alert-danger",
      style: { margin: "20px" },
      html: `<strong>Error:</strong> ${escapeHtml(message)}`,
    })
  );
}