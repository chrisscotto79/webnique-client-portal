<?php
/**
 * SEO Model
 * 
 * Manages SEO tracking data for clients
 * 
 * @package WebNique Portal
 */

namespace WNQ\Models;

if (!defined('ABSPATH')) {
    exit;
}

final class SEO
{
    public static function createTables(): void
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        // Main SEO tasks table
        $table_seo = $wpdb->prefix . 'wnq_seo_tasks';
        $sql_seo = "CREATE TABLE IF NOT EXISTS $table_seo (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            client_id varchar(100) NOT NULL,
            month_year varchar(7) NOT NULL,
            service_type varchar(50) NOT NULL,
            task_group varchar(255),
            task_name varchar(255) NOT NULL,
            task_description text,
            status varchar(20) DEFAULT 'pending',
            completed_date datetime,
            notes text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY client_month (client_id, month_year),
            KEY service_type (service_type),
            KEY status (status)
        ) $charset_collate;";

        // Monthly SEO reports table
        $table_reports = $wpdb->prefix . 'wnq_seo_reports';
        $sql_reports = "CREATE TABLE IF NOT EXISTS $table_reports (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            client_id varchar(100) NOT NULL,
            month_year varchar(7) NOT NULL,
            report_url varchar(500),
            keywords_tracked int DEFAULT 0,
            avg_position decimal(5,2),
            organic_traffic int DEFAULT 0,
            backlinks_added int DEFAULT 0,
            summary text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY client_month (client_id, month_year)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_seo);
        dbDelta($sql_reports);
    }

    public static function createTask(array $data): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        return (bool) $wpdb->insert($table, [
            'client_id' => $data['client_id'],
            'month_year' => $data['month_year'],
            'service_type' => $data['service_type'],
            'task_group' => $data['task_group'] ?? '',
            'task_name' => $data['task_name'],
            'task_description' => $data['task_description'] ?? '',
            'status' => $data['status'] ?? 'pending',
            'notes' => $data['notes'] ?? '',
        ]);
    }

    public static function updateTask(int $id, array $data): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        $update_data = [];
        $allowed_fields = ['task_name', 'task_description', 'status', 'notes', 'completed_date'];
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                $update_data[$field] = $data[$field];
            }
        }
        
        if (empty($update_data)) {
            return false;
        }
        
        return (bool) $wpdb->update($table, $update_data, ['id' => $id]);
    }

    public static function completeTask(int $id): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        return (bool) $wpdb->update($table, [
            'status' => 'completed',
            'completed_date' => current_time('mysql')
        ], ['id' => $id]);
    }

    public static function getTasksByClient(string $client_id, ?string $month_year = null): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        if ($month_year) {
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table WHERE client_id = %s AND month_year = %s ORDER BY service_type, task_group, id",
                $client_id,
                $month_year
            ), ARRAY_A);
        } else {
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table WHERE client_id = %s ORDER BY month_year DESC, service_type, task_group, id",
                $client_id
            ), ARRAY_A);
        }
        
        return $results ?: [];
    }

    public static function getTasksByMonth(string $month_year): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE month_year = %s ORDER BY client_id, service_type",
            $month_year
        ), ARRAY_A);
        
        return $results ?: [];
    }

    public static function deleteTask(int $id): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        return (bool) $wpdb->delete($table, ['id' => $id]);
    }

    public static function saveReport(array $data): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_reports';
        
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE client_id = %s AND month_year = %s",
            $data['client_id'],
            $data['month_year']
        ));
        
        if ($existing) {
            return (bool) $wpdb->update($table, [
                'report_url' => $data['report_url'] ?? '',
                'keywords_tracked' => $data['keywords_tracked'] ?? 0,
                'avg_position' => $data['avg_position'] ?? 0,
                'organic_traffic' => $data['organic_traffic'] ?? 0,
                'backlinks_added' => $data['backlinks_added'] ?? 0,
                'summary' => $data['summary'] ?? '',
            ], [
                'client_id' => $data['client_id'],
                'month_year' => $data['month_year']
            ]);
        } else {
            return (bool) $wpdb->insert($table, [
                'client_id' => $data['client_id'],
                'month_year' => $data['month_year'],
                'report_url' => $data['report_url'] ?? '',
                'keywords_tracked' => $data['keywords_tracked'] ?? 0,
                'avg_position' => $data['avg_position'] ?? 0,
                'organic_traffic' => $data['organic_traffic'] ?? 0,
                'backlinks_added' => $data['backlinks_added'] ?? 0,
                'summary' => $data['summary'] ?? '',
            ]);
        }
    }

    public static function getReport(string $client_id, string $month_year): ?array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_reports';
        
        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE client_id = %s AND month_year = %s",
            $client_id,
            $month_year
        ), ARRAY_A);
        
        return $result ?: null;
    }

    public static function getClientReports(string $client_id): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_reports';
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE client_id = %s ORDER BY month_year DESC",
            $client_id
        ), ARRAY_A);
        
        return $results ?: [];
    }

    public static function getMonthlyProgress(string $client_id, string $month_year): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(*) as total_tasks,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_tasks,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_tasks,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_tasks
            FROM $table 
            WHERE client_id = %s AND month_year = %s",
            $client_id,
            $month_year
        ), ARRAY_A);
        
        $stats = $stats ?: ['total_tasks' => 0, 'completed_tasks' => 0, 'in_progress_tasks' => 0, 'pending_tasks' => 0];
        
        $stats['completion_percentage'] = $stats['total_tasks'] > 0 
            ? round(($stats['completed_tasks'] / $stats['total_tasks']) * 100, 1)
            : 0;
        
        return $stats;
    }

    public static function getServiceTypeProgress(string $client_id, string $month_year): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT 
                service_type,
                COUNT(*) as total,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
            FROM $table 
            WHERE client_id = %s AND month_year = %s
            GROUP BY service_type",
            $client_id,
            $month_year
        ), ARRAY_A);
        
        return $results ?: [];
    }

    public static function initializeMonthlyTasks(string $client_id, string $month_year): bool
    {
        $onpage_tasks = [
            'Client Intake & Page Selection' => [
                'Complete client intake questionnaire',
                'Create full page inventory',
                'Classify each page role (primary/supporting/utility)',
                'Assign page priority levels (P1/P2/P3)',
                'Map page-to-intent for all pages',
                'Flag pages for exclusion or revision',
            ],
            'Keyword Research & Assignment' => [
                'Assign primary keyword per page',
                'Identify supporting keyword variations',
                'Confirm search intent matches page role',
                'Check for keyword cannibalization',
                'Document keyword assignments',
                'Review competitor keyword strategies',
            ],
            'Page Structure & Content' => [
                'Define page topic and H1',
                'Write clear introduction section',
                'Structure main content with H2s',
                'Add H3 subsections where needed',
                'Implement answer-first content structure',
                'Add relevant CTAs',
            ],
            'Title Tag & Meta Optimization' => [
                'Optimize title tag with primary keyword',
                'Write compelling meta description',
                'Ensure title matches page intent',
                'Verify meta description is unique',
                'Test title length (50-60 characters)',
                'Review meta descriptions for all pages',
            ],
            'URL & Heading Optimization' => [
                'Optimize URL slug',
                'Ensure single H1 per page',
                'Structure H2/H3 hierarchy correctly',
                'Make headings descriptive and scannable',
                'Review URL structure site-wide',
            ],
            'Content Quality & Readability' => [
                'Write content that satisfies search intent',
                'Use short paragraphs and bullet points',
                'Remove fluff and filler content',
                'Ensure clarity and plain language',
                'Add relevant examples and case studies',
                'Review content completeness',
            ],
            'Internal Linking Strategy' => [
                'Add relevant internal links',
                'Use descriptive anchor text',
                'Link to related service pages',
                'Ensure natural link placement',
                'Review site-wide internal linking',
                'Create content hub structure',
            ],
            'Image & Visual Optimization' => [
                'Add relevant images to support content',
                'Write descriptive alt text for all images',
                'Place images near relevant text',
                'Use descriptive image file names',
                'Optimize image placement',
                'Add infographics where helpful',
            ],
            'On-Page SEO QA' => [
                'Run complete QA checklist',
                'Verify keyword usage is natural',
                'Check all metadata is unique',
                'Confirm content structure is logical',
                'Review readability scores',
                'Approve page as "On-Page SEO Complete"',
            ],
        ];

        $technical_tasks = [
            'Site Speed & Performance' => [
                'Run PageSpeed Insights analysis',
                'Check Core Web Vitals scores',
                'Identify render-blocking resources',
                'Review JavaScript execution time',
            ],
            'Mobile Optimization' => [
                'Test mobile responsiveness',
                'Check mobile usability in GSC',
                'Verify touch elements are properly sized',
                'Test mobile page speed',
            ],
            'XML Sitemap & Robots.txt' => [
                'Update XML sitemap',
                'Verify sitemap submission in GSC',
                'Review robots.txt configuration',
                'Check sitemap is accessible',
            ],
            'Schema Markup' => [
                'Implement LocalBusiness schema',
                'Add Organization schema',
                'Validate schema with Rich Results Test',
                'Add breadcrumb schema',
            ],
            'Site Architecture' => [
                'Review URL structure',
                'Check internal linking depth',
                'Verify canonical tags',
                'Review site navigation structure',
            ],
        ];

        $local_tasks = [
            'Google Business Profile' => [
                'Update GMB business information',
                'Add/update business photos',
                'Create Google Posts (2-3 this month)',
                'Respond to reviews',
                'Update business hours if needed',
            ],
            'NAP Consistency' => [
                'Audit NAP across all citations',
                'Fix inconsistent listings',
                'Update NAP on website',
                'Verify NAP in schema markup',
            ],
            'Local Citations' => [
                'Build 3-5 new citations',
                'Update existing citations',
                'Verify citation accuracy',
                'Document all citations',
            ],
            'Review Management' => [
                'Monitor new reviews',
                'Respond to all reviews',
                'Request reviews from clients',
                'Address negative reviews appropriately',
            ],
            'Local Content' => [
                'Create location-specific content',
                'Update service area pages',
                'Add local keywords naturally',
                'Include local references',
            ],
        ];

        $offpage_tasks = [
            'Backlink Acquisition' => [
                'Identify 5-10 link opportunities',
                'Reach out to potential link sources',
                'Secure 2-3 quality backlinks',
                'Document new backlinks acquired',
            ],
            'Guest Posting' => [
                'Identify guest post opportunities',
                'Pitch 3-5 guest post ideas',
                'Write and submit guest posts',
                'Ensure proper attribution links',
            ],
            'Directory Submissions' => [
                'Submit to relevant directories',
                'Update existing directory listings',
                'Focus on niche-specific directories',
                'Verify all submissions',
            ],
            'Brand Mentions' => [
                'Monitor brand mentions',
                'Request links for unlinked mentions',
                'Respond to brand discussions',
                'Track mention sentiment',
            ],
            'Social Signals' => [
                'Share content on social platforms',
                'Engage with industry content',
                'Build social media presence',
                'Encourage social sharing',
            ],
        ];

        $monthly_tasks = [
            'Keyword Rankings & Traffic' => [
                'Update keyword ranking report',
                'Analyze traffic trends',
                'Identify ranking opportunities',
                'Compare month-over-month changes',
            ],
            'Competitor Analysis' => [
                'Review top 3 competitors',
                'Analyze competitor keywords',
                'Identify content gaps',
                'Track competitor backlinks',
            ],
            'Content Planning' => [
                'Create content calendar',
                'Identify blog topic ideas',
                'Plan service page updates',
                'Schedule content production',
            ],
            'Reporting' => [
                'Compile monthly SEO report',
                'Document all work completed',
                'Prepare client presentation',
                'Schedule report delivery',
            ],
            'Strategy' => [
                'Review overall SEO strategy',
                'Identify next month priorities',
                'Provide improvement recommendations',
                'Set goals for next month',
            ],
        ];

        $all_service_types = [
            'onpage' => $onpage_tasks,
            'technical' => $technical_tasks,
            'local' => $local_tasks,
            'offpage' => $offpage_tasks,
            'monthly' => $monthly_tasks,
        ];

        $success = true;
        foreach ($all_service_types as $service_type => $groups) {
            foreach ($groups as $task_group => $tasks) {
                foreach ($tasks as $task_name) {
                    $result = self::createTask([
                        'client_id' => $client_id,
                        'month_year' => $month_year,
                        'service_type' => $service_type,
                        'task_group' => $task_group,
                        'task_name' => $task_name,
                        'status' => 'pending',
                    ]);
                    if (!$result) {
                        $success = false;
                    }
                }
            }
        }
        
        return $success;
    }
}