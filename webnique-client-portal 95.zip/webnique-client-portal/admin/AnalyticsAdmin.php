<?php
/**
 * Analytics Admin Page - COMPLETE SELF-CONTAINED VERSION
 * 
 * All-in-one solution with embedded API calls and error handling
 * 
 * @package WebNique Portal
 */

namespace WNQ\Admin;

use WNQ\Models\AnalyticsConfig;

if (!defined('ABSPATH')) {
    exit;
}

final class AnalyticsAdmin
{
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addSubmenu'], 20);
        add_action('admin_enqueue_scripts', [self::class, 'enqueueAssets'], 999);
        add_action('admin_post_wnq_save_analytics_settings', [self::class, 'handleSaveSettings']);
        add_action('admin_post_wnq_test_analytics_connection', [self::class, 'handleTestConnection']);
        add_action('admin_post_wnq_clear_analytics_cache', [self::class, 'handleClearCache']);
        add_action('wp_ajax_wnq_get_analytics_data', [self::class, 'ajaxGetAnalyticsData']);
    }

    public static function addSubmenu(): void
    {
        $capability = current_user_can('wnq_manage_portal') ? 'wnq_manage_portal' : 'manage_options';
        add_submenu_page('wnq-portal', 'Analytics', 'Analytics', $capability, 'wnq-analytics', [self::class, 'render']);
    }

    public static function enqueueAssets($hook): void
    {
        $is_analytics_page = (isset($_GET['page']) && $_GET['page'] === 'wnq-analytics');
        if (!$is_analytics_page) return;
        
        wp_enqueue_script('jquery');
        $plugin_url = plugin_dir_url(dirname(__FILE__));
        wp_enqueue_style('wnq-analytics-dashboard', $plugin_url . 'assets/admin/analytics-dashboard.css', [], time());
    }

    public static function render(): void
    {
        if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : 'dashboard';
        
        switch ($view) {
            case 'settings':
                self::renderSettings();
                break;
            default:
                self::renderDashboard();
                break;
        }
    }

    private static function renderDashboard(): void
    {
        $client_id = self::getCurrentClientId();
        $config = AnalyticsConfig::getClientConfig($client_id);
        $credentials = AnalyticsConfig::getCredentials();

        if (!$credentials || !$config) {
            self::renderSetupPrompt();
            return;
        }
        ?>
        <div class="wrap wnq-analytics-admin">
            <div class="analytics-header">
                <div>
                    <h1>📊 Analytics Dashboard</h1>
                    <p class="subtitle"><?php echo esc_html($config['website_url'] ?? 'web-nique.com'); ?></p>
                </div>
                <div class="header-actions">
                    <button type="button" id="wnq-refresh-data" class="button">🔄 Refresh Data</button>
                    <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=settings'); ?>" class="button">⚙️ Settings</a>
                </div>
            </div>

            <div class="date-range-selector">
                <select id="wnq-date-range" class="date-range-select">
                    <option value="7">Last 7 Days</option>
                    <option value="30" selected>Last 30 Days</option>
                    <option value="90">Last 90 Days</option>
                </select>
            </div>

            <div id="wnq-analytics-loading" class="analytics-loading">
                <div class="loading-spinner"></div>
                <p>Loading analytics data...</p>
            </div>

            <div id="wnq-analytics-content" style="display: none;"></div>

            <div class="analytics-footer">
                <p>Powered by <strong>WebNique</strong> Analytics Dashboard</p>
            </div>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
        
        <script type="text/javascript">
        console.log('=== WebNique Analytics Debug ===');
        console.log('jQuery loaded:', typeof jQuery !== 'undefined');
        console.log('Chart.js loaded:', typeof Chart !== 'undefined');
        
        window.wnqAnalytics = {
            ajaxUrl: '<?php echo admin_url('admin-ajax.php'); ?>',
            nonce: '<?php echo wp_create_nonce('wnq_analytics_nonce'); ?>',
            clientId: '<?php echo self::getCurrentClientId(); ?>',
            debug: true
        };
        console.log('wnqAnalytics defined:', window.wnqAnalytics);
        </script>

        <script type="text/javascript">
        (function($) {
            'use strict';
            console.log('=== Analytics Dashboard Loading ===');

            let currentChart = null;

            function initDashboard() {
                console.log('Initializing dashboard...');
                bindEvents();
                loadAnalyticsData(30);
            }

            function bindEvents() {
                $('#wnq-date-range').on('change', function() {
                    loadAnalyticsData(parseInt($(this).val()));
                });
                $('#wnq-refresh-data').on('click', function() {
                    $(this).prop('disabled', true).text('🔄 Refreshing...');
                    loadAnalyticsData(parseInt($('#wnq-date-range').val()));
                });
            }

            function loadAnalyticsData(dateRange) {
                console.log('Loading data for ' + dateRange + ' days...');
                $('#wnq-analytics-loading').show();
                $('#wnq-analytics-content').hide();

                $.ajax({
                    url: wnqAnalytics.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'wnq_get_analytics_data',
                        nonce: wnqAnalytics.nonce,
                        client_id: wnqAnalytics.clientId,
                        date_range: dateRange
                    },
                    success: function(response) {
                        console.log('AJAX Response:', response);
                        if (response.success) {
                            renderDashboard(response.data);
                            $('#wnq-analytics-loading').hide();
                            $('#wnq-analytics-content').show();
                        } else {
                            showError(response.data?.message || 'Failed to load analytics data');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX ERROR:', {status, error, response: xhr.responseText, statusCode: xhr.status});
                        let errorMsg = 'Network error';
                        if (xhr.status === 500) errorMsg = 'Server error (500). Check PHP error logs.';
                        else if (xhr.status === 403) errorMsg = 'Permission denied (403)';
                        else if (xhr.responseText) {
                            try {
                                const parsed = JSON.parse(xhr.responseText);
                                errorMsg = parsed.data || parsed.message || errorMsg;
                            } catch(e) {
                                errorMsg += ': ' + xhr.responseText.substring(0, 200);
                            }
                        }
                        showError(errorMsg);
                    },
                    complete: function() {
                        $('#wnq-refresh-data').prop('disabled', false).text('🔄 Refresh Data');
                    }
                });
            }

            function renderDashboard(data) {
                console.log('Rendering dashboard:', data);
                let html = '<div style="padding: 20px;">';
                
                if (data.overview) {
                    html += '<div class="analytics-stats-grid">';
                    html += '<div class="stat-card"><h3>👥 Visitors</h3><div class="stat-value">' + (data.overview.total_users || 0).toLocaleString() + '</div></div>';
                    html += '<div class="stat-card"><h3>📄 Page Views</h3><div class="stat-value">' + (data.overview.page_views || 0).toLocaleString() + '</div></div>';
                    html += '<div class="stat-card"><h3>📊 Sessions</h3><div class="stat-value">' + (data.overview.sessions || 0).toLocaleString() + '</div></div>';
                    html += '<div class="stat-card"><h3>📈 Bounce Rate</h3><div class="stat-value">' + (data.overview.bounce_rate || 0).toFixed(1) + '%</div></div>';
                    html += '</div>';
                }
                
                if (data.visitors_over_time && data.visitors_over_time.length > 0) {
                    html += '<div class="chart-section" style="margin-top: 30px;"><h2>Visitors Over Time</h2><canvas id="visitors-chart" style="max-height: 300px;"></canvas></div>';
                }
                
                if (data.traffic_sources && data.traffic_sources.length > 0) {
                    html += '<div class="table-section" style="margin-top: 30px;"><h2>Traffic Sources</h2><table class="wp-list-table widefat fixed striped">';
                    html += '<thead><tr><th>Channel</th><th>Sessions</th><th>Users</th><th>%</th></tr></thead><tbody>';
                    data.traffic_sources.forEach(s => {
                        html += '<tr><td>' + s.channel + '</td><td>' + s.sessions.toLocaleString() + '</td><td>' + s.users.toLocaleString() + '</td><td>' + s.percentage + '%</td></tr>';
                    });
                    html += '</tbody></table></div>';
                }
                
                if (data.top_pages && data.top_pages.length > 0) {
                    html += '<div class="table-section" style="margin-top: 30px;"><h2>Top Pages</h2><table class="wp-list-table widefat fixed striped">';
                    html += '<thead><tr><th>Page</th><th>Views</th><th>Bounce</th></tr></thead><tbody>';
                    data.top_pages.forEach(p => {
                        html += '<tr><td><code>' + p.path + '</code></td><td>' + p.views.toLocaleString() + '</td><td>' + p.bounce_rate.toFixed(1) + '%</td></tr>';
                    });
                    html += '</tbody></table></div>';
                }
                
                html += '</div>';
                $('#wnq-analytics-content').html(html);
                
                if (data.visitors_over_time && data.visitors_over_time.length > 0 && typeof Chart !== 'undefined') {
                    renderVisitorsChart(data.visitors_over_time);
                }
            }

            function renderVisitorsChart(data) {
                const ctx = document.getElementById('visitors-chart');
                if (!ctx) return;
                if (currentChart) currentChart.destroy();
                
                currentChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: data.map(d => d.date),
                        datasets: [{
                            label: 'Visitors',
                            data: data.map(d => d.users),
                            borderColor: '#0073aa',
                            backgroundColor: 'rgba(0, 115, 170, 0.1)',
                            tension: 0.4,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: true,
                        plugins: { legend: { display: false } },
                        scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
                    }
                });
            }

            function showError(message) {
                console.error('Error:', message);
                $('#wnq-analytics-loading').hide();
                $('#wnq-analytics-content').html(
                    '<div class="notice notice-error" style="padding:20px;margin:20px;"><p><strong>Error:</strong> ' + message + '</p><p><small>Check console and PHP logs.</small></p></div>'
                ).show();
            }

            $(document).ready(function() {
                console.log('Document ready!');
                if ($('#wnq-analytics-content').length) {
                    console.log('Initializing...');
                    initDashboard();
                }
            });
        })(jQuery);
        </script>
        
        <style>
        .analytics-stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }
        .stat-card { background: #fff; border: 1px solid #ddd; border-radius: 4px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .stat-card h3 { margin: 0 0 10px 0; font-size: 14px; color: #666; }
        .stat-value { font-size: 32px; font-weight: bold; color: #0073aa; }
        .chart-section, .table-section { background: #fff; border: 1px solid #ddd; border-radius: 4px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .chart-section h2, .table-section h2 { margin: 0 0 20px 0; font-size: 18px; }
        </style>
        <?php
    }

    private static function renderSettings(): void
    {
        $client_id = self::getCurrentClientId();
        $config = AnalyticsConfig::getClientConfig($client_id);
        $credentials = AnalyticsConfig::getCredentials();
        ?>
        <div class="wrap wnq-analytics-admin">
            <h1>Analytics Settings</h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-analytics'); ?>" class="page-title-action">← Back</a>

            <?php if (isset($_GET['saved'])): ?><div class="notice notice-success"><p>Settings saved!</p></div><?php endif; ?>
            <?php if (isset($_GET['tested'])): ?><div class="notice notice-success"><p>Connection successful!</p></div><?php endif; ?>
            <?php if (isset($_GET['cleared'])): ?><div class="notice notice-success"><p>Cache cleared!</p></div><?php endif; ?>
            <?php if (isset($_GET['error'])): ?><div class="notice notice-error"><p>Error: <?php echo esc_html($_GET['message'] ?? 'Unknown error'); ?></p></div><?php endif; ?>

            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" enctype="multipart/form-data">
                <?php wp_nonce_field('wnq_save_analytics_settings'); ?>
                <input type="hidden" name="action" value="wnq_save_analytics_settings">
                
                <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ddd;">
                    <h2>🔐 Service Account</h2>
                    <table class="form-table">
                        <tr>
                            <th>JSON File</th>
                            <td>
                                <input type="file" name="credentials_file" accept=".json">
                                <?php if ($credentials): ?>
                                    <p class="description">✅ Uploaded: <?php echo esc_html($credentials['email']); ?></p>
                                <?php else: ?>
                                    <p class="description">⚠️ No credentials uploaded</p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>

                <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ddd;">
                    <h2>⚙️ Configuration</h2>
                    <table class="form-table">
                        <tr>
                            <th>Client Name</th>
                            <td><input type="text" name="client_name" value="<?php echo esc_attr($config['client_name'] ?? 'WebNique'); ?>" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th>GA4 Property ID</th>
                            <td>
                                <input type="text" name="ga4_property_id" value="<?php echo esc_attr($config['ga4_property_id'] ?? ''); ?>" class="regular-text" placeholder="properties/123456789">
                                <p class="description">Format: properties/123456789</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Website URL</th>
                            <td><input type="url" name="website_url" value="<?php echo esc_attr($config['website_url'] ?? ''); ?>" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th>Timezone</th>
                            <td>
                                <select name="timezone">
                                    <option value="America/New_York" <?php selected($config['timezone'] ?? '', 'America/New_York'); ?>>Eastern</option>
                                    <option value="America/Chicago" <?php selected($config['timezone'] ?? '', 'America/Chicago'); ?>>Central</option>
                                    <option value="America/Denver" <?php selected($config['timezone'] ?? '', 'America/Denver'); ?>>Mountain</option>
                                    <option value="America/Los_Angeles" <?php selected($config['timezone'] ?? '', 'America/Los_Angeles'); ?>>Pacific</option>
                                    <option value="UTC" <?php selected($config['timezone'] ?? '', 'UTC'); ?>>UTC</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </div>

                <p class="submit"><button type="submit" class="button button-primary">Save Settings</button></p>
            </form>

            <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ddd;">
                <h2>🧪 Test Connection</h2>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                    <?php wp_nonce_field('wnq_test_connection'); ?>
                    <input type="hidden" name="action" value="wnq_test_analytics_connection">
                    <button type="submit" class="button">Test Connection</button>
                </form>
            </div>

            <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ddd;">
                <h2>💾 Cache</h2>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                    <?php wp_nonce_field('wnq_clear_cache'); ?>
                    <input type="hidden" name="action" value="wnq_clear_analytics_cache">
                    <button type="submit" class="button">Clear Cache</button>
                </form>
            </div>
        </div>
        <?php
    }

    private static function renderSetupPrompt(): void
    {
        ?>
        <div class="wrap wnq-analytics-admin">
            <div style="max-width: 800px; margin: 50px auto; text-align: center; background: #fff; padding: 60px; border: 1px solid #ddd; border-radius: 8px;">
                <div style="font-size: 64px; margin-bottom: 20px;">📊</div>
                <h1>Welcome to Analytics!</h1>
                <p style="font-size: 16px; color: #666; margin-bottom: 40px;">Configure your Google Analytics connection.</p>
                <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=settings'); ?>" class="button button-primary button-hero">Get Started →</a>
            </div>
        </div>
        <?php
    }

    public static function ajaxGetAnalyticsData(): void
    {
        error_log('=== WNQ Analytics AJAX Started ===');
        
        try {
            if (!check_ajax_referer('wnq_analytics_nonce', 'nonce', false)) {
                error_log('Nonce failed');
                wp_send_json_error(['message' => 'Security check failed', 'type' => 'nonce_error']);
                return;
            }

            if (!current_user_can('manage_options') && !current_user_can('wnq_manage_portal')) {
                error_log('Permission denied');
                wp_send_json_error(['message' => 'Permission denied', 'type' => 'permission_error']);
                return;
            }

            $client_id = isset($_POST['client_id']) ? sanitize_text_field($_POST['client_id']) : '';
            $date_range = isset($_POST['date_range']) ? intval($_POST['date_range']) : 30;

            error_log("Processing: client=$client_id, range=$date_range");

            if (empty($client_id)) {
                wp_send_json_error(['message' => 'Client ID required', 'type' => 'validation_error']);
                return;
            }

            $config = AnalyticsConfig::getClientConfig($client_id);
            $credentials = AnalyticsConfig::getCredentials();

            if (!$config || !$credentials) {
                error_log('Missing config/credentials');
                wp_send_json_error(['message' => 'Analytics not configured', 'type' => 'config_error']);
                return;
            }

            error_log('Config loaded. GA4 Property: ' . ($config['ga4_property_id'] ?? 'not set'));

            $data = self::fetchAnalyticsData($credentials['credentials'], $config['ga4_property_id'], $date_range);

            error_log('Data fetched successfully');
            wp_send_json_success($data);

        } catch (\Exception $e) {
            error_log('ERROR: ' . $e->getMessage());
            error_log('Stack: ' . $e->getTraceAsString());
            wp_send_json_error(['message' => 'Error: ' . $e->getMessage(), 'type' => 'exception']);
        }
    }

    private static function fetchAnalyticsData(array $credentials, string $property_id, int $date_range): array
    {
        error_log('Starting data fetch');
        
        $access_token = self::getGoogleAccessToken($credentials);
        error_log('Token obtained');

        $end_date = date('Y-m-d');
        $start_date = date('Y-m-d', strtotime("-{$date_range} days"));
        error_log("Dates: {$start_date} to {$end_date}");

        $data = [];

        try {
            $data['overview'] = self::fetchOverviewStats($access_token, $property_id, $start_date, $end_date);
            error_log('Overview fetched');
        } catch (\Exception $e) {
            error_log('Overview error: ' . $e->getMessage());
            $data['overview'] = ['total_users' => 0, 'page_views' => 0, 'sessions' => 0, 'bounce_rate' => 0];
        }

        try {
            $data['visitors_over_time'] = self::fetchVisitorsOverTime($access_token, $property_id, $start_date, $end_date);
            error_log('Visitors over time fetched');
        } catch (\Exception $e) {
            error_log('Visitors error: ' . $e->getMessage());
            $data['visitors_over_time'] = [];
        }

        try {
            $data['traffic_sources'] = self::fetchTrafficSources($access_token, $property_id, $start_date, $end_date);
            error_log('Traffic sources fetched');
        } catch (\Exception $e) {
            error_log('Traffic error: ' . $e->getMessage());
            $data['traffic_sources'] = [];
        }

        try {
            $data['top_pages'] = self::fetchTopPages($access_token, $property_id, $start_date, $end_date);
            error_log('Top pages fetched');
        } catch (\Exception $e) {
            error_log('Pages error: ' . $e->getMessage());
            $data['top_pages'] = [];
        }

        return $data;
    }

    private static function getGoogleAccessToken(array $credentials): string
    {
        $cached_token = get_transient('wnq_ga_access_token');
        if ($cached_token) return $cached_token;

        $now = time();
        $header = ['alg' => 'RS256', 'typ' => 'JWT'];
        $claim = [
            'iss' => $credentials['client_email'],
            'scope' => 'https://www.googleapis.com/auth/analytics.readonly',
            'aud' => 'https://oauth2.googleapis.com/token',
            'exp' => $now + 3600,
            'iat' => $now
        ];

        $segments = [
            self::base64UrlEncode(wp_json_encode($header)),
            self::base64UrlEncode(wp_json_encode($claim))
        ];
        $signing_input = implode('.', $segments);

        $signature = '';
        if (!openssl_sign($signing_input, $signature, $credentials['private_key'], 'SHA256')) {
            throw new \Exception('JWT signing failed');
        }

        $segments[] = self::base64UrlEncode($signature);
        $jwt = implode('.', $segments);

        $response = wp_remote_post('https://oauth2.googleapis.com/token', [
            'body' => [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $jwt
            ],
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            throw new \Exception('Token request failed: ' . $response->get_error_message());
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!isset($body['access_token'])) {
            $error = $body['error_description'] ?? $body['error'] ?? 'Unknown error';
            throw new \Exception('Token failed: ' . $error);
        }

        $token = $body['access_token'];
        set_transient('wnq_ga_access_token', $token, 3000);
        return $token;
    }

    private static function fetchOverviewStats(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'metrics' => [
                ['name' => 'totalUsers'],
                ['name' => 'screenPageViews'],
                ['name' => 'sessions'],
                ['name' => 'bounceRate']
            ]
        ]);
        
        $m = $data['rows'][0]['metricValues'] ?? [];
        return [
            'total_users' => isset($m[0]) ? intval($m[0]['value']) : 0,
            'page_views' => isset($m[1]) ? intval($m[1]['value']) : 0,
            'sessions' => isset($m[2]) ? intval($m[2]['value']) : 0,
            'bounce_rate' => isset($m[3]) ? floatval($m[3]['value']) * 100 : 0
        ];
    }

    private static function fetchVisitorsOverTime(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'date']],
            'metrics' => [['name' => 'totalUsers'], ['name' => 'sessions']],
            'orderBys' => [['dimension' => ['dimensionName' => 'date']]]
        ]);
        
        $trends = [];
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $date = $row['dimensionValues'][0]['value'];
                $trends[] = [
                    'date' => substr($date, 0, 4) . '-' . substr($date, 4, 2) . '-' . substr($date, 6, 2),
                    'users' => intval($row['metricValues'][0]['value']),
                    'sessions' => intval($row['metricValues'][1]['value'])
                ];
            }
        }
        return $trends;
    }

    private static function fetchTrafficSources(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'sessionDefaultChannelGroup']],
            'metrics' => [['name' => 'sessions'], ['name' => 'totalUsers']],
            'orderBys' => [['metric' => ['metricName' => 'sessions'], 'desc' => true]],
            'limit' => 10
        ]);
        
        $sources = [];
        $total = 0;
        
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $total += intval($row['metricValues'][0]['value']);
            }
            foreach ($data['rows'] as $row) {
                $sessions = intval($row['metricValues'][0]['value']);
                $sources[] = [
                    'channel' => $row['dimensionValues'][0]['value'],
                    'sessions' => $sessions,
                    'users' => intval($row['metricValues'][1]['value']),
                    'percentage' => $total > 0 ? round(($sessions / $total) * 100, 1) : 0
                ];
            }
        }
        return $sources;
    }

    private static function fetchTopPages(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'pagePath'], ['name' => 'pageTitle']],
            'metrics' => [['name' => 'screenPageViews'], ['name' => 'bounceRate']],
            'orderBys' => [['metric' => ['metricName' => 'screenPageViews'], 'desc' => true]],
            'limit' => 10
        ]);
        
        $pages = [];
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $pages[] = [
                    'path' => $row['dimensionValues'][0]['value'],
                    'title' => $row['dimensionValues'][1]['value'] ?? 'Untitled',
                    'views' => intval($row['metricValues'][0]['value']),
                    'bounce_rate' => floatval($row['metricValues'][1]['value'] ?? 0) * 100
                ];
            }
        }
        return $pages;
    }

    private static function makeGARequest(string $token, string $property_id, array $body): array
    {
        $url = "https://analyticsdata.googleapis.com/v1beta/{$property_id}:runReport";
        
        $response = wp_remote_post($url, [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
            'body' => wp_json_encode($body),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            throw new \Exception('GA API failed: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);

        if ($code !== 200) {
            $error = $data['error']['message'] ?? "HTTP {$code}";
            throw new \Exception('GA API error: ' . $error);
        }

        if (!$data) throw new \Exception('Invalid GA response');
        return $data;
    }

    private static function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    public static function handleSaveSettings(): void
    {
        check_admin_referer('wnq_save_analytics_settings');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $client_id = self::getCurrentClientId();

        if (isset($_FILES['credentials_file']) && $_FILES['credentials_file']['size'] > 0) {
            $file = $_FILES['credentials_file'];
            
            if ($file['type'] !== 'application/json' && !str_ends_with($file['name'], '.json')) {
                wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&error=1&message=' . urlencode('Invalid file type')));
                exit;
            }

            $json = file_get_contents($file['tmp_name']);
            $creds = json_decode($json, true);

            if (!$creds || !isset($creds['client_email']) || !isset($creds['private_key'])) {
                wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&error=1&message=' . urlencode('Invalid JSON')));
                exit;
            }

            if (!AnalyticsConfig::saveCredentials($creds)) {
                wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&error=1&message=' . urlencode('Save failed')));
                exit;
            }
        }

        $config = [
            'client_id' => $client_id,
            'client_name' => sanitize_text_field($_POST['client_name'] ?? 'WebNique'),
            'ga4_property_id' => sanitize_text_field($_POST['ga4_property_id'] ?? ''),
            'website_url' => esc_url_raw($_POST['website_url'] ?? ''),
            'timezone' => sanitize_text_field($_POST['timezone'] ?? 'America/New_York'),
        ];

        AnalyticsConfig::saveClientConfig($config);
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&saved=1'));
        exit;
    }

    public static function handleTestConnection(): void
    {
        check_admin_referer('wnq_test_connection');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $client_id = self::getCurrentClientId();
        $result = AnalyticsConfig::testConnection($client_id);

        if ($result['success']) {
            wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&tested=1'));
        } else {
            wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&error=1&message=' . urlencode($result['message'])));
        }
        exit;
    }

    public static function handleClearCache(): void
    {
        check_admin_referer('wnq_clear_cache');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        delete_transient('wnq_ga_access_token');
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&cleared=1'));
        exit;
    }

    private static function getCurrentClientId(): string
    {
        return 'web-nique';
    }
}