<?php
/**
 * TasksAdmin - ENHANCED VERSION
 * 
 * Complete task management with:
 * - Task categories (Client/WebNique/General) with filters
 * - Countdown timers on all cards
 * - Archive system with restore
 * - Enhanced stats dashboard
 * - Complete forms with all fields
 * 
 * @package WebNique Portal
 */

namespace WNQ\Admin;

use WNQ\Models\Task;

if (!defined('ABSPATH')) {
    exit;
}

final class TasksAdmin
{
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addSubmenu'], 15);
        add_action('admin_enqueue_scripts', [self::class, 'enqueueAssets']);
    }

    public static function addSubmenu(): void
    {
        $capability = current_user_can('wnq_manage_portal') ? 'wnq_manage_portal' : 'manage_options';

        add_submenu_page(
            'wnq-portal',
            'Tasks',
            'Tasks',
            $capability,
            'wnq-tasks',
            [self::class, 'render']
        );
    }

    public static function enqueueAssets($hook): void
    {
        if ($hook !== 'webnique-portal_page_wnq-tasks') {
            return;
        }

        wp_enqueue_script('jquery-ui-draggable');
        wp_enqueue_script('jquery-ui-droppable');
    }

    public static function render(): void
    {
        if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : 'kanban';
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';
        $task_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

        if ($action === 'edit' && $task_id) {
            self::renderEditForm($task_id);
            return;
        }

        if ($action === 'add') {
            self::renderAddForm();
            return;
        }

        // Render based on view
        switch ($view) {
            case 'archive':
                self::renderArchiveView();
                break;
            default:
                self::renderKanbanBoard();
                break;
        }
    }

    private static function renderKanbanBoard(): void
    {
        // Load clients
        $clients = [];
        if (file_exists(WNQ_PORTAL_PATH . 'includes/Models/Client.php')) {
            require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
            if (class_exists('WNQ\\Models\\Client')) {
                $clients = \WNQ\Models\Client::getAll();
            }
        }

        // Get filter
        $filter_type = isset($_GET['filter']) ? sanitize_text_field($_GET['filter']) : '';

        // Get tasks
        $filters = [];
        if ($filter_type) {
            $filters['task_type'] = $filter_type;
        }
        $tasks = Task::getAll($filters);
        
        $counts = Task::getCountsByStatus();
        $type_counts = Task::getCountsByType();
        $overdue = Task::getOverdue();
        $this_week = Task::getDueThisWeek();
        $archived_count = count(Task::getArchived());

        // Group tasks by status
        $tasksByStatus = [
            'todo' => [],
            'in_progress' => [],
            'review' => [],
            'done' => [],
        ];

        foreach ($tasks as $task) {
            $status = $task['status'] ?? 'todo';
            if (isset($tasksByStatus[$status])) {
                $tasksByStatus[$status][] = $task;
            }
        }

        $team_members = [
            'christopher-scotto' => 'Christopher Scotto',
            'christopher-sanders' => 'Christopher Sanders',
        ];

        ?>
        <div class="wrap wnq-tasks-admin">
            <!-- Navigation Tabs -->
            <div class="nav-tabs">
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=kanban'); ?>" class="nav-tab nav-tab-active">
                    📋 Kanban
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=archive'); ?>" class="nav-tab">
                    📦 Archive <?php if ($archived_count > 0) echo "($archived_count)"; ?>
                </a>
            </div>

            <div class="tasks-header">
                <div>
                    <h1>Task Management</h1>
                    <p class="subtitle">Kanban board with categories, timers, and archive</p>
                </div>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&action=add'); ?>" class="button button-primary button-large">
                    + New Task
                </a>
            </div>

            <!-- Enhanced Stats -->
            <div class="tasks-stats">
                <div class="stat-card">
                    <span class="stat-label">To Do</span>
                    <span class="stat-value"><?php echo $counts['todo']; ?></span>
                </div>
                <div class="stat-card" style="border-left-color: #0d539e;">
                    <span class="stat-label">In Progress</span>
                    <span class="stat-value" style="color: #0d539e;"><?php echo $counts['in_progress']; ?></span>
                </div>
                <div class="stat-card" style="border-left-color: #f59e0b;">
                    <span class="stat-label">Review</span>
                    <span class="stat-value" style="color: #f59e0b;"><?php echo $counts['review']; ?></span>
                </div>
                <div class="stat-card" style="border-left-color: #10b981;">
                    <span class="stat-label">Done</span>
                    <span class="stat-value" style="color: #10b981;"><?php echo $counts['done']; ?></span>
                </div>
                <?php if (!empty($overdue)): ?>
                <div class="stat-card" style="border-left-color: #dc2626;">
                    <span class="stat-label">Overdue</span>
                    <span class="stat-value" style="color: #dc2626;"><?php echo count($overdue); ?></span>
                </div>
                <?php endif; ?>
                <div class="stat-card" style="border-left-color: #8b5cf6;">
                    <span class="stat-label">This Week</span>
                    <span class="stat-value" style="color: #8b5cf6;"><?php echo count($this_week); ?></span>
                </div>
            </div>

            <!-- Type Filters -->
            <div class="type-filters">
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks'); ?>" 
                   class="filter-tab <?php echo empty($filter_type) ? 'active' : ''; ?>">
                    All Tasks (<?php echo array_sum($type_counts); ?>)
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&filter=client'); ?>" 
                   class="filter-tab <?php echo $filter_type === 'client' ? 'active' : ''; ?>">
                    🏢 Client Tasks (<?php echo $type_counts['client']; ?>)
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&filter=webnique'); ?>" 
                   class="filter-tab <?php echo $filter_type === 'webnique' ? 'active' : ''; ?>">
                    🏪 WebNique Tasks (<?php echo $type_counts['webnique']; ?>)
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&filter=general'); ?>" 
                   class="filter-tab <?php echo $filter_type === 'general' ? 'active' : ''; ?>">
                    📝 General Tasks (<?php echo $type_counts['general']; ?>)
                </a>
            </div>

            <!-- Kanban Board -->
            <div class="kanban-board">
                <?php
                $columns = [
                    'todo' => ['icon' => '📋', 'title' => 'To Do'],
                    'in_progress' => ['icon' => '🚀', 'title' => 'In Progress'],
                    'review' => ['icon' => '👀', 'title' => 'Review'],
                    'done' => ['icon' => '✅', 'title' => 'Done'],
                ];

                foreach ($columns as $status => $col):
                ?>
                    <div class="kanban-column" data-status="<?php echo esc_attr($status); ?>">
                        <div class="column-header">
                            <h3><?php echo $col['icon'] . ' ' . $col['title']; ?></h3>
                            <span class="column-count"><?php echo count($tasksByStatus[$status]); ?></span>
                        </div>
                        <div class="column-tasks" id="column-<?php echo esc_attr($status); ?>">
                            <?php foreach ($tasksByStatus[$status] as $task): ?>
                                <?php self::renderTaskCard($task, $team_members, $clients, $status); ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <?php self::renderStyles(); ?>
        <?php self::renderScript(); ?>
        <?php
    }

    private static function renderTaskCard(array $task, array $team_members, array $clients, string $column_status): void
    {
        $priority = $task['priority'] ?? 'medium';
        $task_type = $task['task_type'] ?? 'general';
        $due_date = $task['due_date'] ?? null;
        $assignee_name = !empty($task['assigned_to']) ? ($team_members[$task['assigned_to']] ?? $task['assigned_to']) : '';

        // Get client name
        $client_name = '';
        if (!empty($task['client_id'])) {
            foreach ($clients as $client) {
                if ($client['client_id'] === $task['client_id']) {
                    $client_name = $client['name'];
                    break;
                }
            }
        }

        // Calculate countdown
        $countdown_html = '';
        $countdown_class = '';
        if ($due_date) {
            $today = strtotime('today');
            $due_timestamp = strtotime($due_date);
            $days_diff = floor(($due_timestamp - $today) / (60 * 60 * 24));

            if ($days_diff < 0 && $task['status'] !== 'done') {
                $countdown_html = '⚠️ Overdue by ' . abs($days_diff) . ' day' . (abs($days_diff) !== 1 ? 's' : '');
                $countdown_class = 'countdown-overdue';
            } elseif ($days_diff === 0) {
                $countdown_html = '📅 Due today';
                $countdown_class = 'countdown-today';
            } elseif ($days_diff === 1) {
                $countdown_html = '📅 Due tomorrow';
                $countdown_class = 'countdown-soon';
            } elseif ($days_diff <= 3) {
                $countdown_html = '📅 Due in ' . $days_diff . ' days';
                $countdown_class = 'countdown-soon';
            } elseif ($days_diff <= 7) {
                $countdown_html = '📅 Due in ' . $days_diff . ' days';
                $countdown_class = 'countdown-normal';
            } else {
                $countdown_html = '📅 ' . date('M j', $due_timestamp);
                $countdown_class = 'countdown-normal';
            }
        }

        // Type badge
        $type_badges = [
            'client' => '🏢 Client',
            'webnique' => '🏪 WebNique',
            'general' => '📝 General',
        ];
        $type_badge = $type_badges[$task_type] ?? '📝 General';

        ?>
        <div class="task-card" data-task-id="<?php echo esc_attr($task['id']); ?>">
            <div class="task-type-badge type-<?php echo esc_attr($task_type); ?>">
                <?php echo $type_badge; ?>
            </div>
            
            <div class="task-title"><?php echo esc_html($task['title']); ?></div>
            
            <?php if (!empty($task['description'])): ?>
            <div class="task-description">
                <?php echo wp_trim_words(esc_html($task['description']), 15); ?>
            </div>
            <?php endif; ?>
            
            <div class="task-meta">
                <span class="task-priority priority-<?php echo esc_attr($priority); ?>">
                    <?php echo esc_html(ucfirst($priority)); ?>
                </span>
                
                <?php if ($assignee_name): ?>
                <span class="task-assignee">
                    👤 <?php echo esc_html($assignee_name); ?>
                </span>
                <?php endif; ?>
                
                <?php if ($countdown_html): ?>
                <span class="task-countdown <?php echo esc_attr($countdown_class); ?>">
                    <?php echo $countdown_html; ?>
                </span>
                <?php endif; ?>

                <?php if ($client_name): ?>
                <span class="task-client">
                    🏢 <?php echo esc_html($client_name); ?>
                </span>
                <?php endif; ?>
            </div>

            <div class="task-actions">
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&action=edit&id=' . $task['id']); ?>">
                    Edit
                </a>
                
                <?php if ($column_status === 'done'): ?>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                    <?php wp_nonce_field('wnq_archive_task'); ?>
                    <input type="hidden" name="action" value="wnq_archive_task">
                    <input type="hidden" name="id" value="<?php echo esc_attr($task['id']); ?>">
                    <button type="submit" class="task-archive">
                        Archive
                    </button>
                </form>
                <?php endif; ?>
                
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                    <?php wp_nonce_field('wnq_delete_task'); ?>
                    <input type="hidden" name="action" value="wnq_delete_task">
                    <input type="hidden" name="id" value="<?php echo esc_attr($task['id']); ?>">
                    <button type="submit" onclick="return confirm('Delete this task?');" class="task-delete">
                        Delete
                    </button>
                </form>
            </div>
        </div>
        <?php
    }

    private static function renderArchiveView(): void
    {
        $archived_tasks = Task::getArchived();
        $archived_count = count($archived_tasks);

        ?>
        <div class="wrap wnq-tasks-admin">
            <!-- Navigation Tabs -->
            <div class="nav-tabs">
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=kanban'); ?>" class="nav-tab">
                    📋 Kanban
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=archive'); ?>" class="nav-tab nav-tab-active">
                    📦 Archive <?php if ($archived_count > 0) echo "($archived_count)"; ?>
                </a>
            </div>

            <div class="tasks-header">
                <div>
                    <h1>Archived Tasks</h1>
                    <p class="subtitle">View and restore archived tasks</p>
                </div>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks'); ?>" class="button button-secondary">
                    ← Back to Kanban
                </a>
            </div>

            <?php if (empty($archived_tasks)): ?>
                <div class="empty-archive">
                    <div class="empty-icon">📦</div>
                    <h3>No Archived Tasks</h3>
                    <p>Archived tasks will appear here</p>
                </div>
            <?php else: ?>
                <div class="archive-grid">
                    <?php foreach ($archived_tasks as $task): ?>
                        <div class="archive-card">
                            <div class="archive-card-header">
                                <div class="task-type-badge type-<?php echo esc_attr($task['task_type'] ?? 'general'); ?>">
                                    <?php 
                                    $types = ['client' => '🏢 Client', 'webnique' => '🏪 WebNique', 'general' => '📝 General'];
                                    echo $types[$task['task_type'] ?? 'general'] ?? '📝 General';
                                    ?>
                                </div>
                                <div class="archive-date">
                                    Archived: <?php echo date('M j, Y', strtotime($task['archived_at'])); ?>
                                </div>
                            </div>
                            
                            <h3 class="archive-title"><?php echo esc_html($task['title']); ?></h3>
                            
                            <?php if (!empty($task['description'])): ?>
                            <p class="archive-description">
                                <?php echo wp_trim_words(esc_html($task['description']), 20); ?>
                            </p>
                            <?php endif; ?>
                            
                            <div class="archive-meta">
                                <span class="task-priority priority-<?php echo esc_attr($task['priority'] ?? 'medium'); ?>">
                                    <?php echo esc_html(ucfirst($task['priority'] ?? 'medium')); ?>
                                </span>
                                <?php if (!empty($task['assigned_to'])): ?>
                                <span class="task-assignee">
                                    👤 <?php echo esc_html($task['assigned_to']); ?>
                                </span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="archive-actions">
                                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                                    <?php wp_nonce_field('wnq_restore_task'); ?>
                                    <input type="hidden" name="action" value="wnq_restore_task">
                                    <input type="hidden" name="id" value="<?php echo esc_attr($task['id']); ?>">
                                    <button type="submit" class="button button-primary">
                                        ↩️ Restore
                                    </button>
                                </form>
                                
                                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                                    <?php wp_nonce_field('wnq_delete_task'); ?>
                                    <input type="hidden" name="action" value="wnq_delete_task">
                                    <input type="hidden" name="id" value="<?php echo esc_attr($task['id']); ?>">
                                    <button type="submit" onclick="return confirm('Permanently delete this task?');" class="button">
                                        Delete
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php self::renderStyles(); ?>
        <?php
    }

    private static function renderStyles(): void
    {
        ?>
        <style>
        .wnq-tasks-admin { margin: 20px 20px 20px 0; }
        
        /* Navigation Tabs */
        .nav-tabs { border-bottom: 1px solid #c3c4c7; margin-bottom: 20px; }
        .nav-tab { display: inline-block; padding: 10px 15px; text-decoration: none; border: 1px solid transparent; margin: 0 4px -1px 0; }
        .nav-tab-active { border: 1px solid #c3c4c7; border-bottom-color: #f0f0f1; background: #f0f0f1; }
        
        .tasks-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
        .tasks-header h1 { margin: 0 0 4px; font-size: 28px; font-weight: 700; }
        .subtitle { color: #6b7280; margin: 0; font-size: 14px; }
        
        .tasks-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px; border-left: 4px solid #0d539e; }
        .stat-label { display: block; font-size: 12px; color: #6b7280; font-weight: 600; text-transform: uppercase; margin-bottom: 8px; }
        .stat-value { display: block; font-size: 32px; font-weight: 800; color: #1e293b; }
        
        /* Type Filters */
        .type-filters { display: flex; gap: 8px; margin-bottom: 20px; padding: 16px; background: white; border: 1px solid #e5e7eb; border-radius: 8px; }
        .filter-tab { padding: 8px 16px; border: 1px solid #e5e7eb; border-radius: 6px; text-decoration: none; color: #374151; font-weight: 600; transition: all 0.2s; }
        .filter-tab:hover { background: #f3f4f6; }
        .filter-tab.active { background: #0d539e; color: white; border-color: #0d539e; }
        
        .kanban-board { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; min-height: 600px; }
        .kanban-column { background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px; min-height: 500px; }
        .column-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 2px solid #e5e7eb; }
        .column-header h3 { margin: 0; font-size: 16px; font-weight: 700; }
        .column-count { background: #e5e7eb; color: #6b7280; padding: 4px 10px; border-radius: 12px; font-size: 13px; font-weight: 700; }
        .column-tasks { min-height: 400px; }
        .column-hover { background: #eff6ff; border-color: #0d539e; }
        
        .task-card { background: white; border: 1px solid #e5e7eb; border-radius: 6px; padding: 12px; margin-bottom: 12px; cursor: move; transition: all 0.2s; position: relative; }
        .task-card:hover { box-shadow: 0 4px 6px rgba(0,0,0,0.1); transform: translateY(-2px); }
        .task-card.dragging { opacity: 0.5; }
        
        /* Task Type Badge */
        .task-type-badge { display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; margin-bottom: 8px; }
        .type-client { background: #dbeafe; color: #1e40af; }
        .type-webnique { background: #d1fae5; color: #065f46; }
        .type-general { background: #f3f4f6; color: #374151; }
        
        .task-title { font-size: 14px; font-weight: 600; color: #1e293b; margin-bottom: 8px; line-height: 1.4; }
        .task-description { font-size: 12px; color: #64748b; margin-bottom: 8px; line-height: 1.5; }
        .task-meta { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 8px; }
        
        .task-priority { padding: 3px 8px; border-radius: 4px; font-weight: 600; text-transform: uppercase; font-size: 11px; }
        .priority-high { background: #fee2e2; color: #991b1b; }
        .priority-medium { background: #fef3c7; color: #92400e; }
        .priority-low { background: #e0f2fe; color: #075985; }
        
        .task-assignee, .task-client { padding: 3px 8px; background: #f3f4f6; border-radius: 4px; color: #374151; font-size: 11px; }
        
        /* Countdown Timers */
        .task-countdown { padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
        .countdown-overdue { background: #fee2e2; color: #991b1b; }
        .countdown-today { background: #fef3c7; color: #92400e; }
        .countdown-soon { background: #fef3c7; color: #92400e; }
        .countdown-normal { background: #e0f2fe; color: #075985; }
        
        .task-actions { display: flex; gap: 8px; margin-top: 8px; padding-top: 8px; border-top: 1px solid #f3f4f6; }
        .task-actions a, .task-actions button { font-size: 11px; text-decoration: none; color: #0d539e; border: none; background: none; cursor: pointer; padding: 0; }
        .task-delete { color: #dc2626 !important; }
        .task-archive { color: #8b5cf6 !important; }
        .task-actions button:hover { text-decoration: underline; }
        
        /* Archive View */
        .empty-archive { text-align: center; padding: 80px 20px; }
        .empty-icon { font-size: 64px; margin-bottom: 16px; }
        .empty-archive h3 { font-size: 20px; margin: 0 0 8px; }
        .empty-archive p { color: #6b7280; margin: 0; }
        
        .archive-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
        .archive-card { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px; }
        .archive-card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .archive-date { font-size: 11px; color: #6b7280; }
        .archive-title { margin: 0 0 8px; font-size: 16px; font-weight: 600; }
        .archive-description { font-size: 13px; color: #64748b; margin: 0 0 12px; }
        .archive-meta { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 12px; }
        .archive-actions { display: flex; gap: 8px; padding-top: 12px; border-top: 1px solid #f3f4f6; }
        
        @media (max-width: 1400px) { .kanban-board { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 900px) { .kanban-board { grid-template-columns: 1fr; } }
        </style>
        <?php
    }

    private static function renderScript(): void
    {
        ?>
        <script>
        jQuery(document).ready(function($) {
            $('.task-card').draggable({
                revert: 'invalid',
                helper: 'clone',
                cursor: 'move',
                opacity: 0.7,
                zIndex: 1000,
                start: function() { $(this).addClass('dragging'); },
                stop: function() { $(this).removeClass('dragging'); }
            });

            $('.column-tasks').droppable({
                accept: '.task-card',
                hoverClass: 'column-hover',
                drop: function(event, ui) {
                    const taskId = ui.draggable.data('task-id');
                    const newStatus = $(this).parent().data('status');
                    
                    $(this).append(ui.draggable);
                    ui.draggable.css({top: 0, left: 0, position: 'relative'});

                    $.post(ajaxurl, {
                        action: 'wnq_update_task_status',
                        task_id: taskId,
                        status: newStatus,
                        nonce: '<?php echo wp_create_nonce('wnq_task_nonce'); ?>'
                    }, function(response) {
                        if (response.success) {
                            $('.kanban-column').each(function() {
                                $(this).find('.column-count').text($(this).find('.task-card').length);
                            });
                        } else {
                            alert('Failed to update task');
                            location.reload();
                        }
                    });
                }
            });
        });
        </script>
        <?php
    }

    private static function renderAddForm(): void
    {
        ?>
        <div class="wrap">
            <h1>New Task</h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-tasks'); ?>" class="page-title-action">← Back</a>
            <?php self::renderTaskForm(null); ?>
        </div>
        <?php
    }

    private static function renderEditForm(int $id): void
    {
        $task = Task::getById($id);
        if (!$task) wp_die('Task not found.');
        ?>
        <div class="wrap">
            <h1>Edit Task</h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-tasks'); ?>" class="page-title-action">← Back</a>
            <?php self::renderTaskForm($task); ?>
        </div>
        <?php
    }

    private static function renderTaskForm(?array $task): void
    {
        $is_edit = !empty($task);
        
        $clients = [];
        if (file_exists(WNQ_PORTAL_PATH . 'includes/Models/Client.php')) {
            require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
            if (class_exists('WNQ\\Models\\Client')) {
                $clients = \WNQ\Models\Client::getAll();
            }
        }

        $team_members = [
            'christopher-scotto' => 'Christopher Scotto',
            'christopher-sanders' => 'Christopher Sanders',
        ];

        ?>
        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" class="task-form">
            <?php wp_nonce_field('wnq_save_task'); ?>
            <input type="hidden" name="action" value="wnq_save_task">
            <?php if ($is_edit): ?>
                <input type="hidden" name="id" value="<?php echo esc_attr($task['id']); ?>">
            <?php endif; ?>

            <div class="task-form-section">
                <h2>Task Details</h2>
                <table class="form-table">
                    <tr>
                        <th><label for="title">Title *</label></th>
                        <td><input type="text" name="title" id="title" value="<?php echo esc_attr($task['title'] ?? ''); ?>" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="description">Description</label></th>
                        <td><textarea name="description" id="description" rows="5" class="large-text"><?php echo esc_textarea($task['description'] ?? ''); ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="task_type">Task Type</label></th>
                        <td>
                            <select name="task_type" id="task_type">
                                <option value="general" <?php selected($task['task_type'] ?? 'general', 'general'); ?>>📝 General</option>
                                <option value="client" <?php selected($task['task_type'] ?? '', 'client'); ?>>🏢 Client Task</option>
                                <option value="webnique" <?php selected($task['task_type'] ?? '', 'webnique'); ?>>🏪 WebNique Task</option>
                            </select>
                            <p class="description">Choose the category for this task</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="status">Status</label></th>
                        <td>
                            <select name="status" id="status">
                                <option value="todo" <?php selected($task['status'] ?? 'todo', 'todo'); ?>>To Do</option>
                                <option value="in_progress" <?php selected($task['status'] ?? '', 'in_progress'); ?>>In Progress</option>
                                <option value="review" <?php selected($task['status'] ?? '', 'review'); ?>>Review</option>
                                <option value="done" <?php selected($task['status'] ?? '', 'done'); ?>>Done</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="priority">Priority</label></th>
                        <td>
                            <select name="priority" id="priority">
                                <option value="low" <?php selected($task['priority'] ?? '', 'low'); ?>>Low</option>
                                <option value="medium" <?php selected($task['priority'] ?? 'medium', 'medium'); ?>>Medium</option>
                                <option value="high" <?php selected($task['priority'] ?? '', 'high'); ?>>High</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="assigned_to">Assign To</label></th>
                        <td>
                            <select name="assigned_to" id="assigned_to">
                                <option value="">Unassigned</option>
                                <?php foreach ($team_members as $id => $name): ?>
                                    <option value="<?php echo esc_attr($id); ?>" <?php selected($task['assigned_to'] ?? '', $id); ?>><?php echo esc_html($name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="due_date">Due Date</label></th>
                        <td><input type="date" name="due_date" id="due_date" value="<?php echo esc_attr($task['due_date'] ?? ''); ?>"></td>
                    </tr>
                    <?php if (!empty($clients)): ?>
                    <tr>
                        <th><label for="client_id">Client (Optional)</label></th>
                        <td>
                            <select name="client_id" id="client_id">
                                <option value="">No client</option>
                                <?php foreach ($clients as $client): ?>
                                    <option value="<?php echo esc_attr($client['client_id']); ?>" <?php selected($task['client_id'] ?? '', $client['client_id']); ?>>
                                        <?php echo esc_html($client['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">Link this task to a client</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <th><label for="is_recurring">Recurring Task</label></th>
                        <td>
                            <label>
                                <input type="checkbox" name="is_recurring" id="is_recurring" value="1" <?php checked(!empty($task['is_recurring'])); ?>>
                                This task repeats
                            </label>
                        </td>
                    </tr>
                    <tr id="recurring_frequency_row" style="<?php echo empty($task['is_recurring']) ? 'display:none;' : ''; ?>">
                        <th><label for="recurring_frequency">Frequency</label></th>
                        <td>
                            <select name="recurring_frequency" id="recurring_frequency">
                                <option value="daily" <?php selected($task['recurring_frequency'] ?? '', 'daily'); ?>>Daily</option>
                                <option value="weekly" <?php selected($task['recurring_frequency'] ?? '', 'weekly'); ?>>Weekly</option>
                                <option value="monthly" <?php selected($task['recurring_frequency'] ?? '', 'monthly'); ?>>Monthly</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="notes">Notes</label></th>
                        <td><textarea name="notes" id="notes" rows="4" class="large-text"><?php echo esc_textarea($task['notes'] ?? ''); ?></textarea></td>
                    </tr>
                </table>
            </div>

            <p class="submit">
                <button type="submit" class="button button-primary button-large"><?php echo $is_edit ? 'Update Task' : 'Create Task'; ?></button>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks'); ?>" class="button button-large">Cancel</a>
            </p>
        </form>

        <script>
        jQuery(document).ready(function($) {
            $('#is_recurring').change(function() {
                if ($(this).is(':checked')) {
                    $('#recurring_frequency_row').show();
                } else {
                    $('#recurring_frequency_row').hide();
                }
            });
        });
        </script>

        <style>
        .task-form-section { background: white; padding: 20px; margin-bottom: 20px; border: 1px solid #e5e7eb; border-radius: 8px; }
        .task-form-section h2 { margin-top: 0; padding-bottom: 10px; border-bottom: 1px solid #e5e7eb; font-size: 18px; }
        </style>
        <?php
    }

    // Form handlers
    public static function handleSaveTask(): void
    {
        check_admin_referer('wnq_save_task');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $data = [
            'title' => sanitize_text_field($_POST['title'] ?? ''),
            'description' => wp_kses_post($_POST['description'] ?? ''),
            'status' => sanitize_text_field($_POST['status'] ?? 'todo'),
            'task_type' => sanitize_text_field($_POST['task_type'] ?? 'general'),
            'priority' => sanitize_text_field($_POST['priority'] ?? 'medium'),
            'assigned_to' => sanitize_text_field($_POST['assigned_to'] ?? ''),
            'due_date' => sanitize_text_field($_POST['due_date'] ?? ''),
            'client_id' => sanitize_text_field($_POST['client_id'] ?? ''),
            'notes' => wp_kses_post($_POST['notes'] ?? ''),
            'is_recurring' => !empty($_POST['is_recurring']) ? 1 : 0,
            'recurring_frequency' => !empty($_POST['is_recurring']) ? sanitize_text_field($_POST['recurring_frequency'] ?? '') : null,
        ];

        $success = $id ? Task::update($id, $data) : Task::create($data);
        wp_redirect(admin_url('admin.php?page=wnq-tasks'));
        exit;
    }

    public static function handleDeleteTask(): void
    {
        check_admin_referer('wnq_delete_task');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        Task::delete($id);
        
        $redirect = isset($_POST['redirect']) ? sanitize_text_field($_POST['redirect']) : 'kanban';
        wp_redirect(admin_url('admin.php?page=wnq-tasks&view=' . $redirect));
        exit;
    }

    public static function handleArchive(): void
    {
        check_admin_referer('wnq_archive_task');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        Task::archive($id);
        wp_redirect(admin_url('admin.php?page=wnq-tasks'));
        exit;
    }

    public static function handleRestore(): void
    {
        check_admin_referer('wnq_restore_task');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        Task::restore($id);
        wp_redirect(admin_url('admin.php?page=wnq-tasks&view=archive'));
        exit;
    }

    public static function ajaxUpdateTaskStatus(): void
    {
        check_ajax_referer('wnq_task_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Insufficient permissions');

        $task_id = isset($_POST['task_id']) ? intval($_POST['task_id']) : 0;
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';

        if (!$task_id || !$status) wp_send_json_error('Invalid data');

        $success = Task::update($task_id, ['status' => $status]);
        $success ? wp_send_json_success() : wp_send_json_error('Failed');
    }
}