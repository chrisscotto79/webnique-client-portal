<?php

namespace WNQ\PublicSite;

use WNQ\Core\Permissions;

if (!defined('ABSPATH')) {
  exit;
}

final class Shortcode
{
  private static bool $moduleTagHooked = false;

  public static function register(): void
  {
    add_shortcode('wnq_portal', [self::class, 'render']);
  }

  public static function render($atts = []): string
  {
    if (!Permissions::isLoggedIn()) {
      return '<p>You must be logged in to view this portal.</p>';
    }

    $clientId = Permissions::currentUserClientId();

    if ($clientId === null && !Permissions::currentUserCanManagePortal()) {
      return '<p>Your account is not linked to a client yet. Please contact WebNique.</p>';
    }

    self::enqueueAssets($clientId ?? '');

    $args = [
      'client_id' => $clientId ?? '',
      'mode' => Permissions::currentUserCanManagePortal() ? 'admin' : 'client',
    ];

    // portal-shell.php must define this function.
    return \wnq_portal_shell_html($args);
  }

  private static function enqueueAssets(string $clientId): void
  {
    $cssPath = WNQ_PORTAL_PATH . 'assets/app/app.css';
    $jsPath  = WNQ_PORTAL_PATH . 'assets/app/app.js';

    $cssVer = file_exists($cssPath)
      ? (string) filemtime($cssPath)
      : (defined('WNQ_PORTAL_VERSION') ? WNQ_PORTAL_VERSION : (string) time());

    $jsVer = file_exists($jsPath)
      ? (string) filemtime($jsPath)
      : (defined('WNQ_PORTAL_VERSION') ? WNQ_PORTAL_VERSION : (string) time());

    wp_enqueue_style(
      'wnq-portal-app',
      WNQ_PORTAL_URL . 'assets/app/app.css',
      [],
      $cssVer
    );

    wp_enqueue_script(
      'wnq-portal-app',
      WNQ_PORTAL_URL . 'assets/app/app.js',
      [],
      $jsVer,
      true
    );

    /**
     * ✅ Make app.js an ES module (so `import ...` works)
     * Preferred: wp_script_add_data (no global filter).
     * Fallback: script_loader_tag filter (added once).
     */
    if (function_exists('wp_script_add_data')) {
      // Works on modern WP builds that support "type" on scripts.
      wp_script_add_data('wnq-portal-app', 'type', 'module');
    } else {
      // Older WP fallback
      self::ensureModuleScriptTagFallback();
    }

    wp_localize_script('wnq-portal-app', 'WNQ_PORTAL', [
      'restUrl'   => esc_url_raw(rest_url('wnq/v1')),
      'nonce'     => wp_create_nonce('wp_rest'),
      'clientId'  => $clientId,
      'isAdmin'   => current_user_can('wnq_manage_portal') || current_user_can('manage_options'),
    ]);
  }

  private static function ensureModuleScriptTagFallback(): void
  {
    if (self::$moduleTagHooked) {
      return;
    }
    self::$moduleTagHooked = true;

    add_filter('script_loader_tag', function ($tag, $handle, $src) {
      if ($handle === 'wnq-portal-app') {
        return '<script type="module" src="' . esc_url($src) . '"></script>';
      }
      return $tag;
    }, 10, 3);
  }
}
