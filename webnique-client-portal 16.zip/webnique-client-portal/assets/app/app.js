(async function () {
  const root = document.getElementById("wnq-portal-root");
  if (!root) return;

  const clientId = root.getAttribute("data-client-id") || "";
  const mode = root.getAttribute("data-mode") || "";
  const restBase = window.WNQ_PORTAL?.restUrl || "";
  const nonce = window.WNQ_PORTAL?.nonce || "";
  const isAdmin = !!window.WNQ_PORTAL?.isAdmin;

  // Brand
  const BRAND = { primary: "#0d539e" };

  // ---------------- CSS ----------------
  const css = `
    :root{
      --wnq-primary:${BRAND.primary};
      --wnq-primary-weak: rgba(13,83,158,.10);
      --wnq-primary-mid: rgba(13,83,158,.18);
      --wnq-border: #e5e7eb;
      --wnq-text: #0f172a;
      --wnq-muted: #64748b;
      --wnq-bg: #ffffff;
      --wnq-soft: #f8fafc;
      --wnq-shadow: 0 1px 0 rgba(15,23,42,.04);
      --wnq-radius: 18px;
    }

    .wnq-root{
      font-family: system-ui,-apple-system,Segoe UI,Roboto,Arial;
      color: var(--wnq-text);
    }

    .wnq-shell{
      display:grid;
      grid-template-columns: 280px 1fr;
      gap: 14px;
      align-items:start;
    }

    @media (max-width: 1024px){
      .wnq-shell{ grid-template-columns: 1fr; }
      .wnq-sidebar{ position: relative; top:auto; }
    }

    .wnq-card{
      background: var(--wnq-bg);
      border: 1px solid var(--wnq-border);
      border-radius: var(--wnq-radius);
      box-shadow: var(--wnq-shadow);
    }

    .wnq-sidebar{
      position: sticky;
      top: 18px;
      padding: 14px;
      overflow:hidden;
    }

    .wnq-sidebar:before{
      content:"";
      display:block;
      height: 4px;
      border-radius: 999px;
      background: linear-gradient(90deg, var(--wnq-primary), rgba(13,83,158,.55));
      margin-bottom: 12px;
    }

    .wnq-brand{
      display:flex;
      flex-direction:column;
      gap:6px;
      padding: 4px 2px 12px;
    }

    .wnq-brand h2{
      margin:0;
      font-size:16px;
      font-weight:950;
      letter-spacing:-0.01em;
    }
    .wnq-brand .sub{
      font-size:12px;
      color: var(--wnq-muted);
      line-height: 1.35;
    }

    .wnq-code{
      background: rgba(15,23,42,0.05);
      border: 1px solid rgba(15,23,42,0.06);
      padding: 2px 7px;
      border-radius: 10px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
      font-size: 12px;
    }

    .wnq-pill{
      display:inline-flex;align-items:center;gap:6px;
      padding:7px 11px;border-radius:999px;
      font-size:12px;white-space:nowrap;
      border:1px solid var(--wnq-border);
      background: var(--wnq-soft);
      color: #334155;
      font-weight: 800;
    }
    .wnq-pill.ok{border-color:rgba(16,185,129,.35);background:rgba(16,185,129,.10);color:#065f46;}
    .wnq-pill.warn{border-color:rgba(245,158,11,.35);background:rgba(245,158,11,.10);color:#92400e;}
    .wnq-pill.err{border-color:rgba(239,68,68,.35);background:rgba(239,68,68,.10);color:#991b1b;}
    .wnq-pill.brand{border-color:rgba(13,83,158,.30);background:var(--wnq-primary-weak);color:var(--wnq-primary);}

    .wnq-nav{
      display:grid;
      gap: 6px;
      margin-top: 8px;
    }

    .wnq-nav button{
      width:100%;
      text-align:left;
      border-radius: 14px;
      border:1px solid var(--wnq-border);
      background:#fff;
      padding: 10px 12px;
      cursor:pointer;
      font-weight: 950;
      color: var(--wnq-text);
      display:flex;
      justify-content:space-between;
      align-items:center;
      transition: background .15s ease, border-color .15s ease, transform .05s ease;
    }

    .wnq-nav button:hover{
      background: var(--wnq-primary-weak);
      border-color: rgba(13,83,158,.28);
    }

    .wnq-nav button:active{ transform: translateY(1px); }

    .wnq-nav button.active{
      background: var(--wnq-primary-weak);
      border-color: rgba(13,83,158,.45);
      box-shadow: 0 0 0 3px rgba(13,83,158,.10);
    }

    .wnq-nav small{
      color: var(--wnq-muted);
      font-weight: 800;
    }

    .wnq-sidebar-footer{
      margin-top: 12px;
      padding-top: 12px;
      border-top: 1px dashed var(--wnq-border);
      display:grid;
      gap:10px;
    }

    .wnq-btn{
      padding:10px 12px;
      border-radius:14px;
      border:1px solid var(--wnq-border);
      background:#fff;
      cursor:pointer;
      font-weight: 950;
      color: var(--wnq-primary);
      transition: transform .05s ease, background .15s ease, border-color .15s ease, box-shadow .15s ease;
    }
    .wnq-btn:hover{
      background: var(--wnq-primary-weak);
      border-color: rgba(13,83,158,.28);
    }
    .wnq-btn:active{ transform: translateY(1px); }
    .wnq-btn.solid{
      color:#fff;
      background: var(--wnq-primary);
      border-color: rgba(13,83,158,.55);
      box-shadow: 0 0 0 3px rgba(13,83,158,.10);
    }
    .wnq-btn.solid:hover{
      background: #0b4a88;
      border-color: #0b4a88;
    }

    .wnq-main{
      padding: 0;
    }

    .wnq-header{
      padding: 16px;
      border-radius: var(--wnq-radius);
      border: 1px solid var(--wnq-border);
      background: var(--wnq-bg);
      box-shadow: var(--wnq-shadow);
      position: relative;
      overflow:hidden;
      margin-bottom: 14px;
    }

    .wnq-header:before{
      content:"";
      position:absolute;
      left:0; top:0; right:0;
      height:4px;
      background: linear-gradient(90deg, var(--wnq-primary), rgba(13,83,158,.55));
    }

    .wnq-header .row{
      display:flex;
      justify-content:space-between;
      gap:12px;
      align-items:flex-start;
      flex-wrap:wrap;
    }

    .wnq-header h1{
      margin:0;
      font-size: 18px;
      font-weight: 950;
      letter-spacing:-0.01em;
    }
    .wnq-header .meta{
      margin-top:6px;
      font-size: 13px;
      color: var(--wnq-muted);
      line-height: 1.35;
    }

    .wnq-grid{
      display:grid;
      gap: 12px;
    }
    .wnq-grid.kpis{ grid-template-columns: repeat(12, minmax(0,1fr)); }
    .wnq-col-3{grid-column: span 3;}
    .wnq-col-4{grid-column: span 4;}
    .wnq-col-5{grid-column: span 5;}
    .wnq-col-6{grid-column: span 6;}
    .wnq-col-7{grid-column: span 7;}
    .wnq-col-8{grid-column: span 8;}
    .wnq-col-12{grid-column: span 12;}
    @media (max-width: 960px){
      .wnq-col-3,.wnq-col-4,.wnq-col-5,.wnq-col-6,.wnq-col-7,.wnq-col-8{grid-column:span 12;}
    }

    .wnq-metric{
      padding: 16px;
    }
    .wnq-metric-label{
      font-size:12px;
      color: var(--wnq-muted);
      margin-bottom: 6px;
      font-weight: 850;
    }
    .wnq-metric-value{
      font-size: 18px;
      font-weight: 950;
      letter-spacing:-0.01em;
    }
    .wnq-muted{
      color: var(--wnq-muted);
      font-size: 13px;
      line-height: 1.4;
    }

    .wnq-section{
      padding: 16px;
    }
    .wnq-section-title{
      font-size: 16px;
      font-weight: 950;
      margin: 0;
    }
    .wnq-section-sub{
      margin-top: 6px;
      color: var(--wnq-muted);
      font-size: 13px;
    }

    .wnq-item{
      display:flex;
      justify-content:space-between;
      gap: 10px;
      align-items:flex-start;
      padding: 12px;
      border:1px solid var(--wnq-border);
      border-radius: 16px;
      background:#fff;
    }

    .wnq-item-title{font-weight:950;}
    .wnq-item-meta{color:var(--wnq-muted);font-size:12px;margin-top:4px;}

    .wnq-pre{
      white-space:pre-wrap;
      background: rgba(15,23,42,0.04);
      padding:10px;
      border-radius:14px;
      max-height:360px;
      overflow:auto;
      border:1px solid var(--wnq-border);
      color:#0f172a;
      font-size: 12px;
    }

    .wnq-skel{
      border-radius:12px;
      background: linear-gradient(90deg, rgba(13,83,158,0.06), rgba(13,83,158,0.12), rgba(13,83,158,0.06));
      background-size:200% 100%;
      animation:wnqShimmer 1.2s infinite;
    }
    @keyframes wnqShimmer{0%{background-position:0% 0}100%{background-position:200% 0}}
  `;

  const oldStyle = document.getElementById("wnq-style");
  if (oldStyle) oldStyle.remove();
  const styleTag = document.createElement("style");
  styleTag.id = "wnq-style";
  styleTag.textContent = css;
  document.head.appendChild(styleTag);

  // ---------------- helpers ----------------
  const el = (tag, cls, html) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  };

  const code = (v) => `<code class="wnq-code">${String(v)}</code>`;

  async function api(path, { method = "GET", body = null } = {}) {
    if (!restBase || !nonce) return { ok: false, error: "Missing restUrl/nonce" };
    const opts = { method, credentials: "same-origin", headers: { "X-WP-Nonce": nonce } };
    if (body != null) {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
    try {
      const res = await fetch(`${restBase}${path}`, opts);
      const data = await res.json().catch(() => ({}));
      return { ok: true, http_ok: res.ok, status: res.status, data };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  }

  // ---------------- state ----------------
  const State = {
    page: "dashboard",
    ping: null,
    client: null,
    statusPill: { text: "loading…", kind: "brand" },
  };

  const Pages = [
    { id: "dashboard", label: "Dashboard", hint: "Overview" },
    { id: "subscription", label: "Subscription", hint: "Stripe" },
    { id: "analytics", label: "Analytics", hint: "GA4/GSC" },
    { id: "requests", label: "Web Requests", hint: "Tickets" },
    { id: "settings", label: "Settings", hint: "Profile" },
  ];

  function setStatus(text, kind = "brand") {
    State.statusPill = { text, kind };
    renderAll();
  }

  // ---------------- layout ----------------
  root.classList.add("wnq-root");
  const shell = el("div", "wnq-shell");

  const sidebar = el("aside", "wnq-card wnq-sidebar");
  const main = el("main", "wnq-main");

  shell.appendChild(sidebar);
  shell.appendChild(main);
  root.appendChild(shell);

  // ---------------- sidebar ----------------
  function renderSidebar() {
    sidebar.innerHTML = "";

    const brand = el(
      "div",
      "wnq-brand",
      `<h2>WebNique Client Portal</h2>
       <div class="sub">Client: ${code(clientId || "(none)")}<br/>Mode: ${code(mode || "(none)")} ${isAdmin ? `· ${code("admin")}` : ""}</div>`
    );

    const pill = el("div", "");
    const pillNode = el("span", `wnq-pill ${State.statusPill.kind}`, State.statusPill.text);
    pill.appendChild(pillNode);

    const nav = el("nav", "wnq-nav");
    Pages.forEach((p) => {
      const b = el("button", State.page === p.id ? "active" : "", `${p.label} <small>${p.hint}</small>`);
      b.type = "button";
      b.addEventListener("click", () => {
        State.page = p.id;
        renderAll();
      });
      nav.appendChild(b);
    });

    const footer = el("div", "wnq-sidebar-footer");
    const btnPing = el("button", "wnq-btn", "Ping (REST)");
    btnPing.type = "button";
    btnPing.addEventListener("click", async () => {
      setStatus("pinging…", "brand");
      const r = await api("/ping");
      if (r.ok && r.http_ok) {
        State.ping = r.data;
        setStatus("ping ok", "ok");
      } else setStatus("ping failed", "err");
      renderAll();
    });

    const btnClient = el("button", "wnq-btn", "Load Client Doc");
    btnClient.type = "button";
    btnClient.addEventListener("click", async () => {
      setStatus("loading client…", "brand");
      const r = await api("/client");
      if (r.ok && r.http_ok) {
        State.client = r.data;
        setStatus(r.data?.exists ? "client loaded" : "client missing", r.data?.exists ? "ok" : "warn");
      } else setStatus("client error", "err");
      renderAll();
    });

    footer.appendChild(btnPing);
    footer.appendChild(btnClient);

    if (isAdmin) {
      const btnBoot = el("button", "wnq-btn solid", "Bootstrap Client");
      btnBoot.type = "button";
      btnBoot.addEventListener("click", async () => {
        setStatus("bootstrapping…", "brand");
        const r = await api("/clients/bootstrap", { method: "POST", body: { client_id: clientId } });
        if (r.ok && r.http_ok) {
          setStatus("bootstrapped", "ok");
        } else setStatus("bootstrap failed", "err");
        // refresh client after boot
        const c = await api("/client");
        if (c.ok && c.http_ok) State.client = c.data;
        renderAll();
      });
      footer.appendChild(btnBoot);
    }

    sidebar.appendChild(brand);
    sidebar.appendChild(pill);
    sidebar.appendChild(nav);
    sidebar.appendChild(footer);
  }

  // ---------------- main header ----------------
  function renderMainHeader() {
    const header = el("div", "wnq-header");
    const row = el("div", "row");

    const left = el(
      "div",
      "",
      `<h1>${Pages.find((p) => p.id === State.page)?.label || "Portal"}</h1>
       <div class="meta">Client: ${code(clientId || "(none)")} · Mode: ${code(mode || "(none)")} ${
        isAdmin ? ` · ${code("admin")}` : ""
      }</div>`
    );

    const right = el("div", "");
    const p = el("span", `wnq-pill ${State.statusPill.kind}`, State.statusPill.text);
    right.appendChild(p);

    row.appendChild(left);
    row.appendChild(right);
    header.appendChild(row);

    return header;
  }

  // ---------------- views ----------------
  function kpi(label, value, hint, colClass = "wnq-col-3") {
    const c = el("div", `wnq-card wnq-metric ${colClass}`);
    c.innerHTML = `
      <div class="wnq-metric-label">${label}</div>
      <div class="wnq-metric-value">${value}</div>
      <div class="wnq-muted" style="margin-top:6px;">${hint}</div>
    `;
    return c;
  }

  function dashboardView() {
    const v = el("div", "wnq-grid");

    const clientExists = State.client?.exists === true;

    const kpis = el("div", "wnq-grid kpis");
    kpis.appendChild(kpi("Client Doc", clientExists ? "Exists" : "Missing", "Firestore clients/{client_id}", "wnq-col-3"));
    kpis.appendChild(kpi("Subscription", "Not connected", "Stripe next phase", "wnq-col-3"));
    kpis.appendChild(kpi("SEO Progress", "Coming soon", "Milestones later", "wnq-col-3"));
    kpis.appendChild(kpi("Last Update", "—", "Activity later", "wnq-col-3"));
    v.appendChild(kpis);

    const grid = el("div", "wnq-grid kpis");

    const left = el("div", "wnq-card wnq-section wnq-col-7");
    left.innerHTML = `
      <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
        <div>
          <div class="wnq-section-title">Overview</div>
          <div class="wnq-section-sub">This is the dashboard shell. We’ll add real metrics later.</div>
        </div>
        <span class="wnq-pill ${clientExists ? "ok" : "warn"}">${clientExists ? "client ready" : "needs bootstrap"}</span>
      </div>

      <div style="margin-top:14px; display:grid; gap:10px;">
        <div class="wnq-item">
          <div>
            <div class="wnq-item-title">Next: Dashboard UI</div>
            <div class="wnq-item-meta">Finalize layout + components before adding APIs.</div>
          </div>
          <span class="wnq-pill brand">phase 1</span>
        </div>
        <div class="wnq-item">
          <div>
            <div class="wnq-item-title">Later: Stripe subscription</div>
            <div class="wnq-item-meta">Plan, status, renewal date (server-side REST + Stripe SDK).</div>
          </div>
          <span class="wnq-pill">phase 2</span>
        </div>
        <div class="wnq-item">
          <div>
            <div class="wnq-item-title">Later: Analytics</div>
            <div class="wnq-item-meta">GA4 + GSC summarized in Firestore.</div>
          </div>
          <span class="wnq-pill">phase 3</span>
        </div>
      </div>
    `;

    const right = el("div", "wnq-card wnq-section wnq-col-5");
    right.innerHTML = `
      <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap;">
        <div>
          <div class="wnq-section-title">Quick Actions</div>
          <div class="wnq-section-sub">These actions will stay in sidebar too.</div>
        </div>
        <span class="wnq-pill brand">ui only</span>
      </div>

      <div style="margin-top:14px; display:flex; gap:10px; flex-wrap:wrap;">
        <button type="button" class="wnq-btn" data-act="load">Load Client Doc</button>
        ${isAdmin ? `<button type="button" class="wnq-btn solid" data-act="boot">Bootstrap Client</button>` : ``}
        <button type="button" class="wnq-btn" data-act="ping">Ping (REST)</button>
      </div>

      <div style="margin-top:14px;">
        <div class="wnq-muted">Output</div>
        <div id="wnq-out" class="wnq-pre" style="margin-top:8px;">(actions will show JSON here)</div>
      </div>
    `;

    grid.appendChild(left);
    grid.appendChild(right);
    v.appendChild(grid);

    // wire actions
    const out = right.querySelector("#wnq-out");
    const show = (json) => (out.textContent = JSON.stringify(json, null, 2));

    right.querySelector('[data-act="ping"]').addEventListener("click", async () => {
      out.textContent = "Pinging…";
      const r = await api("/ping");
      show(r.ok ? r.data : r);
      if (r.ok && r.http_ok) {
        State.ping = r.data;
        setStatus("ping ok", "ok");
      } else setStatus("ping failed", "err");
    });

    right.querySelector('[data-act="load"]').addEventListener("click", async () => {
      out.textContent = "Loading client…";
      const r = await api("/client");
      show(r.ok ? r.data : r);
      if (r.ok && r.http_ok) {
        State.client = r.data;
        setStatus(r.data?.exists ? "client loaded" : "client missing", r.data?.exists ? "ok" : "warn");
      } else setStatus("client error", "err");
    });

    const boot = right.querySelector('[data-act="boot"]');
    if (boot) {
      boot.addEventListener("click", async () => {
        out.textContent = "Bootstrapping…";
        const r = await api("/clients/bootstrap", { method: "POST", body: { client_id: clientId } });
        show(r.ok ? r.data : r);
        setStatus(r.ok && r.http_ok ? "bootstrapped" : "bootstrap failed", r.ok && r.http_ok ? "ok" : "err");
      });
    }

    return v;
  }

  function placeholderView(title, subtitle) {
    const c = el("div", "wnq-card wnq-section");
    c.innerHTML = `
      <div class="wnq-section-title">${title}</div>
      <div class="wnq-section-sub">${subtitle}</div>
      <div style="margin-top:14px;">
        <div class="wnq-skel" style="height:14px;width:260px;"></div>
        <div class="wnq-skel" style="height:14px;width:65%;margin-top:10px;"></div>
        <div class="wnq-skel" style="height:14px;width:45%;margin-top:10px;"></div>
        <div class="wnq-skel" style="height:240px;width:100%;margin-top:14px;"></div>
      </div>
    `;
    return c;
  }

  function renderMain() {
    main.innerHTML = "";
    main.appendChild(renderMainHeader());

    if (State.page === "dashboard") {
      main.appendChild(dashboardView());
      return;
    }

    if (State.page === "subscription") {
      main.appendChild(placeholderView("Subscription", "UI only. We’ll wire Stripe later."));
      return;
    }

    if (State.page === "analytics") {
      main.appendChild(placeholderView("Analytics", "UI only. We’ll wire GA4 + GSC later."));
      return;
    }

    if (State.page === "requests") {
      main.appendChild(placeholderView("Web Requests", "UI only. We’ll wire threads/messages later."));
      return;
    }

    if (State.page === "settings") {
      main.appendChild(placeholderView("Settings", "UI only. Minimal for v1."));
      return;
    }
  }

  function renderAll() {
    renderSidebar();
    renderMain();
  }

  // ---------------- boot ----------------
  renderAll();
  setStatus("loading…", "brand");

  // Auto-hydrate ping + client
  const pingRes = await api("/ping");
  if (pingRes.ok && pingRes.http_ok) {
    State.ping = pingRes.data;
    setStatus("ping ok", "ok");
  } else {
    setStatus("ping failed", "err");
  }

  const clientRes = await api("/client");
  if (clientRes.ok && clientRes.http_ok) {
    State.client = clientRes.data;
    setStatus(clientRes.data?.exists ? "ready" : "client missing", clientRes.data?.exists ? "ok" : "warn");
  }

  renderAll();
})();
