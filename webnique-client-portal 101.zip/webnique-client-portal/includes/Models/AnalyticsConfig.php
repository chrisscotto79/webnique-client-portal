<?php
/**
 * Analytics Configuration Model - COMPLETE
 * 
 * Manages multi-client analytics configuration
 * Stores client-specific settings and shared credentials
 */

namespace WNQ\Models;

if (!defined('ABSPATH')) exit;

class AnalyticsConfig
{
    /**
     * Create database tables
     */
    public static function createTables(): void
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Client configurations table
        $config_table = $wpdb->prefix . 'wnq_analytics_config';
        $config_sql = "CREATE TABLE IF NOT EXISTS {$config_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            client_id varchar(100) NOT NULL,
            client_name varchar(255) NOT NULL,
            ga4_property_id varchar(100) NOT NULL,
            website_url varchar(255) NOT NULL,
            search_console_url varchar(255) DEFAULT NULL,
            timezone varchar(50) DEFAULT 'America/New_York',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY client_id (client_id)
        ) {$charset_collate};";

        // Shared credentials table
        $creds_table = $wpdb->prefix . 'wnq_analytics_credentials';
        $creds_sql = "CREATE TABLE IF NOT EXISTS {$creds_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            email varchar(255) NOT NULL,
            credentials longtext NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) {$charset_collate};";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($config_sql);
        dbDelta($creds_sql);
    }

    /**
     * Get all clients
     */
    public static function getAllClients(): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_analytics_config';
        
        $results = $wpdb->get_results(
            "SELECT * FROM {$table} ORDER BY client_name ASC",
            ARRAY_A
        );
        
        return $results ?: [];
    }

    /**
     * Get specific client configuration
     */
    public static function getClientConfig(string $client_id): ?array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_analytics_config';
        
        $result = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table} WHERE client_id = %s", $client_id),
            ARRAY_A
        );
        
        return $result ?: null;
    }

    /**
     * Save or update client configuration
     */
    public static function saveClientConfig(array $config): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_analytics_config';
        
        // Check if client exists
        $exists = $wpdb->get_var(
            $wpdb->prepare("SELECT id FROM {$table} WHERE client_id = %s", $config['client_id'])
        );
        
        $data = [
            'client_id' => $config['client_id'],
            'client_name' => $config['client_name'],
            'ga4_property_id' => $config['ga4_property_id'],
            'website_url' => $config['website_url'],
            'search_console_url' => $config['search_console_url'] ?? '',
            'timezone' => $config['timezone'] ?? 'America/New_York',
        ];
        
        if ($exists) {
            // Update existing
            $result = $wpdb->update(
                $table,
                $data,
                ['client_id' => $config['client_id']],
                ['%s', '%s', '%s', '%s', '%s', '%s'],
                ['%s']
            );
            
            return $result !== false;
        } else {
            // Insert new
            $result = $wpdb->insert(
                $table,
                $data,
                ['%s', '%s', '%s', '%s', '%s', '%s']
            );
            
            return $result !== false;
        }
    }

    /**
     * Delete a client
     */
    public static function deleteClient(string $client_id): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_analytics_config';
        
        $result = $wpdb->delete(
            $table,
            ['client_id' => $client_id],
            ['%s']
        );
        
        return $result !== false;
    }

    /**
     * Get service account credentials
     */
    public static function getCredentials(): ?array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_analytics_credentials';
        
        $result = $wpdb->get_row(
            "SELECT * FROM {$table} ORDER BY id DESC LIMIT 1",
            ARRAY_A
        );
        
        if (!$result) {
            return null;
        }
        
        // Parse credentials JSON
        $credentials = json_decode($result['credentials'], true);
        
        return [
            'email' => $result['email'],
            'credentials' => $credentials
        ];
    }

    /**
     * Save service account credentials
     */
    public static function saveCredentials(array $creds): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_analytics_credentials';
        
        // Delete existing credentials (we only keep one set)
        $wpdb->query("TRUNCATE TABLE {$table}");
        
        // Insert new credentials
        $result = $wpdb->insert(
            $table,
            [
                'email' => $creds['client_email'],
                'credentials' => json_encode($creds)
            ],
            ['%s', '%s']
        );
        
        return $result !== false;
    }

    /**
     * Get count of clients
     */
    public static function getClientCount(): int
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_analytics_config';
        
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
    }
}