// assets/app/modules/tabs/requests.js
/**
 * Web Requests Tab - Real-time Firebase Messaging
 * 
 * Direct Firebase integration - no REST API needed
 * Real-time updates when messages are sent/received
 */

import { el, pill, button, escapeHtml } from "../ui.js";
import {
  initFirebase,
  getThreads,
  getMessages,
  sendMessage,
  createThread,
  subscribeToThreads,
  subscribeToMessages,
  markThreadAsRead,
} from "../services/firebase.js";

// State
let currentThreadId = null;
let threadsUnsubscribe = null;
let messagesUnsubscribe = null;

export function renderRequests(main, side, state, shell) {
  main.innerHTML = "";
  side.innerHTML = "";

  if (shell?.setStatus) {
    shell.setStatus("Loading requests...", "neutral");
  }

  // ========================================
  // HEADER
  // ========================================
  const headerContainer = el("div");
  main.appendChild(headerContainer);

  // ========================================
  // CREATE LAYOUT (2-COLUMN)
  // ========================================
  const layout = el("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "350px 1fr",
      gap: "20px",
      minHeight: "600px",
    },
  });

  // Thread list (left)
  const threadList = el("div", {
    id: "thread-list",
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "12px",
      overflow: "hidden",
    },
  });

  // Message view (center)
  const messageView = el("div", {
    id: "message-view",
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "12px",
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
    },
  });

  layout.appendChild(threadList);
  layout.appendChild(messageView);
  main.appendChild(layout);

  // ========================================
  // INITIALIZE FIREBASE & LOAD DATA
  // ========================================
  initFirebase().then((success) => {
    if (!success) {
      showError(messageView, "Failed to initialize messaging system. Check Firebase config.");
      if (shell?.setStatus) {
        shell.setStatus("Error", "bad");
      }
      return;
    }

    // Render header with new request button
    headerContainer.appendChild(
      createHeader(state, () => {
        showNewThreadModal(state, threadList, messageView, side, shell);
      })
    );

    // Load threads
    loadThreadsWithFirebase(threadList, messageView, side, state, shell);
  });
}

/**
 * Create header with new request button
 */
function createHeader(state, onNewRequest) {
  const header = el("div", {
    style: {
      marginBottom: "24px",
      paddingBottom: "20px",
      borderBottom: "2px solid rgba(2,6,23,0.08)",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
    },
  });

  const titleSection = el("div");

  titleSection.appendChild(
    el("h1", {
      text: "Web Requests",
      style: {
        fontSize: "32px",
        fontWeight: "900",
        color: "#111827",
        marginBottom: "8px",
      },
    })
  );

  titleSection.appendChild(
    el("p", {
      text: "Communicate with the WebNique team about your website.",
      style: {
        fontSize: "16px",
        color: "#6b7280",
        margin: "0",
      },
    })
  );

  header.appendChild(titleSection);

  // New request button
  const newRequestBtn = button(
    state,
    "+ New Request",
    onNewRequest,
    "solid"
  );
  header.appendChild(newRequestBtn);

  return header;
}

/**
 * Load threads with Firebase real-time updates
 */
async function loadThreadsWithFirebase(threadList, messageView, side, state, shell) {
  try {
    // Unsubscribe from previous listener
    if (threadsUnsubscribe) {
      threadsUnsubscribe();
    }

    // Show loading
    threadList.innerHTML = "";
    threadList.appendChild(
      el("div", {
        style: { padding: "40px", textAlign: "center" },
        html: '<div class="wnq-spinner"></div>',
      })
    );

    // Get initial threads
    const threads = await getThreads(state.clientId);

    if (shell?.setStatus) {
      shell.setStatus("Ready", "good");
    }

    if (threads.length === 0) {
      renderEmptyState(threadList, messageView);
      return;
    }

    // Render thread list
    renderThreadList(threadList, threads, (thread) => {
      loadMessagesForThread(messageView, side, state, thread);
    });

    // Load first thread
    loadMessagesForThread(messageView, side, state, threads[0]);

    // Subscribe to real-time updates
    threadsUnsubscribe = subscribeToThreads(state.clientId, (updatedThreads) => {
      console.log("[Requests] Threads updated:", updatedThreads.length);
      renderThreadList(threadList, updatedThreads, (thread) => {
        loadMessagesForThread(messageView, side, state, thread);
      });
    });

  } catch (error) {
    console.error("[Requests] Load error:", error);
    showError(threadList, error.message);
    if (shell?.setStatus) {
      shell.setStatus("Error", "bad");
    }
  }
}

/**
 * Render thread list
 */
function renderThreadList(container, threads, onThreadClick) {
  container.innerHTML = "";

  // Header
  const header = el("div", {
    style: {
      padding: "16px 20px",
      borderBottom: "1px solid #e5e7eb",
      background: "#f9fafb",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
    },
  });

  header.appendChild(
    el("h3", {
      text: "All Requests",
      style: {
        fontSize: "14px",
        fontWeight: "700",
        color: "#374151",
        margin: "0",
      },
    })
  );

  header.appendChild(
    pill(`${threads.length}`, "neutral")
  );

  container.appendChild(header);

  // Thread items
  const listContainer = el("div", {
    style: {
      maxHeight: "calc(100vh - 400px)",
      overflowY: "auto",
    },
  });

  const activeThreadId = currentThreadId || threads[0]?.id;

  threads.forEach((thread) => {
    const item = createThreadItem(thread, thread.id === activeThreadId);

    item.addEventListener("click", () => {
      currentThreadId = thread.id;

      // Update active state
      listContainer.querySelectorAll("[data-thread-item]").forEach((el) => {
        el.style.background = "white";
        el.style.borderLeft = "3px solid transparent";
      });

      item.style.background = "#f0f9ff";
      item.style.borderLeft = "3px solid #0d539e";

      // Mark as read
      markThreadAsRead(thread.id);

      // Load messages
      onThreadClick(thread);
    });

    listContainer.appendChild(item);
  });

  container.appendChild(listContainer);
}

/**
 * Create thread item
 */
function createThreadItem(thread, isActive) {
  const item = el("div", {
    "data-thread-item": "true",
    style: {
      padding: "16px 20px",
      borderBottom: "1px solid #f3f4f6",
      borderLeft: isActive ? "3px solid #0d539e" : "3px solid transparent",
      background: isActive ? "#f0f9ff" : "white",
      cursor: "pointer",
      transition: "all 0.2s ease",
      position: "relative",
    },
  });

  item.addEventListener("mouseenter", () => {
    if (!isActive) {
      item.style.background = "#f9fafb";
    }
  });

  item.addEventListener("mouseleave", () => {
    if (!isActive) {
      item.style.background = "white";
    }
  });

  // Subject
  item.appendChild(
    el("div", {
      text: escapeHtml(thread.subject || "Untitled Request"),
      style: {
        fontSize: "15px",
        fontWeight: "600",
        color: "#111827",
        marginBottom: "6px",
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
      },
    })
  );

  // Meta row
  const meta = el("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      marginBottom: "6px",
    },
  });

  meta.appendChild(
    pill(
      escapeHtml(thread.status || "open"),
      thread.status === "closed" ? "neutral" :
      thread.status === "pending" ? "warn" : "good"
    )
  );

  if (thread.priority === "high") {
    meta.appendChild(
      el("span", { text: "🔥", style: { fontSize: "14px" } })
    );
  }

  item.appendChild(meta);

  // Last update
  item.appendChild(
    el("div", {
      text: formatTimestamp(thread.last_updated),
      style: {
        fontSize: "12px",
        color: "#9ca3af",
      },
    })
  );

  // Unread indicator
  if (thread.unread) {
    item.appendChild(
      el("div", {
        style: {
          position: "absolute",
          top: "20px",
          right: "20px",
          width: "8px",
          height: "8px",
          borderRadius: "50%",
          background: "#0d539e",
        },
      })
    );
  }

  return item;
}

/**
 * Load messages for a thread with real-time updates
 */
async function loadMessagesForThread(container, side, state, thread) {
  container.innerHTML = "";
  currentThreadId = thread.id;

  // Unsubscribe from previous messages listener
  if (messagesUnsubscribe) {
    messagesUnsubscribe();
  }

  // Loading state
  const loading = el("div", {
    style: {
      padding: "40px",
      textAlign: "center",
      flex: "1",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    },
  });
  loading.appendChild(el("div", { class: "wnq-spinner" }));
  container.appendChild(loading);

  try {
    // Get initial messages
    const messages = await getMessages(thread.id);

    // Render message view
    container.innerHTML = "";
    renderMessageView(container, thread, messages, state);

    // Render sidebar
    renderThreadMetadata(side, thread, state);

    // Subscribe to real-time message updates
    messagesUnsubscribe = subscribeToMessages(thread.id, (updatedMessages) => {
      console.log("[Requests] Messages updated:", updatedMessages.length);
      
      // Re-render messages but keep scroll position
      const messagesContainer = container.querySelector('[data-messages-container]');
      if (messagesContainer) {
        const scrollHeight = messagesContainer.scrollHeight;
        const scrollTop = messagesContainer.scrollTop;
        const clientHeight = messagesContainer.clientHeight;
        const wasAtBottom = scrollHeight - scrollTop - clientHeight < 50;

        // Update messages
        messagesContainer.innerHTML = "";
        updatedMessages.forEach((msg) => {
          messagesContainer.appendChild(createMessageBubble(msg, state));
        });

        // Scroll to bottom if was at bottom
        if (wasAtBottom) {
          messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
      }
    });

  } catch (error) {
    container.innerHTML = "";
    console.error("[Requests] Message load error:", error);
    showError(container, error.message);
  }
}

/**
 * Render message view with reply functionality
 */
function renderMessageView(container, thread, messages, state) {
  // Header
  const header = el("div", {
    style: {
      padding: "20px 24px",
      borderBottom: "1px solid #e5e7eb",
      background: "#f9fafb",
    },
  });

  header.appendChild(
    el("h2", {
      text: escapeHtml(thread.subject || "Untitled Request"),
      style: {
        fontSize: "20px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "8px",
      },
    })
  );

  const metaRow = el("div", {
    style: {
      display: "flex",
      gap: "12px",
      alignItems: "center",
    },
  });

  metaRow.appendChild(
    pill(escapeHtml(thread.status || "open"), 
    thread.status === "closed" ? "neutral" :
    thread.status === "pending" ? "warn" : "good")
  );

  if (thread.priority) {
    metaRow.appendChild(
      el("span", {
        text: `Priority: ${escapeHtml(thread.priority)}`,
        style: {
          fontSize: "13px",
          color: "#6b7280",
          fontWeight: "600",
        },
      })
    );
  }

  header.appendChild(metaRow);
  container.appendChild(header);

  // Messages container
  const messagesContainer = el("div", {
    "data-messages-container": "true",
    style: {
      padding: "24px",
      flex: "1",
      overflowY: "auto",
      maxHeight: "calc(100vh - 550px)",
    },
  });

  if (messages.length === 0) {
    messagesContainer.appendChild(
      el("p", {
        text: "No messages yet. Start the conversation!",
        style: {
          color: "#9ca3af",
          textAlign: "center",
          padding: "40px 0",
        },
      })
    );
  } else {
    messages.forEach((message) => {
      messagesContainer.appendChild(createMessageBubble(message, state));
    });

    // Scroll to bottom
    setTimeout(() => {
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }, 100);
  }

  container.appendChild(messagesContainer);

  // Reply area (ENABLED!)
  container.appendChild(createReplyArea(thread.id, state));
}

/**
 * Create message bubble
 */
function createMessageBubble(message, state) {
  const isClient = message.author_type === "client";
  const isCurrentUser = isClient; // Assume client is viewing

  const bubble = el("div", {
    style: {
      display: "flex",
      justifyContent: isCurrentUser ? "flex-end" : "flex-start",
      marginBottom: "16px",
    },
  });

  const content = el("div", {
    style: {
      maxWidth: "70%",
      padding: "12px 16px",
      borderRadius: "12px",
      background: isCurrentUser ? "#0d539e" : "#f3f4f6",
      color: isCurrentUser ? "white" : "#111827",
    },
  });

  // Author
  content.appendChild(
    el("div", {
      text: escapeHtml(message.author_name || (isClient ? "You" : "WebNique Team")),
      style: {
        fontSize: "12px",
        fontWeight: "700",
        opacity: isCurrentUser ? "0.9" : "1",
        marginBottom: "4px",
        color: isCurrentUser ? "white" : "#6b7280",
      },
    })
  );

  // Message text
  content.appendChild(
    el("div", {
      text: escapeHtml(message.content || ""),
      style: {
        fontSize: "14px",
        lineHeight: "1.6",
        marginBottom: "6px",
        whiteSpace: "pre-wrap",
      },
    })
  );

  // Timestamp
  content.appendChild(
    el("div", {
      text: formatTimestamp(message.timestamp),
      style: {
        fontSize: "11px",
        opacity: "0.7",
      },
    })
  );

  bubble.appendChild(content);
  return bubble;
}

/**
 * Create reply area with real send functionality
 */
function createReplyArea(threadId, state) {
  const replyArea = el("div", {
    style: {
      padding: "20px 24px",
      borderTop: "1px solid #e5e7eb",
      background: "#f9fafb",
    },
  });

  const form = el("form", {
    style: {
      display: "flex",
      gap: "12px",
    },
  });

  // Textarea
  const textarea = el("textarea", {
    placeholder: "Type your message...",
    rows: "2",
    style: {
      flex: "1",
      padding: "12px",
      borderRadius: "8px",
      border: "1px solid #d1d5db",
      fontSize: "14px",
      resize: "none",
      fontFamily: "inherit",
    },
  });

  form.appendChild(textarea);

  // Send button
  const sendBtn = button(
    state,
    "Send",
    async (e) => {
      e.preventDefault();

      const content = textarea.value.trim();
      if (!content) return;

      sendBtn.disabled = true;
      sendBtn.textContent = "Sending...";

      try {
        await sendMessage(
          threadId,
          content,
          "client",
          state.user?.name || "Client"
        );

        // Clear textarea
        textarea.value = "";
        textarea.focus();

        // Message will appear via real-time listener
      } catch (error) {
        console.error("[Requests] Send error:", error);
        alert("Failed to send message. Please try again.");
      } finally {
        sendBtn.disabled = false;
        sendBtn.textContent = "Send";
      }
    },
    "solid"
  );

  form.appendChild(sendBtn);

  // Handle form submission
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    sendBtn.click();
  });

  // Handle Enter key (Shift+Enter for new line)
  textarea.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendBtn.click();
    }
  });

  replyArea.appendChild(form);
  return replyArea;
}

/**
 * Show new thread modal
 */
function showNewThreadModal(state, threadList, messageView, side, shell) {
  // Create overlay
  const overlay = el("div", {
    style: {
      position: "fixed",
      top: "0",
      left: "0",
      right: "0",
      bottom: "0",
      background: "rgba(0,0,0,0.5)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: "9999",
    },
  });

  // Modal
  const modal = el("div", {
    style: {
      background: "white",
      borderRadius: "16px",
      padding: "32px",
      maxWidth: "500px",
      width: "90%",
      maxHeight: "90vh",
      overflowY: "auto",
    },
  });

  // Title
  modal.appendChild(
    el("h2", {
      text: "New Request",
      style: {
        fontSize: "24px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "20px",
      },
    })
  );

  // Subject field
  const subjectGroup = el("div", { style: { marginBottom: "20px" } });
  subjectGroup.appendChild(
    el("label", {
      class: "wnq-label",
      text: "Subject",
    })
  );

  const subjectInput = el("input", {
    class: "wnq-input",
    type: "text",
    placeholder: "What do you need help with?",
    required: true,
  });
  subjectGroup.appendChild(subjectInput);
  modal.appendChild(subjectGroup);

  // Message field
  const messageGroup = el("div", { style: { marginBottom: "20px" } });
  messageGroup.appendChild(
    el("label", {
      class: "wnq-label",
      text: "Message",
    })
  );

  const messageInput = el("textarea", {
    class: "wnq-textarea",
    rows: "6",
    placeholder: "Describe your request in detail...",
  });
  messageGroup.appendChild(messageInput);
  modal.appendChild(messageGroup);

  // Buttons
  const buttonRow = el("div", {
    style: {
      display: "flex",
      gap: "12px",
      justifyContent: "flex-end",
    },
  });

  const cancelBtn = button(
    state,
    "Cancel",
    () => {
      document.body.removeChild(overlay);
    },
    "outline"
  );

  const createBtn = button(
    state,
    "Create Request",
    async () => {
      const subject = subjectInput.value.trim();
      const message = messageInput.value.trim();

      if (!subject) {
        alert("Please enter a subject");
        return;
      }

      createBtn.disabled = true;
      createBtn.textContent = "Creating...";

      try {
        await createThread(
          state.clientId,
          subject,
          message,
          state.user?.name || "Client"
        );

        // Close modal
        document.body.removeChild(overlay);

        // Threads will update via real-time listener
      } catch (error) {
        console.error("[Requests] Create error:", error);
        alert("Failed to create request. Please try again.");
        createBtn.disabled = false;
        createBtn.textContent = "Create Request";
      }
    },
    "solid"
  );

  buttonRow.appendChild(cancelBtn);
  buttonRow.appendChild(createBtn);
  modal.appendChild(buttonRow);

  overlay.appendChild(modal);

  // Close on overlay click
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) {
      document.body.removeChild(overlay);
    }
  });

  document.body.appendChild(overlay);
  subjectInput.focus();
}

/**
 * Render thread metadata sidebar
 */
function renderThreadMetadata(side, thread, state) {
  side.innerHTML = "";

  const card = el("div", {
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "16px",
      padding: "20px",
    },
  });

  card.appendChild(
    el("h3", {
      text: "Request Details",
      style: {
        fontSize: "16px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "16px",
      },
    })
  );

  const details = [
    { label: "Status", value: thread.status || "open" },
    { label: "Priority", value: thread.priority || "normal" },
    { label: "Assigned To", value: thread.assigned_to || "WebNique Team" },
    { label: "Created", value: formatTimestamp(thread.created_at) },
    { label: "Last Updated", value: formatTimestamp(thread.last_updated) },
  ];

  if (thread.related_service) {
    details.push({
      label: "Related Service",
      value: thread.related_service,
    });
  }

  details.forEach((detail, index) => {
    const row = el("div", {
      style: {
        padding: "12px 0",
        borderTop: index > 0 ? "1px solid #f3f4f6" : "none",
      },
    });

    row.appendChild(
      el("div", {
        text: detail.label,
        style: {
          fontSize: "12px",
          color: "#6b7280",
          fontWeight: "600",
          marginBottom: "4px",
        },
      })
    );

    row.appendChild(
      el("div", {
        text: escapeHtml(detail.value),
        style: {
          fontSize: "14px",
          color: "#111827",
          fontWeight: "600",
        },
      })
    );

    card.appendChild(row);
  });

  side.appendChild(card);
}

/**
 * Render empty state
 */
function renderEmptyState(threadList, messageView) {
  threadList.innerHTML = "";
  messageView.innerHTML = "";

  const empty = el("div", {
    style: {
      textAlign: "center",
      padding: "60px 40px",
    },
  });

  empty.appendChild(
    el("div", {
      text: "📭",
      style: {
        fontSize: "64px",
        marginBottom: "20px",
      },
    })
  );

  empty.appendChild(
    el("h3", {
      text: "No Requests Yet",
      style: {
        fontSize: "20px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "12px",
      },
    })
  );

  empty.appendChild(
    el("p", {
      text: 'Click "New Request" to start a conversation with the WebNique team.',
      style: {
        fontSize: "14px",
        color: "#6b7280",
        lineHeight: "1.6",
      },
    })
  );

  messageView.appendChild(empty);
}

/**
 * Format timestamp
 */
function formatTimestamp(timestamp) {
  if (!timestamp) return "Unknown";

  try {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / (1000 * 60));

    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
    if (diffMins < 2880) return "Yesterday";

    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: date.getFullYear() !== now.getFullYear() ? "numeric" : undefined,
    });
  } catch (e) {
    return "Unknown";
  }
}

/**
 * Show error
 */
function showError(container, message) {
  container.innerHTML = "";
  container.appendChild(
    el("div", {
      class: "wnq-alert wnq-alert-danger",
      style: { margin: "20px" },
      html: `<strong>Error:</strong> ${escapeHtml(message)}`,
    })
  );
}