<?php
/**
 * Plugin Name: SEO Database Updater - Complete
 * Description: Automatically adds/updates all required columns for SEO tracking system. Run once, then deactivate and delete.
 * Version: 1.0
 * Author: WebNique
 */

if (!defined('ABSPATH')) {
    exit;
}

register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table = $wpdb->prefix . 'wnq_seo_tasks';

    // Check table exists
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
    if (!$table_exists) {
        set_transient('seo_updater_error', 'Table wp_wnq_seo_tasks does not exist. Please activate the WebNique Portal plugin first.', 60);
        return;
    }

    $results = [];
    $errors = [];

    // Get existing columns
    $existing_columns = $wpdb->get_col("SHOW COLUMNS FROM `{$table}`", 0);

    // 1. Add task_group if missing
    if (!in_array('task_group', $existing_columns, true)) {
        $result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `task_group` varchar(255) DEFAULT '' AFTER `service_type`");
        $result !== false ? $results[] = 'Added task_group column' : $errors[] = 'Failed to add task_group';
    } else {
        $results[] = 'task_group already exists';
    }

    // 2. Add month_year if missing
    if (!in_array('month_year', $existing_columns, true)) {
        $result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `month_year` varchar(7) DEFAULT NULL AFTER `notes`");
        $result !== false ? $results[] = 'Added month_year column' : $errors[] = 'Failed to add month_year';
    } else {
        // Make sure it allows NULL
        $wpdb->query("ALTER TABLE `{$table}` MODIFY COLUMN `month_year` varchar(7) DEFAULT NULL");
        $results[] = 'month_year updated to allow NULL';
    }

    // 3. Add is_recurring if missing
    if (!in_array('is_recurring', $existing_columns, true)) {
        $result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `is_recurring` tinyint(1) DEFAULT 0 AFTER `month_year`");
        $result !== false ? $results[] = 'Added is_recurring column' : $errors[] = 'Failed to add is_recurring';
    } else {
        $results[] = 'is_recurring already exists';
    }

    // 4. Add sort_order if missing
    if (!in_array('sort_order', $existing_columns, true)) {
        $result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `sort_order` int UNSIGNED DEFAULT 0 AFTER `is_recurring`");
        $result !== false ? $results[] = 'Added sort_order column' : $errors[] = 'Failed to add sort_order';
    } else {
        $results[] = 'sort_order already exists';
    }

    // 5. Add/update indexes
    $wpdb->query("ALTER TABLE `{$table}` DROP INDEX IF EXISTS `client_service_month`");
    $index_result = $wpdb->query("ALTER TABLE `{$table}` ADD KEY `client_service_month` (`client_id`, `service_type`, `month_year`)");
    if ($index_result !== false) {
        $results[] = 'Added client_service_month index';
    }

    // Store results
    set_transient('seo_updater_results', $results, 60);
    set_transient('seo_updater_errors', $errors, 60);
    set_transient('seo_updater_success', empty($errors), 60);
});

add_action('admin_notices', function() {
    if ($error = get_transient('seo_updater_error')) {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p><strong>❌ Error:</strong> ' . esc_html($error) . '</p>';
        echo '</div>';
        delete_transient('seo_updater_error');
        return;
    }

    $success = get_transient('seo_updater_success');
    $results = get_transient('seo_updater_results');
    $errors = get_transient('seo_updater_errors');

    if ($success === null) {
        return; // Not activated yet
    }

    global $wpdb;
    $table = $wpdb->prefix . 'wnq_seo_tasks';

    // Verify final state
    $columns = $wpdb->get_col("SHOW COLUMNS FROM `{$table}`", 0);
    $has_task_group = in_array('task_group', $columns, true);
    $has_month_year = in_array('month_year', $columns, true);
    $has_is_recurring = in_array('is_recurring', $columns, true);
    $has_sort_order = in_array('sort_order', $columns, true);

    $all_present = $has_task_group && $has_month_year && $has_is_recurring && $has_sort_order;

    if ($all_present && empty($errors)) {
        echo '<div class="notice notice-success is-dismissible" style="border-left-color:#10b981;padding:20px">';
        echo '<h2 style="margin-top:0">✅ SUCCESS! Database Updated</h2>';
        echo '<p><strong>All required columns are now present and properly configured:</strong></p>';
        echo '<ul style="margin-left:20px;list-style:disc">';
        echo '<li><code>task_group</code> column: <strong style="color:#10b981">✅ Present</strong></li>';
        echo '<li><code>month_year</code> column: <strong style="color:#10b981">✅ Present (allows NULL)</strong></li>';
        echo '<li><code>is_recurring</code> column: <strong style="color:#10b981">✅ Present</strong></li>';
        echo '<li><code>sort_order</code> column: <strong style="color:#10b981">✅ Present</strong></li>';
        echo '</ul>';
        
        if (!empty($results)) {
            echo '<details style="margin:15px 0;padding:10px;background:#f0fdf4;border-radius:6px">';
            echo '<summary style="cursor:pointer;font-weight:600">📋 View Changes Made</summary>';
            echo '<ul style="margin:10px 0 0 20px;list-style:circle">';
            foreach ($results as $msg) {
                echo '<li>' . esc_html($msg) . '</li>';
            }
            echo '</ul>';
            echo '</details>';
        }
        
        echo '<hr style="margin:20px 0;border:none;border-top:2px solid #e5e7eb">';
        echo '<div style="background:#fffbeb;padding:15px;border-radius:8px;border-left:4px solid #f59e0b">';
        echo '<h3 style="margin:0 0 10px;color:#92400e">🎯 Next Steps:</h3>';
        echo '<ol style="line-height:2;margin:0">';
        echo '<li>Go to <strong>Plugins</strong> page</li>';
        echo '<li><strong>Deactivate</strong> this plugin</li>';
        echo '<li><strong>Delete</strong> this plugin (it\'s no longer needed)</li>';
        echo '<li>Go to <strong>SEO Tracking</strong> page</li>';
        echo '<li>Click <strong>"Initialize SEO Tasks"</strong> or use <strong>"Bulk Import"</strong></li>';
        echo '<li>All 200+ tasks will now load successfully! 🚀</li>';
        echo '</ol>';
        echo '</div>';
        echo '</div>';
    } else {
        echo '<div class="notice notice-warning is-dismissible">';
        echo '<h2>⚠️ Database Update Partially Complete</h2>';
        echo '<p>Some columns may still need manual adjustment:</p>';
        echo '<ul style="margin-left:20px;list-style:disc">';
        echo '<li><code>task_group</code>: ' . ($has_task_group ? '✅' : '❌ Missing') . '</li>';
        echo '<li><code>month_year</code>: ' . ($has_month_year ? '✅' : '❌ Missing') . '</li>';
        echo '<li><code>is_recurring</code>: ' . ($has_is_recurring ? '✅' : '❌ Missing') . '</li>';
        echo '<li><code>sort_order</code>: ' . ($has_sort_order ? '✅' : '❌ Missing') . '</li>';
        echo '</ul>';

        if (!empty($errors)) {
            echo '<p><strong>Errors encountered:</strong></p>';
            echo '<ul style="margin-left:20px;list-style:disc">';
            foreach ($errors as $err) {
                echo '<li>' . esc_html($err) . '</li>';
            }
            echo '</ul>';
        }

        echo '<p><strong>Please run these SQL commands manually in phpMyAdmin:</strong></p>';
        echo '<pre style="background:#f5f5f5;padding:15px;overflow-x:auto;border:1px solid #ddd;border-radius:4px">';
        if (!$has_task_group) {
            echo "ALTER TABLE `{$table}` ADD COLUMN `task_group` varchar(255) DEFAULT '' AFTER `service_type`;\n";
        }
        if (!$has_month_year) {
            echo "ALTER TABLE `{$table}` ADD COLUMN `month_year` varchar(7) DEFAULT NULL AFTER `notes`;\n";
        }
        echo "ALTER TABLE `{$table}` MODIFY COLUMN `month_year` varchar(7) DEFAULT NULL;\n";
        if (!$has_is_recurring) {
            echo "ALTER TABLE `{$table}` ADD COLUMN `is_recurring` tinyint(1) DEFAULT 0 AFTER `month_year`;\n";
        }
        if (!$has_sort_order) {
            echo "ALTER TABLE `{$table}` ADD COLUMN `sort_order` int UNSIGNED DEFAULT 0 AFTER `is_recurring`;\n";
        }
        echo "ALTER TABLE `{$table}` ADD KEY `client_service_month` (`client_id`, `service_type`, `month_year`);\n";
        echo '</pre>';
        echo '</div>';
    }

    // Clean up transients
    delete_transient('seo_updater_success');
    delete_transient('seo_updater_results');
    delete_transient('seo_updater_errors');
});