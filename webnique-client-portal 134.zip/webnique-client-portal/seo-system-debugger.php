<?php
/**
 * Plugin Name: SEO System Debugger
 * Description: Test SEO system - check database, manually complete a task, verify progress. Deactivate after use.
 * Version: 1.0
 * Author: WebNique
 */

if (!defined('ABSPATH')) {
    exit;
}

register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table = $wpdb->prefix . 'wnq_seo_tasks';

    // Check if table exists
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
    if (!$table_exists) {
        set_transient('seo_debug_error', 'Table wp_wnq_seo_tasks does not exist!', 60);
        return;
    }

    // Get total task count
    $total_tasks = $wpdb->get_var("SELECT COUNT(*) FROM `{$table}`");
    
    // Get tasks by status
    $completed = $wpdb->get_var("SELECT COUNT(*) FROM `{$table}` WHERE status = 'completed'");
    $pending = $wpdb->get_var("SELECT COUNT(*) FROM `{$table}` WHERE status = 'pending'");
    $in_progress = $wpdb->get_var("SELECT COUNT(*) FROM `{$table}` WHERE status = 'in_progress'");

    // Get one task to test with
    $test_task = $wpdb->get_row("SELECT id, task_name, status FROM `{$table}` WHERE status = 'pending' LIMIT 1", ARRAY_A);

    // Store results
    set_transient('seo_debug_stats', [
        'total' => (int) $total_tasks,
        'completed' => (int) $completed,
        'pending' => (int) $pending,
        'in_progress' => (int) $in_progress,
        'test_task' => $test_task,
    ], 60);
    
    set_transient('seo_debug_success', true, 60);
});

add_action('admin_notices', function() {
    if ($error = get_transient('seo_debug_error')) {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p><strong>❌ Error:</strong> ' . esc_html($error) . '</p>';
        echo '</div>';
        delete_transient('seo_debug_error');
        return;
    }

    if (!get_transient('seo_debug_success')) {
        return;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'wnq_seo_tasks';
    $stats = get_transient('seo_debug_stats');

    echo '<div class="notice notice-info is-dismissible" style="padding:20px">';
    echo '<h2 style="margin-top:0">🔍 SEO System Status</h2>';
    
    echo '<div style="background:#f0f9ff;padding:15px;border-radius:8px;margin:15px 0;border-left:4px solid #0284c7">';
    echo '<h3 style="margin:0 0 10px;color:#0c4a6e">📊 Current Task Stats:</h3>';
    echo '<ul style="margin:5px 0;list-style:none;padding:0">';
    echo '<li style="padding:5px 0">✅ <strong>Completed:</strong> ' . $stats['completed'] . ' tasks</li>';
    echo '<li style="padding:5px 0">⏳ <strong>In Progress:</strong> ' . $stats['in_progress'] . ' tasks</li>';
    echo '<li style="padding:5px 0">📋 <strong>Pending:</strong> ' . $stats['pending'] . ' tasks</li>';
    echo '<li style="padding:5px 0">📊 <strong>Total:</strong> ' . $stats['total'] . ' tasks</li>';
    
    if ($stats['total'] > 0) {
        $percentage = round(($stats['completed'] / $stats['total']) * 100, 1);
        echo '<li style="padding:10px 0;margin-top:10px;border-top:1px solid #bae6fd"><strong>📈 Completion:</strong> ' . $percentage . '%</li>';
    }
    echo '</ul>';
    echo '</div>';

    if ($stats['test_task']) {
        echo '<div style="background:#fef3c7;padding:15px;border-radius:8px;margin:15px 0;border-left:4px solid #f59e0b">';
        echo '<h3 style="margin:0 0 10px;color:#92400e">🧪 Test Task Found:</h3>';
        echo '<p style="margin:5px 0"><strong>ID:</strong> ' . $stats['test_task']['id'] . '</p>';
        echo '<p style="margin:5px 0"><strong>Name:</strong> ' . esc_html($stats['test_task']['task_name']) . '</p>';
        echo '<p style="margin:5px 0"><strong>Status:</strong> ' . $stats['test_task']['status'] . '</p>';
        
        echo '<form method="post" action="' . admin_url('admin-post.php') . '" style="margin-top:15px">';
        wp_nonce_field('seo_debug_complete_task');
        echo '<input type="hidden" name="action" value="seo_debug_complete_task">';
        echo '<input type="hidden" name="task_id" value="' . $stats['test_task']['id'] . '">';
        echo '<button type="submit" class="button button-primary button-large" style="background:#059669;border-color:#047857">✅ Complete This Task (Test)</button>';
        echo '</form>';
        echo '</div>';
    } else {
        echo '<div style="background:#dcfce7;padding:15px;border-radius:8px;margin:15px 0;border-left:4px solid #16a34a">';
        echo '<p style="margin:0;color:#166534">✅ All tasks are already completed! Great job!</p>';
        echo '</div>';
    }

    echo '<div style="background:#f1f5f9;padding:15px;border-radius:8px;margin:15px 0">';
    echo '<h3 style="margin:0 0 10px">🔧 Database Info:</h3>';
    echo '<p style="margin:5px 0;font-family:monospace;font-size:13px">Table: <code>' . $table . '</code></p>';
    
    // Check columns
    $columns = $wpdb->get_col("SHOW COLUMNS FROM `{$table}`", 0);
    $required = ['id', 'client_id', 'service_type', 'task_name', 'status', 'month_year', 'is_recurring', 'sort_order'];
    $missing = array_diff($required, $columns);
    
    if (empty($missing)) {
        echo '<p style="margin:5px 0;color:#16a34a">✅ All required columns present</p>';
    } else {
        echo '<p style="margin:5px 0;color:#dc2626">❌ Missing columns: ' . implode(', ', $missing) . '</p>';
    }
    echo '</div>';

    echo '<hr style="margin:20px 0">';
    echo '<p><strong>Next Steps:</strong></p>';
    echo '<ol style="line-height:1.8">';
    echo '<li>Click "Complete This Task" button above to test</li>';
    echo '<li>Go to <strong>SEO Tracking</strong> page</li>';
    echo '<li>Check if progress bar updated</li>';
    echo '<li>If it works, <strong>deactivate & delete</strong> this plugin</li>';
    echo '</ol>';
    echo '</div>';

    delete_transient('seo_debug_success');
});

// Handler to complete a task
add_action('admin_post_seo_debug_complete_task', function() {
    check_admin_referer('seo_debug_complete_task');
    if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

    global $wpdb;
    $table = $wpdb->prefix . 'wnq_seo_tasks';
    $task_id = isset($_POST['task_id']) ? intval($_POST['task_id']) : 0;

    if (!$task_id) {
        wp_die('Invalid task ID');
    }

    // Update task to completed
    $result = $wpdb->update($table, [
        'status' => 'completed',
        'completed_date' => current_time('mysql'),
    ], [
        'id' => $task_id
    ]);

    if ($result !== false) {
        set_transient('seo_debug_complete_success', $task_id, 60);
    } else {
        set_transient('seo_debug_complete_error', $wpdb->last_error, 60);
    }

    wp_redirect(admin_url('plugins.php'));
    exit;
});

add_action('admin_notices', function() {
    if ($task_id = get_transient('seo_debug_complete_success')) {
        echo '<div class="notice notice-success is-dismissible" style="border-left-color:#10b981;padding:20px">';
        echo '<h2 style="margin-top:0">✅ SUCCESS!</h2>';
        echo '<p><strong>Task #' . $task_id . ' has been marked as completed.</strong></p>';
        echo '<hr style="margin:15px 0">';
        echo '<p><strong>Now test the progress bar:</strong></p>';
        echo '<ol style="line-height:1.8">';
        echo '<li>Go to <strong>SEO Tracking</strong> page</li>';
        echo '<li>Look at the progress bar</li>';
        echo '<li>It should now show <strong>1 Completed</strong> task</li>';
        echo '<li>Progress should be <strong>0.3%</strong> (1/386)</li>';
        echo '</ol>';
        echo '<p style="margin-top:15px"><a href="' . admin_url('admin.php?page=wnq-seo') . '" class="button button-primary">→ Go to SEO Tracking</a></p>';
        echo '</div>';
        delete_transient('seo_debug_complete_success');
    }

    if ($error = get_transient('seo_debug_complete_error')) {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p><strong>❌ Failed to complete task:</strong> ' . esc_html($error) . '</p>';
        echo '</div>';
        delete_transient('seo_debug_complete_error');
    }
});