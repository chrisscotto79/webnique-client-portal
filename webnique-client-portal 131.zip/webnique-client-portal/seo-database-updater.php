<?php
/**
 * Plugin Name: SEO Database Updater v3 - FINAL
 * Description: Adds missing columns (month_year, is_recurring, sort_order) to SEO tasks table. Deactivate and delete after use.
 * Version: 3.0
 * Author: WebNique
 */

if (!defined('ABSPATH')) {
    exit;
}

register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table = $wpdb->prefix . 'wnq_seo_tasks';

    // Check table exists
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
    if (!$table_exists) {
        set_transient('seo_updater_v3_error', 'Table ' . $table . ' does not exist. Please activate WebNique Portal plugin first.', 60);
        return;
    }

    $added = [];
    $already_exist = [];

    // Get existing columns
    $existing = $wpdb->get_col("SHOW COLUMNS FROM `{$table}`", 0);

    // 1. Add month_year column if missing
    if (!in_array('month_year', $existing, true)) {
        $result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `month_year` varchar(7) NULL AFTER `notes`");
        if ($result !== false) {
            $added[] = 'month_year';
        }
    } else {
        $already_exist[] = 'month_year';
    }

    // 2. Add is_recurring column if missing
    if (!in_array('is_recurring', $existing, true)) {
        $result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `is_recurring` tinyint(1) DEFAULT 0 AFTER `month_year`");
        if ($result !== false) {
            $added[] = 'is_recurring';
        }
    } else {
        $already_exist[] = 'is_recurring';
    }

    // 3. Add sort_order column if missing
    if (!in_array('sort_order', $existing, true)) {
        $result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `sort_order` int UNSIGNED DEFAULT 0 AFTER `is_recurring`");
        if ($result !== false) {
            $added[] = 'sort_order';
        }
    } else {
        $already_exist[] = 'sort_order';
    }

    // 4. Update indexes
    $indexes = $wpdb->get_results("SHOW INDEX FROM `{$table}` WHERE Key_name = 'client_service_month'");
    if (empty($indexes)) {
        $wpdb->query("ALTER TABLE `{$table}` ADD KEY `client_service_month` (`client_id`, `service_type`, `month_year`)");
        $added[] = 'index: client_service_month';
    }

    // Store results
    set_transient('seo_updater_v3_added', $added, 60);
    set_transient('seo_updater_v3_existing', $already_exist, 60);
    set_transient('seo_updater_v3_done', true, 60);
});

add_action('admin_notices', function() {
    if ($error = get_transient('seo_updater_v3_error')) {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p><strong>❌ SEO Database Updater Error:</strong> ' . esc_html($error) . '</p>';
        echo '</div>';
        delete_transient('seo_updater_v3_error');
        return;
    }

    if (!get_transient('seo_updater_v3_done')) {
        return;
    }

    global $wpdb;
    $table  = $wpdb->prefix . 'wnq_seo_tasks';
    $added  = get_transient('seo_updater_v3_added') ?: [];
    $existing = get_transient('seo_updater_v3_existing') ?: [];

    // Verify final state
    $columns = $wpdb->get_col("SHOW COLUMNS FROM `{$table}`", 0);
    $has_month_year = in_array('month_year', $columns, true);
    $has_is_recurring = in_array('is_recurring', $columns, true);
    $has_sort_order = in_array('sort_order', $columns, true);

    $all_good = $has_month_year && $has_is_recurring && $has_sort_order;

    if ($all_good) {
        echo '<div class="notice notice-success is-dismissible" style="border-left-color:#10b981;padding:20px">';
        echo '<h2 style="margin-top:0">✅ SUCCESS! Database Updated</h2>';
        echo '<p><strong>All required columns are now present:</strong></p>';
        echo '<ul style="margin-left:20px;list-style:disc">';
        echo '<li><code>month_year</code> column: <strong>✅ Present</strong></li>';
        echo '<li><code>is_recurring</code> column: <strong>✅ Present</strong></li>';
        echo '<li><code>sort_order</code> column: <strong>✅ Present</strong></li>';
        echo '</ul>';
        
        if (!empty($added)) {
            echo '<p><strong>Columns added:</strong> ' . esc_html(implode(', ', $added)) . '</p>';
        }
        if (!empty($existing)) {
            echo '<p><strong>Already existed:</strong> ' . esc_html(implode(', ', $existing)) . '</p>';
        }
        
        echo '<hr style="margin:20px 0">';
        echo '<h3>🎯 Next Steps:</h3>';
        echo '<ol style="line-height:1.8">';
        echo '<li>Go to <strong>Plugins</strong></li>';
        echo '<li><strong>Deactivate</strong> "SEO Database Updater v3 - FINAL"</li>';
        echo '<li><strong>Delete</strong> this plugin</li>';
        echo '<li>Go to <strong>SEO Tracking</strong> and click <strong>"Initialize SEO Tasks"</strong></li>';
        echo '<li>All 200+ tasks will now load successfully! 🚀</li>';
        echo '</ol>';
        echo '</div>';
    } else {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p><strong>❌ Some columns are still missing.</strong></p>';
        echo '<p>Current status:</p>';
        echo '<ul style="margin-left:20px;list-style:disc">';
        echo '<li><code>month_year</code>: ' . ($has_month_year ? '✅' : '❌') . '</li>';
        echo '<li><code>is_recurring</code>: ' . ($has_is_recurring ? '✅' : '❌') . '</li>';
        echo '<li><code>sort_order</code>: ' . ($has_sort_order ? '✅' : '❌') . '</li>';
        echo '</ul>';
        echo '<p><strong>Please run these SQL commands manually in phpMyAdmin:</strong></p>';
        echo '<pre style="background:#f5f5f5;padding:15px;overflow-x:auto;border:1px solid #ddd">';
        if (!$has_month_year) {
            echo "ALTER TABLE `{$table}` ADD COLUMN `month_year` varchar(7) NULL;\n";
        }
        if (!$has_is_recurring) {
            echo "ALTER TABLE `{$table}` ADD COLUMN `is_recurring` tinyint(1) DEFAULT 0;\n";
        }
        if (!$has_sort_order) {
            echo "ALTER TABLE `{$table}` ADD COLUMN `sort_order` int UNSIGNED DEFAULT 0;\n";
        }
        echo '</pre>';
        echo '</div>';
    }

    delete_transient('seo_updater_v3_done');
    delete_transient('seo_updater_v3_added');
    delete_transient('seo_updater_v3_existing');
});