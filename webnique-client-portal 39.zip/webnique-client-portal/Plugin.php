<?php
/**
 * Main Plugin Class
 * 
 * @package WebNique Portal
 */

namespace WNQ\Core;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Plugin
 * Main plugin initialization and bootstrapping
 */
final class Plugin
{
    /**
     * @var bool Track if plugin is already booted
     */
    private static bool $booted = false;

    /**
     * Initialize the plugin
     * Runs on 'plugins_loaded' hook
     */
    public static function init(): void
    {
        // Prevent double initialization
        if (self::$booted) {
            return;
        }
        self::$booted = true;

        // Load all required files
        self::includes();

        // Register REST API routes
        Router::register();

        // Register public-facing functionality
        add_action('init', [\WNQ\PublicSite\Shortcode::class, 'register']);

        // Register user meta functionality
        add_action('init', [UserMeta::class, 'register']);

        // Register admin functionality
        if (is_admin()) {
            \WNQ\Admin\AdminMenu::register();
        }

        // Allow other plugins to hook in after initialization
        do_action('wnq_portal_initialized');
    }

    /**
     * Plugin activation hook
     * Runs once when plugin is activated
     */
    public static function activate(): void
    {
        // Load required files for activation
        self::includes();

        // Run activation tasks
        Activator::run();

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Plugin deactivation hook
     * Runs when plugin is deactivated
     */
    public static function deactivate(): void
    {
        // Flush rewrite rules
        flush_rewrite_rules();

        // Allow cleanup hooks
        do_action('wnq_portal_deactivated');
    }

    /**
     * Load all required plugin files
     * Organized by directory structure
     */
    private static function includes(): void
    {
        // Define base path
        $base = WNQ_PORTAL_PATH . 'includes/';

        // Core files
        $core_files = [
            'Core/Activator.php',
            'Core/Permissions.php',
            'Core/Router.php',
            'Core/Logger.php',
            'Core/UserMeta.php',
        ];

        // Controller files
        $controller_files = [
            'Controllers/DashboardController.php',
            'Controllers/AnalyticsController.php',
            'Controllers/SubscriptionController.php',
            'Controllers/ThreadsController.php',
            'Controllers/MessagesController.php',
            'Controllers/SettingsController.php',
        ];

        // Service files
        $service_files = [
            'Services/FirebaseStore.php',
        ];

        // View files
        $view_files = [
            'Views/portal-shell.php',
        ];

        // Public files
        $public_files = [
            '../public/Shortcode.php',
        ];

        // Admin files
        $admin_files = [
            '../admin/AdminMenu.php',
            '../admin/AdminSettings.php',
        ];

        // Combine all files
        $all_files = array_merge(
            $core_files,
            $controller_files,
            $service_files,
            $view_files,
            $public_files,
            $admin_files
        );

        // Load each file with error handling
        foreach ($all_files as $file) {
            $filepath = $base . $file;
            
            if (file_exists($filepath)) {
                require_once $filepath;
            } else {
                // Log missing file error
                if (function_exists('error_log')) {
                    error_log("WNQ Portal: Missing required file - {$filepath}");
                }
            }
        }
    }

    /**
     * Get plugin version
     * 
     * @return string Plugin version
     */
    public static function getVersion(): string
    {
        return defined('WNQ_PORTAL_VERSION') ? WNQ_PORTAL_VERSION : '1.0.0';
    }

    /**
     * Check if plugin is fully loaded
     * 
     * @return bool True if plugin is booted
     */
    public static function isBooted(): bool
    {
        return self::$booted;
    }
}