(async function () {
  const root = document.getElementById("wnq-portal-root");
  if (!root) return;

  const clientId = root.getAttribute("data-client-id") || "";
  const mode = root.getAttribute("data-mode") || "";

  const restBase = window.WNQ_PORTAL?.restUrl;
  const nonce = window.WNQ_PORTAL?.nonce;
  const isAdmin = !!window.WNQ_PORTAL?.isAdmin;

  const card = document.createElement("div");
  card.style.padding = "12px";
  card.style.marginTop = "12px";
  card.style.border = "1px solid #e5e7eb";
  card.style.borderRadius = "10px";
  card.style.fontFamily = "system-ui";

  card.innerHTML = `
    <strong>WNQ App.js Loaded ✅</strong><br/>
    Client ID: <code>${clientId || "(none)"}</code><br/>
    Mode: <code>${mode || "(none)"}</code><br/>
    Ping: <code id="wnq-ping-status">checking...</code>
    <div id="wnq-actions" style="margin-top:12px; display:flex; gap:10px; flex-wrap:wrap;"></div>
    <div id="wnq-result" style="margin-top:10px;"></div>
  `;

  root.appendChild(card);

  const actions = document.getElementById("wnq-actions");
  const out = document.getElementById("wnq-result");

  function renderJson(json) {
    out.innerHTML = `<pre style="white-space:pre-wrap;background:rgba(0,0,0,0.04);padding:10px;border-radius:10px;max-height:420px;overflow:auto;">${JSON.stringify(
      json,
      null,
      2
    )}</pre>`;
  }

  function makeButton(label, onClick) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.textContent = label;
    btn.style.padding = "10px 12px";
    btn.style.borderRadius = "10px";
    btn.style.border = "1px solid #d1d5db";
    btn.style.background = "white";
    btn.style.cursor = "pointer";
    btn.addEventListener("click", onClick);
    return btn;
  }

  // Ping
  try {
    if (!restBase || !nonce) {
      document.getElementById("wnq-ping-status").textContent = "missing restUrl/nonce";
      return;
    }

    const res = await fetch(`${restBase}/ping`, {
      method: "GET",
      credentials: "same-origin",
      headers: { "X-WP-Nonce": nonce },
    });

    const json = await res.json();
    document.getElementById("wnq-ping-status").textContent = json?.ok ? "ok" : "not ok";

    const proof = document.createElement("div");
    proof.style.marginTop = "8px";
    proof.innerHTML = `REST user_id: <code>${json?.wp?.user_id ?? "(none)"}</code>, client_id: <code>${json?.wp?.client_id ?? "(null)"}</code>`;
    card.appendChild(proof);
  } catch (e) {
    console.error(e);
    const node = document.getElementById("wnq-ping-status");
    if (node) node.textContent = "error (see console)";
  }

  // Admin: Bootstrap client
  if (isAdmin) {
    actions.appendChild(
      makeButton("Bootstrap Firestore Client", async () => {
        out.textContent = "Bootstrapping...";
        const res = await fetch(`${restBase}/clients/bootstrap`, {
          method: "POST",
          credentials: "same-origin",
          headers: {
            "X-WP-Nonce": nonce,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ client_id: clientId }),
        });
        const json = await res.json();
        renderJson(json);
      })
    );
  }

  // Load client doc (works for admin + client users)
  actions.appendChild(
    makeButton("Load Client Doc", async () => {
      out.textContent = "Loading client...";
      const res = await fetch(`${restBase}/client`, {
        method: "GET",
        credentials: "same-origin",
        headers: { "X-WP-Nonce": nonce },
      });
      const json = await res.json();
      renderJson(json);
    })
  );
})();
