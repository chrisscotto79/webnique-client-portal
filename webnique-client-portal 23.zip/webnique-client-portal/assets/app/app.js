// assets/app/app.js
// ✅ WordPress-safe ES Module entrypoint
// Requires Shortcode.php to output this script with type="module" (script_loader_tag filter).
// This file mounts the portal shell + routes tab rendering.

import { initAppState } from "./modules/state.js";
import { mountShell } from "./modules/ui.js";

import { renderDashboard } from "./modules/tabs/dashboard.js";
import { renderSubscription } from "./modules/tabs/subscription.js";
import { renderAnalytics } from "./modules/tabs/analytics.js";
import { renderRequests } from "./modules/tabs/requests.js";
import { renderSettings } from "./modules/tabs/settings.js";

(function () {
  const root = document.getElementById("wnq-portal-root");
  if (!root) return;

  // Always reference localized config via window (module-safe)
  const cfg = window.WNQ_PORTAL || {};
  const restBase = (cfg.restUrl || "").replace(/\/$/, "");
  const nonce = cfg.nonce || "";
  const isAdmin = !!cfg.isAdmin;

  // Initialize shared state (module owns shape, but we enforce cfg in state)
  const state = initAppState(root);

  // Ensure state has config (in case state.js didn’t already)
  state.cfg = state.cfg || {};
  state.cfg.restBase = restBase;
  state.cfg.nonce = nonce;
  state.cfg.isAdmin = isAdmin;

  // Optional: keep clientId consistent across WP + DOM
  const domClientId = root.getAttribute("data-client-id") || "";
  const wpClientId = cfg.clientId || "";
  state.clientId = state.clientId || domClientId || wpClientId || "";

  // ---------- helpers ----------
  function safeJsonParse(text) {
    try {
      return JSON.parse(text);
    } catch (_) {
      return null;
    }
  }

  async function apiGet(path) {
    if (!restBase || !nonce) {
      return {
        ok: false,
        status: 0,
        error: "Missing restUrl/nonce (check wp_localize_script).",
      };
    }

    const url = `${restBase}${path.startsWith("/") ? "" : "/"}${path}`;
    const res = await fetch(url, {
      method: "GET",
      credentials: "same-origin",
      headers: { "X-WP-Nonce": nonce },
    });

    const text = await res.text();
    const json = safeJsonParse(text);

    return json || {
      ok: false,
      status: res.status,
      error: "Non-JSON response",
      raw: text,
    };
  }

  async function apiPost(path, body) {
    if (!restBase || !nonce) {
      return {
        ok: false,
        status: 0,
        error: "Missing restUrl/nonce (check wp_localize_script).",
      };
    }

    const url = `${restBase}${path.startsWith("/") ? "" : "/"}${path}`;
    const res = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      headers: {
        "X-WP-Nonce": nonce,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body || {}),
    });

    const text = await res.text();
    const json = safeJsonParse(text);

    return json || {
      ok: false,
      status: res.status,
      error: "Non-JSON response",
      raw: text,
    };
  }

  // Expose tiny debug helpers (optional)
  window.WNQ_APP = {
    state,
    api: { get: apiGet, post: apiPost },
  };

  // ---------- mount UI shell ----------
  const shell = mountShell(root, state, {
    onTabChange: (key) => renderTab(key),
    // Optional hooks (only if your ui.js supports them)
    // onPrimaryAction: () => {},
  });

  // Tab render map
  const tabs = {
    dashboard: renderDashboard,
    subscription: renderSubscription,
    analytics: renderAnalytics,
    requests: renderRequests,
    settings: renderSettings,
  };

  function renderTab(key) {
    const fn = tabs[key] || tabs.dashboard;

    // UI shell API
    if (shell && typeof shell.setActiveTab === "function") {
      shell.setActiveTab(key);
    }

    // Clear main area (and side if your layout uses it)
    if (shell?.main) shell.main.innerHTML = "";
    if (shell?.side) shell.side.innerHTML = "";

    // Render selected tab
    fn(shell.main, shell.side, state, shell);
  }

  // ---------- initial hydration ----------
  (async function boot() {
    // 1) Ping REST for auth proof + perms
    const ping = await apiGet("/ping");
    state.rest = state.rest || {};
    state.rest.ping = ping;

    // Update shell badges if supported
    if (shell && typeof shell.setStatus === "function") {
      shell.setStatus(ping?.ok ? "ready" : "not ready");
    }

    // 2) Load client doc if we have a clientId (clients should; admins sometimes too)
    // This is safe even if it returns 400 when no client_id is set.
    const client = await apiGet("/client");
    state.rest.client = client;

    // If your UI wants a right-side pill badge
    if (shell && typeof shell.setPill === "function") {
      if (client?.ok && client?.exists) shell.setPill("client doc exists");
      else if (client?.ok && !client?.exists) shell.setPill("no client doc");
      else shell.setPill("client not linked");
    }

    // 3) Provide common actions to UI (your tabs can call these)
    state.actions = {
      ping: async () => {
        const j = await apiGet("/ping");
        state.rest.ping = j;
        return j;
      },
      loadClient: async () => {
        const j = await apiGet("/client");
        state.rest.client = j;
        return j;
      },
      bootstrapClient: async () => {
        // Admin-only route (server enforces)
        const j = await apiPost("/clients/bootstrap", { client_id: state.clientId });
        state.rest.bootstrap = j;
        return j;
      },
    };

    // 4) Render first tab
    renderTab("dashboard");
  })();
})();
