<?php

namespace WNQ\PublicSite;

use WNQ\Core\Permissions;

if (!defined('ABSPATH')) {
  exit;
}

final class Shortcode
{
  public static function register(): void
  {
    add_shortcode('wnq_portal', [self::class, 'render']);
  }

  public static function render($atts = []): string
  {
    if (!Permissions::isLoggedIn()) {
      return '<p>You must be logged in to view this portal.</p>';
    }

    $clientId = Permissions::currentUserClientId();

    if ($clientId === null && !Permissions::currentUserCanManagePortal()) {
      return '<p>Your account is not linked to a client yet. Please contact WebNique.</p>';
    }

    self::enqueueAssets($clientId ?? '');

    $args = [
      'client_id' => $clientId ?? '',
      'mode' => Permissions::currentUserCanManagePortal() ? 'admin' : 'client',
    ];

    return \wnq_portal_shell_html($args);
  }

  private static function enqueueAssets(string $clientId): void
  {
    $ver = defined('WNQ_PORTAL_VERSION') ? WNQ_PORTAL_VERSION : time();

    wp_enqueue_style(
      'wnq-portal-app',
      WNQ_PORTAL_URL . 'assets/app/app.css',
      [],
      $ver
    );

    // Enqueue JS (we'll mark it as type="module" via filter below)
    wp_enqueue_script(
      'wnq-portal-app',
      WNQ_PORTAL_URL . 'assets/app/app.js',
      [],
      $ver,
      true
    );

    // ✅ Mark as ES module so `import ...` works
    add_filter('script_loader_tag', function ($tag, $handle, $src) {
      if ($handle !== 'wnq-portal-app') {
        return $tag;
      }
      return '<script type="module" src="' . esc_url($src) . '"></script>';
    }, 10, 3);

    // ✅ Provide REST base + nonce + clientId to frontend
    wp_localize_script('wnq-portal-app', 'WNQ_PORTAL', [
      'restUrl'   => esc_url_raw(rest_url('wnq/v1')),
      'nonce'     => wp_create_nonce('wp_rest'),
      'clientId'  => $clientId,
      'isAdmin'   => current_user_can('wnq_manage_portal') || current_user_can('manage_options'),
    ]);
  }
}
