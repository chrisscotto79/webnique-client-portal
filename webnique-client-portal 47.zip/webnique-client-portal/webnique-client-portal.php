<?php
/**
 * Plugin Name: WebNique Client Portal
 * Description: Private client dashboard portal for WebNique (SEO / Analytics / Subscription / Messaging).
 * Version: 0.1.0
 * Author: WebNique
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Text Domain: webnique-portal
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WNQ_PORTAL_VERSION', '0.1.4');
define('WNQ_PORTAL_PATH', plugin_dir_path(__FILE__));
define('WNQ_PORTAL_URL', plugin_dir_url(__FILE__));

// Check if the Plugin class file exists
$plugin_file = WNQ_PORTAL_PATH . 'includes/Core/Plugin.php';

if (!file_exists($plugin_file)) {
    // Show error in admin
    add_action('admin_notices', function() use ($plugin_file) {
        echo '<div class="notice notice-error"><p>';
        echo '<strong>WebNique Portal Error:</strong> Core Plugin file not found at: ' . esc_html($plugin_file);
        echo '</p></div>';
    });
    
    // Log error
    error_log('WebNique Portal: Plugin.php not found at ' . $plugin_file);
    return;
}

// Load the Plugin class
require_once $plugin_file;

// Check if the class was loaded successfully
if (!class_exists('WNQ\\Core\\Plugin')) {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-error"><p>';
        echo '<strong>WebNique Portal Error:</strong> Plugin class could not be loaded. Check for PHP errors.';
        echo '</p></div>';
    });
    
    error_log('WebNique Portal: Plugin class not found after require');
    return;
}

// Register activation hook
register_activation_hook(__FILE__, function() {
    if (class_exists('WNQ\\Core\\Plugin')) {
        WNQ\Core\Plugin::activate();
    }
});

// Register deactivation hook
register_deactivation_hook(__FILE__, function() {
    if (class_exists('WNQ\\Core\\Plugin') && method_exists('WNQ\\Core\\Plugin', 'deactivate')) {
        WNQ\Core\Plugin::deactivate();
    }
    flush_rewrite_rules();
});

// Initialize plugin on plugins_loaded
add_action('plugins_loaded', function() {
    if (!class_exists('WNQ\\Core\\Plugin')) {
        error_log('WebNique Portal: Plugin class not available on plugins_loaded');
        return;
    }
    
    try {
        // DEBUG: Log that we're calling init
        error_log('WebNique Portal: Calling Plugin::init()');
        
        WNQ\Core\Plugin::init();
        
        // DEBUG: Check if admin was initialized
        if (is_admin()) {
            error_log('WebNique Portal: is_admin() = true');
            
            // Check if AdminMenu class exists
            if (class_exists('WNQ\\Admin\\AdminMenu')) {
                error_log('WebNique Portal: AdminMenu class exists');
            } else {
                error_log('WebNique Portal: AdminMenu class NOT found!');
            }
        }
        
        // Verify shortcode was registered (debug mode only)
        if (defined('WP_DEBUG') && WP_DEBUG) {
            add_action('init', function() {
                global $shortcode_tags;
                if (!isset($shortcode_tags['wnq_portal'])) {
                    error_log('WebNique Portal: Shortcode [wnq_portal] was not registered!');
                }
            }, 999);
        }
        
        // DEBUG: Check if admin_menu action was registered
        add_action('admin_menu', function() {
            error_log('WebNique Portal: admin_menu action is firing');
        }, 999);
        
    } catch (Exception $e) {
        error_log('WebNique Portal Init Error: ' . $e->getMessage());
        error_log('WebNique Portal Init Error Trace: ' . $e->getTraceAsString());
        
        add_action('admin_notices', function() use ($e) {
            echo '<div class="notice notice-error"><p>';
            echo '<strong>WebNique Portal Error:</strong> ' . esc_html($e->getMessage());
            echo '</p></div>';
        });
    }
}, 10);

// TEMPORARY DEBUG: Add test menu to verify WordPress can create menus
add_action('admin_menu', function() {
    add_menu_page(
        'DEBUG Test',
        'DEBUG Test',
        'manage_options',
        'wnq-debug-test',
        function() {
            echo '<div class="wrap">';
            echo '<h1>Debug Test Menu</h1>';
            echo '<p>If you see this menu, WordPress CAN create menus.</p>';
            echo '<p>Check wp-content/debug.log for debug messages.</p>';
            echo '</div>';
        },
        'dashicons-admin-generic',
        59
    );
}, 1);