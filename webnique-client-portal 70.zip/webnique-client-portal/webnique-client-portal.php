<?php
/**
 * Plugin Name: WebNique Client Portal
 * Description: Complete client management system with portal, analytics, billing, tasks, and messaging
 * Version: 1.0.0
 * Author: WebNique
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Text Domain: webnique-portal
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WNQ_PORTAL_VERSION', '1.0.0');
define('WNQ_PORTAL_PATH', plugin_dir_path(__FILE__));
define('WNQ_PORTAL_URL', plugin_dir_url(__FILE__));

// Check if the Plugin class file exists
$plugin_file = WNQ_PORTAL_PATH . 'includes/Core/Plugin.php';

if (!file_exists($plugin_file)) {
    add_action('admin_notices', function() use ($plugin_file) {
        echo '<div class="notice notice-error"><p>';
        echo '<strong>WebNique Portal Error:</strong> Core Plugin file not found at: ' . esc_html($plugin_file);
        echo '</p></div>';
    });
    error_log('WebNique Portal: Plugin.php not found at ' . $plugin_file);
    return;
}

// Load the Plugin class
require_once $plugin_file;

// Check if the class was loaded successfully
if (!class_exists('WNQ\\Core\\Plugin')) {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-error"><p>';
        echo '<strong>WebNique Portal Error:</strong> Plugin class could not be loaded. Check for PHP errors.';
        echo '</p></div>';
    });
    error_log('WebNique Portal: Plugin class not found after require');
    return;
}

// ============================================
// ACTIVATION HOOK
// ============================================
register_activation_hook(__FILE__, function() {
    if (class_exists('WNQ\\Core\\Plugin')) {
        WNQ\Core\Plugin::activate();
    }
    
    // Create clients table
    $client_model = WNQ_PORTAL_PATH . 'includes/Models/Client.php';
    if (file_exists($client_model)) {
        require_once $client_model;
        if (class_exists('WNQ\\Models\\Client')) {
            \WNQ\Models\Client::createTable();
        }
    }
    
    // Create tasks table
    $task_model = WNQ_PORTAL_PATH . 'includes/Models/Task.php';
    if (file_exists($task_model)) {
        require_once $task_model;
        if (class_exists('WNQ\\Models\\Task')) {
            \WNQ\Models\Task::createTable();
        }
    }
});

// ============================================
// DEACTIVATION HOOK
// ============================================
register_deactivation_hook(__FILE__, function() {
    if (class_exists('WNQ\\Core\\Plugin') && method_exists('WNQ\\Core\\Plugin', 'deactivate')) {
        WNQ\Core\Plugin::deactivate();
    }
    flush_rewrite_rules();
});

// ============================================
// INITIALIZE PLUGIN
// ============================================
add_action('plugins_loaded', function() {
    if (!class_exists('WNQ\\Core\\Plugin')) {
        error_log('WebNique Portal: Plugin class not available on plugins_loaded');
        return;
    }
    
    try {
        WNQ\Core\Plugin::init();
        
        // Verify shortcode was registered (debug mode only)
        if (defined('WP_DEBUG') && WP_DEBUG) {
            add_action('init', function() {
                global $shortcode_tags;
                if (!isset($shortcode_tags['wnq_portal'])) {
                    error_log('WebNique Portal: Shortcode [wnq_portal] was not registered!');
                }
            }, 999);
        }
    } catch (Exception $e) {
        error_log('WebNique Portal Init Error: ' . $e->getMessage());
        
        add_action('admin_notices', function() use ($e) {
            echo '<div class="notice notice-error"><p>';
            echo '<strong>WebNique Portal Error:</strong> ' . esc_html($e->getMessage());
            echo '</p></div>';
        });
    }
}, 10);

// ============================================
// CLIENT FORM HANDLERS
// ============================================
add_action('admin_post_wnq_save_client', function() {
    error_log('WNQ: Save client handler called');
    
    $clients_admin = WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
    if (file_exists($clients_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
        require_once $clients_admin;
        
        error_log('WNQ: Files loaded, calling handleSaveClient');
        
        \WNQ\Admin\ClientsAdmin::handleSaveClient();
    } else {
        error_log('WNQ: ClientsAdmin.php not found at: ' . $clients_admin);
    }
});

add_action('admin_post_wnq_delete_client', function() {
    $clients_admin = WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
    if (file_exists($clients_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
        require_once $clients_admin;
        \WNQ\Admin\ClientsAdmin::handleDeleteClient();
    }
});

add_action('admin_post_wnq_mark_paid', function() {
    error_log('WNQ: Mark paid handler called');
    
    $clients_admin = WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
    if (file_exists($clients_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
        require_once $clients_admin;
        
        error_log('WNQ: Files loaded, calling handleMarkPaid');
        
        \WNQ\Admin\ClientsAdmin::handleMarkPaid();
    } else {
        error_log('WNQ: ClientsAdmin.php not found at: ' . $clients_admin);
    }
});

// ============================================
// TASK FORM HANDLERS
// ============================================
add_action('admin_post_wnq_save_task', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::handleSaveTask();
    }
});

add_action('admin_post_wnq_delete_task', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::handleDeleteTask();
    }
});

// ============================================
// AJAX HANDLERS FOR TASKS
// ============================================
add_action('wp_ajax_wnq_update_task_status', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::ajaxUpdateTaskStatus();
    }
});

add_action('wp_ajax_wnq_update_task_position', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::ajaxUpdateTaskPosition();
    }
});

// ============================================
// ADMIN MENU REGISTRATION
// ============================================
add_action('admin_menu', function() {
    $capability = current_user_can('wnq_manage_portal') ? 'wnq_manage_portal' : 'manage_options';
    
    // Main menu
    add_menu_page(
        'WebNique Portal',
        'WebNique Portal',
        $capability,
        'wnq-portal',
        'wnq_render_settings_page',
        'dashicons-chart-area',
        58
    );
    
    // Settings submenu
    add_submenu_page(
        'wnq-portal',
        'Settings',
        'Settings',
        $capability,
        'wnq-portal',
        'wnq_render_settings_page'
    );
    
    // Clients submenu
    add_submenu_page(
        'wnq-portal',
        'Clients',
        'Clients',
        $capability,
        'wnq-clients',
        'wnq_render_clients_page'
    );
    
    // Tasks submenu
    add_submenu_page(
        'wnq-portal',
        'Tasks',
        'Tasks',
        $capability,
        'wnq-tasks',
        'wnq_render_tasks_page'
    );
    
    // Web Requests submenu
    add_submenu_page(
        'wnq-portal',
        'Web Requests',
        'Web Requests',
        $capability,
        'wnq-web-requests',
        'wnq_render_requests_page'
    );
}, 10);

// ============================================
// RENDER FUNCTIONS
// ============================================

/**
 * Render Settings Page
 */
function wnq_render_settings_page() {
    if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    
    $version = WNQ_PORTAL_VERSION;
    
    wp_enqueue_style('wnq-admin-settings', WNQ_PORTAL_URL . 'assets/app/app.css', [], $version);
    wp_enqueue_script('wnq-admin-settings', WNQ_PORTAL_URL . 'assets/app/settings.js', [], $version, true);
    
    add_filter('script_loader_tag', function ($tag, $handle, $src) {
        if ($handle !== 'wnq-admin-settings') return $tag;
        return '<script type="module" src="' . esc_url($src) . '"></script>';
    }, 10, 3);
    
    wp_localize_script('wnq-admin-settings', 'WNQ_ADMIN', [
        'restUrl'   => esc_url_raw(rest_url('wnq/v1')),
        'nonce'     => wp_create_nonce('wp_rest'),
        'isAdmin'   => true,
        'ajaxUrl'   => admin_url('admin-ajax.php'),
    ]);
    
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        <div id="wnq-admin-settings-root"></div>
        <div class="wnq-admin-fallback" style="display: none;">
            <h2>WebNique Portal Settings</h2>
            <p>Loading settings interface...</p>
        </div>
    </div>
    <?php
}

/**
 * Render Clients Page
 */
function wnq_render_clients_page() {
    if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    
    $client_model = WNQ_PORTAL_PATH . 'includes/Models/Client.php';
    if (!file_exists($client_model)) {
        echo '<div class="wrap"><div class="notice notice-error"><p><strong>Error:</strong> Client model not found.</p></div></div>';
        return;
    }
    
    require_once $client_model;
    
    $clients_admin = WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
    if (!file_exists($clients_admin)) {
        echo '<div class="wrap"><div class="notice notice-error"><p><strong>Error:</strong> ClientsAdmin not found.</p></div></div>';
        return;
    }
    
    require_once $clients_admin;
    \WNQ\Admin\ClientsAdmin::render();
}

/**
 * Render Tasks Page
 */
function wnq_render_tasks_page() {
    if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    
    $task_model = WNQ_PORTAL_PATH . 'includes/Models/Task.php';
    if (!file_exists($task_model)) {
        echo '<div class="wrap"><div class="notice notice-error"><p><strong>Error:</strong> Task model not found.</p></div></div>';
        return;
    }
    
    require_once $task_model;
    
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (!file_exists($tasks_admin)) {
        echo '<div class="wrap"><div class="notice notice-error"><p><strong>Error:</strong> TasksAdmin not found.</p></div></div>';
        return;
    }
    
    require_once $tasks_admin;
    \WNQ\Admin\TasksAdmin::render();
}

/**
 * Render Web Requests Page
 */
function wnq_render_requests_page() {
    if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    
    $version = WNQ_PORTAL_VERSION;
    
    wp_enqueue_style('wnq-admin-requests', WNQ_PORTAL_URL . 'assets/admin/requests-admin.css', [], $version);
    wp_enqueue_script('wnq-admin-requests', WNQ_PORTAL_URL . 'assets/admin/requests-admin.js', [], $version, true);
    
    add_filter('script_loader_tag', function ($tag, $handle, $src) {
        if ($handle !== 'wnq-admin-requests') return $tag;
        return '<script type="module" src="' . esc_url($src) . '"></script>';
    }, 10, 3);
    
    $current_user = wp_get_current_user();
    
    wp_localize_script('wnq-admin-requests', 'WNQ_ADMIN_CONFIG', [
        'ajaxUrl'   => admin_url('admin-ajax.php'),
        'nonce'     => wp_create_nonce('wnq_admin_requests'),
        'restUrl'   => esc_url_raw(rest_url('wnq/v1')),
        'user'      => [
            'id'    => get_current_user_id(),
            'name'  => $current_user->display_name ?: $current_user->user_login,
            'email' => $current_user->user_email,
        ],
        'firebaseConfig' => [
            'apiKey'            => 'AIzaSyDlN2rZlJYC0u1_mq9oEqApb1crQe-Nrk8',
            'authDomain'        => 'webnique-client-portal.firebaseapp.com',
            'projectId'         => 'webnique-client-portal',
            'storageBucket'     => 'webnique-client-portal.firebasestorage.app',
            'messagingSenderId' => '174763137944',
            'appId'             => '1:174763137944:web:2e6e6b3adb39b9ccc5a9ed',
        ],
    ]);
    
    ?>
    <div class="wrap wnq-admin-requests">
        <div id="wnq-admin-requests-root">
            <div style="padding: 40px; text-align: center;">
                <div class="wnq-spinner"></div>
                <p style="margin-top: 20px; color: #6b7280;">Loading requests...</p>
            </div>
        </div>
    </div>
    
    <style>
    .wnq-spinner {
        border: 3px solid #e5e7eb;
        border-top-color: #0d539e;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        animation: spin 0.8s linear infinite;
        margin: 0 auto;
    }
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    </style>
    <?php
}