<?php
/**
 * Task Model
 * 
 * Handles database operations for task management
 * 
 * @package WebNique Portal
 */

namespace WNQ\Models;

if (!defined('ABSPATH')) {
    exit;
}

final class Task
{
    private static string $table = 'wnq_tasks';

    /**
     * Create tasks table
     */
    public static function createTable(): void
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            description longtext DEFAULT NULL,
            status varchar(50) DEFAULT 'todo',
            priority varchar(50) DEFAULT 'medium',
            assigned_to varchar(255) DEFAULT NULL,
            due_date date DEFAULT NULL,
            client_id varchar(100) DEFAULT NULL,
            attachments longtext DEFAULT NULL,
            notes longtext DEFAULT NULL,
            position int(11) DEFAULT 0,
            created_by bigint(20) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            completed_at datetime DEFAULT NULL,
            
            PRIMARY KEY (id),
            KEY status (status),
            KEY assigned_to (assigned_to),
            KEY priority (priority),
            KEY due_date (due_date)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * Get all tasks
     */
    public static function getAll(array $filters = []): array
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table;

        $where = ['1=1'];
        $params = [];

        if (!empty($filters['status'])) {
            $where[] = 'status = %s';
            $params[] = $filters['status'];
        }

        if (!empty($filters['assigned_to'])) {
            $where[] = 'assigned_to = %s';
            $params[] = $filters['assigned_to'];
        }

        if (!empty($filters['priority'])) {
            $where[] = 'priority = %s';
            $params[] = $filters['priority'];
        }

        if (!empty($filters['client_id'])) {
            $where[] = 'client_id = %s';
            $params[] = $filters['client_id'];
        }

        $where_sql = implode(' AND ', $where);
        $order_by = 'ORDER BY position ASC, created_at DESC';

        if (empty($params)) {
            $results = $wpdb->get_results(
                "SELECT * FROM $table_name WHERE $where_sql $order_by",
                ARRAY_A
            );
        } else {
            $results = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM $table_name WHERE $where_sql $order_by",
                    ...$params
                ),
                ARRAY_A
            );
        }

        return $results ?: [];
    }

    /**
     * Get task by ID
     */
    public static function getById(int $id): ?array
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table;

        $result = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id),
            ARRAY_A
        );

        return $result ?: null;
    }

    /**
     * Create new task
     */
    public static function create(array $data): int|false
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table;

        if (empty($data['title'])) {
            return false;
        }

        $insert_data = [
            'title' => sanitize_text_field($data['title']),
            'description' => wp_kses_post($data['description'] ?? ''),
            'status' => sanitize_text_field($data['status'] ?? 'todo'),
            'priority' => sanitize_text_field($data['priority'] ?? 'medium'),
            'assigned_to' => sanitize_text_field($data['assigned_to'] ?? ''),
            'due_date' => !empty($data['due_date']) ? sanitize_text_field($data['due_date']) : null,
            'client_id' => !empty($data['client_id']) ? sanitize_text_field($data['client_id']) : null,
            'notes' => wp_kses_post($data['notes'] ?? ''),
            'position' => isset($data['position']) ? intval($data['position']) : 0,
            'created_by' => get_current_user_id(),
        ];

        if (!empty($data['attachments'])) {
            $insert_data['attachments'] = is_array($data['attachments']) 
                ? wp_json_encode($data['attachments'])
                : $data['attachments'];
        }

        $result = $wpdb->insert($table_name, $insert_data);

        return $result !== false ? $wpdb->insert_id : false;
    }

    /**
     * Update task
     */
    public static function update(int $id, array $data): bool
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table;

        $update_data = [];

        if (isset($data['title'])) {
            $update_data['title'] = sanitize_text_field($data['title']);
        }
        if (isset($data['description'])) {
            $update_data['description'] = wp_kses_post($data['description']);
        }
        if (isset($data['status'])) {
            $update_data['status'] = sanitize_text_field($data['status']);
            
            // Set completed_at if status is done
            if ($data['status'] === 'done' && !isset($data['completed_at'])) {
                $update_data['completed_at'] = current_time('mysql');
            }
        }
        if (isset($data['priority'])) {
            $update_data['priority'] = sanitize_text_field($data['priority']);
        }
        if (isset($data['assigned_to'])) {
            $update_data['assigned_to'] = sanitize_text_field($data['assigned_to']);
        }
        if (isset($data['due_date'])) {
            $update_data['due_date'] = !empty($data['due_date']) 
                ? sanitize_text_field($data['due_date']) 
                : null;
        }
        if (isset($data['client_id'])) {
            $update_data['client_id'] = sanitize_text_field($data['client_id']);
        }
        if (isset($data['notes'])) {
            $update_data['notes'] = wp_kses_post($data['notes']);
        }
        if (isset($data['position'])) {
            $update_data['position'] = intval($data['position']);
        }
        if (isset($data['attachments'])) {
            $update_data['attachments'] = is_array($data['attachments'])
                ? wp_json_encode($data['attachments'])
                : $data['attachments'];
        }

        if (empty($update_data)) {
            return false;
        }

        $result = $wpdb->update(
            $table_name,
            $update_data,
            ['id' => $id],
            null,
            ['%d']
        );

        return $result !== false;
    }

    /**
     * Delete task
     */
    public static function delete(int $id): bool
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table;

        $result = $wpdb->delete(
            $table_name,
            ['id' => $id],
            ['%d']
        );

        return $result !== false;
    }

    /**
     * Get tasks by status
     */
    public static function getByStatus(string $status): array
    {
        return self::getAll(['status' => $status]);
    }

    /**
     * Get tasks by assignee
     */
    public static function getByAssignee(string $assignee): array
    {
        return self::getAll(['assigned_to' => $assignee]);
    }

    /**
     * Get task counts by status
     */
    public static function getCountsByStatus(): array
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table;

        $results = $wpdb->get_results(
            "SELECT status, COUNT(*) as count FROM $table_name GROUP BY status",
            ARRAY_A
        );

        $counts = [
            'todo' => 0,
            'in_progress' => 0,
            'review' => 0,
            'done' => 0,
        ];

        foreach ($results as $row) {
            $counts[$row['status']] = intval($row['count']);
        }

        return $counts;
    }

    /**
     * Get overdue tasks
     */
    public static function getOverdue(): array
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table;

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table_name 
                WHERE due_date < %s 
                AND status != 'done' 
                ORDER BY due_date ASC",
                current_time('Y-m-d')
            ),
            ARRAY_A
        );

        return $results ?: [];
    }
}