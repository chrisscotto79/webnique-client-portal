<?php
/**
 * Tasks Admin Page - Complete Full-Featured Version
 * 
 * Employee task management with Kanban board, drag & drop, forms, and AJAX
 * 
 * Features:
 * - Visual Kanban board with 4 columns
 * - Drag and drop tasks between statuses
 * - Priority levels (High, Medium, Low)
 * - Team member assignments
 * - Due dates with overdue tracking
 * - Client linking
 * - AJAX updates (no page reload)
 * - Stats dashboard
 * 
 * @package WebNique Portal
 */

namespace WNQ\Admin;

use WNQ\Models\Task;

if (!defined('ABSPATH')) {
    exit;
}

final class TasksAdmin
{
    /**
     * Register admin page and AJAX handlers
     */
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addSubmenu'], 15);
        add_action('admin_enqueue_scripts', [self::class, 'enqueueAssets']);
    }

    /**
     * Add submenu page
     */
    public static function addSubmenu(): void
    {
        $capability = current_user_can('wnq_manage_portal') ? 'wnq_manage_portal' : 'manage_options';

        add_submenu_page(
            'wnq-portal',
            'Tasks',
            'Tasks',
            $capability,
            'wnq-tasks',
            [self::class, 'render']
        );
    }

    /**
     * Enqueue scripts for drag and drop
     */
    public static function enqueueAssets($hook): void
    {
        if ($hook !== 'webnique-portal_page_wnq-tasks') {
            return;
        }

        wp_enqueue_script('jquery-ui-draggable');
        wp_enqueue_script('jquery-ui-droppable');
    }

    /**
     * Main render function
     */
    public static function render(): void
    {
        if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';
        $task_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

        if ($action === 'edit' && $task_id) {
            self::renderEditForm($task_id);
            return;
        }

        if ($action === 'add') {
            self::renderAddForm();
            return;
        }

        self::renderKanbanBoard();
    }

    /**
     * Render Kanban board
     */
    private static function renderKanbanBoard(): void
    {
        // Load clients
        $clients = [];
        if (file_exists(WNQ_PORTAL_PATH . 'includes/Models/Client.php')) {
            require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
            if (class_exists('WNQ\\Models\\Client')) {
                $clients = \WNQ\Models\Client::getAll();
            }
        }

        $tasks = Task::getAll();
        $counts = Task::getCountsByStatus();
        $overdue = Task::getOverdue();

        // Group tasks by status
        $tasksByStatus = [
            'todo' => [],
            'in_progress' => [],
            'review' => [],
            'done' => [],
        ];

        foreach ($tasks as $task) {
            $status = $task['status'] ?? 'todo';
            if (isset($tasksByStatus[$status])) {
                $tasksByStatus[$status][] = $task;
            }
        }

        // Team members
        $team_members = [
            'christopher-scotto' => 'Christopher Scotto',
            'christopher-sanders' => 'Christopher Sanders',
        ];

        ?>
        <div class="wrap wnq-tasks-admin">
            <div class="tasks-header">
                <div>
                    <h1>Task Management</h1>
                    <p class="subtitle">Kanban board for team tasks</p>
                </div>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&action=add'); ?>" class="button button-primary button-large">
                    + New Task
                </a>
            </div>

            <!-- Stats Dashboard -->
            <div class="tasks-stats">
                <div class="stat-card">
                    <span class="stat-label">To Do</span>
                    <span class="stat-value"><?php echo $counts['todo']; ?></span>
                </div>
                <div class="stat-card" style="border-left-color: #0d539e;">
                    <span class="stat-label">In Progress</span>
                    <span class="stat-value" style="color: #0d539e;"><?php echo $counts['in_progress']; ?></span>
                </div>
                <div class="stat-card" style="border-left-color: #f59e0b;">
                    <span class="stat-label">Review</span>
                    <span class="stat-value" style="color: #f59e0b;"><?php echo $counts['review']; ?></span>
                </div>
                <div class="stat-card" style="border-left-color: #10b981;">
                    <span class="stat-label">Done</span>
                    <span class="stat-value" style="color: #10b981;"><?php echo $counts['done']; ?></span>
                </div>
                <?php if (!empty($overdue)): ?>
                <div class="stat-card" style="border-left-color: #dc2626;">
                    <span class="stat-label">Overdue</span>
                    <span class="stat-value" style="color: #dc2626;"><?php echo count($overdue); ?></span>
                </div>
                <?php endif; ?>
            </div>

            <!-- Kanban Board -->
            <div class="kanban-board">
                <?php
                $columns = [
                    'todo' => ['icon' => '📋', 'title' => 'To Do'],
                    'in_progress' => ['icon' => '🚀', 'title' => 'In Progress'],
                    'review' => ['icon' => '👀', 'title' => 'Review'],
                    'done' => ['icon' => '✅', 'title' => 'Done'],
                ];

                foreach ($columns as $status => $col):
                ?>
                    <div class="kanban-column" data-status="<?php echo esc_attr($status); ?>">
                        <div class="column-header">
                            <h3><?php echo $col['icon'] . ' ' . $col['title']; ?></h3>
                            <span class="column-count"><?php echo count($tasksByStatus[$status]); ?></span>
                        </div>
                        <div class="column-tasks" id="column-<?php echo esc_attr($status); ?>">
                            <?php foreach ($tasksByStatus[$status] as $task): ?>
                                <?php self::renderTaskCard($task, $team_members, $clients); ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <?php self::renderStyles(); ?>
        <?php self::renderScript(); ?>
        <?php
    }

    /**
     * Render individual task card
     */
    private static function renderTaskCard(array $task, array $team_members, array $clients): void
    {
        $priority = $task['priority'] ?? 'medium';
        $due_date = $task['due_date'] ?? null;
        $is_overdue = $due_date && strtotime($due_date) < strtotime('today') && $task['status'] !== 'done';
        $assignee_name = !empty($task['assigned_to']) ? ($team_members[$task['assigned_to']] ?? $task['assigned_to']) : '';

        // Get client name
        $client_name = '';
        if (!empty($task['client_id'])) {
            foreach ($clients as $client) {
                if ($client['client_id'] === $task['client_id']) {
                    $client_name = $client['name'];
                    break;
                }
            }
        }

        ?>
        <div class="task-card" data-task-id="<?php echo esc_attr($task['id']); ?>">
            <div class="task-title"><?php echo esc_html($task['title']); ?></div>
            
            <?php if (!empty($task['description'])): ?>
            <div class="task-description">
                <?php echo wp_trim_words(esc_html($task['description']), 15); ?>
            </div>
            <?php endif; ?>
            
            <div class="task-meta">
                <span class="task-priority priority-<?php echo esc_attr($priority); ?>">
                    <?php echo esc_html(ucfirst($priority)); ?>
                </span>
                
                <?php if ($assignee_name): ?>
                <span class="task-assignee">
                    👤 <?php echo esc_html($assignee_name); ?>
                </span>
                <?php endif; ?>
                
                <?php if ($due_date): ?>
                <span class="task-due <?php echo $is_overdue ? 'overdue' : ''; ?>">
                    📅 <?php echo date('M j', strtotime($due_date)); ?>
                </span>
                <?php endif; ?>

                <?php if ($client_name): ?>
                <span class="task-client">
                    🏢 <?php echo esc_html($client_name); ?>
                </span>
                <?php endif; ?>
            </div>

            <div class="task-actions">
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&action=edit&id=' . $task['id']); ?>">
                    Edit
                </a>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                    <?php wp_nonce_field('wnq_delete_task'); ?>
                    <input type="hidden" name="action" value="wnq_delete_task">
                    <input type="hidden" name="id" value="<?php echo esc_attr($task['id']); ?>">
                    <button type="submit" onclick="return confirm('Delete this task?');" class="task-delete">
                        Delete
                    </button>
                </form>
            </div>
        </div>
        <?php
    }

    /**
     * Render CSS styles
     */
    private static function renderStyles(): void
    {
        ?>
        <style>
        .wnq-tasks-admin { margin: 20px 20px 20px 0; }
        .tasks-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
        .tasks-header h1 { margin: 0 0 4px; font-size: 28px; font-weight: 700; }
        .subtitle { color: #6b7280; margin: 0; font-size: 14px; }
        
        .tasks-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px; border-left: 4px solid #0d539e; }
        .stat-label { display: block; font-size: 12px; color: #6b7280; font-weight: 600; text-transform: uppercase; margin-bottom: 8px; }
        .stat-value { display: block; font-size: 32px; font-weight: 800; color: #1e293b; }
        
        .kanban-board { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; min-height: 600px; }
        .kanban-column { background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px; min-height: 500px; }
        .column-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 2px solid #e5e7eb; }
        .column-header h3 { margin: 0; font-size: 16px; font-weight: 700; }
        .column-count { background: #e5e7eb; color: #6b7280; padding: 4px 10px; border-radius: 12px; font-size: 13px; font-weight: 700; }
        .column-tasks { min-height: 400px; }
        .column-hover { background: #eff6ff; border-color: #0d539e; }
        
        .task-card { background: white; border: 1px solid #e5e7eb; border-radius: 6px; padding: 12px; margin-bottom: 12px; cursor: move; transition: all 0.2s; }
        .task-card:hover { box-shadow: 0 4px 6px rgba(0,0,0,0.1); transform: translateY(-2px); }
        .task-card.dragging { opacity: 0.5; }
        .task-title { font-size: 14px; font-weight: 600; color: #1e293b; margin-bottom: 8px; }
        .task-description { font-size: 12px; color: #64748b; margin-bottom: 8px; line-height: 1.5; }
        .task-meta { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 8px; }
        
        .task-priority { padding: 3px 8px; border-radius: 4px; font-weight: 600; text-transform: uppercase; font-size: 11px; }
        .priority-high { background: #fee2e2; color: #991b1b; }
        .priority-medium { background: #fef3c7; color: #92400e; }
        .priority-low { background: #e0f2fe; color: #075985; }
        .task-assignee, .task-due, .task-client { padding: 3px 8px; background: #f3f4f6; border-radius: 4px; color: #374151; font-size: 11px; }
        .task-due.overdue { background: #fee2e2; color: #991b1b; }
        
        .task-actions { display: flex; gap: 8px; margin-top: 8px; padding-top: 8px; border-top: 1px solid #f3f4f6; }
        .task-actions a { font-size: 11px; text-decoration: none; color: #0d539e; }
        .task-delete { border: none; background: none; color: #dc2626; cursor: pointer; font-size: 11px; padding: 0; }
        .task-delete:hover { text-decoration: underline; }
        
        .task-form-section { background: white; padding: 20px; margin-bottom: 20px; border: 1px solid #e5e7eb; border-radius: 8px; }
        .task-form-section h2 { margin-top: 0; padding-bottom: 10px; border-bottom: 1px solid #e5e7eb; font-size: 18px; }
        
        @media (max-width: 1400px) { .kanban-board { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 900px) { .kanban-board { grid-template-columns: 1fr; } }
        </style>
        <?php
    }

    /**
     * Render drag-and-drop JavaScript
     */
    private static function renderScript(): void
    {
        ?>
        <script>
        jQuery(document).ready(function($) {
            $('.task-card').draggable({
                revert: 'invalid',
                helper: 'clone',
                cursor: 'move',
                opacity: 0.7,
                zIndex: 1000,
                start: function() { $(this).addClass('dragging'); },
                stop: function() { $(this).removeClass('dragging'); }
            });

            $('.column-tasks').droppable({
                accept: '.task-card',
                hoverClass: 'column-hover',
                drop: function(event, ui) {
                    const taskId = ui.draggable.data('task-id');
                    const newStatus = $(this).parent().data('status');
                    
                    $(this).append(ui.draggable);
                    ui.draggable.css({top: 0, left: 0, position: 'relative'});

                    $.post(ajaxurl, {
                        action: 'wnq_update_task_status',
                        task_id: taskId,
                        status: newStatus,
                        nonce: '<?php echo wp_create_nonce('wnq_task_nonce'); ?>'
                    }, function(response) {
                        if (response.success) {
                            $('.kanban-column').each(function() {
                                $(this).find('.column-count').text($(this).find('.task-card').length);
                            });
                        } else {
                            alert('Failed to update task');
                            location.reload();
                        }
                    });
                }
            });
        });
        </script>
        <?php
    }

    // Form rendering methods
    private static function renderAddForm(): void
    {
        ?>
        <div class="wrap">
            <h1>New Task</h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-tasks'); ?>" class="page-title-action">← Back</a>
            <?php self::renderTaskForm(null); ?>
        </div>
        <?php
    }

    private static function renderEditForm(int $id): void
    {
        $task = Task::getById($id);
        if (!$task) wp_die('Task not found.');
        ?>
        <div class="wrap">
            <h1>Edit Task</h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-tasks'); ?>" class="page-title-action">← Back</a>
            <?php self::renderTaskForm($task); ?>
        </div>
        <?php
    }

    private static function renderTaskForm(?array $task): void
    {
        $is_edit = !empty($task);
        
        $clients = [];
        if (file_exists(WNQ_PORTAL_PATH . 'includes/Models/Client.php')) {
            require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
            if (class_exists('WNQ\\Models\\Client')) {
                $clients = \WNQ\Models\Client::getAll();
            }
        }

        $team_members = [
            'christopher-scotto' => 'Christopher Scotto',
            'christopher-sanders' => 'Christopher Sanders',
        ];

        ?>
        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <?php wp_nonce_field('wnq_save_task'); ?>
            <input type="hidden" name="action" value="wnq_save_task">
            <?php if ($is_edit): ?>
                <input type="hidden" name="id" value="<?php echo esc_attr($task['id']); ?>">
            <?php endif; ?>

            <div class="task-form-section">
                <h2>Task Details</h2>
                <table class="form-table">
                    <tr>
                        <th><label for="title">Title *</label></th>
                        <td><input type="text" name="title" id="title" value="<?php echo esc_attr($task['title'] ?? ''); ?>" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="description">Description</label></th>
                        <td><textarea name="description" id="description" rows="5" class="large-text"><?php echo esc_textarea($task['description'] ?? ''); ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="status">Status</label></th>
                        <td>
                            <select name="status" id="status">
                                <option value="todo" <?php selected($task['status'] ?? 'todo', 'todo'); ?>>To Do</option>
                                <option value="in_progress" <?php selected($task['status'] ?? '', 'in_progress'); ?>>In Progress</option>
                                <option value="review" <?php selected($task['status'] ?? '', 'review'); ?>>Review</option>
                                <option value="done" <?php selected($task['status'] ?? '', 'done'); ?>>Done</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="priority">Priority</label></th>
                        <td>
                            <select name="priority" id="priority">
                                <option value="low" <?php selected($task['priority'] ?? '', 'low'); ?>>Low</option>
                                <option value="medium" <?php selected($task['priority'] ?? 'medium', 'medium'); ?>>Medium</option>
                                <option value="high" <?php selected($task['priority'] ?? '', 'high'); ?>>High</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="assigned_to">Assign To</label></th>
                        <td>
                            <select name="assigned_to" id="assigned_to">
                                <option value="">Unassigned</option>
                                <?php foreach ($team_members as $id => $name): ?>
                                    <option value="<?php echo esc_attr($id); ?>" <?php selected($task['assigned_to'] ?? '', $id); ?>><?php echo esc_html($name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="due_date">Due Date</label></th>
                        <td><input type="date" name="due_date" id="due_date" value="<?php echo esc_attr($task['due_date'] ?? ''); ?>"></td>
                    </tr>
                    <?php if (!empty($clients)): ?>
                    <tr>
                        <th><label for="client_id">Client</label></th>
                        <td>
                            <select name="client_id" id="client_id">
                                <option value="">No client</option>
                                <?php foreach ($clients as $client): ?>
                                    <option value="<?php echo esc_attr($client['client_id']); ?>" <?php selected($task['client_id'] ?? '', $client['client_id']); ?>>
                                        <?php echo esc_html($client['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <th><label for="notes">Notes</label></th>
                        <td><textarea name="notes" id="notes" rows="4" class="large-text"><?php echo esc_textarea($task['notes'] ?? ''); ?></textarea></td>
                    </tr>
                </table>
            </div>

            <p class="submit">
                <button type="submit" class="button button-primary button-large"><?php echo $is_edit ? 'Update Task' : 'Create Task'; ?></button>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks'); ?>" class="button button-large">Cancel</a>
            </p>
        </form>
        <?php
    }

    // Form handlers
    public static function handleSaveTask(): void
    {
        check_admin_referer('wnq_save_task');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $data = [
            'title' => sanitize_text_field($_POST['title'] ?? ''),
            'description' => wp_kses_post($_POST['description'] ?? ''),
            'status' => sanitize_text_field($_POST['status'] ?? 'todo'),
            'priority' => sanitize_text_field($_POST['priority'] ?? 'medium'),
            'assigned_to' => sanitize_text_field($_POST['assigned_to'] ?? ''),
            'due_date' => sanitize_text_field($_POST['due_date'] ?? ''),
            'client_id' => sanitize_text_field($_POST['client_id'] ?? ''),
            'notes' => wp_kses_post($_POST['notes'] ?? ''),
        ];

        $success = $id ? Task::update($id, $data) : Task::create($data);
        wp_redirect(admin_url('admin.php?page=wnq-tasks'));
        exit;
    }

    public static function handleDeleteTask(): void
    {
        check_admin_referer('wnq_delete_task');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        Task::delete($id);
        wp_redirect(admin_url('admin.php?page=wnq-tasks'));
        exit;
    }

    public static function ajaxUpdateTaskStatus(): void
    {
        check_ajax_referer('wnq_task_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Insufficient permissions');

        $task_id = isset($_POST['task_id']) ? intval($_POST['task_id']) : 0;
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';

        if (!$task_id || !$status) wp_send_json_error('Invalid data');

        $success = Task::update($task_id, ['status' => $status]);
        $success ? wp_send_json_success() : wp_send_json_error('Failed');
    }
}