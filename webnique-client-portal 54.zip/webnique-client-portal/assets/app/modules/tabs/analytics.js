// assets/app/modules/tabs/analytics.js
/**
 * Analytics Tab - Results & Performance
 * 
 * Shows: Traffic overview, SEO performance, trends, insights
 * Data: GA4 + Google Search Console (via Firestore cache)
 */

import { el, pill, button, escapeHtml } from "../ui.js";

export function renderAnalytics(main, side, state, shell) {
  main.innerHTML = "";
  side.innerHTML = "";

  if (shell?.setStatus) {
    shell.setStatus("Loading analytics...", "neutral");
  }

  // ========================================
  // HEADER
  // ========================================
  main.appendChild(createHeader());

  // ========================================
  // PERIOD SELECTOR
  // ========================================
  const periodControl = createPeriodSelector((period) => {
    loadAnalytics(main, side, state, shell, period);
  });
  main.appendChild(periodControl);

  // ========================================
  // LOAD DATA
  // ========================================
  loadAnalytics(main, side, state, shell, 30);
}

/**
 * Create header
 */
function createHeader() {
  const header = el("div", {
    style: {
      marginBottom: "24px",
      paddingBottom: "20px",
      borderBottom: "2px solid rgba(2,6,23,0.08)",
    },
  });

  header.appendChild(
    el("h1", {
      text: "Analytics & Performance",
      style: {
        fontSize: "32px",
        fontWeight: "900",
        color: "#111827",
        marginBottom: "8px",
      },
    })
  );

  header.appendChild(
    el("p", {
      text: "Track your website's traffic, SEO performance, and trends.",
      style: {
        fontSize: "16px",
        color: "#6b7280",
        margin: "0",
      },
    })
  );

  return header;
}

/**
 * Create period selector
 */
function createPeriodSelector(onChange) {
  const container = el("div", {
    style: {
      marginBottom: "24px",
      display: "flex",
      gap: "8px",
    },
  });

  const periods = [
    { label: "Last 30 Days", value: 30 },
    { label: "Last 60 Days", value: 60 },
    { label: "Last 90 Days", value: 90 },
  ];

  let activePeriod = 30;

  periods.forEach((period) => {
    const btn = el("button", {
      text: period.label,
      type: "button",
      style: {
        padding: "10px 16px",
        borderRadius: "8px",
        border: "1px solid #e5e7eb",
        background: activePeriod === period.value ? "#0d539e" : "white",
        color: activePeriod === period.value ? "white" : "#6b7280",
        fontSize: "14px",
        fontWeight: "600",
        cursor: "pointer",
        transition: "all 0.2s ease",
      },
    });

    btn.addEventListener("click", () => {
      // Update active state
      activePeriod = period.value;
      
      // Update button styles
      container.querySelectorAll("button").forEach((b, i) => {
        if (periods[i].value === activePeriod) {
          b.style.background = "#0d539e";
          b.style.color = "white";
        } else {
          b.style.background = "white";
          b.style.color = "#6b7280";
        }
      });

      // Trigger reload
      onChange(period.value);
    });

    container.appendChild(btn);
  });

  return container;
}

/**
 * Load analytics data
 */
async function loadAnalytics(main, side, state, shell, period) {
  // Create loading state
  const loadingSection = el("div", { 
    style: { textAlign: "center", padding: "40px 0" } 
  });
  loadingSection.appendChild(el("div", { class: "wnq-spinner" }));
  loadingSection.appendChild(
    el("p", { 
      text: "Loading analytics data...",
      style: { marginTop: "16px", color: "#6b7280" },
    })
  );
  
  const tempContainer = el("div");
  tempContainer.appendChild(loadingSection);
  main.appendChild(tempContainer);

  try {
    const [summaryRes, trendsRes, notesRes] = await Promise.all([
      state.actions?.get?.(`/analytics/summary?period=${period}`) || Promise.resolve({ ok: false }),
      state.actions?.get?.(`/analytics/trends?period=${period}`) || Promise.resolve({ ok: false }),
      state.actions?.get?.("/analytics/notes") || Promise.resolve({ ok: false }),
    ]);

    // Remove loading
    tempContainer.remove();

    if (!summaryRes.ok) {
      showError(main, "Failed to load analytics data");
      if (shell?.setStatus) {
        shell.setStatus("Error", "bad");
      }
      return;
    }

    if (shell?.setStatus) {
      shell.setStatus("Ready", "good");
    }

    // Render sections
    main.appendChild(createTrafficOverview(summaryRes.data || {}));
    main.appendChild(createSEOPerformance(summaryRes.data?.seo || {}));
    main.appendChild(createTrendCharts(trendsRes.ok ? trendsRes.data : null, period));

    // Render sidebar
    renderSidebar(side, notesRes.ok ? notesRes.data : [], period);

  } catch (error) {
    tempContainer.remove();
    console.error("[Analytics] Load error:", error);
    showError(main, error.message);
    if (shell?.setStatus) {
      shell.setStatus("Error", "bad");
    }
  }
}

/**
 * Create traffic overview section
 */
function createTrafficOverview(data) {
  const section = el("div", { style: { marginBottom: "32px" } });

  section.appendChild(
    el("h2", {
      text: "Traffic Overview",
      style: {
        fontSize: "20px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "16px",
      },
    })
  );

  const grid = el("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
      gap: "16px",
    },
  });

  const metrics = [
    {
      label: "Sessions",
      value: formatNumber(data.sessions || 0),
      change: data.sessions_change || "+0%",
      icon: "👥",
      positive: parseChange(data.sessions_change) >= 0,
    },
    {
      label: "Users",
      value: formatNumber(data.users || 0),
      change: data.users_change || "+0%",
      icon: "👤",
      positive: parseChange(data.users_change) >= 0,
    },
    {
      label: "Page Views",
      value: formatNumber(data.pageviews || 0),
      change: data.pageviews_change || "+0%",
      icon: "📄",
      positive: parseChange(data.pageviews_change) >= 0,
    },
    {
      label: "Avg. Duration",
      value: formatDuration(data.avg_duration || 0),
      change: data.duration_change || "+0%",
      icon: "⏱️",
      positive: parseChange(data.duration_change) >= 0,
    },
  ];

  metrics.forEach((metric) => {
    grid.appendChild(createMetricCard(metric));
  });

  section.appendChild(grid);
  return section;
}

/**
 * Create metric card
 */
function createMetricCard(metric) {
  const card = el("div", {
    class: "wnq-card",
    style: {
      padding: "20px",
      transition: "all 0.2s ease",
    },
  });

  card.addEventListener("mouseenter", () => {
    card.style.transform = "translateY(-2px)";
    card.style.boxShadow = "0 8px 16px rgba(0,0,0,0.1)";
  });
  card.addEventListener("mouseleave", () => {
    card.style.transform = "translateY(0)";
  });

  // Icon
  card.appendChild(
    el("div", {
      text: metric.icon,
      style: {
        fontSize: "28px",
        marginBottom: "12px",
      },
    })
  );

  // Label
  card.appendChild(
    el("div", {
      text: metric.label,
      style: {
        fontSize: "12px",
        fontWeight: "600",
        color: "#6b7280",
        textTransform: "uppercase",
        letterSpacing: "0.05em",
        marginBottom: "8px",
      },
    })
  );

  // Value
  card.appendChild(
    el("div", {
      text: metric.value,
      style: {
        fontSize: "32px",
        fontWeight: "900",
        color: "#111827",
        marginBottom: "4px",
        lineHeight: "1",
      },
    })
  );

  // Change
  card.appendChild(
    el("div", {
      text: metric.change,
      style: {
        fontSize: "14px",
        fontWeight: "600",
        color: metric.positive ? "#10b981" : "#ef4444",
      },
    })
  );

  return card;
}

/**
 * Create SEO performance section
 */
function createSEOPerformance(data) {
  const section = el("div", { style: { marginBottom: "32px" } });

  section.appendChild(
    el("h2", {
      text: "Search Performance (SEO)",
      style: {
        fontSize: "20px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "16px",
      },
    })
  );

  const card = el("div", { class: "wnq-card" });

  // Metrics grid
  const metricsGrid = el("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
      gap: "20px",
      marginBottom: "24px",
    },
  });

  const seoMetrics = [
    { label: "Clicks", value: formatNumber(data.clicks || 0) },
    { label: "Impressions", value: formatNumber(data.impressions || 0) },
    { label: "CTR", value: `${(data.ctr || 0).toFixed(1)}%` },
    { label: "Avg. Position", value: (data.avg_position || 0).toFixed(1) },
  ];

  seoMetrics.forEach((metric) => {
    const item = el("div");
    
    item.appendChild(
      el("div", {
        text: metric.label,
        style: {
          fontSize: "12px",
          color: "#6b7280",
          fontWeight: "600",
          marginBottom: "4px",
        },
      })
    );

    item.appendChild(
      el("div", {
        text: metric.value,
        style: {
          fontSize: "24px",
          fontWeight: "900",
          color: "#111827",
        },
      })
    );

    metricsGrid.appendChild(item);
  });

  card.appendChild(metricsGrid);

  // Top pages
  if (data.top_pages && data.top_pages.length > 0) {
    card.appendChild(
      el("h3", {
        text: "Top Performing Pages",
        style: {
          fontSize: "16px",
          fontWeight: "700",
          color: "#111827",
          marginBottom: "12px",
          paddingTop: "20px",
          borderTop: "1px solid #e5e7eb",
        },
      })
    );

    data.top_pages.slice(0, 5).forEach((page, index) => {
      const pageItem = el("div", {
        style: {
          padding: "12px 0",
          borderBottom: index < 4 ? "1px solid #f3f4f6" : "none",
        },
      });

      pageItem.appendChild(
        el("div", {
          text: escapeHtml(page.url || "/"),
          style: {
            fontSize: "14px",
            fontWeight: "600",
            color: "#0d539e",
            marginBottom: "4px",
          },
        })
      );

      pageItem.appendChild(
        el("div", {
          text: `${formatNumber(page.clicks || 0)} clicks • ${formatNumber(page.impressions || 0)} impressions`,
          style: {
            fontSize: "12px",
            color: "#6b7280",
          },
        })
      );

      card.appendChild(pageItem);
    });
  }

  section.appendChild(card);
  return section;
}

/**
 * Create trend charts section
 */
function createTrendCharts(data, period) {
  const section = el("div", { style: { marginBottom: "32px" } });

  section.appendChild(
    el("h2", {
      text: `Trends (Last ${period} Days)`,
      style: {
        fontSize: "20px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "16px",
      },
    })
  );

  const card = el("div", { class: "wnq-card" });

  if (!data || !data.dataPoints || data.dataPoints.length === 0) {
    card.appendChild(
      el("p", {
        text: "No trend data available for this period.",
        style: {
          color: "#6b7280",
          textAlign: "center",
          padding: "40px 20px",
        },
      })
    );
  } else {
    // Simple ASCII-style chart (in v1, replace with actual charting library later)
    card.appendChild(createSimpleChart(data.dataPoints, period));
  }

  section.appendChild(card);
  return section;
}

/**
 * Create simple chart visualization
 */
function createSimpleChart(dataPoints, period) {
  const container = el("div", {
    style: {
      background: "#f9fafb",
      borderRadius: "12px",
      padding: "20px",
      minHeight: "200px",
    },
  });

  container.appendChild(
    el("p", {
      text: "📈 Chart visualization",
      style: {
        fontSize: "14px",
        color: "#6b7280",
        textAlign: "center",
        fontStyle: "italic",
      },
    })
  );

  container.appendChild(
    el("p", {
      text: "(Chart.js integration coming in v1.5)",
      style: {
        fontSize: "12px",
        color: "#9ca3af",
        textAlign: "center",
        marginTop: "8px",
      },
    })
  );

  return container;
}

/**
 * Render sidebar
 */
function renderSidebar(side, notes, period) {
  // Insights card
  const insightsCard = el("div", {
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "16px",
      padding: "20px",
      marginBottom: "20px",
    },
  });

  insightsCard.appendChild(
    el("div", {
      text: "💡",
      style: { fontSize: "32px", marginBottom: "12px" },
    })
  );

  insightsCard.appendChild(
    el("h3", {
      text: "Insights & Notes",
      style: {
        fontSize: "16px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "12px",
      },
    })
  );

  if (!notes || notes.length === 0) {
    insightsCard.appendChild(
      el("p", {
        text: "No insights available yet. Check back later for updates from the WebNique team.",
        style: {
          fontSize: "14px",
          color: "#6b7280",
          lineHeight: "1.6",
        },
      })
    );
  } else {
    notes.slice(0, 3).forEach((note, index) => {
      const noteEl = el("div", {
        style: {
          padding: "12px 0",
          borderTop: index > 0 ? "1px solid #f3f4f6" : "none",
        },
      });

      noteEl.appendChild(
        el("div", {
          text: escapeHtml(note.title || "Note"),
          style: {
            fontSize: "14px",
            fontWeight: "600",
            color: "#111827",
            marginBottom: "4px",
          },
        })
      );

      noteEl.appendChild(
        el("div", {
          text: escapeHtml(note.content || ""),
          style: {
            fontSize: "13px",
            color: "#6b7280",
            lineHeight: "1.5",
          },
        })
      );

      insightsCard.appendChild(noteEl);
    });
  }

  side.appendChild(insightsCard);

  // Period summary
  const summaryCard = el("div", {
    style: {
      background: "#f0f9ff",
      border: "1px solid #bfdbfe",
      borderRadius: "16px",
      padding: "20px",
    },
  });

  summaryCard.appendChild(
    el("h3", {
      text: "Period Summary",
      style: {
        fontSize: "16px",
        fontWeight: "800",
        color: "#1e3a8a",
        marginBottom: "12px",
      },
    })
  );

  summaryCard.appendChild(
    el("p", {
      text: `Showing data for the last ${period} days. Switch periods to compare different timeframes.`,
      style: {
        fontSize: "13px",
        color: "#1e40af",
        lineHeight: "1.6",
      },
    })
  );

  side.appendChild(summaryCard);
}

/**
 * Helper functions
 */

function formatNumber(num) {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + "M";
  if (num >= 1000) return (num / 1000).toFixed(1) + "K";
  return num.toString();
}

function formatDuration(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, "0")}`;
}

function parseChange(changeStr) {
  if (!changeStr) return 0;
  const num = parseFloat(changeStr.replace(/[^0-9.-]/g, ""));
  return isNaN(num) ? 0 : num;
}

function showError(container, message) {
  container.appendChild(
    el("div", {
      class: "wnq-alert wnq-alert-danger",
      html: `<strong>Error:</strong> ${escapeHtml(message)}`,
    })
  );
}