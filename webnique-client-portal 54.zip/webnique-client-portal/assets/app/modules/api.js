/**
 * API Helper Functions
 * 
 * @package WebNique Portal
 */

/**
 * Make an API request (generic helper)
 * @param {Object} state - Application state
 * @param {string} path - API endpoint path
 * @param {Object} opts - Fetch options
 * @returns {Promise<Object>} Response object with { res, json }
 */
export async function api(state, path, opts = {}) {
  // Validate state
  if (!state) {
    throw new Error("[API] State object is required");
  }

  // Use restBase or restUrl from state
  const restBase = state.restBase || state.restUrl || "";
  const nonce = state.nonce || "";

  // Validate configuration
  if (!restBase) {
    throw new Error("[API] Missing REST URL in state");
  }

  if (!nonce) {
    throw new Error("[API] Missing nonce in state");
  }

  // Clean up path
  const cleanPath = path.startsWith("/") ? path : `/${path}`;
  const url = `${restBase}${cleanPath}`;

  // Default headers
  const defaultHeaders = {
    "X-WP-Nonce": nonce,
    "Content-Type": "application/json",
  };

  // Merge headers
  const headers = {
    ...defaultHeaders,
    ...(opts.headers || {}),
  };

  try {
    // Make fetch request
    const res = await fetch(url, {
      credentials: "same-origin",
      ...opts,
      headers,
    });

    // Try to parse JSON response
    let json;
    try {
      json = await res.json();
    } catch (parseError) {
      console.warn("[API] Failed to parse JSON response:", parseError);
      json = {
        ok: false,
        error: "Invalid JSON response",
        status: res.status,
      };
    }

    return { res, json };
  } catch (error) {
    console.error("[API] Request failed:", error);
    throw error;
  }
}

/**
 * Make a GET request
 * @param {Object} state - Application state
 * @param {string} path - API endpoint path
 * @returns {Promise<Object>} Response JSON
 */
export async function get(state, path) {
  try {
    const { res, json } = await api(state, path, {
      method: "GET",
    });

    return {
      ...json,
      ok: res.ok,
      status: res.status,
    };
  } catch (error) {
    return {
      ok: false,
      status: 0,
      error: error.message || "Network error",
    };
  }
}

/**
 * Make a POST request
 * @param {Object} state - Application state
 * @param {string} path - API endpoint path
 * @param {Object} body - Request body
 * @returns {Promise<Object>} Response JSON
 */
export async function post(state, path, body = {}) {
  try {
    const { res, json } = await api(state, path, {
      method: "POST",
      body: JSON.stringify(body),
    });

    return {
      ...json,
      ok: res.ok,
      status: res.status,
    };
  } catch (error) {
    return {
      ok: false,
      status: 0,
      error: error.message || "Network error",
    };
  }
}

/**
 * Make a PUT request
 * @param {Object} state - Application state
 * @param {string} path - API endpoint path
 * @param {Object} body - Request body
 * @returns {Promise<Object>} Response JSON
 */
export async function put(state, path, body = {}) {
  try {
    const { res, json } = await api(state, path, {
      method: "PUT",
      body: JSON.stringify(body),
    });

    return {
      ...json,
      ok: res.ok,
      status: res.status,
    };
  } catch (error) {
    return {
      ok: false,
      status: 0,
      error: error.message || "Network error",
    };
  }
}

/**
 * Make a DELETE request
 * @param {Object} state - Application state
 * @param {string} path - API endpoint path
 * @returns {Promise<Object>} Response JSON
 */
export async function del(state, path) {
  try {
    const { res, json } = await api(state, path, {
      method: "DELETE",
    });

    return {
      ...json,
      ok: res.ok,
      status: res.status,
    };
  } catch (error) {
    return {
      ok: false,
      status: 0,
      error: error.message || "Network error",
    };
  }
}

/**
 * Check API health/status
 * @param {Object} state - Application state
 * @returns {Promise<Object>} Ping response
 */
export async function ping(state) {
  return get(state, "/ping");
}

/**
 * Load client data
 * @param {Object} state - Application state
 * @returns {Promise<Object>} Client response
 */
export async function loadClient(state) {
  return get(state, "/client");
}

/**
 * Bootstrap a new client (admin only)
 * @param {Object} state - Application state
 * @param {string} clientId - Client ID to bootstrap
 * @returns {Promise<Object>} Bootstrap response
 */
export async function bootstrapClient(state, clientId) {
  if (!clientId) {
    return {
      ok: false,
      error: "Client ID is required",
    };
  }

  return post(state, "/clients/bootstrap", { client_id: clientId });
}

/**
 * Handle API errors consistently
 * @param {Object} response - API response
 * @param {string} fallbackMessage - Fallback error message
 * @returns {string} Error message
 */
export function getErrorMessage(response, fallbackMessage = "An error occurred") {
  if (!response) {
    return fallbackMessage;
  }

  // Check for error message in various formats
  if (response.error) {
    return typeof response.error === "string"
      ? response.error
      : response.error.message || fallbackMessage;
  }

  if (response.message) {
    return response.message;
  }

  // Check for HTTP status errors
  if (response.status >= 400) {
    const statusMessages = {
      400: "Bad request",
      401: "Unauthorized",
      403: "Forbidden",
      404: "Not found",
      500: "Server error",
      503: "Service unavailable",
    };

    return statusMessages[response.status] || `Error ${response.status}`;
  }

  return fallbackMessage;
}

/**
 * Check if response is successful
 * @param {Object} response - API response
 * @returns {boolean} True if successful
 */
export function isSuccess(response) {
  return !!(response && response.ok === true);
}

/**
 * Check if response is an error
 * @param {Object} response - API response
 * @returns {boolean} True if error
 */
export function isError(response) {
  return !isSuccess(response);
}