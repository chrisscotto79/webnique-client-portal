(async function () {
  const root = document.getElementById("wnq-portal-root");
  if (!root) return;

  const clientId = root.getAttribute("data-client-id") || "";
  const mode = root.getAttribute("data-mode") || "";
  const restBase = window.WNQ_PORTAL?.restUrl || "";
  const nonce = window.WNQ_PORTAL?.nonce || "";
  const isAdmin = !!window.WNQ_PORTAL?.isAdmin;

  // Brand
  const BRAND = {
    primary: "#0d539e",
  };

  // ---------- tiny UI toolkit ----------
  const css = `
    :root{
      --wnq-primary:${BRAND.primary};
      --wnq-primary-weak: rgba(13,83,158,.10);
      --wnq-primary-mid: rgba(13,83,158,.18);
      --wnq-border: #e5e7eb;
      --wnq-text: #0f172a;
      --wnq-muted: #64748b;
      --wnq-bg: #ffffff;
      --wnq-soft: #f8fafc;
      --wnq-shadow: 0 1px 0 rgba(15,23,42,.04);
    }

    .wnq-wrap{
      font-family: system-ui,-apple-system,Segoe UI,Roboto,Arial;
      display:grid;
      gap:14px;
      color: var(--wnq-text);
    }

    .wnq-card{
      background: var(--wnq-bg);
      border: 1px solid var(--wnq-border);
      border-radius: 18px;
      padding: 16px;
      box-shadow: var(--wnq-shadow);
    }

    /* Header card gets a subtle branded top border */
    .wnq-card.header{
      position:relative;
      overflow:hidden;
    }
    .wnq-card.header:before{
      content:"";
      position:absolute;
      left:0; top:0; right:0;
      height:4px;
      background: linear-gradient(90deg, var(--wnq-primary), rgba(13,83,158,.55));
    }

    .wnq-row{display:flex;gap:10px;flex-wrap:wrap;align-items:center;}
    .wnq-space{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;}
    .wnq-title{margin:0;font-size:18px;font-weight:900;letter-spacing:-0.01em;}
    .wnq-sub{margin-top:6px;color:var(--wnq-muted);font-size:13px;line-height:1.4;}

    .wnq-code{
      background: rgba(15,23,42,0.05);
      border: 1px solid rgba(15,23,42,0.06);
      padding: 2px 7px;
      border-radius: 10px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
      font-size: 12px;
    }

    .wnq-pill{
      display:inline-flex;align-items:center;gap:6px;
      padding:7px 11px;border-radius:999px;
      font-size:12px;white-space:nowrap;
      border:1px solid var(--wnq-border);
      background: var(--wnq-soft);
      color: #334155;
      font-weight: 800;
    }
    .wnq-pill.ok{border-color:rgba(16,185,129,.35);background:rgba(16,185,129,.10);color:#065f46;}
    .wnq-pill.warn{border-color:rgba(245,158,11,.35);background:rgba(245,158,11,.10);color:#92400e;}
    .wnq-pill.err{border-color:rgba(239,68,68,.35);background:rgba(239,68,68,.10);color:#991b1b;}
    .wnq-pill.brand{border-color:rgba(13,83,158,.30);background:var(--wnq-primary-weak);color:var(--wnq-primary);}

    .wnq-tabs{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;}
    .wnq-tab{
      padding:10px 12px;
      border-radius: 14px;
      border:1px solid var(--wnq-border);
      background:#fff;
      cursor:pointer;
      font-weight: 900;
      font-size: 14px;
      color: var(--wnq-primary);
      transition: transform .05s ease, background .15s ease, border-color .15s ease;
    }
    .wnq-tab:hover{
      background: var(--wnq-primary-weak);
      border-color: rgba(13,83,158,.28);
    }
    .wnq-tab:active{ transform: translateY(1px); }
    .wnq-tab.active{
      border-color: rgba(13,83,158,.45);
      background: var(--wnq-primary-weak);
      box-shadow: 0 0 0 3px rgba(13,83,158,.10);
    }

    .wnq-grid{display:grid;gap:12px;}
    .wnq-grid.kpis{grid-template-columns:repeat(12,minmax(0,1fr));}
    .wnq-col-3{grid-column:span 3;}
    .wnq-col-4{grid-column:span 4;}
    .wnq-col-5{grid-column:span 5;}
    .wnq-col-6{grid-column:span 6;}
    .wnq-col-7{grid-column:span 7;}
    .wnq-col-8{grid-column:span 8;}
    .wnq-col-12{grid-column:span 12;}
    @media (max-width: 960px){
      .wnq-col-3,.wnq-col-4,.wnq-col-5,.wnq-col-6,.wnq-col-7,.wnq-col-8{grid-column:span 12;}
    }

    .wnq-metric-label{font-size:12px;color:var(--wnq-muted);margin-bottom:6px;font-weight:800;}
    .wnq-metric-value{font-size:18px;font-weight:950;letter-spacing:-0.01em;}
    .wnq-muted{color:var(--wnq-muted);font-size:13px;line-height:1.4;}

    .wnq-btn{
      padding:10px 12px;
      border-radius:14px;
      border:1px solid var(--wnq-border);
      background:#fff;
      cursor:pointer;
      font-weight: 950;
      color: var(--wnq-primary);
      transition: transform .05s ease, background .15s ease, border-color .15s ease, box-shadow .15s ease;
    }
    .wnq-btn:hover{
      background: var(--wnq-primary-weak);
      border-color: rgba(13,83,158,.28);
    }
    .wnq-btn:active{ transform: translateY(1px); }
    .wnq-btn.primary{
      background: linear-gradient(180deg, rgba(13,83,158,.10), rgba(13,83,158,.06));
      border-color: rgba(13,83,158,.40);
      box-shadow: 0 0 0 3px rgba(13,83,158,.08);
    }
    .wnq-btn.solid{
      color:#fff;
      background: var(--wnq-primary);
      border-color: rgba(13,83,158,.55);
      box-shadow: 0 0 0 3px rgba(13,83,158,.10);
    }
    .wnq-btn.solid:hover{
      background: #0b4a88;
      border-color: #0b4a88;
    }

    .wnq-list{display:grid;gap:10px;margin-top:10px;}
    .wnq-item{
      display:flex;
      justify-content:space-between;
      gap:10px;
      align-items:flex-start;
      padding:12px;
      border:1px solid var(--wnq-border);
      border-radius:16px;
      background:#fff;
    }
    .wnq-item-title{font-weight:950;}
    .wnq-item-meta{color:var(--wnq-muted);font-size:12px;margin-top:4px;}

    .wnq-skel{
      border-radius:12px;
      background: linear-gradient(90deg, rgba(13,83,158,0.06), rgba(13,83,158,0.12), rgba(13,83,158,0.06));
      background-size:200% 100%;
      animation:wnqShimmer 1.2s infinite;
    }
    @keyframes wnqShimmer{0%{background-position:0% 0}100%{background-position:200% 0}}

    .wnq-pre{
      white-space:pre-wrap;
      background: rgba(15,23,42,0.04);
      padding:10px;
      border-radius:14px;
      max-height:360px;
      overflow:auto;
      border:1px solid var(--wnq-border);
      color:#0f172a;
    }
    details.wnq-debug summary{
      cursor:pointer;
      font-weight:950;
      color:#334155;
    }
  `;

  const existing = document.getElementById("wnq-style");
  if (existing) existing.remove();
  const styleTag = document.createElement("style");
  styleTag.id = "wnq-style";
  styleTag.textContent = css;
  document.head.appendChild(styleTag);

  const el = (tag, cls, html) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  };
  const code = (v) => `<code class="wnq-code">${String(v)}</code>`;

  async function api(path, { method = "GET", body = null } = {}) {
    if (!restBase || !nonce) return { ok: false, error: "Missing restUrl/nonce" };
    const opts = { method, credentials: "same-origin", headers: { "X-WP-Nonce": nonce } };
    if (body != null) {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
    try {
      const res = await fetch(`${restBase}${path}`, opts);
      const data = await res.json().catch(() => ({}));
      return { ok: true, http_ok: res.ok, status: res.status, data };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  }

  // ---------- state ----------
  const State = { tab: "dashboard", ping: null, client: null };

  const Tabs = [
    { id: "dashboard", label: "Dashboard" },
    { id: "subscription", label: "Subscription" },
    { id: "analytics", label: "Analytics" },
    { id: "requests", label: "Web Requests" },
    { id: "settings", label: "Settings" },
  ];

  // ---------- mount ----------
  const wrap = el("div", "wnq-wrap");
  const header = el("div", "wnq-card header");
  const content = el("div", "wnq-card");
  const debug = el("details", "wnq-debug", `<summary>Debug</summary><div class="wnq-row" style="margin-top:10px;"></div><div style="margin-top:10px;"></div>`);

  wrap.appendChild(header);
  wrap.appendChild(content);
  wrap.appendChild(debug);
  root.appendChild(wrap);

  const debugBtns = debug.querySelector(".wnq-row");
  const debugOut = debug.querySelectorAll("div")[1];

  function setHeaderStatus(text, kind = "neutral") {
    const pill = header.querySelector("[data-pill]");
    if (!pill) return;

    pill.className = "wnq-pill";
    if (kind === "ok") pill.classList.add("ok");
    else if (kind === "warn") pill.classList.add("warn");
    else if (kind === "err") pill.classList.add("err");
    else pill.classList.add("brand");

    pill.textContent = text;
  }

  function renderHeader() {
    header.innerHTML = "";

    const top = el("div", "wnq-space");
    const left = el(
      "div",
      "",
      `<h1 class="wnq-title">WebNique Client Portal</h1>
       <div class="wnq-sub">Client: ${code(clientId || "(none)")} · Mode: ${code(mode || "(none)")}${isAdmin ? ` · ${code("admin")}` : ""}</div>`
    );
    const right = el("div", "wnq-row");
    const pill = el("span", "wnq-pill brand", "loading…");
    pill.setAttribute("data-pill", "1");
    right.appendChild(pill);

    top.appendChild(left);
    top.appendChild(right);

    const tabs = el("div", "wnq-tabs");
    Tabs.forEach((t) => {
      const b = el("button", `wnq-tab ${State.tab === t.id ? "active" : ""}`, t.label);
      b.type = "button";
      b.addEventListener("click", () => {
        State.tab = t.id;
        renderHeader();
        renderContent();
      });
      tabs.appendChild(b);
    });

    header.appendChild(top);
    header.appendChild(tabs);
  }

  // ---------- dashboard view ----------
  function kpi(label, value, hint, colClass = "wnq-col-3") {
    const c = el("div", `wnq-card ${colClass}`);
    c.innerHTML = `
      <div class="wnq-metric-label">${label}</div>
      <div class="wnq-metric-value">${value}</div>
      <div class="wnq-muted" style="margin-top:6px;">${hint}</div>
    `;
    return c;
  }

  function dashboardView() {
    const v = el("div", "wnq-grid");

    const kpis = el("div", "wnq-grid kpis");
    const clientExists = State.client?.exists === true;

    kpis.appendChild(kpi("Client Doc", clientExists ? "Exists" : "Missing", "Firestore clients/{client_id}", "wnq-col-3"));
    kpis.appendChild(kpi("Subscription", "Not connected", "Stripe next phase", "wnq-col-3"));
    kpis.appendChild(kpi("SEO Progress", "Coming soon", "We’ll add milestones later", "wnq-col-3"));
    kpis.appendChild(kpi("Last Update", "—", "We’ll show activity later", "wnq-col-3"));
    v.appendChild(kpis);

    const grid = el("div", "wnq-grid kpis");

    const left = el("div", "wnq-card wnq-col-7");
    left.innerHTML = `
      <div class="wnq-row" style="justify-content:space-between;">
        <div>
          <div style="font-weight:950;font-size:16px;">Overview</div>
          <div class="wnq-muted" style="margin-top:6px;">Dashboard shell is live. Next: make this real.</div>
        </div>
        <span class="wnq-pill ${clientExists ? "ok" : "warn"}">${clientExists ? "client ready" : "needs bootstrap"}</span>
      </div>

      <div style="margin-top:14px; display:grid; gap:10px;">
        <div class="wnq-item">
          <div>
            <div class="wnq-item-title">Next step: UI foundation</div>
            <div class="wnq-item-meta">Navigation, layout, and components (no real data yet).</div>
          </div>
          <span class="wnq-pill brand">phase 1</span>
        </div>

        <div class="wnq-item">
          <div>
            <div class="wnq-item-title">Then: Subscription</div>
            <div class="wnq-item-meta">Stripe status + billing portal link.</div>
          </div>
          <span class="wnq-pill">phase 2</span>
        </div>

        <div class="wnq-item">
          <div>
            <div class="wnq-item-title">Then: Analytics</div>
            <div class="wnq-item-meta">GA4 + Search Console metrics stored in Firestore.</div>
          </div>
          <span class="wnq-pill">phase 3</span>
        </div>
      </div>
    `;

    const right = el("div", "wnq-card wnq-col-5");
    right.innerHTML = `
      <div style="font-weight:950;font-size:16px;">Quick Actions</div>
      <div class="wnq-muted" style="margin-top:6px;">Admin-only actions only show for admins.</div>

      <div class="wnq-row" style="margin-top:14px;">
        <button type="button" class="wnq-btn primary" data-action="load-client">Load Client Doc</button>
        ${isAdmin ? `<button type="button" class="wnq-btn" data-action="bootstrap">Bootstrap Client</button>` : ``}
        <button type="button" class="wnq-btn" data-action="ping">Ping (REST)</button>
      </div>

      <div style="margin-top:16px; font-weight:950;">Recent Activity (placeholder)</div>
      <div class="wnq-list">
        <div class="wnq-item">
          <div>
            <div class="wnq-item-title">Portal initialized</div>
            <div class="wnq-item-meta">Just now</div>
          </div>
          <span class="wnq-pill ok">ok</span>
        </div>
        <div class="wnq-item">
          <div>
            <div class="wnq-item-title">Client status loaded</div>
            <div class="wnq-item-meta">${clientExists ? "Firestore doc exists" : "No Firestore doc yet"}</div>
          </div>
          <span class="wnq-pill ${clientExists ? "ok" : "warn"}">${clientExists ? "ready" : "todo"}</span>
        </div>
      </div>

      <div style="margin-top:14px;">
        <div class="wnq-muted">Output</div>
        <div id="wnq-mini-out" class="wnq-pre" style="margin-top:8px;">(actions will show JSON here)</div>
      </div>
    `;

    grid.appendChild(left);
    grid.appendChild(right);
    v.appendChild(grid);

    // wire up actions
    const miniOut = right.querySelector("#wnq-mini-out");
    const renderMini = (json) => (miniOut.textContent = JSON.stringify(json, null, 2));

    right.querySelector('[data-action="ping"]').addEventListener("click", async () => {
      miniOut.textContent = "Pinging…";
      const r = await api("/ping");
      renderMini(r.ok ? r.data : r);
      if (r.ok && r.http_ok) {
        State.ping = r.data;
        setHeaderStatus("ping ok", "ok");
      } else setHeaderStatus("ping failed", "err");
      renderContent();
    });

    right.querySelector('[data-action="load-client"]').addEventListener("click", async () => {
      miniOut.textContent = "Loading client…";
      const r = await api("/client");
      renderMini(r.ok ? r.data : r);
      if (r.ok && r.http_ok) {
        State.client = r.data;
        setHeaderStatus(r.data?.exists ? "ready" : "client missing", r.data?.exists ? "ok" : "warn");
      } else setHeaderStatus("client error", "err");
      renderContent();
    });

    const bootstrapBtn = right.querySelector('[data-action="bootstrap"]');
    if (bootstrapBtn) {
      bootstrapBtn.addEventListener("click", async () => {
        miniOut.textContent = "Bootstrapping…";
        const r = await api("/clients/bootstrap", { method: "POST", body: { client_id: clientId } });
        renderMini(r.ok ? r.data : r);
        setHeaderStatus(r.ok && r.http_ok ? "bootstrapped" : "bootstrap failed", r.ok && r.http_ok ? "ok" : "err");
      });
    }

    return v;
  }

  function placeholderView(title, subtitle) {
    const v = el("div", "");
    v.innerHTML = `
      <div style="font-weight:950;font-size:16px;">${title}</div>
      <div class="wnq-muted" style="margin-top:8px;">${subtitle}</div>
      <div style="margin-top:14px;" class="wnq-card">
        <div class="wnq-skel" style="height:14px;width:220px;"></div>
        <div class="wnq-skel" style="height:14px;width:65%;margin-top:10px;"></div>
        <div class="wnq-skel" style="height:14px;width:45%;margin-top:10px;"></div>
        <div class="wnq-skel" style="height:220px;width:100%;margin-top:14px;"></div>
      </div>
    `;
    return v;
  }

  function renderContent() {
    content.innerHTML = "";

    if (State.tab === "dashboard") content.appendChild(dashboardView());
    else if (State.tab === "subscription")
      content.appendChild(placeholderView("Subscription", "UI only. We’ll wire Stripe later."));
    else if (State.tab === "analytics")
      content.appendChild(placeholderView("Analytics", "UI only. We’ll wire GA4 + GSC later."));
    else if (State.tab === "requests")
      content.appendChild(placeholderView("Web Requests", "UI only. We’ll wire threads/messages later."));
    else if (State.tab === "settings")
      content.appendChild(placeholderView("Settings", "UI only. Settings stays minimal for v1."));
  }

  // ---------- Debug panel ----------
  function renderDebugButtons() {
    debugBtns.innerHTML = "";

    function btn(label, onClick) {
      const b = el("button", "wnq-btn", label);
      b.type = "button";
      b.addEventListener("click", onClick);
      return b;
    }

    debugBtns.appendChild(
      btn("Ping (REST)", async () => {
        debugOut.textContent = "Pinging…";
        const r = await api("/ping");
        debugOut.innerHTML = `<pre class="wnq-pre">${JSON.stringify(r.ok ? r.data : r, null, 2)}</pre>`;
      })
    );

    debugBtns.appendChild(
      btn("Load Client Doc", async () => {
        debugOut.textContent = "Loading…";
        const r = await api("/client");
        debugOut.innerHTML = `<pre class="wnq-pre">${JSON.stringify(r.ok ? r.data : r, null, 2)}</pre>`;
      })
    );

    if (isAdmin) {
      debugBtns.appendChild(
        btn("Bootstrap Client", async () => {
          debugOut.textContent = "Bootstrapping…";
          const r = await api("/clients/bootstrap", { method: "POST", body: { client_id: clientId } });
          debugOut.innerHTML = `<pre class="wnq-pre">${JSON.stringify(r.ok ? r.data : r, null, 2)}</pre>`;
        })
      );
    }
  }

  // ---------- boot ----------
  renderHeader();
  renderContent();
  renderDebugButtons();
  setHeaderStatus("loading…", "neutral");

  // Auto-hydrate
  const pingRes = await api("/ping");
  if (pingRes.ok && pingRes.http_ok) {
    State.ping = pingRes.data;
    setHeaderStatus("ping ok", "ok");
  } else {
    setHeaderStatus("ping failed", "err");
  }

  const clientRes = await api("/client");
  if (clientRes.ok && clientRes.http_ok) {
    State.client = clientRes.data;
    setHeaderStatus(clientRes.data?.exists ? "ready" : "client missing", clientRes.data?.exists ? "ok" : "warn");
  }

  renderContent();
})();
