<?php
/**
 * Analytics Admin - MULTI-CLIENT VERSION
 * 
 * Admin can switch between clients
 * Frontend portal users only see their own analytics
 */

namespace WNQ\Admin;

use WNQ\Models\AnalyticsConfig;

if (!defined('ABSPATH')) exit;

final class AnalyticsAdmin
{
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addSubmenu'], 20);
        add_action('admin_enqueue_scripts', [self::class, 'enqueueAssets'], 999);
        add_action('admin_post_wnq_save_analytics_settings', [self::class, 'handleSaveSettings']);
        add_action('admin_post_wnq_add_client', [self::class, 'handleAddClient']);
        add_action('admin_post_wnq_delete_client', [self::class, 'handleDeleteClient']);
        add_action('wp_ajax_wnq_get_analytics_data', [self::class, 'ajaxGetAnalyticsData']);
        
        // Frontend AJAX for portal users
        add_action('wp_ajax_wnq_get_client_analytics', [self::class, 'ajaxGetClientAnalytics']);
    }

    public static function addSubmenu(): void
    {
        $capability = current_user_can('wnq_manage_portal') ? 'wnq_manage_portal' : 'manage_options';
        add_submenu_page('wnq-portal', 'Analytics', 'Analytics', $capability, 'wnq-analytics', [self::class, 'render']);
    }

    public static function enqueueAssets($hook): void
    {
        if (!isset($_GET['page']) || $_GET['page'] !== 'wnq-analytics') return;
        wp_enqueue_script('jquery');
        wp_enqueue_style('wnq-analytics', plugin_dir_url(dirname(__FILE__)) . 'assets/admin/analytics-dashboard.css', [], time());
    }

    public static function render(): void
    {
        if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions.'));
        }

        $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : 'dashboard';
        
        switch ($view) {
            case 'settings':
                self::renderSettings();
                break;
            case 'clients':
                self::renderClientsManager();
                break;
            default:
                self::renderDashboard();
                break;
        }
    }

    private static function renderDashboard(): void
    {
        // Get all clients
        $all_clients = AnalyticsConfig::getAllClients();
        
        // Get current selected client (from GET param or first client)
        $current_client_id = isset($_GET['client']) ? sanitize_text_field($_GET['client']) : '';
        
        if (empty($current_client_id) && !empty($all_clients)) {
            $current_client_id = $all_clients[0]['client_id'];
        }
        
        $config = $current_client_id ? AnalyticsConfig::getClientConfig($current_client_id) : null;
        $credentials = AnalyticsConfig::getCredentials();

        ?>
        <div class="wrap">
            <h1>📊 Analytics Dashboard</h1>
            
            <?php if (empty($all_clients)): ?>
                <div class="notice notice-warning">
                    <p>No clients configured. <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=clients'); ?>">Add your first client →</a></p>
                </div>
                <?php return; ?>
            <?php endif; ?>

            <?php if (!$credentials): ?>
                <div class="notice notice-error">
                    <p>⚠️ Service account not configured. <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=settings'); ?>">Configure now →</a></p>
                </div>
                <?php return; ?>
            <?php endif; ?>

            <!-- Client Selector -->
            <div style="background: #fff; padding: 15px; margin: 20px 0; border: 1px solid #ddd; display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <strong>Select Client:</strong>
                    <select id="client-selector" style="padding: 5px 10px; font-size: 14px;">
                        <?php foreach ($all_clients as $client): ?>
                            <option value="<?php echo esc_attr($client['client_id']); ?>" <?php selected($client['client_id'], $current_client_id); ?>>
                                <?php echo esc_html($client['client_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=clients'); ?>" class="button">👥 Manage Clients</a>
                    <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=settings'); ?>" class="button">⚙️ Settings</a>
                </div>
            </div>

            <?php if ($config): ?>
                <!-- Current Client Info -->
                <div class="notice notice-info" style="padding: 15px;">
                    <p><strong>Current Client:</strong> <?php echo esc_html($config['client_name']); ?></p>
                    <ul style="list-style: disc; margin-left: 20px;">
                        <li>Website: <?php echo esc_html($config['website_url']); ?></li>
                        <li>GA4 Property: <code><?php echo esc_html($config['ga4_property_id']); ?></code></li>
                    </ul>
                </div>

                <!-- Date Range & Refresh -->
                <div style="background: #fff; padding: 15px; margin: 20px 0; border: 1px solid #ddd;">
                    <button type="button" id="wnq-refresh-data" class="button">🔄 Refresh Data</button>
                    <select id="wnq-date-range" class="button">
                        <option value="7">Last 7 Days</option>
                        <option value="30" selected>Last 30 Days</option>
                        <option value="90">Last 90 Days</option>
                    </select>
                </div>

                <!-- Loading & Content -->
                <div id="wnq-analytics-loading" style="padding: 40px; text-align: center; background: #fff; border: 1px solid #ddd;">
                    <p>⏳ Loading analytics data...</p>
                </div>

                <div id="wnq-analytics-content" style="display: none;"></div>
            <?php endif; ?>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
        
        <script>
        window.wnqAnalytics = {
            ajaxUrl: '<?php echo admin_url('admin-ajax.php'); ?>',
            nonce: '<?php echo wp_create_nonce('wnq_analytics_nonce'); ?>',
            clientId: '<?php echo esc_js($current_client_id); ?>'
        };

        (function($) {
            let currentChart = null;

            // Client selector change
            $('#client-selector').on('change', function() {
                const clientId = $(this).val();
                window.location.href = '<?php echo admin_url('admin.php?page=wnq-analytics'); ?>&client=' + clientId;
            });

            function loadData(days) {
                $('#wnq-analytics-loading').show();
                $('#wnq-analytics-content').hide();

                $.ajax({
                    url: wnqAnalytics.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'wnq_get_analytics_data',
                        nonce: wnqAnalytics.nonce,
                        client_id: wnqAnalytics.clientId,
                        date_range: days
                    },
                    success: function(resp) {
                        if (resp.success) {
                            renderData(resp.data);
                        } else {
                            showError(resp.data?.message || 'Failed to load data');
                        }
                    },
                    error: function(xhr) {
                        showError('Error loading data');
                    },
                    complete: function() {
                        $('#wnq-refresh-data').prop('disabled', false).text('🔄 Refresh Data');
                    }
                });
            }

            function renderData(data) {
                let html = '<div style="padding: 20px; background: #fff; border: 1px solid #ddd;">';
                
                // Overview Cards
                html += '<h2>📊 Overview</h2>';
                html += '<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin: 20px 0;">';
                html += '<div style="padding: 20px; background: #f0f0f0; border-radius: 4px;"><h3 style="margin: 0 0 10px 0; font-size: 14px; color: #666;">Visitors</h3><div style="font-size: 32px; font-weight: bold; color: #0073aa;">' + (data.overview.total_users || 0).toLocaleString() + '</div></div>';
                html += '<div style="padding: 20px; background: #f0f0f0; border-radius: 4px;"><h3 style="margin: 0 0 10px 0; font-size: 14px; color: #666;">Page Views</h3><div style="font-size: 32px; font-weight: bold; color: #0073aa;">' + (data.overview.page_views || 0).toLocaleString() + '</div></div>';
                html += '<div style="padding: 20px; background: #f0f0f0; border-radius: 4px;"><h3 style="margin: 0 0 10px 0; font-size: 14px; color: #666;">Sessions</h3><div style="font-size: 32px; font-weight: bold; color: #0073aa;">' + (data.overview.sessions || 0).toLocaleString() + '</div></div>';
                html += '<div style="padding: 20px; background: #f0f0f0; border-radius: 4px;"><h3 style="margin: 0 0 10px 0; font-size: 14px; color: #666;">Bounce Rate</h3><div style="font-size: 32px; font-weight: bold; color: #0073aa;">' + (data.overview.bounce_rate || 0).toFixed(1) + '%</div></div>';
                html += '</div>';
                
                // Visitors Chart
                if (data.visitors_over_time && data.visitors_over_time.length > 0) {
                    html += '<div style="margin-top: 30px;"><h2>Visitors Over Time</h2><canvas id="visitors-chart" style="max-height: 300px;"></canvas></div>';
                }
                
                // Traffic Sources Table
                if (data.traffic_sources && data.traffic_sources.length > 0) {
                    html += '<div style="margin-top: 30px;"><h2>Traffic Sources</h2><table class="wp-list-table widefat fixed striped">';
                    html += '<thead><tr><th>Channel</th><th>Sessions</th><th>Users</th><th>%</th></tr></thead><tbody>';
                    data.traffic_sources.forEach(s => {
                        html += '<tr><td>' + s.channel + '</td><td>' + s.sessions.toLocaleString() + '</td><td>' + s.users.toLocaleString() + '</td><td>' + s.percentage + '%</td></tr>';
                    });
                    html += '</tbody></table></div>';
                }
                
                // Top Pages Table
                if (data.top_pages && data.top_pages.length > 0) {
                    html += '<div style="margin-top: 30px;"><h2>Top Pages</h2><table class="wp-list-table widefat fixed striped">';
                    html += '<thead><tr><th>Page</th><th>Views</th><th>Bounce Rate</th></tr></thead><tbody>';
                    data.top_pages.forEach(p => {
                        html += '<tr><td><code>' + p.path + '</code></td><td>' + p.views.toLocaleString() + '</td><td>' + p.bounce_rate.toFixed(1) + '%</td></tr>';
                    });
                    html += '</tbody></table></div>';
                }
                
                html += '</div>';
                
                $('#wnq-analytics-content').html(html).show();
                $('#wnq-analytics-loading').hide();
                
                // Render chart
                if (data.visitors_over_time && data.visitors_over_time.length > 0 && typeof Chart !== 'undefined') {
                    const ctx = document.getElementById('visitors-chart');
                    if (ctx && currentChart) currentChart.destroy();
                    
                    currentChart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: data.visitors_over_time.map(d => d.date),
                            datasets: [{
                                label: 'Visitors',
                                data: data.visitors_over_time.map(d => d.users),
                                borderColor: '#0073aa',
                                backgroundColor: 'rgba(0, 115, 170, 0.1)',
                                tension: 0.4,
                                fill: true
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: true,
                            plugins: { legend: { display: false } },
                            scales: { y: { beginAtZero: true } }
                        }
                    });
                }
            }

            function showError(msg) {
                $('#wnq-analytics-content').html('<div class="notice notice-error" style="padding: 20px;"><p>' + msg + '</p></div>').show();
                $('#wnq-analytics-loading').hide();
            }

            $('#wnq-refresh-data').on('click', function() {
                $(this).prop('disabled', true).text('⏳ Loading...');
                loadData(parseInt($('#wnq-date-range').val()));
            });

            $('#wnq-date-range').on('change', function() {
                loadData(parseInt($(this).val()));
            });

            $(document).ready(function() {
                if (wnqAnalytics.clientId) {
                    loadData(30);
                }
            });
        })(jQuery);
        </script>
        <?php
    }

    private static function renderClientsManager(): void
    {
        $clients = AnalyticsConfig::getAllClients();
        ?>
        <div class="wrap">
            <h1>👥 Manage Clients</h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-analytics'); ?>" class="button">← Back to Dashboard</a>

            <?php if (isset($_GET['added'])): ?>
                <div class="notice notice-success"><p>✅ Client added successfully!</p></div>
            <?php endif; ?>
            
            <?php if (isset($_GET['deleted'])): ?>
                <div class="notice notice-success"><p>✅ Client deleted successfully!</p></div>
            <?php endif; ?>

            <!-- Add New Client Form -->
            <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ddd;">
                <h2>➕ Add New Client</h2>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                    <?php wp_nonce_field('wnq_add_client'); ?>
                    <input type="hidden" name="action" value="wnq_add_client">
                    
                    <table class="form-table">
                        <tr>
                            <th>Client ID</th>
                            <td>
                                <input type="text" name="client_id" class="regular-text" required placeholder="my-client-name">
                                <p class="description">Unique identifier (lowercase, no spaces)</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Client Name</th>
                            <td><input type="text" name="client_name" class="regular-text" required placeholder="My Client Name"></td>
                        </tr>
                        <tr>
                            <th>GA4 Property ID</th>
                            <td>
                                <input type="text" name="ga4_property_id" class="regular-text" required placeholder="properties/123456789">
                                <p class="description">Must start with "properties/"</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Website URL</th>
                            <td><input type="url" name="website_url" class="regular-text" required placeholder="https://example.com"></td>
                        </tr>
                    </table>
                    
                    <p class="submit"><button type="submit" class="button button-primary">Add Client</button></p>
                </form>
            </div>

            <!-- Existing Clients -->
            <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ddd;">
                <h2>📋 Existing Clients (<?php echo count($clients); ?>)</h2>
                
                <?php if (empty($clients)): ?>
                    <p>No clients yet. Add your first client above.</p>
                <?php else: ?>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Client Name</th>
                                <th>Website</th>
                                <th>GA4 Property</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($clients as $client): ?>
                                <tr>
                                    <td><strong><?php echo esc_html($client['client_name']); ?></strong></td>
                                    <td><?php echo esc_html($client['website_url']); ?></td>
                                    <td><code><?php echo esc_html($client['ga4_property_id']); ?></code></td>
                                    <td>
                                        <a href="<?php echo admin_url('admin.php?page=wnq-analytics&client=' . urlencode($client['client_id'])); ?>" class="button button-small">View Analytics</a>
                                        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                                            <?php wp_nonce_field('wnq_delete_client'); ?>
                                            <input type="hidden" name="action" value="wnq_delete_client">
                                            <input type="hidden" name="client_id" value="<?php echo esc_attr($client['client_id']); ?>">
                                            <button type="submit" class="button button-small" onclick="return confirm('Delete this client?');">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    private static function renderSettings(): void
    {
        $credentials = AnalyticsConfig::getCredentials();
        ?>
        <div class="wrap">
            <h1>⚙️ Global Settings</h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-analytics'); ?>" class="button">← Back to Dashboard</a>

            <?php if (isset($_GET['saved'])): ?>
                <div class="notice notice-success"><p>✅ Settings saved!</p></div>
            <?php endif; ?>

            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" enctype="multipart/form-data" style="margin-top: 20px;">
                <?php wp_nonce_field('wnq_save_analytics_settings'); ?>
                <input type="hidden" name="action" value="wnq_save_analytics_settings">
                
                <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ddd;">
                    <h2>🔐 Service Account (Shared for All Clients)</h2>
                    <p>Upload your Google Cloud service account JSON file. This will be used for ALL clients.</p>
                    
                    <table class="form-table">
                        <tr>
                            <th>Service Account JSON</th>
                            <td>
                                <input type="file" name="credentials_file" accept=".json">
                                <?php if ($credentials): ?>
                                    <p class="description">✅ Current: <?php echo esc_html($credentials['email']); ?></p>
                                <?php else: ?>
                                    <p class="description">⚠️ No credentials uploaded</p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit"><button type="submit" class="button button-primary">💾 Save Settings</button></p>
                </div>
            </form>

            <div style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ddd;">
                <h2>📋 Setup Instructions</h2>
                <ol style="line-height: 2;">
                    <li>Create a service account in Google Cloud Console</li>
                    <li>Download the JSON file and upload it above</li>
                    <li>For EACH client, add the service account to their GA4 property:
                        <ul style="margin-left: 30px;">
                            <li>Go to GA4 → Admin → Property Access Management</li>
                            <li>Add: <code><?php echo esc_html($credentials['email'] ?? 'Upload credentials first'); ?></code></li>
                            <li>Role: Viewer</li>
                        </ul>
                    </li>
                    <li>Add clients in the <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=clients'); ?>">Clients Manager</a></li>
                </ol>
            </div>
        </div>
        <?php
    }

    public static function ajaxGetAnalyticsData(): void
    {
        try {
            check_ajax_referer('wnq_analytics_nonce', 'nonce');

            if (!current_user_can('manage_options') && !current_user_can('wnq_manage_portal')) {
                wp_send_json_error(['message' => 'Permission denied']);
                return;
            }

            $client_id = sanitize_text_field($_POST['client_id'] ?? '');
            $date_range = intval($_POST['date_range'] ?? 30);

            $config = AnalyticsConfig::getClientConfig($client_id);
            $credentials = AnalyticsConfig::getCredentials();

            if (!$config || !$credentials) {
                wp_send_json_error(['message' => 'Not configured']);
                return;
            }

            $data = self::fetchAnalyticsData($credentials['credentials'], $config['ga4_property_id'], $date_range);
            wp_send_json_success($data);

        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }

    /**
     * AJAX for frontend portal - clients only see their own data
     */
    public static function ajaxGetClientAnalytics(): void
    {
        try {
            check_ajax_referer('wnq_client_analytics_nonce', 'nonce');

            // Get current user's client ID
            $user_id = get_current_user_id();
            $client_id = get_user_meta($user_id, 'wnq_client_id', true);

            if (empty($client_id)) {
                wp_send_json_error(['message' => 'No client assigned to your account']);
                return;
            }

            $date_range = intval($_POST['date_range'] ?? 30);

            $config = AnalyticsConfig::getClientConfig($client_id);
            $credentials = AnalyticsConfig::getCredentials();

            if (!$config || !$credentials) {
                wp_send_json_error(['message' => 'Analytics not configured']);
                return;
            }

            $data = self::fetchAnalyticsData($credentials['credentials'], $config['ga4_property_id'], $date_range);
            wp_send_json_success($data);

        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }

    private static function fetchAnalyticsData(array $credentials, string $property_id, int $date_range): array
    {
        $token = self::getGoogleAccessToken($credentials);
        $end_date = date('Y-m-d');
        $start_date = date('Y-m-d', strtotime("-{$date_range} days"));

        $data = [];

        try {
            $data['overview'] = self::fetchOverviewStats($token, $property_id, $start_date, $end_date);
        } catch (\Exception $e) {
            $data['overview'] = ['total_users' => 0, 'page_views' => 0, 'sessions' => 0, 'bounce_rate' => 0];
        }

        try {
            $data['visitors_over_time'] = self::fetchVisitorsOverTime($token, $property_id, $start_date, $end_date);
        } catch (\Exception $e) {
            $data['visitors_over_time'] = [];
        }

        try {
            $data['traffic_sources'] = self::fetchTrafficSources($token, $property_id, $start_date, $end_date);
        } catch (\Exception $e) {
            $data['traffic_sources'] = [];
        }

        try {
            $data['top_pages'] = self::fetchTopPages($token, $property_id, $start_date, $end_date);
        } catch (\Exception $e) {
            $data['top_pages'] = [];
        }

        return $data;
    }

    private static function getGoogleAccessToken(array $credentials): string
    {
        $cached = get_transient('wnq_ga_access_token');
        if ($cached) return $cached;

        $now = time();
        $header = ['alg' => 'RS256', 'typ' => 'JWT'];
        $claim = [
            'iss' => $credentials['client_email'],
            'scope' => 'https://www.googleapis.com/auth/analytics.readonly',
            'aud' => 'https://oauth2.googleapis.com/token',
            'exp' => $now + 3600,
            'iat' => $now
        ];

        $segments = [
            self::base64UrlEncode(wp_json_encode($header)),
            self::base64UrlEncode(wp_json_encode($claim))
        ];
        $signing_input = implode('.', $segments);

        $signature = '';
        if (!openssl_sign($signing_input, $signature, $credentials['private_key'], 'SHA256')) {
            throw new \Exception('JWT signing failed');
        }

        $segments[] = self::base64UrlEncode($signature);
        $jwt = implode('.', $segments);

        $response = wp_remote_post('https://oauth2.googleapis.com/token', [
            'body' => [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $jwt
            ],
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            throw new \Exception('Token request failed');
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!isset($body['access_token'])) {
            throw new \Exception('Token failed');
        }

        $token = $body['access_token'];
        set_transient('wnq_ga_access_token', $token, 3000);
        return $token;
    }

    private static function fetchOverviewStats(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'metrics' => [
                ['name' => 'totalUsers'],
                ['name' => 'screenPageViews'],
                ['name' => 'sessions'],
                ['name' => 'bounceRate']
            ]
        ]);
        
        $m = $data['rows'][0]['metricValues'] ?? [];
        return [
            'total_users' => isset($m[0]) ? intval($m[0]['value']) : 0,
            'page_views' => isset($m[1]) ? intval($m[1]['value']) : 0,
            'sessions' => isset($m[2]) ? intval($m[2]['value']) : 0,
            'bounce_rate' => isset($m[3]) ? floatval($m[3]['value']) * 100 : 0
        ];
    }

    private static function fetchVisitorsOverTime(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'date']],
            'metrics' => [['name' => 'totalUsers'], ['name' => 'sessions']],
            'orderBys' => [['dimension' => ['dimensionName' => 'date']]]
        ]);
        
        $trends = [];
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $date = $row['dimensionValues'][0]['value'];
                $trends[] = [
                    'date' => substr($date, 0, 4) . '-' . substr($date, 4, 2) . '-' . substr($date, 6, 2),
                    'users' => intval($row['metricValues'][0]['value']),
                    'sessions' => intval($row['metricValues'][1]['value'])
                ];
            }
        }
        return $trends;
    }

    private static function fetchTrafficSources(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'sessionDefaultChannelGroup']],
            'metrics' => [['name' => 'sessions'], ['name' => 'totalUsers']],
            'orderBys' => [['metric' => ['metricName' => 'sessions'], 'desc' => true]],
            'limit' => 10
        ]);
        
        $sources = [];
        $total = 0;
        
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $total += intval($row['metricValues'][0]['value']);
            }
            foreach ($data['rows'] as $row) {
                $sessions = intval($row['metricValues'][0]['value']);
                $sources[] = [
                    'channel' => $row['dimensionValues'][0]['value'],
                    'sessions' => $sessions,
                    'users' => intval($row['metricValues'][1]['value']),
                    'percentage' => $total > 0 ? round(($sessions / $total) * 100, 1) : 0
                ];
            }
        }
        return $sources;
    }

    private static function fetchTopPages(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'pagePath'], ['name' => 'pageTitle']],
            'metrics' => [['name' => 'screenPageViews'], ['name' => 'bounceRate']],
            'orderBys' => [['metric' => ['metricName' => 'screenPageViews'], 'desc' => true]],
            'limit' => 10
        ]);
        
        $pages = [];
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $pages[] = [
                    'path' => $row['dimensionValues'][0]['value'],
                    'title' => $row['dimensionValues'][1]['value'] ?? 'Untitled',
                    'views' => intval($row['metricValues'][0]['value']),
                    'bounce_rate' => floatval($row['metricValues'][1]['value'] ?? 0) * 100
                ];
            }
        }
        return $pages;
    }

    private static function makeGARequest(string $token, string $property_id, array $body): array
    {
        $url = "https://analyticsdata.googleapis.com/v1beta/{$property_id}:runReport";
        
        $response = wp_remote_post($url, [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
            'body' => wp_json_encode($body),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            throw new \Exception('GA API failed');
        }

        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);

        if ($code !== 200) {
            throw new \Exception('GA API error: ' . ($data['error']['message'] ?? 'Unknown'));
        }

        return $data;
    }

    private static function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    public static function handleSaveSettings(): void
    {
        check_admin_referer('wnq_save_analytics_settings');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        if (isset($_FILES['credentials_file']) && $_FILES['credentials_file']['size'] > 0) {
            $file = $_FILES['credentials_file'];
            $json = file_get_contents($file['tmp_name']);
            $creds = json_decode($json, true);

            if ($creds && isset($creds['client_email']) && isset($creds['private_key'])) {
                AnalyticsConfig::saveCredentials($creds);
            }
        }

        delete_transient('wnq_ga_access_token');
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&saved=1'));
        exit;
    }

    public static function handleAddClient(): void
    {
        check_admin_referer('wnq_add_client');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $config = [
            'client_id' => sanitize_text_field($_POST['client_id']),
            'client_name' => sanitize_text_field($_POST['client_name']),
            'ga4_property_id' => sanitize_text_field($_POST['ga4_property_id']),
            'website_url' => esc_url_raw($_POST['website_url']),
            'timezone' => 'America/New_York'
        ];

        AnalyticsConfig::saveClientConfig($config);
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=clients&added=1'));
        exit;
    }

    public static function handleDeleteClient(): void
    {
        check_admin_referer('wnq_delete_client');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $client_id = sanitize_text_field($_POST['client_id']);
        AnalyticsConfig::deleteClient($client_id);
        
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=clients&deleted=1'));
        exit;
    }
}