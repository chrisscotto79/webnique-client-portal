<?php
/**
 * Debug Script for WebNique Portal Shortcode Issue
 * 
 * Upload this to: /wp-content/plugins/webnique-client-portal/debug-shortcode.php
 * Access via: https://yoursite.com/wp-content/plugins/webnique-client-portal/debug-shortcode.php
 */

require_once('../../../wp-load.php');

if (!current_user_can('manage_options')) {
    wp_die('Access denied');
}

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Shortcode Debug</title>
    <style>
        body { font-family: sans-serif; max-width: 900px; margin: 20px auto; padding: 20px; }
        .pass { color: #16a34a; font-weight: bold; }
        .fail { color: #dc2626; font-weight: bold; }
        .info { color: #2563eb; }
        pre { background: #f3f4f6; padding: 15px; border-radius: 5px; overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        table td { padding: 8px; border-bottom: 1px solid #e5e7eb; }
        table td:first-child { font-weight: bold; width: 300px; }
        h1 { color: #0d539e; }
        h2 { color: #334155; border-bottom: 2px solid #e5e7eb; padding-bottom: 8px; }
    </style>
</head>
<body>
    <h1>🔍 WebNique Portal - Shortcode Debug Report</h1>
    
    <?php
    echo '<h2>1. Plugin Constants</h2>';
    echo '<table>';
    
    $constants = ['WNQ_PORTAL_VERSION', 'WNQ_PORTAL_PATH', 'WNQ_PORTAL_URL'];
    foreach ($constants as $const) {
        echo '<tr><td>' . $const . '</td><td>';
        if (defined($const)) {
            echo '<span class="pass">✓ DEFINED</span> = ' . constant($const);
        } else {
            echo '<span class="fail">✗ NOT DEFINED</span>';
        }
        echo '</td></tr>';
    }
    echo '</table>';
    
    echo '<h2>2. Core Classes</h2>';
    echo '<table>';
    
    $classes = [
        'WNQ\\Core\\Plugin',
        'WNQ\\PublicSite\\Shortcode',
        'WNQ\\Admin\\AdminMenu',
        'WNQ\\Admin\\AdminSettings',
    ];
    
    foreach ($classes as $class) {
        echo '<tr><td>' . $class . '</td><td>';
        if (class_exists($class)) {
            echo '<span class="pass">✓ EXISTS</span>';
            
            // Show methods if it's the Shortcode class
            if ($class === 'WNQ\\PublicSite\\Shortcode') {
                $methods = get_class_methods($class);
                if (in_array('register', $methods) && in_array('render', $methods)) {
                    echo ' <span class="info">(has register() and render())</span>';
                } else {
                    echo ' <span class="fail">(missing methods!)</span>';
                }
            }
        } else {
            echo '<span class="fail">✗ NOT FOUND</span>';
        }
        echo '</td></tr>';
    }
    echo '</table>';
    
    echo '<h2>3. Shortcode Registration</h2>';
    global $shortcode_tags;
    
    echo '<table>';
    echo '<tr><td>Shortcode [wnq_portal] registered?</td><td>';
    if (isset($shortcode_tags['wnq_portal'])) {
        echo '<span class="pass">✓ YES</span>';
        echo '<br><span class="info">Callback: ';
        if (is_array($shortcode_tags['wnq_portal'])) {
            echo get_class($shortcode_tags['wnq_portal'][0]) . '::' . $shortcode_tags['wnq_portal'][1];
        } else {
            echo $shortcode_tags['wnq_portal'];
        }
        echo '</span>';
    } else {
        echo '<span class="fail">✗ NO</span> - This is the problem!';
    }
    echo '</td></tr>';
    
    echo '<tr><td>Total shortcodes registered</td><td>' . count($shortcode_tags) . '</td></tr>';
    echo '</table>';
    
    if (!isset($shortcode_tags['wnq_portal'])) {
        echo '<div style="background: #fee2e2; padding: 15px; border-radius: 5px; border: 2px solid #dc2626; margin: 20px 0;">';
        echo '<h3 style="margin-top: 0; color: #991b1b;">🚨 PROBLEM FOUND</h3>';
        echo '<p>The shortcode [wnq_portal] is NOT registered. This means:</p>';
        echo '<ul>';
        echo '<li>The Shortcode::register() method was never called</li>';
        echo '<li>Plugin::init() might not be running properly</li>';
        echo '<li>There might be a PHP error preventing initialization</li>';
        echo '</ul>';
        echo '</div>';
    }
    
    echo '<h2>4. File Structure Check</h2>';
    $plugin_path = WP_PLUGIN_DIR . '/webnique-client-portal/';
    
    $files_to_check = [
        'webnique-client-portal.php',
        'includes/Core/Plugin.php',
        'public/Shortcode.php',
        'admin/AdminMenu.php',
        'admin/AdminSettings.php',
        'includes/Views/portal-shell.php',
    ];
    
    echo '<table>';
    foreach ($files_to_check as $file) {
        echo '<tr><td>' . $file . '</td><td>';
        if (file_exists($plugin_path . $file)) {
            echo '<span class="pass">✓ EXISTS</span>';
            
            // Check file size
            $size = filesize($plugin_path . $file);
            if ($size < 100) {
                echo ' <span class="fail">(file is very small: ' . $size . ' bytes - might be empty!)</span>';
            }
        } else {
            echo '<span class="fail">✗ MISSING</span>';
        }
        echo '</td></tr>';
    }
    echo '</table>';
    
    echo '<h2>5. WordPress Hooks</h2>';
    global $wp_filter;
    
    echo '<table>';
    echo '<tr><td>plugins_loaded hook</td><td>';
    if (isset($wp_filter['plugins_loaded'])) {
        $count = 0;
        foreach ($wp_filter['plugins_loaded']->callbacks as $priority => $callbacks) {
            $count += count($callbacks);
        }
        echo '<span class="info">' . $count . ' callbacks registered</span>';
    } else {
        echo '<span class="fail">No callbacks</span>';
    }
    echo '</td></tr>';
    
    echo '<tr><td>init hook</td><td>';
    if (isset($wp_filter['init'])) {
        $count = 0;
        foreach ($wp_filter['init']->callbacks as $priority => $callbacks) {
            $count += count($callbacks);
        }
        echo '<span class="info">' . $count . ' callbacks registered</span>';
    } else {
        echo '<span class="fail">No callbacks</span>';
    }
    echo '</td></tr>';
    echo '</table>';
    
    echo '<h2>6. Check Plugin.php Code</h2>';
    $plugin_php = $plugin_path . 'includes/Core/Plugin.php';
    if (file_exists($plugin_php)) {
        $content = file_get_contents($plugin_php);
        
        echo '<table>';
        echo '<tr><td>Contains "Shortcode::register()"?</td><td>';
        if (strpos($content, 'Shortcode::register') !== false) {
            echo '<span class="pass">✓ YES</span>';
        } else {
            echo '<span class="fail">✗ NO - Missing shortcode registration!</span>';
        }
        echo '</td></tr>';
        
        echo '<tr><td>Shortcode.php is included?</td><td>';
        if (strpos($content, 'public/Shortcode.php') !== false || strpos($content, 'Shortcode.php') !== false) {
            echo '<span class="pass">✓ YES</span>';
        } else {
            echo '<span class="fail">✗ NO - Shortcode.php not being loaded!</span>';
        }
        echo '</td></tr>';
        echo '</table>';
    }
    
    echo '<h2>7. Test Shortcode Directly</h2>';
    echo '<p>Attempting to render [wnq_portal] shortcode:</p>';
    echo '<div style="background: white; border: 2px solid #0d539e; padding: 15px; border-radius: 5px;">';
    
    if (isset($shortcode_tags['wnq_portal'])) {
        echo do_shortcode('[wnq_portal]');
    } else {
        echo '<span class="fail">Cannot render - shortcode not registered</span>';
    }
    
    echo '</div>';
    
    echo '<h2>8. Check for PHP Errors</h2>';
    $log_file = WP_CONTENT_DIR . '/debug.log';
    
    if (file_exists($log_file)) {
        echo '<p>Last 20 lines of debug.log:</p>';
        $lines = file($log_file);
        $recent_lines = array_slice($lines, -20);
        echo '<pre>' . esc_html(implode('', $recent_lines)) . '</pre>';
    } else {
        echo '<p><span class="info">debug.log not found. Enable WP_DEBUG in wp-config.php:</span></p>';
        echo '<pre>define(\'WP_DEBUG\', true);
define(\'WP_DEBUG_LOG\', true);
define(\'WP_DEBUG_DISPLAY\', false);</pre>';
    }
    
    echo '<h2>9. Recommendations</h2>';
    echo '<div style="background: #dbeafe; padding: 15px; border-radius: 5px; border-left: 4px solid #2563eb;">';
    
    if (!isset($shortcode_tags['wnq_portal'])) {
        echo '<h3>The shortcode is not registered. Here\'s what to check:</h3>';
        echo '<ol>';
        echo '<li><strong>Check Plugin.php:</strong> Make sure it calls <code>Shortcode::register()</code> on the init hook</li>';
        echo '<li><strong>Check Shortcode.php:</strong> Make sure the file exists in <code>public/Shortcode.php</code></li>';
        echo '<li><strong>Check includes:</strong> Make sure Plugin.php is loading Shortcode.php</li>';
        echo '<li><strong>Check for errors:</strong> Look at debug.log for PHP errors</li>';
        echo '<li><strong>Try deactivating and reactivating</strong> the plugin</li>';
        echo '</ol>';
        
        echo '<h3>Quick Fix:</h3>';
        echo '<p>Your Plugin.php should have this line in the init() method:</p>';
        echo '<pre>add_action(\'init\', [\\WNQ\\PublicSite\\Shortcode::class, \'register\']);</pre>';
    } else {
        echo '<h3>✅ Shortcode is registered correctly!</h3>';
        echo '<p>If it\'s still showing as plain text on your page, try:</p>';
        echo '<ol>';
        echo '<li>Clear all caches (browser, WordPress, server)</li>';
        echo '<li>Make sure you\'re using <code>[wnq_portal]</code> and not <code>[wnq_portal]</code> (check for special characters)</li>';
        echo '<li>Check if the user viewing the page is logged in</li>';
        echo '<li>Check browser console (F12) for JavaScript errors</li>';
        echo '</ol>';
    }
    
    echo '</div>';
    ?>
    
    <p style="text-align: center; color: #64748b; margin-top: 40px;">
        Generated: <?php echo date('Y-m-d H:i:s'); ?>
    </p>
</body>
</html>