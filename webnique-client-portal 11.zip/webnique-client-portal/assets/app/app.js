(async function () {
  const root = document.getElementById("wnq-portal-root");
  if (!root) return;

  const clientId = root.getAttribute("data-client-id") || "";
  const mode = root.getAttribute("data-mode") || "";

  const restBase = window.WNQ_PORTAL?.restUrl;
  const nonce = window.WNQ_PORTAL?.nonce;
  const isAdmin = !!window.WNQ_PORTAL?.isAdmin;

  const el = document.createElement("div");
  el.style.padding = "12px";
  el.style.marginTop = "12px";
  el.style.border = "1px solid #e5e7eb";
  el.style.borderRadius = "10px";
  el.style.fontFamily = "system-ui";
  el.innerHTML = `
    <strong>WNQ App.js Loaded ✅</strong><br/>
    Client ID: <code>${clientId || "(none)"}</code><br/>
    Mode: <code>${mode || "(none)"}</code><br/>
    Ping: <code id="wnq-ping-status">checking...</code>
    <div id="wnq-admin-area" style="margin-top:12px;"></div>
    <div id="wnq-result" style="margin-top:10px;"></div>
  `;
  root.appendChild(el);

  // Ping
  try {
    if (!restBase || !nonce) {
      document.getElementById("wnq-ping-status").textContent = "missing restUrl/nonce";
      return;
    }

    const res = await fetch(`${restBase}/ping`, {
      method: "GET",
      credentials: "same-origin",
      headers: { "X-WP-Nonce": nonce },
    });
    const json = await res.json();

    document.getElementById("wnq-ping-status").textContent = json?.ok ? "ok" : "not ok";

    const proof = document.createElement("div");
    proof.style.marginTop = "8px";
    proof.innerHTML = `REST user_id: <code>${json?.wp?.user_id ?? "(none)"}</code>, client_id: <code>${json?.wp?.client_id ?? "(null)"}</code>`;
    root.appendChild(proof);
  } catch (e) {
    console.error(e);
    const node = document.getElementById("wnq-ping-status");
    if (node) node.textContent = "error (see console)";
  }

  // Admin-only: Bootstrap Firestore client doc
  if (isAdmin) {
    const adminArea = document.getElementById("wnq-admin-area");
    const btn = document.createElement("button");
    btn.type = "button";
    btn.textContent = "Bootstrap Firestore Client";
    btn.style.padding = "10px 12px";
    btn.style.borderRadius = "10px";
    btn.style.border = "1px solid #d1d5db";
    btn.style.background = "white";
    btn.style.cursor = "pointer";

    btn.addEventListener("click", async () => {
      const out = document.getElementById("wnq-result");
      out.innerHTML = "Bootstrapping...";

      try {
        const res = await fetch(`${restBase}/clients/bootstrap`, {
          method: "POST",
          credentials: "same-origin",
          headers: {
            "X-WP-Nonce": nonce,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ client_id: clientId }),
        });

        const json = await res.json();
        console.log("[WNQ] bootstrap response", json);

        out.innerHTML = `<pre style="white-space:pre-wrap;background:rgba(0,0,0,0.04);padding:10px;border-radius:10px;">${JSON.stringify(json, null, 2)}</pre>`;
      } catch (e) {
        console.error(e);
        out.textContent = "Bootstrap error (see console)";
      }
    });

    adminArea.appendChild(btn);
  }
})();
