<?php
/**
 * Plugin Name: WebNique Client Portal
 * Description: Complete client management with portal, analytics, billing, tasks, SEO tracking, and messaging
 * Version: 2.0.0
 * Author: WebNique
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Text Domain: webnique-portal
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WNQ_PORTAL_VERSION', '2.0.0');
define('WNQ_PORTAL_PATH', plugin_dir_path(__FILE__));
define('WNQ_PORTAL_URL', plugin_dir_url(__FILE__));

$plugin_file = WNQ_PORTAL_PATH . 'includes/Core/Plugin.php';

if (!file_exists($plugin_file)) {
    add_action('admin_notices', function() use ($plugin_file) {
        echo '<div class="notice notice-error"><p><strong>WebNique Portal Error:</strong> Core Plugin file not found at: ' . esc_html($plugin_file) . '</p></div>';
    });
    return;
}

require_once $plugin_file;

if (!class_exists('WNQ\\Core\\Plugin')) {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-error"><p><strong>WebNique Portal Error:</strong> Plugin class could not be loaded</p></div>';
    });
    return;
}

// ACTIVATION
register_activation_hook(__FILE__, function() {
    if (class_exists('WNQ\\Core\\Plugin')) {
        WNQ\Core\Plugin::activate();
    }
    
    // Create clients table
    $client_model = WNQ_PORTAL_PATH . 'includes/Models/Client.php';
    if (file_exists($client_model)) {
        require_once $client_model;
        if (class_exists('WNQ\\Models\\Client')) {
            \WNQ\Models\Client::createTable();
        }
    }
    
    // Create tasks table
    $task_model = WNQ_PORTAL_PATH . 'includes/Models/Task.php';
    if (file_exists($task_model)) {
        require_once $task_model;
        if (class_exists('WNQ\\Models\\Task')) {
            \WNQ\Models\Task::createTable();
        }
    }
    
    // Create analytics tables
    $analytics_config = WNQ_PORTAL_PATH . 'includes/Models/AnalyticsConfig.php';
    if (file_exists($analytics_config)) {
        require_once $analytics_config;
        if (class_exists('WNQ\\Models\\AnalyticsConfig')) {
            \WNQ\Models\AnalyticsConfig::createTable();
        }
    }
    
    // Create SEO tables
    $seo_model = WNQ_PORTAL_PATH . 'includes/Models/SEO.php';
    if (file_exists($seo_model)) {
        require_once $seo_model;
        if (class_exists('WNQ\\Models\\SEO')) {
            \WNQ\Models\SEO::createTables();
        }
    }
    
    // Create portal user role
    if (!get_role('portal_user')) {
        add_role('portal_user', 'Portal User', [
            'read' => true,
            'wnq_access_portal' => true,
        ]);
    }
    
    // Add capability to admin role
    $admin = get_role('administrator');
    if ($admin) {
        $admin->add_cap('wnq_manage_portal');
    }
});

// DEACTIVATION
register_deactivation_hook(__FILE__, function() {
    if (class_exists('WNQ\\Core\\Plugin')) {
        WNQ\Core\Plugin::deactivate();
    }
});

// INITIALIZE PLUGIN
add_action('plugins_loaded', function() {
    if (class_exists('WNQ\\Core\\Plugin')) {
        WNQ\Core\Plugin::init();
    }
});

// CLIENT ACTION HANDLERS
add_action('admin_post_wnq_add_client', function() {
    $clients_admin = WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
    if (file_exists($clients_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
        require_once $clients_admin;
        \WNQ\Admin\ClientsAdmin::handleAddClient();
    }
});

add_action('admin_post_wnq_update_client', function() {
    $clients_admin = WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
    if (file_exists($clients_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
        require_once $clients_admin;
        \WNQ\Admin\ClientsAdmin::handleUpdateClient();
    }
});

add_action('admin_post_wnq_delete_client', function() {
    $clients_admin = WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
    if (file_exists($clients_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
        require_once $clients_admin;
        \WNQ\Admin\ClientsAdmin::handleDeleteClient();
    }
});

add_action('admin_post_wnq_delete_client_from_clients', function() {
    $clients_admin = WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
    if (file_exists($clients_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
        require_once $clients_admin;
        \WNQ\Admin\ClientsAdmin::handleDeleteClient();
    }
});

add_action('admin_post_wnq_mark_paid', function() {
    $clients_admin = WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
    if (file_exists($clients_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
        require_once $clients_admin;
        \WNQ\Admin\ClientsAdmin::handleMarkPaid();
    }
});

// TASK ACTION HANDLERS
add_action('admin_post_wnq_save_task', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::handleSaveTask();
    }
});

add_action('admin_post_wnq_update_task', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::handleUpdateTask();
    }
});

add_action('admin_post_wnq_delete_task', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::handleDeleteTask();
    }
});

add_action('admin_post_wnq_archive_task', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::handleArchiveTask();
    }
});

add_action('admin_post_wnq_restore_task', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::handleRestoreTask();
    }
});

add_action('admin_post_wnq_reorder_tasks', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::handleReorderTasks();
    }
});

// ANALYTICS ACTION HANDLERS
add_action('admin_post_wnq_save_analytics_config', function() {
    $analytics_admin = WNQ_PORTAL_PATH . 'admin/AnalyticsAdmin.php';
    if (file_exists($analytics_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/AnalyticsConfig.php';
        require_once $analytics_admin;
        \WNQ\Admin\AnalyticsAdmin::handleSaveConfig();
    }
});

add_action('admin_post_wnq_add_analytics_client', function() {
    $analytics_admin = WNQ_PORTAL_PATH . 'admin/AnalyticsAdmin.php';
    if (file_exists($analytics_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/AnalyticsConfig.php';
        require_once $analytics_admin;
        \WNQ\Admin\AnalyticsAdmin::handleAddClient();
    }
});

add_action('admin_post_wnq_delete_analytics_client', function() {
    $analytics_admin = WNQ_PORTAL_PATH . 'admin/AnalyticsAdmin.php';
    if (file_exists($analytics_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/AnalyticsConfig.php';
        require_once $analytics_admin;
        \WNQ\Admin\AnalyticsAdmin::handleDeleteClient();
    }
});

// SEO ACTION HANDLERS
add_action('admin_post_wnq_init_seo_month', function() {
    $seo_admin = WNQ_PORTAL_PATH . 'admin/SEOAdmin.php';
    if (file_exists($seo_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/SEO.php';
        require_once $seo_admin;
        \WNQ\Admin\SEOAdmin::handleInitMonth();
    }
});

add_action('admin_post_wnq_complete_seo_task', function() {
    $seo_admin = WNQ_PORTAL_PATH . 'admin/SEOAdmin.php';
    if (file_exists($seo_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/SEO.php';
        require_once $seo_admin;
        \WNQ\Admin\SEOAdmin::handleCompleteTask();
    }
});

add_action('admin_post_wnq_update_seo_task', function() {
    $seo_admin = WNQ_PORTAL_PATH . 'admin/SEOAdmin.php';
    if (file_exists($seo_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/SEO.php';
        require_once $seo_admin;
        \WNQ\Admin\SEOAdmin::handleUpdateTask();
    }
});

add_action('admin_post_wnq_save_seo_report', function() {
    $seo_admin = WNQ_PORTAL_PATH . 'admin/SEOAdmin.php';
    if (file_exists($seo_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/SEO.php';
        require_once $seo_admin;
        \WNQ\Admin\SEOAdmin::handleSaveReport();
    }
});

add_action('admin_post_wnq_add_seo_task', function() {
    $seo_admin = WNQ_PORTAL_PATH . 'admin/SEOAdmin.php';
    if (file_exists($seo_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/SEO.php';
        require_once $seo_admin;
        \WNQ\Admin\SEOAdmin::handleAddTask();
    }
});

add_action('admin_post_wnq_delete_seo_task', function() {
    $seo_admin = WNQ_PORTAL_PATH . 'admin/SEOAdmin.php';
    if (file_exists($seo_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/SEO.php';
        require_once $seo_admin;
        \WNQ\Admin\SEOAdmin::handleDeleteTask();
    }
});

// MESSAGE AJAX HANDLER
add_action('wp_ajax_wnq_send_message', function() {
    check_ajax_referer('wnq_ajax', 'nonce');
    
    $message_model = WNQ_PORTAL_PATH . 'includes/Models/Message.php';
    if (file_exists($message_model)) {
        require_once $message_model;
        
        $client_id = sanitize_text_field($_POST['client_id'] ?? '');
        $message = sanitize_textarea_field($_POST['message'] ?? '');
        
        if (empty($client_id) || empty($message)) {
            wp_send_json_error(['message' => 'Missing required fields']);
        }
        
        $sender_id = get_current_user_id();
        $sender_name = wp_get_current_user()->display_name;
        
        $result = \WNQ\Models\Message::sendMessage([
            'client_id' => $client_id,
            'sender_id' => $sender_id,
            'sender_name' => $sender_name,
            'message' => $message
        ]);
        
        if ($result) {
            wp_send_json_success(['message' => 'Message sent']);
        } else {
            wp_send_json_error(['message' => 'Failed to send message']);
        }
    }
});

// SEO CLIENT DASHBOARD RENDER
function wnq_render_seo_page() {
    if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    
    $seo_model = WNQ_PORTAL_PATH . 'includes/Models/SEO.php';
    if (!file_exists($seo_model)) {
        echo '<div class="wrap"><div class="notice notice-error"><p><strong>Error:</strong> SEO model not found.</p></div></div>';
        return;
    }
    
    require_once $seo_model;
    require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
    
    $seo_admin = WNQ_PORTAL_PATH . 'admin/SEOAdmin.php';
    if (!file_exists($seo_admin)) {
        echo '<div class="wrap"><div class="notice notice-error"><p><strong>Error:</strong> SEOAdmin not found.</p></div></div>';
        return;
    }
    
    require_once $seo_admin;
    \WNQ\Admin\SEOAdmin::render();
}