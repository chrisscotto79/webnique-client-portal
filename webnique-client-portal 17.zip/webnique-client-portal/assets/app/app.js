(async function () {
  const root = document.getElementById("wnq-portal-root");
  if (!root) return;

  const PRIMARY = "#0d539e";

  const clientId = root.getAttribute("data-client-id") || "";
  const mode = root.getAttribute("data-mode") || "";

  const restBase = window.WNQ_PORTAL?.restUrl; // e.g. https://site.com/wp-json/wnq/v1
  const nonce = window.WNQ_PORTAL?.nonce;
  const isAdmin = !!window.WNQ_PORTAL?.isAdmin;

  // ---------- helpers ----------
  const el = (tag, props = {}, children = []) => {
    const node = document.createElement(tag);
    Object.entries(props).forEach(([k, v]) => {
      if (k === "class") node.className = v;
      else if (k === "html") node.innerHTML = v;
      else if (k === "style") Object.assign(node.style, v);
      else node.setAttribute(k, v);
    });
    children.forEach((c) => node.appendChild(c));
    return node;
  };

  const pill = (text, tone = "neutral") => {
    const bg =
      tone === "good" ? "rgba(16,185,129,0.12)" :
      tone === "warn" ? "rgba(245,158,11,0.14)" :
      tone === "bad"  ? "rgba(239,68,68,0.12)" :
      "rgba(2,6,23,0.06)";
    const border =
      tone === "good" ? "rgba(16,185,129,0.28)" :
      tone === "warn" ? "rgba(245,158,11,0.28)" :
      tone === "bad"  ? "rgba(239,68,68,0.28)" :
      "rgba(2,6,23,0.10)";

    return el("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: "6px",
        padding: "6px 10px",
        borderRadius: "999px",
        background: bg,
        border: `1px solid ${border}`,
        fontSize: "12px",
        lineHeight: "12px",
        whiteSpace: "nowrap",
      },
      html: text,
    });
  };

  const button = (label, onClick, variant = "outline") => {
    const base = {
      padding: "10px 14px",
      borderRadius: "12px",
      border: "1px solid rgba(2,6,23,0.12)",
      background: "white",
      cursor: "pointer",
      fontWeight: 600,
    };

    const primary = {
      border: `1px solid rgba(13,83,158,0.30)`,
      boxShadow: "0 1px 0 rgba(2,6,23,0.04)",
      color: PRIMARY,
    };

    const solid = {
      background: PRIMARY,
      border: `1px solid ${PRIMARY}`,
      color: "white",
    };

    const style =
      variant === "solid" ? { ...base, ...solid } :
      variant === "primary" ? { ...base, ...primary } :
      base;

    const btn = el("button", { type: "button", style });
    btn.textContent = label;
    btn.addEventListener("click", onClick);
    return btn;
  };

  async function api(path, opts = {}) {
    if (!restBase || !nonce) throw new Error("Missing restUrl/nonce");
    const res = await fetch(`${restBase}${path}`, {
      credentials: "same-origin",
      ...opts,
      headers: {
        "X-WP-Nonce": nonce,
        ...(opts.headers || {}),
      },
    });
    const json = await res.json().catch(() => ({}));
    return { res, json };
  }

  function renderJson(outEl, json) {
    outEl.innerHTML = "";
    outEl.appendChild(
      el("pre", {
        style: {
          whiteSpace: "pre-wrap",
          background: "rgba(2,6,23,0.04)",
          padding: "12px",
          borderRadius: "12px",
          maxHeight: "520px",
          overflow: "auto",
          border: "1px solid rgba(2,6,23,0.08)",
        },
        html: escapeHtml(JSON.stringify(json, null, 2)),
      })
    );
  }

  function escapeHtml(str) {
    return String(str)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  // ---------- layout shell ----------
  root.innerHTML = ""; // clean slate

  const wrap = el("div", {
    style: {
      fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif",
      color: "#0f172a",
      maxWidth: "1200px",
      margin: "0 auto",
      padding: "18px 14px",
    },
  });

  const header = el("div", {
    style: {
      border: "1px solid rgba(2,6,23,0.10)",
      borderRadius: "16px",
      padding: "16px",
      background: "white",
      boxShadow: "0 1px 0 rgba(2,6,23,0.02)",
      marginBottom: "14px",
    },
  });

  const titleRow = el("div", {
    style: { display: "flex", justifyContent: "space-between", gap: "12px", flexWrap: "wrap" },
  });

  const titleLeft = el("div");
  const h1 = el("div", { style: { fontSize: "26px", fontWeight: 800 } });
  h1.textContent = "WebNique Client Portal";

  const subtitle = el("div", {
    style: { marginTop: "6px", color: "#64748b", display: "flex", gap: "10px", flexWrap: "wrap" },
  });

  const chipClient = pill(`Client ID: <b>${clientId || "(none)"}</b>`);
  const chipMode = pill(`Mode: <b>${mode || "(none)"}</b>`);

  subtitle.appendChild(chipClient);
  subtitle.appendChild(chipMode);

  titleLeft.appendChild(h1);
  titleLeft.appendChild(subtitle);

  const statusRight = el("div", { style: { display: "flex", alignItems: "center", gap: "10px" } });
  const statusPill = pill("loading…", "neutral");
  statusRight.appendChild(statusPill);

  titleRow.appendChild(titleLeft);
  titleRow.appendChild(statusRight);

  header.appendChild(titleRow);

  // Tabs row
  const tabsRow = el("div", { style: { marginTop: "14px", display: "flex", gap: "10px", flexWrap: "wrap" } });

  const tabs = [
    { key: "dashboard", label: "Dashboard" },
    { key: "subscription", label: "Subscription" },
    { key: "analytics", label: "Analytics" },
    { key: "requests", label: "Web Requests" },
    { key: "settings", label: "Settings" },
  ];

  let activeTab = "dashboard";

  const tabButtons = new Map();

  function setActiveTab(key) {
    activeTab = key;
    tabButtons.forEach((btn, k) => {
      btn.style.borderColor = k === key ? `rgba(13,83,158,0.45)` : "rgba(2,6,23,0.12)";
      btn.style.background = k === key ? "rgba(13,83,158,0.06)" : "white";
      btn.style.color = k === key ? PRIMARY : "#0f172a";
    });
    renderTab();
  }

  tabs.forEach((t) => {
    const btn = button(t.label, () => setActiveTab(t.key), "primary");
    // tab default styles
    btn.style.fontWeight = 700;
    btn.style.borderColor = "rgba(2,6,23,0.12)";
    btn.style.color = "#0f172a";
    btn.style.background = "white";
    tabButtons.set(t.key, btn);
    tabsRow.appendChild(btn);
  });

  header.appendChild(tabsRow);

  // Main content grid
  const grid = el("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(12, 1fr)",
      gap: "14px",
    },
  });

  const main = el("div", { style: { gridColumn: "span 8" } });
  const side = el("div", { style: { gridColumn: "span 4" } });

  const mainCard = el("div", {
    style: {
      border: "1px solid rgba(2,6,23,0.10)",
      borderRadius: "16px",
      padding: "16px",
      background: "white",
      minHeight: "420px",
    },
  });

  const sideCard = el("div", {
    style: {
      border: "1px solid rgba(2,6,23,0.10)",
      borderRadius: "16px",
      padding: "16px",
      background: "white",
    },
  });

  const outTitle = el("div", { style: { fontWeight: 800, marginTop: "14px" } });
  outTitle.textContent = "Output";
  const out = el("div", { style: { marginTop: "10px" } });

  // Side actions
  const sideTitle = el("div", { style: { fontSize: "16px", fontWeight: 800 } });
  sideTitle.textContent = "Quick Actions";

  const sideHint = el("div", { style: { color: "#64748b", marginTop: "4px", fontSize: "13px" } });
  sideHint.textContent = "These are dev buttons for now. We’ll remove them later.";

  const actions = el("div", { style: { marginTop: "12px", display: "flex", gap: "10px", flexWrap: "wrap" } });

  // Placeholders for “client info”
  const infoBox = el("div", {
    style: {
      marginTop: "12px",
      padding: "12px",
      borderRadius: "12px",
      border: "1px solid rgba(2,6,23,0.08)",
      background: "rgba(2,6,23,0.02)",
    },
  });

  function renderInfo(client) {
    const business = client?.business_name || client?.name || "(no business name yet)";
    const domain = client?.domain || "(no domain yet)";
    const tier = client?.subscription_tier || "(no tier yet)";

    infoBox.innerHTML = `
      <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;">
        <div>
          <div style="font-weight:900;font-size:18px;">${escapeHtml(business)}</div>
          <div style="color:#64748b;margin-top:4px;">
            Domain: <b>${escapeHtml(domain)}</b> · Tier: <b>${escapeHtml(tier)}</b>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px;">
          ${pill(client?.status === "active" ? "active" : "unknown", client?.status === "active" ? "good" : "neutral").outerHTML}
        </div>
      </div>
    `;
  }

  sideCard.appendChild(sideTitle);
  sideCard.appendChild(sideHint);
  sideCard.appendChild(actions);
  sideCard.appendChild(infoBox);
  sideCard.appendChild(outTitle);
  sideCard.appendChild(out);

  main.appendChild(mainCard);
  side.appendChild(sideCard);

  grid.appendChild(main);
  grid.appendChild(side);

  wrap.appendChild(header);
  wrap.appendChild(grid);
  root.appendChild(wrap);

  // ---------- tab content ----------
  function renderTab() {
    mainCard.innerHTML = "";

    const heading = el("div", { style: { fontSize: "18px", fontWeight: 900 } });
    const desc = el("div", { style: { color: "#64748b", marginTop: "6px" } });

    if (activeTab === "dashboard") {
      heading.textContent = "Dashboard";
      desc.textContent = "Shell layout only. Real metrics come later (GA4/GSC/Stripe).";
    } else if (activeTab === "subscription") {
      heading.textContent = "Subscription";
      desc.textContent = "Tier, billing status, renewal date — later via Stripe server-side.";
    } else if (activeTab === "analytics") {
      heading.textContent = "Analytics";
      desc.textContent = "GA4 + Search Console + rankings — later stored in Firestore for client view.";
    } else if (activeTab === "requests") {
      heading.textContent = "Web Requests";
      desc.textContent = "Client ↔ WebNique messaging. We’ll build threads/messages next.";
    } else if (activeTab === "settings") {
      heading.textContent = "Settings";
      desc.textContent = "Profile + preferences (minimal v1).";
    }

    const block = el("div", {
      style: {
        marginTop: "14px",
        padding: "14px",
        borderRadius: "14px",
        border: "1px solid rgba(2,6,23,0.10)",
        background: "rgba(2,6,23,0.02)",
      },
      html: `
        <div style="font-weight:800;">Coming soon</div>
        <div style="color:#64748b;margin-top:4px;">We’re building the UI components first, then wiring real API data.</div>
      `,
    });

    mainCard.appendChild(heading);
    mainCard.appendChild(desc);
    mainCard.appendChild(block);
  }

  setActiveTab("dashboard");

  // ---------- actions ----------
  // Ping
  actions.appendChild(
    button("Ping (REST)", async () => {
      out.textContent = "Pinging...";
      const { json } = await api("/ping", { method: "GET" });
      renderJson(out, json);
      statusPill.replaceWith(pill(json?.ok ? "ready" : "not ready", json?.ok ? "good" : "warn"));
    })
  );

  // Load client doc
  actions.appendChild(
    button("Load Client Doc", async () => {
      out.textContent = "Loading client...";
      const { json } = await api("/client", { method: "GET" });
      renderJson(out, json);

      if (json?.ok && json?.client) {
        renderInfo(json.client);
        statusPill.replaceWith(pill(json?.exists ? "client doc exists" : "client missing", json?.exists ? "good" : "warn"));
      } else {
        renderInfo(null);
        statusPill.replaceWith(pill("client not loaded", "warn"));
      }
    }, "primary")
  );

  // Admin: bootstrap (creates doc if missing)
  if (isAdmin) {
    actions.appendChild(
      button("Bootstrap Client", async () => {
        out.textContent = "Bootstrapping...";
        const { json } = await api("/clients/bootstrap", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ client_id: clientId }),
        });
        renderJson(out, json);
      }, "primary")
    );
  }

  // ---------- initial load ----------
  try {
    const { json } = await api("/client", { method: "GET" });
    if (json?.ok && json?.client) {
      renderInfo(json.client);
      statusPill.replaceWith(pill(json?.exists ? "ready" : "needs setup", json?.exists ? "good" : "warn"));
    } else {
      renderInfo(null);
      statusPill.replaceWith(pill("needs client doc", "warn"));
    }
  } catch (e) {
    console.error(e);
    renderInfo(null);
    statusPill.replaceWith(pill("REST error", "bad"));
  }
})();
