<?php

namespace WNQ\Core;

if (!defined('ABSPATH')) {
  exit;
}

final class Plugin
{
  private static bool $booted = false;

  public static function init(): void
  {
    if (self::$booted) {
      return;
    }
    self::$booted = true;

    self::includes();

    // Public (client-facing)
    add_action('init', [\WNQ\PublicSite\Shortcode::class, 'register']);

    // Admin (WebNique-only) — kept minimal for v1
    if (is_admin()) {
      add_action('admin_menu', [\WNQ\Admin\AdminMenu::class, 'register']);
    }
  }

  public static function activate(): void
  {
    self::includes();

    \WNQ\Core\Activator::run();
  }

  private static function includes(): void
  {
    // Core
    require_once WNQ_PORTAL_PATH . 'includes/Core/Activator.php';
    require_once WNQ_PORTAL_PATH . 'includes/Core/Permissions.php';
    require_once WNQ_PORTAL_PATH . 'includes/Core/Router.php';
    require_once WNQ_PORTAL_PATH . 'includes/Core/Logger.php';

    // Services (Firebase placeholder already added by you)
    require_once WNQ_PORTAL_PATH . 'includes/Services/FirebaseStore.php';

    // Views
    require_once WNQ_PORTAL_PATH . 'includes/Views/portal-shell.php';

    // Public
    require_once WNQ_PORTAL_PATH . 'public/Shortcode.php';

    // Admin
    require_once WNQ_PORTAL_PATH . 'admin/AdminMenu.php';
    require_once WNQ_PORTAL_PATH . 'admin/AdminSettings.php';
  }
}
