<?php
/**
 * Plugin Name: SEO Database Updater v2
 * Description: One-time plugin to add is_recurring and sort_order columns to SEO tasks table. Deactivate and delete after use.
 * Version: 2.0
 * Author: WebNique
 */

if (!defined('ABSPATH')) {
    exit;
}

register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table = $wpdb->prefix . 'wnq_seo_tasks';

    // Check table exists
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
    if (!$table_exists) {
        set_transient('seo_updater_v2_error', 'Table ' . $table . ' does not exist.', 60);
        return;
    }

    $added = [];
    $failed = [];

    // Get existing columns
    $existing = $wpdb->get_col("SHOW COLUMNS FROM `{$table}`", 0);

    // 1. Add is_recurring column
    if (!in_array('is_recurring', $existing, true)) {
        $result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `is_recurring` tinyint(1) DEFAULT 0 AFTER `month_year`");
        $result !== false ? $added[] = 'is_recurring' : $failed[] = 'is_recurring';
    }

    // 2. Add sort_order column
    if (!in_array('sort_order', $existing, true)) {
        $result = $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `sort_order` int UNSIGNED DEFAULT 0 AFTER `is_recurring`");
        $result !== false ? $added[] = 'sort_order' : $failed[] = 'sort_order';
    }

    // 3. Add index on client_service_month if missing
    $indexes = $wpdb->get_results("SHOW INDEX FROM `{$table}` WHERE Key_name = 'client_service_month'");
    if (empty($indexes)) {
        $wpdb->query("ALTER TABLE `{$table}` ADD KEY `client_service_month` (`client_id`, `service_type`, `month_year`)");
    }

    // Store results
    set_transient('seo_updater_v2_added', $added, 60);
    set_transient('seo_updater_v2_failed', $failed, 60);
    set_transient('seo_updater_v2_done', true, 60);
});

add_action('admin_notices', function() {
    if ($error = get_transient('seo_updater_v2_error')) {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p><strong>❌ SEO Database Updater Error:</strong> ' . esc_html($error) . '</p>';
        echo '</div>';
        delete_transient('seo_updater_v2_error');
        return;
    }

    if (!get_transient('seo_updater_v2_done')) {
        return;
    }

    global $wpdb;
    $table  = $wpdb->prefix . 'wnq_seo_tasks';
    $added  = get_transient('seo_updater_v2_added') ?: [];
    $failed = get_transient('seo_updater_v2_failed') ?: [];

    // Verify current state
    $existing = $wpdb->get_col("SHOW COLUMNS FROM `{$table}`", 0);
    $has_is_recurring = in_array('is_recurring', $existing, true);
    $has_sort_order   = in_array('sort_order', $existing, true);

    if ($has_is_recurring && $has_sort_order) {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p><strong>✅ SUCCESS!</strong> SEO tasks table is fully updated.</p>';
        echo '<ul style="margin-left:20px;list-style:disc">';
        echo '<li><code>is_recurring</code> column: ✅ Present</li>';
        echo '<li><code>sort_order</code> column: ✅ Present</li>';
        echo '</ul>';
        if (!empty($added)) {
            echo '<p>Columns added this run: <strong>' . esc_html(implode(', ', $added)) . '</strong></p>';
        }
        echo '<p><strong>Next steps:</strong></p>';
        echo '<ol>';
        echo '<li>Go to Plugins and <strong>deactivate</strong> "SEO Database Updater v2"</li>';
        echo '<li><strong>Delete</strong> this plugin</li>';
        echo '<li>Go to SEO Tracking and initialize/import tasks</li>';
        echo '</ol>';
        echo '</div>';
    } else {
        echo '<div class="notice notice-error is-dismissible">';
        echo '<p><strong>❌ Some columns could not be added.</strong> Please run these SQL statements manually in phpMyAdmin:</p>';
        echo '<pre style="background:#f5f5f5;padding:10px;overflow-x:auto">';
        if (!$has_is_recurring) {
            echo "ALTER TABLE `{$table}` ADD COLUMN `is_recurring` tinyint(1) DEFAULT 0 AFTER `month_year`;\n";
        }
        if (!$has_sort_order) {
            echo "ALTER TABLE `{$table}` ADD COLUMN `sort_order` int UNSIGNED DEFAULT 0 AFTER `is_recurring`;\n";
        }
        echo '</pre>';
        echo '</div>';
    }

    delete_transient('seo_updater_v2_done');
    delete_transient('seo_updater_v2_added');
    delete_transient('seo_updater_v2_failed');
});