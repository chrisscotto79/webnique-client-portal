<?php
/**
 * SEO Admin - FULLY OPTIMIZED
 * 
 * Features:
 * - Full task lists from operations manual (200+ tasks)
 * - Bulk import buttons per service type
 * - Bulk import from CSV file
 * - CSV template download
 * - Export tasks to CSV
 * - Monthly Tasks tab with month selector
 * - AJAX checkbox toggle (no page reload)
 * - Add/delete custom tasks
 * - Task notes editing (AJAX)
 * - Task grouping with collapsible sections
 * - Client website links
 * - Admin notices for success/error feedback
 * - Delete all tasks per service (for re-import)
 * - Sanitized redirects throughout
 * - Consistent permission checks
 * 
 * @package WebNique Portal
 */

namespace WNQ\Admin;

use WNQ\Models\SEO;
use WNQ\Models\Client;

if (!defined('ABSPATH')) {
    exit;
}

final class SEOAdmin
{
    private const CAP = 'manage_options';

    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addSubmenu'], 25);
        add_action('admin_enqueue_scripts', [self::class, 'enqueueAssets']);
        add_action('admin_notices', [self::class, 'showAdminNotices']);
    }

    public static function addSubmenu(): void
    {
        $cap = current_user_can('wnq_manage_portal') ? 'wnq_manage_portal' : self::CAP;
        add_submenu_page('wnq-portal', 'SEO Tracking', 'SEO Tracking', $cap, 'wnq-seo', [self::class, 'render']);
    }

    public static function enqueueAssets(string $hook): void
    {
        if ($hook !== 'webnique-portal_page_wnq-seo') return;
        wp_enqueue_script('jquery');
    }

    /* ── Admin Notices ── */

    public static function showAdminNotices(): void
    {
        $screen = get_current_screen();
        if (!$screen || $screen->id !== 'webnique-portal_page_wnq-seo') return;

        foreach (['success', 'error'] as $type) {
            if ($msg = get_transient('wnq_seo_notice_' . $type)) {
                $class = $type === 'error' ? 'notice-error' : 'notice-success';
                echo '<div class="notice ' . $class . ' is-dismissible"><p>' . esc_html($msg) . '</p></div>';
                delete_transient('wnq_seo_notice_' . $type);
            }
        }
        if ($msgs = get_transient('wnq_seo_notice_warnings')) {
            if (is_array($msgs)) {
                foreach ($msgs as $m) {
                    echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html($m) . '</p></div>';
                }
            }
            delete_transient('wnq_seo_notice_warnings');
        }
    }

    private static function setNotice(string $message, string $type = 'success'): void
    {
        set_transient('wnq_seo_notice_' . $type, $message, 45);
    }

    private static function setWarnings(array $messages): void
    {
        set_transient('wnq_seo_notice_warnings', $messages, 45);
    }

    /* ── Helpers ── */

    private static function checkPermission(): void
    {
        if (!current_user_can('wnq_manage_portal') && !current_user_can(self::CAP)) {
            wp_die(__('You do not have sufficient permissions.'));
        }
    }

    private static function getSafeRedirect(string $fallback = ''): string
    {
        $url = isset($_POST['redirect_url']) ? esc_url_raw(wp_unslash($_POST['redirect_url'])) : '';
        if (empty($url)) $url = $fallback ?: admin_url('admin.php?page=wnq-seo');
        return wp_validate_redirect($url, admin_url('admin.php?page=wnq-seo'));
    }

    private static function findClient(string $client_id): ?array
    {
        foreach (Client::getAll() as $c) {
            if ($c['client_id'] === $client_id) return $c;
        }
        return null;
    }

    private static function normalizeUrl(string $url): string
    {
        $url = trim($url);
        if (empty($url)) return '';
        if (!preg_match('/^https?:\/\//', $url)) $url = 'https://' . $url;
        return $url;
    }

    private static function currentPageUrl(): string
    {
        return esc_url_raw(set_url_scheme('http' . (is_ssl() ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']));
    }

    /* ══════════════════════════════════════
     *  MAIN RENDER ROUTER
     * ══════════════════════════════════════ */

    public static function render(): void
    {
        self::checkPermission();
        $view = isset($_GET['view']) ? sanitize_key($_GET['view']) : 'overview';
        $client_id = isset($_GET['client']) ? sanitize_text_field(wp_unslash($_GET['client'])) : '';

        switch ($view) {
            case 'client':
                $client_id ? self::renderClientView($client_id) : self::renderOverview();
                break;
            case 'report':
                self::renderReportView($client_id);
                break;
            default:
                self::renderOverview();
                break;
        }
    }

    /* ══════════════════════════════════════
     *  OVERVIEW PAGE
     * ══════════════════════════════════════ */

    private static function renderOverview(): void
    {
        $clients = Client::getAll();
        $all_stats = [];
        foreach ($clients as $client) {
            $all_stats[$client['client_id']] = SEO::getOverallProgress($client['client_id']);
        }

        $total_tasks = $total_completed = $active_clients = 0;
        foreach ($all_stats as $stats) {
            $total_tasks     += $stats['total_tasks'];
            $total_completed += $stats['completed_tasks'];
            if ($stats['total_tasks'] > 0) $active_clients++;
        }
        $completion_rate = $total_tasks > 0 ? round(($total_completed / $total_tasks) * 100) : 0;
        ?>
        <div class="wrap wnq-seo-premium">
            <div class="seo-header"><div class="header-content">
                <h1>&#x1F680; SEO Tracking Dashboard</h1>
                <p class="subtitle">Monitor SEO progress across all clients</p>
            </div></div>

            <div class="seo-stats-grid">
                <div class="stat-card"><div class="stat-icon">&#x1F465;</div><div class="stat-content"><div class="stat-value"><?php echo $active_clients; ?></div><div class="stat-label">Active Clients</div></div></div>
                <div class="stat-card"><div class="stat-icon">&#x1F4CB;</div><div class="stat-content"><div class="stat-value"><?php echo $total_tasks; ?></div><div class="stat-label">Total Tasks</div></div></div>
                <div class="stat-card"><div class="stat-icon">&#x2705;</div><div class="stat-content"><div class="stat-value"><?php echo $total_completed; ?></div><div class="stat-label">Completed</div></div></div>
                <div class="stat-card"><div class="stat-icon">&#x1F4CA;</div><div class="stat-content"><div class="stat-value"><?php echo $completion_rate; ?>%</div><div class="stat-label">Completion Rate</div></div></div>
            </div>

            <div class="clients-seo-grid">
                <?php foreach ($clients as $client):
                    $stats = $all_stats[$client['client_id']];
                    $pct   = $stats['completion_percentage'];
                    $wurl  = self::normalizeUrl($client['website_url'] ?? '');
                    $aurl  = $wurl ? rtrim($wurl, '/') . '/wp-admin' : '';
                ?>
                <div class="client-seo-card">
                    <div class="client-card-header">
                        <div class="client-info">
                            <h3><?php if ($wurl): ?><a href="<?php echo esc_url($wurl); ?>" target="_blank" class="client-link"><?php echo esc_html($client['name']); ?> &#x1F517;</a><?php else: echo esc_html($client['name']); endif; ?></h3>
                            <?php if ($aurl): ?><a href="<?php echo esc_url($aurl); ?>" target="_blank" class="admin-link">&#x1F527; WP Admin</a><?php endif; ?>
                        </div>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=wnq-seo&view=client&client=' . urlencode($client['client_id']))); ?>" class="btn-manage">Manage SEO &rarr;</a>
                    </div>
                    <div class="progress-section">
                        <div class="progress-label"><span>Overall Progress</span><span class="progress-pct"><?php echo $pct; ?>%</span></div>
                        <div class="progress-bar"><div class="progress-fill" style="width:<?php echo $pct; ?>%"></div></div>
                    </div>
                    <div class="task-stats">
                        <div class="task-stat"><span class="stat-count"><?php echo $stats['completed_tasks']; ?></span><span class="stat-name">Completed</span></div>
                        <div class="task-stat"><span class="stat-count"><?php echo $stats['in_progress_tasks']; ?></span><span class="stat-name">In Progress</span></div>
                        <div class="task-stat"><span class="stat-count"><?php echo $stats['pending_tasks']; ?></span><span class="stat-name">Pending</span></div>
                    </div>
                    <?php if ($stats['total_tasks'] === 0): ?>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="init-form">
                        <?php wp_nonce_field('wnq_init_seo_client'); ?>
                        <input type="hidden" name="action" value="wnq_init_seo_client">
                        <input type="hidden" name="client_id" value="<?php echo esc_attr($client['client_id']); ?>">
                        <button type="submit" class="btn-init">&#x2728; Initialize SEO Tasks</button>
                    </form>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php self::renderStyles();
    }

    /* ══════════════════════════════════════
     *  CLIENT VIEW (Task Lists)
     * ══════════════════════════════════════ */

    private static function renderClientView(string $client_id): void
    {
        $client = self::findClient($client_id);
        if (!$client) { wp_die('Client not found'); }

        $website_url = self::normalizeUrl($client['website_url'] ?? '');
        $admin_url   = $website_url ? rtrim($website_url, '/') . '/wp-admin' : '';

        $selected_service = isset($_GET['service']) ? sanitize_key($_GET['service']) : 'onpage';
        $selected_month   = isset($_GET['month']) ? sanitize_text_field(wp_unslash($_GET['month'])) : date('Y-m');

        $valid_services = SEO::getValidServiceTypes();
        if (!in_array($selected_service, $valid_services, true)) $selected_service = 'onpage';

        $month_filter = ($selected_service === 'monthly') ? $selected_month : null;
        $tasks    = SEO::getTasksByClient($client_id, $selected_service, $month_filter);
        $progress = SEO::getOverallProgress($client_id, $month_filter);
        $service_progress = SEO::getServiceTypeProgress($client_id, $month_filter);

        $tasks_by_group = [];
        foreach ($tasks as $task) {
            $group = $task['task_group'] ?: 'General';
            $tasks_by_group[$group][] = $task;
        }

        $service_types = [
            'onpage'    => ['name' => 'On-Page SEO',  'icon' => '&#x1F4DD;', 'color' => '#667eea'],
            'technical' => ['name' => 'Technical SEO', 'icon' => '&#x2699;&#xFE0F;',  'color' => '#10b981'],
            'local'     => ['name' => 'Local SEO',     'icon' => '&#x1F4CD;', 'color' => '#f59e0b'],
            'offpage'   => ['name' => 'Off-Page SEO',  'icon' => '&#x1F517;', 'color' => '#8b5cf6'],
            'monthly'   => ['name' => 'Monthly Tasks', 'icon' => '&#x1F4C5;', 'color' => '#ec4899'],
        ];

        $current_service = $service_types[$selected_service] ?? $service_types['onpage'];
        $ajax_nonce = wp_create_nonce('wnq_seo_ajax');
        ?>
        <div class="wrap wnq-seo-premium">
            <div class="seo-header"><div class="header-content">
                <a href="<?php echo esc_url(admin_url('admin.php?page=wnq-seo')); ?>" class="back-link">&larr; Back</a>
                <h1>&#x1F680; <?php echo esc_html($client['name']); ?> &mdash; SEO Tracking</h1>
                <?php if ($website_url || $admin_url): ?>
                <div class="client-links-header">
                    <?php if ($website_url): ?><a href="<?php echo esc_url($website_url); ?>" target="_blank" class="header-link">&#x1F517; Visit Site</a><?php endif; ?>
                    <?php if ($admin_url): ?><a href="<?php echo esc_url($admin_url); ?>" target="_blank" class="header-link">&#x1F527; WP Admin</a><?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="header-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=wnq-seo&view=report&client=' . urlencode($client_id))); ?>" class="header-link">&#x1F4CA; Reports</a>
            </div></div>

            <!-- Progress Overview -->
            <div class="progress-overview"><div class="progress-card">
                <div class="progress-header">
                    <h3><?php echo $selected_service === 'monthly' ? 'Monthly Progress' : 'Overall Progress'; ?></h3>
                    <span class="progress-percentage"><?php echo $progress['completion_percentage']; ?>%</span>
                </div>
                <div class="progress-bar-large"><div class="progress-fill-large" style="width:<?php echo $progress['completion_percentage']; ?>%"></div></div>
                <div class="progress-stats">
                    <div class="stat-item"><strong><?php echo $progress['completed_tasks']; ?></strong><span>Completed</span></div>
                    <div class="stat-item"><strong><?php echo $progress['in_progress_tasks']; ?></strong><span>In Progress</span></div>
                    <div class="stat-item"><strong><?php echo $progress['pending_tasks']; ?></strong><span>Pending</span></div>
                    <div class="stat-item"><strong><?php echo $progress['total_tasks']; ?></strong><span>Total</span></div>
                </div>
            </div></div>

            <!-- Service Tabs -->
            <div class="service-tabs">
                <?php foreach ($service_types as $type => $info):
                    $td = null;
                    foreach ($service_progress as $sp) { if ($sp['service_type'] === $type) { $td = $sp; break; } }
                    $tot = $td ? intval($td['total']) : 0;
                    $don = $td ? intval($td['completed']) : 0;
                    $act = ($selected_service === $type);
                    $tu  = admin_url('admin.php?page=wnq-seo&view=client&client=' . urlencode($client_id) . '&service=' . $type);
                    if ($type === 'monthly') $tu .= '&month=' . urlencode($selected_month);
                ?>
                <a href="<?php echo esc_url($tu); ?>" class="service-tab <?php echo $act ? 'active' : ''; ?>" style="border-color:<?php echo esc_attr($info['color']); ?>">
                    <span class="tab-icon"><?php echo $info['icon']; ?></span>
                    <span class="tab-name"><?php echo esc_html($info['name']); ?></span>
                    <span class="tab-count"><?php echo $don; ?>/<?php echo $tot; ?></span>
                </a>
                <?php endforeach; ?>
            </div>

            <!-- Monthly Controls -->
            <?php if ($selected_service === 'monthly'): ?>
            <div class="monthly-controls">
                <div class="month-selector-wrapper">
                    <label for="month-selector">Select Month:</label>
                    <select id="month-selector" class="month-selector-inline">
                        <?php for ($i = 0; $i < 12; $i++):
                            $mo = date('Y-m', strtotime("-$i months"));
                            $ml = date('F Y', strtotime($mo . '-01'));
                        ?>
                        <option value="<?php echo esc_attr($mo); ?>" <?php selected($selected_month, $mo); ?>><?php echo esc_html($ml); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <?php if (empty($tasks)): ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline">
                    <?php wp_nonce_field('wnq_init_monthly_tasks'); ?>
                    <input type="hidden" name="action" value="wnq_init_monthly_tasks">
                    <input type="hidden" name="client_id" value="<?php echo esc_attr($client_id); ?>">
                    <input type="hidden" name="month_year" value="<?php echo esc_attr($selected_month); ?>">
                    <input type="hidden" name="redirect_url" value="<?php echo esc_url(self::currentPageUrl()); ?>">
                    <button type="submit" class="btn-init-month">&#x1F4C5; Initialize <?php echo esc_html(date('F Y', strtotime($selected_month . '-01'))); ?> Tasks</button>
                </form>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Toolbar -->
            <div class="bulk-actions-toolbar">
                <div class="toolbar-left">
                    <?php if (empty($tasks) && $selected_service !== 'monthly'): ?>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline">
                        <?php wp_nonce_field('wnq_bulk_import_seo'); ?>
                        <input type="hidden" name="action" value="wnq_bulk_import_seo">
                        <input type="hidden" name="client_id" value="<?php echo esc_attr($client_id); ?>">
                        <input type="hidden" name="service_type" value="<?php echo esc_attr($selected_service); ?>">
                        <input type="hidden" name="redirect_url" value="<?php echo esc_url(self::currentPageUrl()); ?>">
                        <button type="submit" class="btn-toolbar btn-import">&#x1F4E6; Bulk Import Template Tasks</button>
                    </form>
                    <?php endif; ?>
                    <button type="button" onclick="document.getElementById('csv-import-panel').style.display=document.getElementById('csv-import-panel').style.display==='none'?'block':'none'" class="btn-toolbar btn-csv">&#x1F4C4; Import from CSV</button>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline">
                        <?php wp_nonce_field('wnq_download_csv_template'); ?>
                        <input type="hidden" name="action" value="wnq_download_csv_template">
                        <button type="submit" class="btn-toolbar btn-download">&#x2B07;&#xFE0F; CSV Template</button>
                    </form>
                </div>
                <div class="toolbar-right">
                    <?php if (!empty($tasks)): ?>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline">
                        <?php wp_nonce_field('wnq_export_seo_csv'); ?>
                        <input type="hidden" name="action" value="wnq_export_seo_csv">
                        <input type="hidden" name="client_id" value="<?php echo esc_attr($client_id); ?>">
                        <input type="hidden" name="service_type" value="<?php echo esc_attr($selected_service); ?>">
                        <button type="submit" class="btn-toolbar btn-export">&#x1F4E4; Export CSV</button>
                    </form>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline" onsubmit="return confirm('Delete ALL <?php echo esc_js($current_service['name']); ?> tasks?')">
                        <?php wp_nonce_field('wnq_delete_all_seo_tasks'); ?>
                        <input type="hidden" name="action" value="wnq_delete_all_seo_tasks">
                        <input type="hidden" name="client_id" value="<?php echo esc_attr($client_id); ?>">
                        <input type="hidden" name="service_type" value="<?php echo esc_attr($selected_service); ?>">
                        <?php if ($selected_service === 'monthly'): ?><input type="hidden" name="month_year" value="<?php echo esc_attr($selected_month); ?>"><?php endif; ?>
                        <input type="hidden" name="redirect_url" value="<?php echo esc_url(self::currentPageUrl()); ?>">
                        <button type="submit" class="btn-toolbar btn-danger">&#x1F5D1;&#xFE0F; Delete All</button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>

            <!-- CSV Import Panel -->
            <div id="csv-import-panel" class="csv-import-panel" style="display:none">
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data">
                    <?php wp_nonce_field('wnq_csv_import_seo'); ?>
                    <input type="hidden" name="action" value="wnq_csv_import_seo">
                    <input type="hidden" name="client_id" value="<?php echo esc_attr($client_id); ?>">
                    <input type="hidden" name="redirect_url" value="<?php echo esc_url(self::currentPageUrl()); ?>">
                    <div class="csv-import-grid">
                        <div class="csv-field"><label>CSV File <span class="required">*</span></label><input type="file" name="csv_file" accept=".csv,.txt" required></div>
                        <div class="csv-field"><label>Default Service Type</label><select name="default_service_type"><option value="">-- From CSV Column --</option>
                            <?php foreach ($service_types as $st => $si): ?><option value="<?php echo esc_attr($st); ?>" <?php selected($selected_service, $st); ?>><?php echo esc_html($si['name']); ?></option><?php endforeach; ?>
                        </select></div>
                        <?php if ($selected_service === 'monthly'): ?><div class="csv-field"><label>Month</label><input type="month" name="month_year" value="<?php echo esc_attr($selected_month); ?>"></div><?php endif; ?>
                        <div class="csv-field csv-submit"><button type="submit" class="btn-toolbar btn-import">&#x1F4C4; Import CSV</button></div>
                    </div>
                    <p class="csv-help">CSV must include a <code>task_name</code> column. Optional: <code>service_type</code>, <code>task_group</code>, <code>task_description</code></p>
                </form>
            </div>

            <!-- Task List -->
            <?php if (!empty($tasks_by_group)): ?>
            <div class="task-section">
                <div class="task-section-header" style="border-left-color:<?php echo esc_attr($current_service['color']); ?>">
                    <div class="section-title">
                        <span class="section-icon"><?php echo $current_service['icon']; ?></span>
                        <h3><?php echo esc_html($current_service['name']); ?></h3>
                        <?php if ($selected_service === 'monthly'): ?><span class="month-badge"><?php echo esc_html(date('F Y', strtotime($selected_month . '-01'))); ?></span><?php endif; ?>
                    </div>
                    <span class="task-count"><?php echo count($tasks); ?> tasks</span>
                </div>

                <?php foreach ($tasks_by_group as $group_name => $group_tasks):
                    $gid  = 'grp-' . md5($selected_service . $group_name);
                    $gd   = count(array_filter($group_tasks, fn($t) => $t['status'] === 'completed'));
                    $gt   = count($group_tasks);
                    $gp   = $gt > 0 ? round(($gd / $gt) * 100) : 0;
                ?>
                <div class="task-group" id="<?php echo esc_attr($gid); ?>">
                    <div class="task-group-header-wrapper" onclick="toggleGroup('<?php echo esc_js($gid); ?>')">
                        <h4 class="task-group-header">
                            <span class="group-toggle">&#x25BC;</span>
                            &#x1F4C1; <?php echo esc_html($group_name); ?>
                            <span class="group-progress">
                                <span class="group-progress-bar"><span class="group-progress-fill" style="width:<?php echo $gp; ?>%"></span></span>
                                <span class="group-task-count"><?php echo $gd; ?>/<?php echo $gt; ?></span>
                            </span>
                        </h4>
                        <button type="button" onclick="event.stopPropagation();toggleAddTask('<?php echo esc_js($gid); ?>')" class="btn-add-task">+ Add Task</button>
                    </div>

                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="quick-add-task-form" id="add-<?php echo esc_attr($gid); ?>" style="display:none">
                        <?php wp_nonce_field('wnq_add_seo_task'); ?>
                        <input type="hidden" name="action" value="wnq_add_seo_task">
                        <input type="hidden" name="client_id" value="<?php echo esc_attr($client_id); ?>">
                        <input type="hidden" name="service_type" value="<?php echo esc_attr($selected_service); ?>">
                        <input type="hidden" name="task_group" value="<?php echo esc_attr($group_name); ?>">
                        <input type="hidden" name="month_year" value="<?php echo $selected_service === 'monthly' ? esc_attr($selected_month) : ''; ?>">
                        <input type="hidden" name="redirect_url" value="<?php echo esc_url(self::currentPageUrl()); ?>">
                        <div class="quick-add-inputs">
                            <input type="text" name="task_name" placeholder="Enter task name..." class="quick-add-input" required>
                            <button type="submit" class="btn-save-task">Save</button>
                            <button type="button" onclick="toggleAddTask('<?php echo esc_js($gid); ?>')" class="btn-cancel-task">Cancel</button>
                        </div>
                    </form>

                    <div class="tasks-list" id="tasks-<?php echo esc_attr($gid); ?>">
                        <?php foreach ($group_tasks as $task): ?>
                        <div class="task-item task-<?php echo esc_attr($task['status']); ?>" id="task-row-<?php echo $task['id']; ?>">
                            <div class="task-checkbox">
                                <button type="button" class="checkbox-btn <?php echo $task['status'] === 'completed' ? 'completed' : ''; ?>"
                                    onclick="toggleTask(<?php echo $task['id']; ?>,'<?php echo $task['status'] === 'completed' ? 'uncomplete' : 'complete'; ?>')"
                                    title="<?php echo $task['status'] === 'completed' ? 'Uncheck' : 'Complete'; ?>">
                                    <?php echo $task['status'] === 'completed' ? '&#x2705;' : '&#x2610;'; ?>
                                </button>
                            </div>
                            <div class="task-content">
                                <div class="task-name"><?php echo esc_html($task['task_name']); ?></div>
                                <?php if (!empty($task['task_description'])): ?><div class="task-description"><?php echo esc_html($task['task_description']); ?></div><?php endif; ?>
                                <?php if (!empty($task['notes'])): ?><div class="task-notes" id="notes-<?php echo $task['id']; ?>">&#x1F4DD; <?php echo esc_html($task['notes']); ?></div><?php endif; ?>
                                <?php if ($task['status'] === 'completed' && !empty($task['completed_date'])): ?><div class="task-completed-date">Completed: <?php echo esc_html(date('M j, Y g:i A', strtotime($task['completed_date']))); ?></div><?php endif; ?>
                            </div>
                            <div class="task-actions">
                                <?php if ($task['status'] !== 'completed' && $task['status'] !== 'in_progress'): ?>
                                <button type="button" onclick="setTaskStatus(<?php echo $task['id']; ?>,'in_progress')" class="btn-action">Start</button>
                                <?php endif; ?>
                                <button type="button" onclick="editTaskNotes(<?php echo $task['id']; ?>)" class="btn-action">Notes</button>
                                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline">
                                    <?php wp_nonce_field('wnq_delete_seo_task'); ?>
                                    <input type="hidden" name="action" value="wnq_delete_seo_task">
                                    <input type="hidden" name="task_id" value="<?php echo esc_attr($task['id']); ?>">
                                    <input type="hidden" name="redirect_url" value="<?php echo esc_url(self::currentPageUrl()); ?>">
                                    <button type="submit" class="btn-action btn-delete" onclick="return confirm('Delete?')">Delete</button>
                                </form>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php elseif ($selected_service !== 'monthly'): ?>
            <div class="empty-state">
                <div class="empty-icon">&#x1F4CB;</div>
                <h3>No <?php echo esc_html($current_service['name']); ?> Tasks Yet</h3>
                <p>Use the toolbar above to bulk import template tasks or import from CSV</p>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">&#x1F4C5;</div>
                <h3>No Monthly Tasks for <?php echo esc_html(date('F Y', strtotime($selected_month . '-01'))); ?></h3>
                <p>Use the "Initialize" button above, or import from CSV</p>
            </div>
            <?php endif; ?>
        </div>

        <?php self::renderStyles(); ?>

        <script>
        (function($){
            var nonce='<?php echo esc_js($ajax_nonce); ?>',ajax='<?php echo esc_js(admin_url('admin-ajax.php')); ?>';

            $('#month-selector').on('change',function(){var u=new URL(location.href);u.searchParams.set('month',$(this).val());location.href=u.toString()});

            window.toggleTask=function(id,act){
                var b=$('#task-row-'+id+' .checkbox-btn'),r=$('#task-row-'+id);
                b.prop('disabled',true).css('opacity',0.5);
                $.post(ajax,{action:'wnq_seo_toggle_task',task_id:id,toggle:act,_wpnonce:nonce},function(res){
                    if(res.success){
                        if(act==='complete'){b.html('&#x2705;').addClass('completed').attr('onclick',"toggleTask("+id+",'uncomplete')");r.removeClass('task-pending task-in_progress').addClass('task-completed')}
                        else{b.html('&#x2610;').removeClass('completed').attr('onclick',"toggleTask("+id+",'complete')");r.removeClass('task-completed').addClass('task-pending')}
                        var g=r.closest('.task-group'),t=g.find('.task-item').length,d=g.find('.task-completed').length,p=t>0?Math.round(d/t*100):0;
                        g.find('.group-task-count').text(d+'/'+t);g.find('.group-progress-fill').css('width',p+'%')
                    }else{alert('Error: '+(res.data||'Failed'))}
                }).fail(function(){alert('Network error')}).always(function(){b.prop('disabled',false).css('opacity',1)})
            };

            window.setTaskStatus=function(id,st){$.post(ajax,{action:'wnq_seo_update_task_status',task_id:id,status:st,_wpnonce:nonce},function(r){r.success?location.reload():alert('Error')})};

            window.editTaskNotes=function(id){
                var ex=$('#notes-'+id).length?$('#notes-'+id).text().replace(/^\S+\s/,''):'';
                var n=prompt('Add/edit notes:',ex);if(n===null)return;
                $.post(ajax,{action:'wnq_seo_update_task_notes',task_id:id,notes:n,_wpnonce:nonce},function(r){
                    if(r.success){if(n.trim()){if($('#notes-'+id).length){$('#notes-'+id).text('&#x1F4DD; '+n)}else{$('#task-row-'+id+' .task-content').append('<div class="task-notes" id="notes-'+id+'">&#x1F4DD; '+$('<span>').text(n).html()+'</div>')}}else{$('#notes-'+id).remove()}}
                    else{alert('Error saving notes')}
                })
            };

            window.toggleAddTask=function(gid){var f=$('#add-'+gid);f.is(':visible')?f.slideUp(200).find('input[name=task_name]').val(''):f.slideDown(200).find('input[name=task_name]').focus()};
            window.toggleGroup=function(gid){var t=$('#tasks-'+gid),g=$('#'+gid+' .group-toggle');t.slideToggle(200);g.text(t.is(':visible')?'&#x25BC;':'&#x25B6;')};
        })(jQuery);
        </script>
        <?php
    }

    /* ══════════════════════════════════════
     *  REPORT VIEW
     * ══════════════════════════════════════ */

    private static function renderReportView(string $client_id): void
    {
        $client = self::findClient($client_id);
        if (!$client) { wp_die('Client not found'); }

        $selected_month = isset($_GET['month']) ? sanitize_text_field(wp_unslash($_GET['month'])) : date('Y-m');
        $report   = SEO::getReport($client_id, $selected_month);
        $progress = SEO::getOverallProgress($client_id, $selected_month);
        ?>
        <div class="wrap wnq-seo-premium">
            <div class="seo-header"><div class="header-content">
                <a href="<?php echo esc_url(admin_url('admin.php?page=wnq-seo&view=client&client=' . urlencode($client_id))); ?>" class="back-link">&larr; Back</a>
                <h1>&#x1F4CA; Monthly SEO Report</h1>
                <p class="subtitle"><?php echo esc_html($client['name']); ?> &mdash; <?php echo esc_html(date('F Y', strtotime($selected_month . '-01'))); ?></p>
            </div>
            <div class="header-actions">
                <select id="month-selector" class="month-selector">
                    <?php for ($i = 0; $i < 12; $i++): $mo = date('Y-m', strtotime("-$i months")); $ml = date('F Y', strtotime($mo . '-01')); ?>
                    <option value="<?php echo esc_attr($mo); ?>" <?php selected($selected_month, $mo); ?>><?php echo esc_html($ml); ?></option>
                    <?php endfor; ?>
                </select>
            </div></div>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="report-form">
                <?php wp_nonce_field('wnq_save_seo_report'); ?>
                <input type="hidden" name="action" value="wnq_save_seo_report">
                <input type="hidden" name="client_id" value="<?php echo esc_attr($client_id); ?>">
                <input type="hidden" name="month_year" value="<?php echo esc_attr($selected_month); ?>">

                <div class="report-section"><h3>&#x1F4C8; Key Metrics</h3>
                    <div class="metrics-grid">
                        <div class="metric-input"><label>Keywords Tracked</label><input type="number" name="keywords_tracked" value="<?php echo esc_attr($report['keywords_tracked'] ?? 0); ?>" class="regular-text"></div>
                        <div class="metric-input"><label>Average Position</label><input type="number" step="0.01" name="avg_position" value="<?php echo esc_attr($report['avg_position'] ?? 0); ?>" class="regular-text"></div>
                        <div class="metric-input"><label>Organic Traffic</label><input type="number" name="organic_traffic" value="<?php echo esc_attr($report['organic_traffic'] ?? 0); ?>" class="regular-text"></div>
                        <div class="metric-input"><label>Backlinks Added</label><input type="number" name="backlinks_added" value="<?php echo esc_attr($report['backlinks_added'] ?? 0); ?>" class="regular-text"></div>
                    </div>
                </div>

                <div class="report-section"><h3>&#x1F517; Report URL</h3>
                    <input type="url" name="report_url" value="<?php echo esc_attr($report['report_url'] ?? ''); ?>" class="large-text" placeholder="https://docs.google.com/...">
                    <p class="description">Link to the full monthly SEO report</p>
                </div>

                <div class="report-section"><h3>&#x1F4DD; Monthly Summary</h3>
                    <textarea name="summary" rows="6" class="large-text" placeholder="Summarize this month's SEO work..."><?php echo esc_textarea($report['summary'] ?? ''); ?></textarea>
                </div>

                <div class="report-section"><h3>&#x2705; Task Completion</h3>
                    <div class="completion-stats">
                        <div class="stat-box"><div class="stat-number"><?php echo $progress['completed_tasks']; ?>/<?php echo $progress['total_tasks']; ?></div><div class="stat-label">Tasks Completed</div></div>
                        <div class="stat-box"><div class="stat-number"><?php echo $progress['completion_percentage']; ?>%</div><div class="stat-label">Completion Rate</div></div>
                    </div>
                </div>

                <p class="submit">
                    <button type="submit" class="button button-primary button-large">&#x1F4BE; Save Report</button>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=wnq-seo&view=client&client=' . urlencode($client_id))); ?>" class="button button-large">Cancel</a>
                </p>
            </form>
        </div>
        <?php self::renderStyles(); ?>
        <script>jQuery('#month-selector').on('change',function(){var u=new URL(location.href);u.searchParams.set('month',jQuery(this).val());location.href=u.toString()});</script>
        <?php
    }

    /* ══════════════════════════════════════
     *  STYLES
     * ══════════════════════════════════════ */

    private static function renderStyles(): void
    {
        ?>
        <style>
        .wnq-seo-premium{margin:20px 20px 20px 0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif}
        .seo-header{display:flex;justify-content:space-between;align-items:center;padding:24px 32px;background:linear-gradient(135deg,#10b981,#059669);border-radius:16px;margin-bottom:24px;box-shadow:0 4px 20px rgba(16,185,129,.3)}
        .seo-header h1{margin:0 0 4px;font-size:28px;font-weight:800;color:#fff}
        .subtitle{margin:0;color:rgba(255,255,255,.9);font-size:15px}
        .back-link{display:inline-block;color:#fff;text-decoration:none;font-weight:600;margin-bottom:8px;opacity:.9}.back-link:hover{opacity:1;color:#fff}
        .client-links-header{display:flex;gap:12px;margin-top:8px}
        .header-link{padding:6px 12px;background:rgba(255,255,255,.2);color:#fff;text-decoration:none;border-radius:6px;font-size:13px;font-weight:600;transition:.2s}.header-link:hover{background:rgba(255,255,255,.3);color:#fff}
        .header-actions{display:flex;gap:8px;align-items:center}
        .month-selector{padding:10px 16px;border:2px solid rgba(255,255,255,.3);border-radius:8px;background:rgba(255,255,255,.9);font-size:14px;font-weight:600}
        .seo-stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px}
        .stat-card{display:flex;align-items:center;gap:16px;padding:20px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
        .stat-icon{font-size:32px}.stat-value{font-size:28px;font-weight:800;color:#1e293b}.stat-label{font-size:12px;color:#64748b;font-weight:600;text-transform:uppercase}
        .clients-seo-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(350px,1fr));gap:20px}
        .client-seo-card{background:#fff;border-radius:12px;padding:24px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
        .client-card-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px}
        .client-info{display:flex;flex-direction:column;gap:4px}
        .client-card-header h3{margin:0;font-size:18px;font-weight:700}
        .client-link{color:#1e293b;text-decoration:none;transition:.2s}.client-link:hover{color:#10b981}
        .admin-link{font-size:12px;color:#64748b;text-decoration:none;font-weight:600}.admin-link:hover{color:#10b981}
        .btn-manage{padding:8px 16px;background:#10b981;color:#fff;text-decoration:none;border-radius:8px;font-weight:600;font-size:13px;white-space:nowrap}.btn-manage:hover{background:#059669;color:#fff}
        .progress-section{margin-bottom:20px}.progress-label{display:flex;justify-content:space-between;margin-bottom:8px;font-size:13px;font-weight:600;color:#64748b}.progress-pct{color:#10b981;font-weight:800}
        .progress-bar{height:8px;background:#e2e8f0;border-radius:4px;overflow:hidden}.progress-fill{height:100%;background:linear-gradient(90deg,#10b981,#059669);transition:width .3s}
        .task-stats{display:flex;justify-content:space-around;padding-top:16px;border-top:1px solid #f1f5f9}
        .task-stat{text-align:center}.stat-count{display:block;font-size:20px;font-weight:800;color:#1e293b}.stat-name{display:block;font-size:11px;color:#64748b;font-weight:600;text-transform:uppercase}
        .btn-init{width:100%;padding:12px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border:none;border-radius:8px;font-weight:700;cursor:pointer;margin-top:16px}.btn-init:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(102,126,234,.3)}
        .progress-overview{margin-bottom:24px}.progress-card{background:#fff;border-radius:12px;padding:24px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
        .progress-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}.progress-header h3{margin:0;font-size:18px}.progress-percentage{font-size:24px;font-weight:800;color:#10b981}
        .progress-bar-large{height:16px;background:#e2e8f0;border-radius:8px;overflow:hidden;margin-bottom:16px}.progress-fill-large{height:100%;background:linear-gradient(90deg,#10b981,#059669);transition:width .3s}
        .progress-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}.stat-item{text-align:center}.stat-item strong{display:block;font-size:24px;color:#1e293b}.stat-item span{font-size:12px;color:#64748b;font-weight:600;text-transform:uppercase}
        .service-tabs{display:flex;gap:12px;margin-bottom:24px;flex-wrap:wrap}
        .service-tab{display:flex;align-items:center;gap:8px;padding:12px 20px;background:#fff;border:2px solid #e2e8f0;border-radius:8px;text-decoration:none;color:#64748b;font-weight:600;transition:.2s}.service-tab:hover{border-color:#cbd5e1;transform:translateY(-2px);color:#64748b}.service-tab.active{background:linear-gradient(135deg,#f8fafc,#f1f5f9);border-width:3px;color:#1e293b}
        .tab-icon{font-size:20px}.tab-name{font-size:14px}.tab-count{padding:2px 8px;background:#f1f5f9;border-radius:12px;font-size:11px}.service-tab.active .tab-count{background:#fff}
        .monthly-controls{background:#fff;border-radius:12px;padding:20px;margin-bottom:24px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 8px rgba(0,0,0,.08)}
        .month-selector-wrapper{display:flex;align-items:center;gap:12px}.month-selector-wrapper label{font-weight:600;color:#1e293b}.month-selector-inline{padding:8px 12px;border:2px solid #e2e8f0;border-radius:6px;font-weight:600}
        .btn-init-month{padding:10px 20px;background:#ec4899;color:#fff;border:none;border-radius:8px;font-weight:600;cursor:pointer}.btn-init-month:hover{background:#db2777}
        .month-badge{padding:4px 12px;background:#fce7f3;color:#ec4899;border-radius:12px;font-size:12px;font-weight:700;margin-left:12px}
        .bulk-actions-toolbar{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;padding:16px 20px;background:#fff;border-radius:12px;margin-bottom:24px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
        .toolbar-left,.toolbar-right{display:flex;gap:8px;flex-wrap:wrap}
        .btn-toolbar{padding:8px 16px;border:1px solid #e2e8f0;background:#fff;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;transition:.2s;white-space:nowrap}.btn-toolbar:hover{background:#f8fafc;border-color:#cbd5e0;transform:translateY(-1px)}
        .btn-toolbar.btn-import{background:#667eea;color:#fff;border-color:#667eea}.btn-toolbar.btn-import:hover{background:#5a67d8}
        .btn-toolbar.btn-csv{background:#f59e0b;color:#fff;border-color:#f59e0b}.btn-toolbar.btn-csv:hover{background:#d97706}
        .btn-toolbar.btn-download{color:#64748b}.btn-toolbar.btn-export{color:#10b981;border-color:#10b981}
        .btn-toolbar.btn-danger{color:#dc2626;border-color:#fecaca;background:#fee2e2}.btn-toolbar.btn-danger:hover{background:#fecaca}
        .csv-import-panel{background:#fffbeb;border:2px solid #f59e0b;border-radius:12px;padding:20px;margin-bottom:24px}
        .csv-import-grid{display:flex;gap:16px;align-items:flex-end;flex-wrap:wrap}
        .csv-field{display:flex;flex-direction:column;gap:4px}.csv-field label{font-size:13px;font-weight:600;color:#1e293b}.csv-field .required{color:#dc2626}
        .csv-field input[type="file"]{padding:8px}.csv-field select,.csv-field input[type="month"]{padding:8px 12px;border:2px solid #e2e8f0;border-radius:6px;font-size:14px}
        .csv-submit{align-self:flex-end}.csv-help{margin:12px 0 0;font-size:12px;color:#92400e}.csv-help code{background:#fef3c7;padding:2px 6px;border-radius:3px;font-size:12px}
        .task-section{background:#fff;border-radius:12px;padding:24px;margin-bottom:24px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
        .task-section-header{display:flex;justify-content:space-between;align-items:center;padding-bottom:16px;margin-bottom:16px;border-bottom:2px solid #f1f5f9;border-left:4px solid;padding-left:16px}
        .section-title{display:flex;align-items:center;gap:12px}.section-icon{font-size:24px}.task-section-header h3{margin:0;font-size:18px;font-weight:700}
        .task-count{padding:4px 12px;background:#f1f5f9;border-radius:12px;font-size:12px;font-weight:700;color:#64748b}
        .task-group{margin-bottom:24px}
        .task-group-header-wrapper{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;cursor:pointer}
        .task-group-header{margin:0;padding:12px 16px;background:linear-gradient(135deg,#f8fafc,#f1f5f9);border-left:4px solid #10b981;border-radius:8px;font-size:15px;font-weight:700;color:#1e293b;flex:1;display:flex;align-items:center;gap:8px}
        .group-toggle{font-size:12px;color:#94a3b8;transition:.2s}
        .group-progress{margin-left:auto;display:flex;align-items:center;gap:8px}
        .group-progress-bar{width:80px;height:6px;background:#e2e8f0;border-radius:3px;overflow:hidden}.group-progress-fill{height:100%;background:#10b981;transition:width .3s}
        .group-task-count{font-size:12px;font-weight:600;color:#64748b;background:#fff;padding:4px 12px;border-radius:12px}
        .btn-add-task{padding:8px 16px;background:#10b981;color:#fff;border:none;border-radius:6px;font-weight:600;font-size:13px;cursor:pointer;margin-left:12px;white-space:nowrap}.btn-add-task:hover{background:#059669}
        .quick-add-task-form{background:#f0fdf4;border:2px solid #10b981;border-radius:8px;padding:16px;margin-bottom:16px}
        .quick-add-inputs{display:flex;gap:8px;align-items:center}
        .quick-add-input{flex:1;padding:10px 12px;border:2px solid #e2e8f0;border-radius:6px;font-size:14px}.quick-add-input:focus{outline:none;border-color:#10b981}
        .btn-save-task{padding:10px 20px;background:#10b981;color:#fff;border:none;border-radius:6px;font-weight:600;cursor:pointer}.btn-save-task:hover{background:#059669}
        .btn-cancel-task{padding:10px 20px;background:#e2e8f0;color:#64748b;border:none;border-radius:6px;font-weight:600;cursor:pointer}.btn-cancel-task:hover{background:#cbd5e1}
        .tasks-list{display:flex;flex-direction:column;gap:8px}
        .task-item{display:flex;align-items:flex-start;gap:16px;padding:12px 16px;background:#f8fafc;border-radius:8px;border:1px solid #e2e8f0;transition:.2s}
        .task-item.task-completed{background:#f0fdf4;border-color:#86efac}.task-item.task-in_progress{background:#fef3c7;border-color:#fde68a}
        .task-checkbox{flex-shrink:0}
        .checkbox-btn{width:32px;height:32px;border:2px solid #cbd5e0;background:#fff;border-radius:6px;cursor:pointer;font-size:20px;display:flex;align-items:center;justify-content:center;padding:0;transition:.15s}.checkbox-btn:hover{border-color:#10b981;background:#f0fdf4}.checkbox-btn.completed{background:#f0fdf4;border-color:#10b981}
        .task-content{flex:1;min-width:0}.task-name{font-size:14px;font-weight:600;color:#1e293b;margin-bottom:2px}.task-description{font-size:13px;color:#64748b;margin-bottom:2px}
        .task-notes{font-size:12px;color:#8b5cf6;margin-top:6px;padding:6px 10px;background:#faf5ff;border-radius:4px;word-break:break-word}
        .task-completed-date{font-size:11px;color:#059669;margin-top:4px}
        .task-actions{display:flex;gap:6px;flex-shrink:0}
        .btn-action{padding:5px 10px;border:1px solid #e2e8f0;background:#fff;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap}.btn-action:hover{background:#f8fafc;border-color:#cbd5e0}
        .btn-delete{color:#dc2626!important;background:#fee2e2!important;border:1px solid #fecaca!important}.btn-delete:hover{background:#fecaca!important}
        .report-form{background:#fff;border-radius:12px;padding:24px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
        .report-section{margin-bottom:32px}.report-section h3{margin:0 0 16px;font-size:16px;font-weight:700;color:#1e293b}
        .metrics-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}.metric-input label{display:block;font-size:13px;font-weight:600;color:#64748b;margin-bottom:8px}
        .completion-stats{display:flex;gap:24px}.stat-box{flex:1;padding:24px;background:linear-gradient(135deg,#10b981,#059669);border-radius:12px;text-align:center;color:#fff}
        .stat-number{font-size:36px;font-weight:800;margin-bottom:8px}
        .empty-state{text-align:center;padding:80px 20px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
        .empty-icon{font-size:64px;margin-bottom:16px}.empty-state h3{margin:0 0 8px;font-size:20px}.empty-state p{margin:0 0 24px;color:#64748b}
        @media(max-width:1200px){.seo-stats-grid{grid-template-columns:repeat(2,1fr)}.metrics-grid{grid-template-columns:1fr}.progress-stats{grid-template-columns:repeat(2,1fr)}}
        @media(max-width:768px){.seo-stats-grid{grid-template-columns:1fr}.service-tabs{flex-direction:column}.bulk-actions-toolbar{flex-direction:column}.toolbar-left,.toolbar-right{width:100%}}
        </style>
        <?php
    }

    /* ══════════════════════════════════════
     *  FORM HANDLERS (admin-post.php)
     * ══════════════════════════════════════ */

    public static function handleInitClient(): void
    {
        check_admin_referer('wnq_init_seo_client');
        self::checkPermission();
        $client_id = sanitize_text_field(wp_unslash($_POST['client_id'] ?? ''));
        $result = SEO::initializeClientTasks($client_id);
        self::setNotice("Initialized {$result['imported']} SEO tasks.");
        wp_safe_redirect(admin_url('admin.php?page=wnq-seo&view=client&client=' . urlencode($client_id)));
        exit;
    }

    public static function handleInitMonthlyTasks(): void
    {
        check_admin_referer('wnq_init_monthly_tasks');
        self::checkPermission();
        $client_id  = sanitize_text_field(wp_unslash($_POST['client_id'] ?? ''));
        $month_year = sanitize_text_field(wp_unslash($_POST['month_year'] ?? ''));
        $result = SEO::initializeMonthlyTasks($client_id, $month_year);
        if (!empty($result['skipped'])) {
            self::setNotice('Monthly tasks already exist for this month.', 'error');
        } else {
            self::setNotice("Initialized {$result['imported']} monthly tasks.");
        }
        wp_safe_redirect(self::getSafeRedirect());
        exit;
    }

    public static function handleBulkImport(): void
    {
        check_admin_referer('wnq_bulk_import_seo');
        self::checkPermission();
        $client_id    = sanitize_text_field(wp_unslash($_POST['client_id'] ?? ''));
        $service_type = sanitize_key($_POST['service_type'] ?? '');
        $month_year   = !empty($_POST['month_year']) ? sanitize_text_field(wp_unslash($_POST['month_year'])) : null;
        $result = SEO::bulkImportTasks($client_id, $service_type, $month_year);
        if (!empty($result['error'])) {
            self::setNotice("Import error: {$result['error']}", 'error');
        } else {
            self::setNotice("Imported {$result['imported']} tasks.");
        }
        wp_safe_redirect(self::getSafeRedirect());
        exit;
    }

    public static function handleCsvImport(): void
    {
        check_admin_referer('wnq_csv_import_seo');
        self::checkPermission();
        $client_id       = sanitize_text_field(wp_unslash($_POST['client_id'] ?? ''));
        $default_service = sanitize_key($_POST['default_service_type'] ?? '') ?: null;
        $month_year      = !empty($_POST['month_year']) ? sanitize_text_field(wp_unslash($_POST['month_year'])) : null;

        if (empty($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
            self::setNotice('No CSV file uploaded or upload error.', 'error');
            wp_safe_redirect(self::getSafeRedirect());
            exit;
        }
        $ext = strtolower(pathinfo($_FILES['csv_file']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['csv', 'txt'], true)) {
            self::setNotice('Invalid file type. Please upload a .csv file.', 'error');
            wp_safe_redirect(self::getSafeRedirect());
            exit;
        }
        $result = SEO::importFromCsv($client_id, $_FILES['csv_file']['tmp_name'], $default_service, $month_year);
        if (!empty($result['errors'])) {
            self::setWarnings(array_slice($result['errors'], 0, 10));
        }
        $msg = "CSV Import: {$result['imported']} imported, {$result['failed']} failed, {$result['skipped']} skipped.";
        self::setNotice($msg, $result['failed'] > 0 ? 'error' : 'success');
        wp_safe_redirect(self::getSafeRedirect());
        exit;
    }

    public static function handleDownloadCsvTemplate(): void
    {
        check_admin_referer('wnq_download_csv_template');
        self::checkPermission();
        $csv = SEO::generateCsvTemplate();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=seo-tasks-template.csv');
        header('Pragma: no-cache');
        header('Expires: 0');
        echo $csv;
        exit;
    }

    public static function handleExportCsv(): void
    {
        check_admin_referer('wnq_export_seo_csv');
        self::checkPermission();
        $client_id    = sanitize_text_field(wp_unslash($_POST['client_id'] ?? ''));
        $service_type = sanitize_key($_POST['service_type'] ?? '');
        $csv      = SEO::exportTasksCsv($client_id, $service_type ?: null);
        $filename = 'seo-tasks-' . sanitize_file_name($client_id) . '-' . ($service_type ?: 'all') . '-' . date('Y-m-d') . '.csv';
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        header('Pragma: no-cache');
        header('Expires: 0');
        echo $csv;
        exit;
    }

    public static function handleDeleteAllTasks(): void
    {
        check_admin_referer('wnq_delete_all_seo_tasks');
        self::checkPermission();
        $client_id    = sanitize_text_field(wp_unslash($_POST['client_id'] ?? ''));
        $service_type = sanitize_key($_POST['service_type'] ?? '');
        $month_year   = !empty($_POST['month_year']) ? sanitize_text_field(wp_unslash($_POST['month_year'])) : null;
        $deleted = SEO::deleteAllTasks($client_id, $service_type, $month_year);
        self::setNotice("Deleted $deleted tasks.");
        wp_safe_redirect(self::getSafeRedirect());
        exit;
    }

    public static function handleCompleteTask(): void
    {
        check_admin_referer('wnq_complete_seo_task');
        self::checkPermission();
        SEO::completeTask(intval($_POST['task_id'] ?? 0));
        wp_safe_redirect(self::getSafeRedirect());
        exit;
    }

    public static function handleUncompleteTask(): void
    {
        check_admin_referer('wnq_uncomplete_seo_task');
        self::checkPermission();
        SEO::uncompleteTask(intval($_POST['task_id'] ?? 0));
        wp_safe_redirect(self::getSafeRedirect());
        exit;
    }

    public static function handleUpdateTask(): void
    {
        check_admin_referer('wnq_update_seo_task');
        self::checkPermission();
        $task_id = intval($_POST['task_id'] ?? 0);
        $data = [];
        if (isset($_POST['status'])) $data['status'] = sanitize_text_field(wp_unslash($_POST['status']));
        if (isset($_POST['notes']))  $data['notes']  = sanitize_textarea_field(wp_unslash($_POST['notes']));
        SEO::updateTask($task_id, $data);
        wp_safe_redirect(self::getSafeRedirect());
        exit;
    }

    public static function handleSaveReport(): void
    {
        check_admin_referer('wnq_save_seo_report');
        self::checkPermission();
        $client_id = sanitize_text_field(wp_unslash($_POST['client_id'] ?? ''));
        SEO::saveReport([
            'client_id'        => $client_id,
            'month_year'       => sanitize_text_field(wp_unslash($_POST['month_year'] ?? '')),
            'report_url'       => esc_url_raw(wp_unslash($_POST['report_url'] ?? '')),
            'keywords_tracked' => intval($_POST['keywords_tracked'] ?? 0),
            'avg_position'     => floatval($_POST['avg_position'] ?? 0),
            'organic_traffic'  => intval($_POST['organic_traffic'] ?? 0),
            'backlinks_added'  => intval($_POST['backlinks_added'] ?? 0),
            'summary'          => sanitize_textarea_field(wp_unslash($_POST['summary'] ?? '')),
        ]);
        self::setNotice('Report saved successfully.');
        wp_safe_redirect(admin_url('admin.php?page=wnq-seo&view=report&client=' . urlencode($client_id) . '&month=' . urlencode($_POST['month_year'] ?? '')));
        exit;
    }

    public static function handleAddTask(): void
    {
        check_admin_referer('wnq_add_seo_task');
        self::checkPermission();
        $task_name = sanitize_text_field(wp_unslash($_POST['task_name'] ?? ''));
        if (empty($task_name)) { wp_safe_redirect(self::getSafeRedirect()); exit; }
        $month_year = !empty($_POST['month_year']) ? sanitize_text_field(wp_unslash($_POST['month_year'])) : null;
        SEO::createTask([
            'client_id'    => sanitize_text_field(wp_unslash($_POST['client_id'] ?? '')),
            'service_type' => sanitize_key($_POST['service_type'] ?? ''),
            'task_group'   => sanitize_text_field(wp_unslash($_POST['task_group'] ?? '')),
            'task_name'    => $task_name,
            'status'       => 'pending',
            'month_year'   => $month_year,
        ]);
        wp_safe_redirect(self::getSafeRedirect());
        exit;
    }

    public static function handleDeleteTask(): void
    {
        check_admin_referer('wnq_delete_seo_task');
        self::checkPermission();
        SEO::deleteTask(intval($_POST['task_id'] ?? 0));
        wp_safe_redirect(self::getSafeRedirect());
        exit;
    }

    /* ══════════════════════════════════════
     *  AJAX HANDLERS
     * ══════════════════════════════════════ */

    public static function ajaxToggleTask(): void
    {
        check_ajax_referer('wnq_seo_ajax');
        self::checkPermission();
        $task_id = intval($_POST['task_id'] ?? 0);
        $toggle  = sanitize_key($_POST['toggle'] ?? '');
        if (!$task_id) wp_send_json_error('Invalid task ID');
        $result = ($toggle === 'complete') ? SEO::completeTask($task_id) : SEO::uncompleteTask($task_id);
        $result ? wp_send_json_success() : wp_send_json_error('Could not update task');
    }

    public static function ajaxUpdateTaskStatus(): void
    {
        check_ajax_referer('wnq_seo_ajax');
        self::checkPermission();
        $task_id = intval($_POST['task_id'] ?? 0);
        $status  = sanitize_key($_POST['status'] ?? '');
        if (!$task_id || !in_array($status, ['pending', 'in_progress', 'completed'], true)) wp_send_json_error('Invalid data');
        $data = ['status' => $status];
        if ($status === 'completed') $data['completed_date'] = current_time('mysql');
        $result = SEO::updateTask($task_id, $data);
        $result ? wp_send_json_success() : wp_send_json_error('Could not update task');
    }

    public static function ajaxUpdateTaskNotes(): void
    {
        check_ajax_referer('wnq_seo_ajax');
        self::checkPermission();
        $task_id = intval($_POST['task_id'] ?? 0);
        $notes   = sanitize_textarea_field(wp_unslash($_POST['notes'] ?? ''));
        if (!$task_id) wp_send_json_error('Invalid task ID');
        $result = SEO::updateTask($task_id, ['notes' => $notes]);
        $result !== false ? wp_send_json_success() : wp_send_json_error('Could not save notes');
    }
}