<?php
/**
 * Core Plugin Class
 * 
 * Main initialization and bootstrap for WebNique Client Portal
 * 
 * @package WebNique Portal
 */

namespace WNQ\Core;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Plugin
 * Handles plugin initialization and component loading
 */
final class Plugin
{
    /**
     * Initialize the plugin
     */
    public static function init(): void
    {
        // Load core classes
        self::loadCore();
        
        // Initialize admin area
        if (is_admin()) {
            self::initAdmin();
        }
        
        // Initialize public/frontend area
        self::initPublic();
        
        // Register REST API routes
        self::registerRestRoutes();
    }

    /**
     * Load core classes
     */
    private static function loadCore(): void
    {
        // Core functionality
        require_once WNQ_PORTAL_PATH . 'includes/Core/Permissions.php';
        require_once WNQ_PORTAL_PATH . 'includes/Core/Router.php';
        require_once WNQ_PORTAL_PATH . 'includes/Core/UserMeta.php';
        
        // Initialize permissions
        Permissions::init();
    }

    /**
     * Initialize admin area
     */
    private static function initAdmin(): void
    {
        // Load models
        require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
        
        // Load admin classes
        require_once WNQ_PORTAL_PATH . 'admin/AdminMenu.php';
        require_once WNQ_PORTAL_PATH . 'admin/AdminSettings.php';
        require_once WNQ_PORTAL_PATH . 'admin/RequestsAdmin.php';
        require_once WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
        
        // Load analytics admin if exists
        $analytics_admin = WNQ_PORTAL_PATH . 'admin/AnalyticsAdmin.php';
        if (file_exists($analytics_admin)) {
            require_once $analytics_admin;
            \WNQ\Admin\AnalyticsAdmin::register();
        }

        // Register admin pages
        \WNQ\Admin\AdminMenu::register();
        \WNQ\Admin\RequestsAdmin::register();
        \WNQ\Admin\ClientsAdmin::register();
    }

    /**
     * Initialize public/frontend area
     */
    private static function initPublic(): void
    {
        // Load public classes
        require_once WNQ_PORTAL_PATH . 'public/Shortcode.php';
        
        // Register shortcode
        \WNQ\PublicSite\Shortcode::register();
    }

    /**
     * Register REST API routes
     */
    private static function registerRestRoutes(): void
    {
        // Load REST API controllers
        add_action('rest_api_init', function() {
            // Check if controllers exist before loading
            $controllers_path = WNQ_PORTAL_PATH . 'includes/Controllers/';
            
            if (file_exists($controllers_path)) {
                // Load only existing controller files
                $controllers = [
                    'DashboardController.php',
                ];

                foreach ($controllers as $controller) {
                    $file = $controllers_path . $controller;
                    if (file_exists($file)) {
                        require_once $file;
                    }
                }

                // Register routes for existing controllers
                if (class_exists('WNQ\\Controllers\\DashboardController')) {
                    \WNQ\Controllers\DashboardController::registerRoutes();
                }
            }
        });
    }

    /**
     * Plugin activation hook
     */
    public static function activate(): void
    {
        // Create custom capabilities
        $admin_role = get_role('administrator');
        if ($admin_role) {
            $admin_role->add_cap('wnq_manage_portal');
        }

        // Flush rewrite rules
        flush_rewrite_rules();

        // Log activation
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('WebNique Portal: Plugin activated');
        }
    }

    /**
     * Plugin deactivation hook
     */
    public static function deactivate(): void
    {
        // Flush rewrite rules
        flush_rewrite_rules();

        // Log deactivation
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('WebNique Portal: Plugin deactivated');
        }
    }
}