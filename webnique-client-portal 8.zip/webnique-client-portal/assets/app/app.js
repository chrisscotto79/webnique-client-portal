(async function () {
  const root = document.getElementById("wnq-portal-root");
  if (!root) return;

  const clientId = root.getAttribute("data-client-id") || "";
  const mode = root.getAttribute("data-mode") || "";

  console.log("[WNQ] Portal booted", { clientId, mode });

  const el = document.createElement("div");
  el.style.padding = "12px";
  el.style.marginTop = "12px";
  el.style.border = "1px solid #e5e7eb";
  el.style.borderRadius = "10px";
  el.style.fontFamily = "system-ui";
  el.innerHTML = `
    <strong>WNQ App.js Loaded ✅</strong><br/>
    Client ID: <code>${clientId || "(none)"}</code><br/>
    Mode: <code>${mode || "(none)"}</code><br/>
    Ping: <code id="wnq-ping-status">checking...</code>
  `;
  root.appendChild(el);

  // Call REST ping with WP nonce
  try {
    const restBase = window.WNQ_PORTAL?.restUrl;
    const nonce = window.WNQ_PORTAL?.nonce;

    if (!restBase || !nonce) {
      document.getElementById("wnq-ping-status").textContent = "missing restUrl/nonce";
      return;
    }

    const res = await fetch(`${restBase}/ping`, {
      method: "GET",
      credentials: "same-origin",
      headers: {
        "X-WP-Nonce": nonce,
      },
    });

    const json = await res.json();
    console.log("[WNQ] Ping response", json);

    const ok = json?.ok ? "ok" : "not ok";
    document.getElementById("wnq-ping-status").textContent = ok;

    // Optional: show user_id for proof
    if (json?.wp?.user_id !== undefined) {
      const proof = document.createElement("div");
      proof.style.marginTop = "8px";
      proof.innerHTML = `REST user_id: <code>${json.wp.user_id}</code>, client_id: <code>${json.wp.client_id ?? "(null)"}</code>`;
      root.appendChild(proof);
    }
  } catch (e) {
    console.error(e);
    const node = document.getElementById("wnq-ping-status");
    if (node) node.textContent = "error (see console)";
  }
})();
