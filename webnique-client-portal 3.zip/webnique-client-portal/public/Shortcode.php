<?php

namespace WNQ\PublicSite;

use WNQ\Core\Permissions;

if (!defined('ABSPATH')) {
  exit;
}

final class Shortcode
{
  public static function register(): void
  {
    add_shortcode('wnq_portal', [self::class, 'render']);
  }

  public static function render($atts = []): string
  {
    if (!Permissions::isLoggedIn()) {
      return '<p>You must be logged in to view this portal.</p>';
    }

    $clientId = Permissions::currentUserClientId();

    // Admins can view shell even without a client_id set (for testing).
    if ($clientId === null && !Permissions::currentUserCanManagePortal()) {
      return '<p>Your account is not linked to a client yet. Please contact WebNique.</p>';
    }

    $args = [
      'client_id' => $clientId ?? '',
      'mode' => Permissions::currentUserCanManagePortal() ? 'admin' : 'client',
    ];

    // Global function (declared in includes/Views/portal-shell.php)
    return wnq_portal_shell_html($args);
  }
}
