<?php
/**
 * Plugin Name: SEO Progress Diagnostic
 * Description: Shows exactly what tasks are being counted vs not counted. One-time use.
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit;

add_action('admin_notices', function() {
    global $wpdb;
    $table = $wpdb->prefix . 'wnq_seo_tasks';
    
    // Get one client ID
    $client_id = 'Sam-pa2893829'; // Update this if needed
    
    echo '<div class="notice notice-info" style="padding:20px;font-family:monospace;font-size:13px">';
    echo '<h2>🔍 SEO Progress Diagnostic</h2>';
    
    // Query 1: ALL tasks
    $all_tasks = $wpdb->get_row($wpdb->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
        FROM $table
        WHERE client_id = %s
    ", $client_id), ARRAY_A);
    
    // Query 2: One-time tasks only (month_year IS NULL)
    $onetime_tasks = $wpdb->get_row($wpdb->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
        FROM $table
        WHERE client_id = %s AND month_year IS NULL
    ", $client_id), ARRAY_A);
    
    // Query 3: Monthly tasks (month_year IS NOT NULL)
    $monthly_tasks = $wpdb->get_row($wpdb->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
        FROM $table
        WHERE client_id = %s AND month_year IS NOT NULL
    ", $client_id), ARRAY_A);
    
    // Show where completed tasks are
    $completed_breakdown = $wpdb->get_results($wpdb->prepare("
        SELECT 
            CASE 
                WHEN month_year IS NULL THEN 'One-Time'
                ELSE CONCAT('Monthly: ', month_year)
            END as task_type,
            COUNT(*) as count
        FROM $table
        WHERE client_id = %s AND status = 'completed'
        GROUP BY month_year
    ", $client_id), ARRAY_A);
    
    echo '<div style="background:#f0f9ff;padding:15px;border-radius:8px;margin:10px 0;border-left:4px solid #0284c7">';
    echo '<h3 style="margin:0 0 10px">📊 ALL TASKS (including monthly):</h3>';
    echo '<p>Total: ' . $all_tasks['total'] . '</p>';
    echo '<p>Completed: ' . $all_tasks['completed'] . '</p>';
    echo '<p>Pending: ' . $all_tasks['pending'] . '</p>';
    echo '<p><strong>Progress: ' . ($all_tasks['total'] > 0 ? round(($all_tasks['completed'] / $all_tasks['total']) * 100, 1) : 0) . '%</strong></p>';
    echo '</div>';
    
    echo '<div style="background:#f0fdf4;padding:15px;border-radius:8px;margin:10px 0;border-left:4px solid #10b981">';
    echo '<h3 style="margin:0 0 10px">✅ ONE-TIME TASKS ONLY (month_year IS NULL):</h3>';
    echo '<p>Total: ' . $onetime_tasks['total'] . '</p>';
    echo '<p>Completed: ' . $onetime_tasks['completed'] . '</p>';
    echo '<p>Pending: ' . $onetime_tasks['pending'] . '</p>';
    echo '<p><strong>Progress: ' . ($onetime_tasks['total'] > 0 ? round(($onetime_tasks['completed'] / $onetime_tasks['total']) * 100, 1) : 0) . '%</strong></p>';
    echo '<p style="color:#059669;font-weight:bold">👆 THIS is what Overview should show</p>';
    echo '</div>';
    
    echo '<div style="background:#fef3c7;padding:15px;border-radius:8px;margin:10px 0;border-left:4px solid #f59e0b">';
    echo '<h3 style="margin:0 0 10px">📅 MONTHLY TASKS (month_year IS NOT NULL):</h3>';
    echo '<p>Total: ' . $monthly_tasks['total'] . '</p>';
    echo '<p>Completed: ' . $monthly_tasks['completed'] . '</p>';
    echo '<p>Pending: ' . $monthly_tasks['pending'] . '</p>';
    echo '</div>';
    
    if (!empty($completed_breakdown)) {
        echo '<div style="background:#fef2f2;padding:15px;border-radius:8px;margin:10px 0;border-left:4px solid #dc2626">';
        echo '<h3 style="margin:0 0 10px">🎯 WHERE ARE YOUR COMPLETED TASKS?</h3>';
        foreach ($completed_breakdown as $row) {
            echo '<p>✅ <strong>' . $row['task_type'] . ':</strong> ' . $row['count'] . ' completed</p>';
        }
        echo '</div>';
    } else {
        echo '<div style="background:#fef2f2;padding:15px;border-radius:8px;margin:10px 0;border-left:4px solid #dc2626">';
        echo '<p>❌ No completed tasks found in database!</p>';
        echo '</div>';
    }
    
    echo '<hr style="margin:20px 0">';
    echo '<p><strong>📝 Analysis:</strong></p>';
    echo '<ul style="line-height:1.8">';
    
    if ($onetime_tasks['completed'] == 0 && $monthly_tasks['completed'] > 0) {
        echo '<li>❌ <strong>PROBLEM FOUND!</strong> You completed ' . $monthly_tasks['completed'] . ' MONTHLY tasks, but Overview only shows ONE-TIME tasks.</li>';
        echo '<li>Solution: Complete some ONE-TIME tasks (from On-Page, Technical, Local, or Off-Page tabs)</li>';
    } elseif ($onetime_tasks['completed'] > 0) {
        echo '<li>✅ You have ' . $onetime_tasks['completed'] . ' completed ONE-TIME tasks</li>';
        echo '<li>✅ Overview SHOULD show ' . round(($onetime_tasks['completed'] / $onetime_tasks['total']) * 100, 1) . '% progress</li>';
        echo '<li>🔧 If Overview shows 0%, there\'s a PHP/SQL bug - check SEO.php getOverallProgress() method</li>';
    } else {
        echo '<li>ℹ️ No tasks completed yet. Click checkboxes on ONE-TIME tasks to see progress bar move.</li>';
    }
    
    echo '</ul>';
    
    echo '<p style="margin-top:20px"><strong>Deactivate this plugin after checking!</strong></p>';
    echo '</div>';
});