<?php
/**
 * Analytics Admin Page - COMPLETE WITH ALL FIXES
 * 
 * This version loads Chart.js inline to guarantee it works
 * 
 * @package WebNique Portal
 */

namespace WNQ\Admin;

use WNQ\Models\AnalyticsConfig;
use WNQ\API\GoogleAnalytics;
use WNQ\API\GoogleSearchConsole;
use WNQ\API\AnalyticsCache;

if (!defined('ABSPATH')) {
    exit;
}

final class AnalyticsAdmin
{
    /**
     * Register admin hooks
     */
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addSubmenu'], 20);
        add_action('admin_enqueue_scripts', [self::class, 'enqueueAssets'], 999);
        add_action('admin_post_wnq_save_analytics_settings', [self::class, 'handleSaveSettings']);
        add_action('admin_post_wnq_test_analytics_connection', [self::class, 'handleTestConnection']);
        add_action('admin_post_wnq_clear_analytics_cache', [self::class, 'handleClearCache']);
        add_action('wp_ajax_wnq_get_analytics_data', [self::class, 'ajaxGetAnalyticsData']);
    }

    /**
     * Add submenu page
     */
    public static function addSubmenu(): void
    {
        $capability = current_user_can('wnq_manage_portal') ? 'wnq_manage_portal' : 'manage_options';

        add_submenu_page(
            'wnq-portal',
            'Analytics',
            'Analytics',
            $capability,
            'wnq-analytics',
            [self::class, 'render']
        );
    }

    /**
     * Enqueue assets
     */
    public static function enqueueAssets($hook): void
    {
        // Only load on analytics page
        $is_analytics_page = (isset($_GET['page']) && $_GET['page'] === 'wnq-analytics');

        if (!$is_analytics_page) {
            return;
        }

        // CRITICAL: Define wnqAnalytics AND embed JavaScript directly
        add_action('admin_footer', function() {
            $plugin_url = plugin_dir_url(dirname(__FILE__));
            ?>
            <script type="text/javascript">
            // Define wnqAnalytics object
            window.wnqAnalytics = {
                ajaxUrl: '<?php echo admin_url('admin-ajax.php'); ?>',
                nonce: '<?php echo wp_create_nonce('wnq_analytics_nonce'); ?>',
                clientId: '<?php echo self::getCurrentClientId(); ?>',
                debug: true
            };
            console.log('wnqAnalytics defined:', window.wnqAnalytics);

            // EMBEDDED ANALYTICS DASHBOARD SCRIPT
            (function($) {
                'use strict';

                console.log('=== Simple Analytics Dashboard Loading (EMBEDDED) ===');

                function initDashboard() {
                    console.log('Initializing dashboard...');
                    bindEvents();
                    loadAnalyticsData(30);
                }

                function bindEvents() {
                    $('#wnq-date-range').on('change', function() {
                        loadAnalyticsData(parseInt($(this).val()));
                    });

                    $('#wnq-refresh-data').on('click', function() {
                        $(this).prop('disabled', true).text('🔄 Refreshing...');
                        loadAnalyticsData(parseInt($('#wnq-date-range').val()));
                    });
                }

                function loadAnalyticsData(dateRange) {
                    console.log('Loading data for ' + dateRange + ' days...');
                    console.log('AJAX URL:', wnqAnalytics.ajaxUrl);
                    console.log('Client ID:', wnqAnalytics.clientId);
                    
                    $('#wnq-analytics-loading').show();
                    $('#wnq-analytics-content').hide();

                    $.ajax({
                        url: wnqAnalytics.ajaxUrl,
                        type: 'POST',
                        data: {
                            action: 'wnq_get_analytics_data',
                            nonce: wnqAnalytics.nonce,
                            client_id: wnqAnalytics.clientId,
                            date_range: dateRange
                        },
                        success: function(response) {
                            console.log('AJAX SUCCESS:', response);
                            
                            if (response.success) {
                                renderDashboard(response.data);
                                $('#wnq-analytics-loading').hide();
                                $('#wnq-analytics-content').show();
                            } else {
                                showError(response.data || 'Failed to load data');
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('AJAX ERROR:', error, status, xhr.responseText);
                            showError('Network error: ' + error);
                        },
                        complete: function() {
                            $('#wnq-refresh-data').prop('disabled', false).text('🔄 Refresh Data');
                        }
                    });
                }

                function renderDashboard(data) {
                    console.log('Rendering data:', data);
                    
                    var html = '<div style="padding: 20px;">';
                    
                    if (data.overview) {
                        html += '<h2>📊 Overview (Last ' + $('#wnq-date-range').val() + ' Days)</h2>';
                        html += '<table class="wp-list-table widefat">';
                        html += '<tr><td><strong>Visitors</strong></td><td>' + (data.overview.total_users.value || 0) + '</td></tr>';
                        html += '<tr><td><strong>Page Views</strong></td><td>' + (data.overview.page_views.value || 0) + '</td></tr>';
                        html += '<tr><td><strong>Bounce Rate</strong></td><td>' + (data.overview.bounce_rate.value || 0) + '%</td></tr>';
                        html += '</table>';
                    }
                    
                    html += '</div>';
                    
                    $('#wnq-analytics-content').html(html);
                }

                function showError(message) {
                    console.error('Error:', message);
                    $('#wnq-analytics-loading').hide();
                    $('#wnq-analytics-content').html(
                        '<div class="notice notice-error" style="padding:20px;margin:20px;"><p><strong>Error:</strong> ' + message + '</p></div>'
                    ).show();
                }

                $(document).ready(function() {
                    console.log('Document ready!');
                    if ($('#wnq-analytics-content').length) {
                        console.log('Found analytics div, initializing...');
                        initDashboard();
                    } else {
                        console.log('Analytics div not found');
                    }
                });

            })(jQuery);
            </script>
            <?php
        });

        // Enqueue jQuery
        wp_enqueue_script('jquery');

        // Get plugin URL
        $plugin_url = plugin_dir_url(dirname(__FILE__));

        // Enqueue dashboard styles
        wp_enqueue_style(
            'wnq-analytics-dashboard',
            $plugin_url . 'assets/admin/analytics-dashboard.css',
            [],
            time()
        );
    }

    /**
     * Render main page
     */
    public static function render(): void
    {
        if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : 'dashboard';

        switch ($view) {
            case 'settings':
                self::renderSettings();
                break;
            default:
                self::renderDashboard();
                break;
        }
    }

    /**
     * Render dashboard view
     */
    private static function renderDashboard(): void
    {
        $client_id = self::getCurrentClientId();
        $config = AnalyticsConfig::getClientConfig($client_id);
        $credentials = AnalyticsConfig::getCredentials();

        // Check if configured
        if (!$credentials || !$config) {
            self::renderSetupPrompt();
            return;
        }

        ?>
        <div class="wrap wnq-analytics-admin">
            <!-- Header -->
            <div class="analytics-header">
                <div>
                    <h1>📊 Analytics Dashboard</h1>
                    <p class="subtitle"><?php echo esc_html($config['website_url'] ?? 'web-nique.com'); ?></p>
                </div>
                <div class="header-actions">
                    <button type="button" id="wnq-refresh-data" class="button">
                        🔄 Refresh Data
                    </button>
                    <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=settings'); ?>" class="button">
                        ⚙️ Settings
                    </a>
                </div>
            </div>

            <!-- Date Range Selector -->
            <div class="date-range-selector">
                <select id="wnq-date-range" class="date-range-select">
                    <option value="7">Last 7 Days</option>
                    <option value="30" selected>Last 30 Days</option>
                    <option value="90">Last 90 Days</option>
                </select>
            </div>

            <!-- Loading Indicator -->
            <div id="wnq-analytics-loading" class="analytics-loading">
                <div class="loading-spinner"></div>
                <p>Loading analytics data...</p>
            </div>

            <!-- Analytics Content -->
            <div id="wnq-analytics-content" style="display: none;">
                
                <!-- Overview Cards -->
                <div class="analytics-overview">
                    <div class="stat-card" id="stat-visitors">
                        <div class="stat-icon">👥</div>
                        <div class="stat-content">
                            <div class="stat-label">Total Visitors</div>
                            <div class="stat-value">-</div>
                            <div class="stat-change">-</div>
                        </div>
                    </div>

                    <div class="stat-card" id="stat-pageviews">
                        <div class="stat-icon">📄</div>
                        <div class="stat-content">
                            <div class="stat-label">Page Views</div>
                            <div class="stat-value">-</div>
                            <div class="stat-change">-</div>
                        </div>
                    </div>

                    <div class="stat-card" id="stat-session">
                        <div class="stat-icon">⏱️</div>
                        <div class="stat-content">
                            <div class="stat-label">Avg Session</div>
                            <div class="stat-value">-</div>
                            <div class="stat-change">-</div>
                        </div>
                    </div>

                    <div class="stat-card" id="stat-bounce">
                        <div class="stat-icon">📉</div>
                        <div class="stat-content">
                            <div class="stat-label">Bounce Rate</div>
                            <div class="stat-value">-</div>
                            <div class="stat-change">-</div>
                        </div>
                    </div>
                </div>

                <!-- Visitors Chart -->
                <div class="analytics-section">
                    <h2>Visitors Over Time</h2>
                    <div class="chart-container">
                        <canvas id="visitors-chart"></canvas>
                    </div>
                </div>

                <!-- Two Column Layout -->
                <div class="analytics-grid">
                    <!-- Traffic Sources -->
                    <div class="analytics-section">
                        <h2>Traffic Sources</h2>
                        <div class="chart-container chart-container-small">
                            <canvas id="sources-chart"></canvas>
                        </div>
                        <div id="sources-table" class="data-table"></div>
                    </div>

                    <!-- Device Breakdown -->
                    <div class="analytics-section">
                        <h2>Device Breakdown</h2>
                        <div class="chart-container chart-container-small">
                            <canvas id="devices-chart"></canvas>
                        </div>
                        <div id="devices-table" class="data-table"></div>
                    </div>
                </div>

                <!-- Top Pages -->
                <div class="analytics-section">
                    <h2>Top Pages</h2>
                    <div id="pages-table" class="data-table"></div>
                </div>

                <!-- Search Console -->
                <div class="analytics-section search-console-section">
                    <h2>🔍 Google Search Console</h2>
                    
                    <div class="search-console-overview">
                        <div class="sc-stat" id="sc-position">
                            <div class="sc-label">Average Position</div>
                            <div class="sc-value">-</div>
                            <div class="sc-change">-</div>
                        </div>
                        <div class="sc-stat" id="sc-clicks">
                            <div class="sc-label">Total Clicks</div>
                            <div class="sc-value">-</div>
                            <div class="sc-change">-</div>
                        </div>
                        <div class="sc-stat" id="sc-impressions">
                            <div class="sc-label">Impressions</div>
                            <div class="sc-value">-</div>
                            <div class="sc-change">-</div>
                        </div>
                        <div class="sc-stat" id="sc-ctr">
                            <div class="sc-label">CTR</div>
                            <div class="sc-value">-</div>
                            <div class="sc-change">-</div>
                        </div>
                    </div>

                    <h3>Top Keywords</h3>
                    <div id="keywords-table" class="data-table"></div>
                </div>

            </div>

            <!-- Footer -->
            <div class="analytics-footer">
                <p>Powered by <strong>WebNique</strong> Analytics Dashboard</p>
            </div>
        </div>

        <!-- CRITICAL: Load Chart.js inline to ensure it loads -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
        
        <!-- Debug and fallback script -->
        <script type="text/javascript">
        console.log('=== WebNique Analytics Debug ===');
        console.log('jQuery loaded:', typeof jQuery !== 'undefined');
        console.log('Chart.js loaded:', typeof Chart !== 'undefined');
        console.log('wnqAnalytics object:', typeof wnqAnalytics !== 'undefined' ? wnqAnalytics : 'NOT FOUND');
        
        // If Chart.js failed to load even inline, show error
        if (typeof Chart === 'undefined') {
            console.error('CRITICAL: Chart.js failed to load even from inline script!');
            console.error('This means CDNs are blocked or there is a network issue');
            document.getElementById('wnq-analytics-loading').innerHTML = 
                '<p style="color: red; padding: 20px;">Error: Chart.js library could not load. CDNs may be blocked. Check console for details.</p>';
        }
        
        // If wnqAnalytics is not defined, create fallback
        if (typeof wnqAnalytics === 'undefined') {
            console.error('ERROR: wnqAnalytics not defined by wp_localize_script!');
            window.wnqAnalytics = {
                ajaxUrl: '<?php echo admin_url('admin-ajax.php'); ?>',
                nonce: '<?php echo wp_create_nonce('wnq_analytics_nonce'); ?>',
                clientId: '<?php echo self::getCurrentClientId(); ?>',
                debug: true
            };
            console.log('Fallback wnqAnalytics created:', window.wnqAnalytics);
        }
        
        // Wait for DOM ready then trigger dashboard init
        if (typeof jQuery !== 'undefined') {
            jQuery(document).ready(function() {
                console.log('Document ready, dashboard should initialize now');
            });
        }
        </script>
        <?php
    }

    /**
     * Render settings view
     */
    private static function renderSettings(): void
    {
        $client_id = self::getCurrentClientId();
        $config = AnalyticsConfig::getClientConfig($client_id);
        $credentials = AnalyticsConfig::getCredentials();

        ?>
        <div class="wrap wnq-analytics-admin">
            <h1>Analytics Settings</h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-analytics'); ?>" class="page-title-action">← Back to Dashboard</a>

            <?php if (isset($_GET['saved'])): ?>
                <div class="notice notice-success"><p>Settings saved successfully!</p></div>
            <?php endif; ?>

            <?php if (isset($_GET['tested'])): ?>
                <div class="notice notice-success"><p>Connection test successful!</p></div>
            <?php endif; ?>

            <?php if (isset($_GET['error'])): ?>
                <div class="notice notice-error"><p>Error: <?php echo esc_html($_GET['message'] ?? 'Unknown error'); ?></p></div>
            <?php endif; ?>

            <div class="analytics-settings">
                
                <!-- Service Account -->
                <div class="settings-section">
                    <h2>Service Account Credentials</h2>
                    
                    <?php if ($credentials): ?>
                        <div class="credentials-status">
                            <span class="status-indicator status-active"></span>
                            <div>
                                <strong>Service Account Active</strong>
                                <p>Email: <?php echo esc_html($credentials['email']); ?></p>
                                <p>Project: <?php echo esc_html($credentials['project_id']); ?></p>
                                <?php if ($credentials['last_tested']): ?>
                                    <p>Last tested: <?php echo esc_html($credentials['last_tested']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="margin-top: 20px;">
                            <?php wp_nonce_field('wnq_test_connection'); ?>
                            <input type="hidden" name="action" value="wnq_test_analytics_connection">
                            <button type="submit" class="button">Test Connection</button>
                        </form>
                    <?php else: ?>
                        <p>No service account configured. Upload your JSON credentials file.</p>
                    <?php endif; ?>

                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" enctype="multipart/form-data" style="margin-top: 20px;">
                        <?php wp_nonce_field('wnq_save_analytics_settings'); ?>
                        <input type="hidden" name="action" value="wnq_save_analytics_settings">
                        
                        <table class="form-table">
                            <tr>
                                <th><label for="credentials_file">Upload Service Account JSON</label></th>
                                <td>
                                    <input type="file" name="credentials_file" id="credentials_file" accept=".json">
                                    <p class="description">Upload your Google Cloud service account JSON file</p>
                                </td>
                            </tr>
                        </table>

                        <h2>Client Configuration</h2>
                        <table class="form-table">
                            <tr>
                                <th><label for="client_name">Client Name</label></th>
                                <td>
                                    <input type="text" name="client_name" id="client_name" 
                                           value="<?php echo esc_attr($config['client_name'] ?? 'WebNique'); ?>" 
                                           class="regular-text">
                                </td>
                            </tr>
                            <tr>
                                <th><label for="ga4_property_id">GA4 Property ID</label></th>
                                <td>
                                    <input type="text" name="ga4_property_id" id="ga4_property_id" 
                                           value="<?php echo esc_attr($config['ga4_property_id'] ?? ''); ?>" 
                                           class="regular-text" placeholder="502405153">
                                    <p class="description">Find in: Google Analytics → Admin → Property Settings</p>
                                </td>
                            </tr>
                            <tr>
                                <th><label for="search_console_url">Search Console URL</label></th>
                                <td>
                                    <input type="text" name="search_console_url" id="search_console_url" 
                                           value="<?php echo esc_attr($config['search_console_url'] ?? ''); ?>" 
                                           class="regular-text" placeholder="sc-domain:web-nique.com">
                                    <p class="description">Example: sc-domain:yoursite.com</p>
                                </td>
                            </tr>
                            <tr>
                                <th><label for="website_url">Website URL</label></th>
                                <td>
                                    <input type="url" name="website_url" id="website_url" 
                                           value="<?php echo esc_attr($config['website_url'] ?? ''); ?>" 
                                           class="regular-text" placeholder="https://web-nique.com">
                                </td>
                            </tr>
                            <tr>
                                <th><label for="timezone">Timezone</label></th>
                                <td>
                                    <select name="timezone" id="timezone">
                                        <option value="America/New_York" <?php selected($config['timezone'] ?? 'America/New_York', 'America/New_York'); ?>>Eastern (New York)</option>
                                        <option value="America/Chicago" <?php selected($config['timezone'] ?? '', 'America/Chicago'); ?>>Central (Chicago)</option>
                                        <option value="America/Denver" <?php selected($config['timezone'] ?? '', 'America/Denver'); ?>>Mountain (Denver)</option>
                                        <option value="America/Los_Angeles" <?php selected($config['timezone'] ?? '', 'America/Los_Angeles'); ?>>Pacific (Los Angeles)</option>
                                    </select>
                                </td>
                            </tr>
                        </table>

                        <p class="submit">
                            <button type="submit" class="button button-primary">Save Settings</button>
                        </p>
                    </form>
                </div>

                <!-- Cache Management -->
                <div class="settings-section">
                    <h2>Cache Management</h2>
                    <p>Analytics data is cached for 1 hour to improve performance.</p>
                    
                    <?php
                    $cache_stats = AnalyticsCache::getStats();
                    ?>
                    <p><strong>Cache Status:</strong> <?php echo esc_html($cache_stats['total_entries']); ?> entries</p>
                    
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                        <?php wp_nonce_field('wnq_clear_cache'); ?>
                        <input type="hidden" name="action" value="wnq_clear_analytics_cache">
                        <button type="submit" class="button">Clear All Cache</button>
                    </form>
                </div>

            </div>
        </div>
        <?php
    }

    /**
     * Render setup prompt
     */
    private static function renderSetupPrompt(): void
    {
        ?>
        <div class="wrap wnq-analytics-admin">
            <div class="analytics-setup-prompt">
                <div class="setup-icon">📊</div>
                <h1>Welcome to Analytics Dashboard!</h1>
                <p>Get started by configuring your Google Analytics and Search Console connection.</p>
                
                <div class="setup-steps">
                    <div class="setup-step">
                        <span class="step-number">1</span>
                        <div class="step-content">
                            <h3>Upload Service Account</h3>
                            <p>Upload your Google Cloud service account JSON file</p>
                        </div>
                    </div>
                    <div class="setup-step">
                        <span class="step-number">2</span>
                        <div class="step-content">
                            <h3>Configure Properties</h3>
                            <p>Enter your GA4 Property ID and Search Console URL</p>
                        </div>
                    </div>
                    <div class="setup-step">
                        <span class="step-number">3</span>
                        <div class="step-content">
                            <h3>View Your Data</h3>
                            <p>Start analyzing your website performance!</p>
                        </div>
                    </div>
                </div>

                <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=settings'); ?>" 
                   class="button button-primary button-hero">
                    Get Started →
                </a>
            </div>
        </div>
        <?php
    }

    /**
     * AJAX: Get analytics data
     */
    public static function ajaxGetAnalyticsData(): void
    {
        // Verify nonce
        check_ajax_referer('wnq_analytics_nonce', 'nonce');

        // Check permissions
        if (!current_user_can('manage_options')) {
            error_log('WNQ Analytics AJAX - Permission denied');
            wp_send_json_error('Insufficient permissions');
            return;
        }

        // Get parameters
        $client_id = isset($_POST['client_id']) ? sanitize_text_field($_POST['client_id']) : '';
        $date_range = isset($_POST['date_range']) ? intval($_POST['date_range']) : 30;

        if (empty($client_id)) {
            error_log('WNQ Analytics AJAX - No client ID');
            wp_send_json_error('Client ID required');
            return;
        }

        error_log("WNQ Analytics AJAX - Starting for client: {$client_id}, range: {$date_range}");

        $data = [];

        // Get Google Analytics data
        try {
            error_log('WNQ Analytics AJAX - Loading GoogleAnalytics');
            $ga = new GoogleAnalytics($client_id);
            
            error_log('WNQ Analytics AJAX - Fetching data');
            $data['overview'] = $ga->getOverviewStats("{$date_range}daysAgo", 'today');
            $data['visitors_over_time'] = $ga->getVisitorsOverTime("{$date_range}daysAgo", 'today');
            $data['traffic_sources'] = $ga->getTrafficSources("{$date_range}daysAgo", 'today');
            $data['top_pages'] = $ga->getTopPages("{$date_range}daysAgo", 'today', 10);
            $data['devices'] = $ga->getDeviceBreakdown("{$date_range}daysAgo", 'today');
            
            error_log('WNQ Analytics AJAX - GA4 SUCCESS');
            
        } catch (\Exception $e) {
            $error = $e->getMessage();
            error_log('WNQ Analytics AJAX - GA4 ERROR: ' . $error);
            
            wp_send_json_error([
                'message' => 'Google Analytics Error: ' . $error,
                'type' => 'ga4_error',
            ]);
            return;
        }

        // Search Console temporarily disabled
        $data['search_console'] = [
            'error' => 'Search Console temporarily disabled for testing'
        ];

        error_log('WNQ Analytics AJAX - SUCCESS');
        wp_send_json_success($data);
    }

    /**
     * Handle save settings
     */
    public static function handleSaveSettings(): void
    {
        check_admin_referer('wnq_save_analytics_settings');

        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $client_id = self::getCurrentClientId();

        // Handle file upload
        if (isset($_FILES['credentials_file']) && $_FILES['credentials_file']['size'] > 0) {
            $file = $_FILES['credentials_file'];
            
            if ($file['type'] !== 'application/json') {
                wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&error=1&message=' . urlencode('Invalid file type')));
                exit;
            }

            $json_content = file_get_contents($file['tmp_name']);
            $credentials = json_decode($json_content, true);

            if (!$credentials) {
                wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&error=1&message=' . urlencode('Invalid JSON')));
                exit;
            }

            AnalyticsConfig::saveCredentials($credentials);
        }

        // Save config
        $config = [
            'client_id' => $client_id,
            'client_name' => sanitize_text_field($_POST['client_name'] ?? 'WebNique'),
            'ga4_property_id' => sanitize_text_field($_POST['ga4_property_id'] ?? ''),
            'search_console_url' => sanitize_text_field($_POST['search_console_url'] ?? ''),
            'website_url' => esc_url_raw($_POST['website_url'] ?? ''),
            'timezone' => sanitize_text_field($_POST['timezone'] ?? 'America/New_York'),
        ];

        AnalyticsConfig::saveClientConfig($config);

        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&saved=1'));
        exit;
    }

    /**
     * Handle test connection
     */
    public static function handleTestConnection(): void
    {
        check_admin_referer('wnq_test_connection');

        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $client_id = self::getCurrentClientId();
        $result = AnalyticsConfig::testConnection($client_id);

        if ($result['success']) {
            wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&tested=1'));
        } else {
            wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&error=1&message=' . urlencode($result['message'])));
        }
        exit;
    }

    /**
     * Handle clear cache
     */
    public static function handleClearCache(): void
    {
        check_admin_referer('wnq_clear_cache');

        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        AnalyticsCache::clearAll();

        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&cleared=1'));
        exit;
    }

    /**
     * Get current client ID
     */
    private static function getCurrentClientId(): string
    {
        return 'web-nique';
    }
}