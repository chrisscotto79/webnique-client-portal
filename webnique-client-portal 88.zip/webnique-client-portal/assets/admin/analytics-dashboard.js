/**
 * WebNique Analytics Dashboard - Frontend JavaScript
 * 
 * Handles data fetching, chart rendering, and UI updates
 * 
 * @package WebNique Portal
 */

(function($) {
    'use strict';

    // Global state
    let chartsInstances = {
        visitors: null,
        sources: null,
        devices: null
    };

    let currentDateRange = 30;

    /**
     * Initialize dashboard
     */
    function initDashboard() {
        // Bind event handlers
        bindEvents();

        // Load initial data
        loadAnalyticsData(currentDateRange);
    }

    /**
     * Bind event handlers
     */
    function bindEvents() {
        // Date range selector
        $('#wnq-date-range').on('change', function() {
            currentDateRange = parseInt($(this).val());
            loadAnalyticsData(currentDateRange);
        });

        // Refresh button
        $('#wnq-refresh-data').on('click', function() {
            $(this).prop('disabled', true).text('🔄 Refreshing...');
            loadAnalyticsData(currentDateRange, true);
        });
    }

    /**
     * Load analytics data via AJAX
     */
    function loadAnalyticsData(dateRange, forceRefresh = false) {
        showLoading();

        $.ajax({
            url: wnqAnalytics.ajaxUrl,
            type: 'POST',
            data: {
                action: 'wnq_get_analytics_data',
                nonce: wnqAnalytics.nonce,
                client_id: wnqAnalytics.clientId,
                date_range: dateRange,
                force_refresh: forceRefresh
            },
            success: function(response) {
                if (response.success) {
                    renderDashboard(response.data);
                    hideLoading();
                } else {
                    showError(response.data || 'Failed to load analytics data');
                }
            },
            error: function(xhr, status, error) {
                showError('Network error: ' + error);
            },
            complete: function() {
                $('#wnq-refresh-data').prop('disabled', false).text('🔄 Refresh Data');
            }
        });
    }

    /**
     * Render complete dashboard
     */
    function renderDashboard(data) {
        // Render overview stats
        if (data.overview) {
            renderOverviewStats(data.overview);
        }

        // Render visitors chart
        if (data.visitors_over_time) {
            renderVisitorsChart(data.visitors_over_time);
        }

        // Render traffic sources
        if (data.traffic_sources) {
            renderTrafficSources(data.traffic_sources);
        }

        // Render device breakdown
        if (data.devices) {
            renderDeviceBreakdown(data.devices);
        }

        // Render top pages
        if (data.top_pages) {
            renderTopPages(data.top_pages);
        }

        // Render Search Console data
        if (data.search_console) {
            renderSearchConsole(data.search_console);
        }
    }

    /**
     * Render overview stat cards
     */
    function renderOverviewStats(overview) {
        // Total Visitors
        updateStatCard('stat-visitors', {
            value: formatNumber(overview.total_users.value),
            change: overview.total_users.change
        });

        // Page Views
        updateStatCard('stat-pageviews', {
            value: formatNumber(overview.page_views.value),
            change: overview.page_views.change
        });

        // Avg Session Duration
        updateStatCard('stat-session', {
            value: overview.avg_session_duration.value,
            change: overview.avg_session_duration.change
        });

        // Bounce Rate
        updateStatCard('stat-bounce', {
            value: overview.bounce_rate.value + '%',
            change: overview.bounce_rate.change
        });
    }

    /**
     * Update individual stat card
     */
    function updateStatCard(cardId, data) {
        const $card = $('#' + cardId);
        
        $card.find('.stat-value').text(data.value);
        
        const changeHtml = formatChange(data.change);
        $card.find('.stat-change').html(changeHtml);
    }

    /**
     * Render visitors over time chart
     */
    function renderVisitorsChart(data) {
        const ctx = document.getElementById('visitors-chart');
        if (!ctx) return;

        // Destroy existing chart
        if (chartsInstances.visitors) {
            chartsInstances.visitors.destroy();
        }

        const labels = data.map(d => d.date);
        const visitors = data.map(d => d.users);
        const sessions = data.map(d => d.sessions);

        chartsInstances.visitors = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Visitors',
                        data: visitors,
                        borderColor: '#0d539e',
                        backgroundColor: 'rgba(13, 83, 158, 0.1)',
                        tension: 0.3,
                        fill: true
                    },
                    {
                        label: 'Sessions',
                        data: sessions,
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        tension: 0.3,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return formatNumber(value);
                            }
                        }
                    }
                }
            }
        });
    }

    /**
     * Render traffic sources chart and table
     */
    function renderTrafficSources(sources) {
        const ctx = document.getElementById('sources-chart');
        if (!ctx) return;

        // Destroy existing chart
        if (chartsInstances.sources) {
            chartsInstances.sources.destroy();
        }

        const labels = sources.map(s => s.source);
        const values = sources.map(s => s.sessions);
        const colors = [
            '#0d539e',
            '#10b981',
            '#f59e0b',
            '#ef4444',
            '#8b5cf6',
            '#ec4899'
        ];

        chartsInstances.sources = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    data: values,
                    backgroundColor: colors.slice(0, values.length),
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                const percentage = sources[context.dataIndex].percentage;
                                return label + ': ' + formatNumber(value) + ' (' + percentage + '%)';
                            }
                        }
                    }
                }
            }
        });

        // Render sources table
        let tableHtml = '<table class="wp-list-table widefat fixed striped">';
        tableHtml += '<thead><tr><th>Source</th><th>Sessions</th><th>Users</th><th>Bounce Rate</th></tr></thead>';
        tableHtml += '<tbody>';
        
        sources.forEach(source => {
            tableHtml += '<tr>';
            tableHtml += '<td><strong>' + source.source + '</strong></td>';
            tableHtml += '<td>' + formatNumber(source.sessions) + ' <span class="percentage">(' + source.percentage + '%)</span></td>';
            tableHtml += '<td>' + formatNumber(source.users) + '</td>';
            tableHtml += '<td>' + source.bounce_rate + '%</td>';
            tableHtml += '</tr>';
        });
        
        tableHtml += '</tbody></table>';
        $('#sources-table').html(tableHtml);
    }

    /**
     * Render device breakdown chart and table
     */
    function renderDeviceBreakdown(devices) {
        const ctx = document.getElementById('devices-chart');
        if (!ctx) return;

        // Destroy existing chart
        if (chartsInstances.devices) {
            chartsInstances.devices.destroy();
        }

        const labels = devices.map(d => d.device);
        const values = devices.map(d => d.sessions);
        const colors = ['#0d539e', '#10b981', '#f59e0b'];

        chartsInstances.devices = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: values,
                    backgroundColor: colors.slice(0, values.length),
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                const percentage = devices[context.dataIndex].percentage;
                                return label + ': ' + formatNumber(value) + ' (' + percentage + '%)';
                            }
                        }
                    }
                }
            }
        });

        // Render devices table
        let tableHtml = '<table class="wp-list-table widefat fixed striped">';
        tableHtml += '<thead><tr><th>Device</th><th>Sessions</th><th>Percentage</th></tr></thead>';
        tableHtml += '<tbody>';
        
        devices.forEach(device => {
            tableHtml += '<tr>';
            tableHtml += '<td><strong>' + device.device + '</strong></td>';
            tableHtml += '<td>' + formatNumber(device.sessions) + '</td>';
            tableHtml += '<td>' + device.percentage + '%</td>';
            tableHtml += '</tr>';
        });
        
        tableHtml += '</tbody></table>';
        $('#devices-table').html(tableHtml);
    }

    /**
     * Render top pages table
     */
    function renderTopPages(pages) {
        let tableHtml = '<table class="wp-list-table widefat fixed striped">';
        tableHtml += '<thead><tr><th>Page</th><th>Views</th><th>Users</th><th>Avg Time</th><th>Bounce Rate</th></tr></thead>';
        tableHtml += '<tbody>';
        
        pages.forEach(page => {
            tableHtml += '<tr>';
            tableHtml += '<td><strong>' + escapeHtml(page.path) + '</strong><br><small>' + escapeHtml(page.title) + '</small></td>';
            tableHtml += '<td>' + formatNumber(page.views) + '</td>';
            tableHtml += '<td>' + formatNumber(page.users) + '</td>';
            tableHtml += '<td>' + page.avg_time + '</td>';
            tableHtml += '<td>' + page.bounce_rate + '%</td>';
            tableHtml += '</tr>';
        });
        
        tableHtml += '</tbody></table>';
        $('#pages-table').html(tableHtml);
    }

    /**
     * Render Search Console data
     */
    function renderSearchConsole(searchConsole) {
        if (!searchConsole || searchConsole.error) {
            $('#sc-position .sc-value').text('N/A');
            $('#sc-clicks .sc-value').text('N/A');
            $('#sc-impressions .sc-value').text('N/A');
            $('#sc-ctr .sc-value').text('N/A');
            
            if (searchConsole && searchConsole.error) {
                $('#keywords-table').html('<p class="notice notice-warning">Search Console Error: ' + searchConsole.error + '</p>');
            }
            return;
        }

        const overview = searchConsole.overview;

        // Update Search Console stats
        $('#sc-position .sc-value').text(overview.position.value);
        $('#sc-position .sc-change').html(formatPositionChange(overview.position.change));

        $('#sc-clicks .sc-value').text(formatNumber(overview.clicks.value));
        $('#sc-clicks .sc-change').html(formatChange(overview.clicks.change));

        $('#sc-impressions .sc-value').text(formatNumber(overview.impressions.value));
        $('#sc-impressions .sc-change').html(formatChange(overview.impressions.change));

        $('#sc-ctr .sc-value').text(overview.ctr.value + '%');
        $('#sc-ctr .sc-change').html(formatChange(overview.ctr.change));

        // Render keywords table
        if (searchConsole.keywords) {
            renderKeywordsTable(searchConsole.keywords);
        }
    }

    /**
     * Render keywords table
     */
    function renderKeywordsTable(keywords) {
        let tableHtml = '<table class="wp-list-table widefat fixed striped">';
        tableHtml += '<thead><tr><th>Keyword</th><th>Position</th><th>Clicks</th><th>Impressions</th><th>CTR</th></tr></thead>';
        tableHtml += '<tbody>';
        
        keywords.forEach(keyword => {
            tableHtml += '<tr>';
            tableHtml += '<td><strong>' + escapeHtml(keyword.keyword) + '</strong></td>';
            tableHtml += '<td>' + keyword.position + '</td>';
            tableHtml += '<td>' + formatNumber(keyword.clicks) + '</td>';
            tableHtml += '<td>' + formatNumber(keyword.impressions) + '</td>';
            tableHtml += '<td>' + keyword.ctr + '%</td>';
            tableHtml += '</tr>';
        });
        
        tableHtml += '</tbody></table>';
        $('#keywords-table').html(tableHtml);
    }

    /**
     * Format change indicator
     */
    function formatChange(change) {
        if (!change || change.percentage === 0) {
            return '<span class="change-neutral">→ 0%</span>';
        }

        const arrow = change.direction === 'up' ? '↑' : '↓';
        const className = change.direction === 'up' ? 'change-up' : 'change-down';
        
        return '<span class="' + className + '">' + arrow + ' ' + change.percentage + '%</span>';
    }

    /**
     * Format position change (lower is better for SEO)
     */
    function formatPositionChange(change) {
        if (!change || change.difference === 0) {
            return '<span class="change-neutral">→ 0</span>';
        }

        const arrow = change.direction === 'up' ? '↑' : '↓';
        const className = change.direction === 'up' ? 'change-up' : 'change-down';
        
        return '<span class="' + className + '">' + arrow + ' ' + change.difference + '</span>';
    }

    /**
     * Format number with commas
     */
    function formatNumber(num) {
        if (num === null || num === undefined) return '0';
        return parseInt(num).toLocaleString();
    }

    /**
     * Escape HTML
     */
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Show loading state
     */
    function showLoading() {
        $('#wnq-analytics-loading').show();
        $('#wnq-analytics-content').hide();
    }

    /**
     * Hide loading state
     */
    function hideLoading() {
        $('#wnq-analytics-loading').hide();
        $('#wnq-analytics-content').show();
    }

    /**
     * Show error message
     */
    function showError(message) {
        $('#wnq-analytics-loading').hide();
        $('#wnq-analytics-content').html(
            '<div class="notice notice-error"><p><strong>Error:</strong> ' + escapeHtml(message) + '</p></div>'
        ).show();
    }

    /**
     * Initialize on document ready
     */
    $(document).ready(function() {
        // Wait for wnqAnalytics to be available
        if (typeof wnqAnalytics === 'undefined') {
            console.log('wnqAnalytics not ready yet, waiting...');
            // Wait a bit for fallback to create it
            setTimeout(function() {
                if (typeof wnqAnalytics !== 'undefined' && $('#wnq-analytics-content').length) {
                    console.log('wnqAnalytics now available, initializing dashboard');
                    initDashboard();
                } else {
                    console.error('wnqAnalytics still not available after delay');
                    showError('Configuration error: wnqAnalytics object not found');
                }
            }, 100);
        } else if ($('#wnq-analytics-content').length) {
            console.log('wnqAnalytics ready, initializing dashboard immediately');
            initDashboard();
        }
    });

})(jQuery);