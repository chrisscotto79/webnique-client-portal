<?php
/**
 * Plugin Name: SEO Database Updater
 * Description: One-time plugin to add task_group column to SEO tasks table. Deactivate and delete after use.
 * Version: 1.0
 * Author: WebNique
 */

if (!defined('ABSPATH')) {
    exit;
}

// Run on activation
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table = $wpdb->prefix . 'wnq_seo_tasks';
    
    // Check if column exists
    $column_exists = $wpdb->get_results("SHOW COLUMNS FROM `{$table}` LIKE 'task_group'");
    
    if (empty($column_exists)) {
        // Add the column
        $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `task_group` varchar(255) DEFAULT NULL AFTER `service_type`");
    }
    
    // Add admin notice
    set_transient('seo_updater_notice', true, 30);
});

// Show admin notice
add_action('admin_notices', function() {
    if (get_transient('seo_updater_notice')) {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        // Verify column was added
        $column_exists = $wpdb->get_results("SHOW COLUMNS FROM `{$table}` LIKE 'task_group'");
        
        if (!empty($column_exists)) {
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p><strong>✅ SUCCESS!</strong> The task_group column has been added to your SEO tasks table.</p>';
            echo '<p>You can now:</p>';
            echo '<ol>';
            echo '<li>Go to Plugins and <strong>deactivate</strong> "SEO Database Updater"</li>';
            echo '<li><strong>Delete</strong> this plugin</li>';
            echo '<li>Go to SEO Tracking and initialize tasks</li>';
            echo '</ol>';
            echo '</div>';
        } else {
            echo '<div class="notice notice-error is-dismissible">';
            echo '<p><strong>❌ ERROR!</strong> Could not add column. Please run this SQL manually in phpMyAdmin:</p>';
            echo '<pre style="background: #f5f5f5; padding: 10px; overflow-x: auto;">ALTER TABLE `' . $table . '` ADD COLUMN `task_group` varchar(255) DEFAULT NULL AFTER `service_type`;</pre>';
            echo '</div>';
        }
        
        delete_transient('seo_updater_notice');
    }
});