// assets/app/modules/tabs/dashboard.js
/**
 * Dashboard Tab - Clean & Focused
 * 
 * Shows: Welcome, Key metrics, Recent activity, Account status
 * Uses brand color #0d539e throughout
 */

import { el, pill, button, escapeHtml } from "../ui.js";
import {
  initFirebase,
  getThreads,
} from "../services/firebase.js";

// Prevent multiple simultaneous loads
let isLoading = false;

export function renderDashboard(main, side, state, shell) {
  // Clear any previous loading flag from a failed attempt
  if (!main || !side) {
    isLoading = false;
    return;
  }

  main.innerHTML = "";
  side.innerHTML = "";

  // RESTORE SHELL'S RIGHT SIDEBAR (in case it was hidden)
  if (side && side.parentElement) {
    side.parentElement.style.display = "block";
  }
  
  // RESTORE MAIN AREA TO NORMAL WIDTH
  if (main && main.parentElement) {
    main.parentElement.style.gridColumn = "span 8";
  }

  if (shell?.setStatus) {
    shell.setStatus("Loading dashboard...", "neutral");
  }

  // Initialize and load
  loadDashboard(main, side, state, shell);
}

/**
 * Load dashboard data
 */
async function loadDashboard(main, side, state, shell) {
  // Prevent multiple simultaneous loads
  if (isLoading) {
    console.log("[Dashboard] Already loading, skipping");
    return;
  }

  isLoading = true;

  // Show loading
  main.appendChild(
    el("div", {
      style: { padding: "40px", textAlign: "center" },
      html: '<div class="wnq-spinner"></div>',
    })
  );

  try {
    // Initialize Firebase (safe to call multiple times)
    const firebaseReady = await initFirebase();
    
    if (!firebaseReady) {
      console.warn("[Dashboard] Firebase not initialized, using fallback data");
    }

    // Get threads for request counts
    let threads = [];
    try {
      if (firebaseReady && state.clientId) {
        threads = await getThreads(state.clientId);
      }
    } catch (error) {
      console.warn("[Dashboard] Could not load threads:", error.message);
      // Continue with empty threads array
    }

    if (shell?.setStatus) {
      shell.setStatus("Ready", "good");
    }

    // Render interface
    main.innerHTML = "";
    renderInterface(main, side, state, threads);

  } catch (error) {
    console.error("[Dashboard] Load error:", error);
    main.innerHTML = "";
    showError(main, error.message);
    if (shell?.setStatus) {
      shell.setStatus("Error", "bad");
    }
  } finally {
    isLoading = false;
  }
}

/**
 * Render complete interface
 */
function renderInterface(main, side, state, threads) {
  // Header
  main.appendChild(createHeader(state));

  // Stats cards
  main.appendChild(createStatsCards(threads));

  // Recent activity
  main.appendChild(createRecentActivity(threads));

  // Sidebar
  renderSidebar(side, state);
}

/**
 * Create header
 */
function createHeader(state) {
  const header = el("div", {
    style: {
      marginBottom: "32px",
      paddingBottom: "20px",
      borderBottom: "2px solid #e5e7eb",
    },
  });

  const greeting = getGreeting();
  const userName = state.user?.name || "there";

  header.appendChild(
    el("h1", {
      text: `${greeting}, ${userName}!`,
      style: {
        fontSize: "32px",
        fontWeight: "900",
        color: "#111827",
        marginBottom: "8px",
        letterSpacing: "-0.02em",
      },
    })
  );

  header.appendChild(
    el("p", {
      text: "Here's what's happening with your account.",
      style: {
        fontSize: "16px",
        color: "#6b7280",
        margin: "0",
      },
    })
  );

  return header;
}

/**
 * Get time-based greeting
 */
function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

/**
 * Create stats cards
 */
function createStatsCards(threads) {
  const section = el("div", {
    style: {
      marginBottom: "32px",
    },
  });

  const grid = el("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
      gap: "20px",
    },
  });

  // Calculate counts
  const openCount = threads.filter(t => t.status === "open").length;
  const totalCount = threads.length;
  const completedCount = threads.filter(t => t.status === "closed").length;

  const stats = [
    {
      label: "OPEN REQUESTS",
      value: openCount,
      icon: "📝",
      color: "#0d539e",
    },
    {
      label: "TOTAL REQUESTS",
      value: totalCount,
      icon: "📊",
      color: "#6b7280",
    },
    {
      label: "COMPLETED",
      value: completedCount,
      icon: "✅",
      color: "#10b981",
    },
  ];

  stats.forEach((stat) => {
    grid.appendChild(createStatCard(stat));
  });

  section.appendChild(grid);
  return section;
}

/**
 * Create individual stat card
 */
function createStatCard({ label, value, icon, color }) {
  const card = el("div", {
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "12px",
      padding: "24px",
      boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
      transition: "all 0.2s ease",
      cursor: "default",
    },
  });

  card.addEventListener("mouseenter", () => {
    card.style.transform = "translateY(-2px)";
    card.style.boxShadow = "0 4px 6px rgba(0,0,0,0.1)";
  });

  card.addEventListener("mouseleave", () => {
    card.style.transform = "translateY(0)";
    card.style.boxShadow = "0 1px 3px rgba(0,0,0,0.1)";
  });

  // Icon
  card.appendChild(
    el("div", {
      text: icon,
      style: {
        fontSize: "32px",
        marginBottom: "12px",
      },
    })
  );

  // Label
  card.appendChild(
    el("div", {
      text: label,
      style: {
        fontSize: "12px",
        fontWeight: "700",
        color: "#6b7280",
        letterSpacing: "0.05em",
        marginBottom: "8px",
      },
    })
  );

  // Value
  card.appendChild(
    el("div", {
      text: value.toString(),
      style: {
        fontSize: "48px",
        fontWeight: "900",
        color: color,
        lineHeight: "1",
      },
    })
  );

  return card;
}

/**
 * Create recent activity section
 */
function createRecentActivity(threads) {
  const section = el("div", {
    style: {
      marginBottom: "32px",
    },
  });

  section.appendChild(
    el("h2", {
      text: "Recent Activity",
      style: {
        fontSize: "20px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "16px",
      },
    })
  );

  const card = el("div", {
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "12px",
      padding: "24px",
      boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
    },
  });

  // Sort threads by last_updated
  const recentThreads = [...threads]
    .sort((a, b) => {
      const dateA = new Date(a.last_updated || 0);
      const dateB = new Date(b.last_updated || 0);
      return dateB - dateA;
    })
    .slice(0, 5);

  if (recentThreads.length === 0) {
    card.appendChild(
      el("p", {
        text: "No recent activity. Create your first request to get started!",
        style: {
          color: "#6b7280",
          textAlign: "center",
          padding: "20px 0",
        },
      })
    );
  } else {
    recentThreads.forEach((thread, index) => {
      card.appendChild(
        createActivityItem(thread, index < recentThreads.length - 1)
      );
    });
  }

  section.appendChild(card);
  return section;
}

/**
 * Create activity item
 */
function createActivityItem(thread, showBorder) {
  const item = el("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "16px",
      padding: "16px 0",
      borderBottom: showBorder ? "1px solid #e5e7eb" : "none",
    },
  });

  // Icon
  const statusIcon = thread.status === "closed" ? "✅" : "📝";
  
  item.appendChild(
    el("div", {
      text: statusIcon,
      style: {
        fontSize: "24px",
        width: "48px",
        height: "48px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#f3f4f6",
        borderRadius: "12px",
      },
    })
  );

  // Content
  const content = el("div", { style: { flex: "1" } });

  content.appendChild(
    el("div", {
      text: escapeHtml(thread.subject || "Untitled Request"),
      style: {
        fontSize: "15px",
        fontWeight: "600",
        color: "#111827",
        marginBottom: "4px",
      },
    })
  );

  content.appendChild(
    el("div", {
      text: formatActivityTime(thread.last_updated),
      style: {
        fontSize: "13px",
        color: "#6b7280",
      },
    })
  );

  item.appendChild(content);

  // Status pill
  item.appendChild(
    pill(
      escapeHtml(thread.status || "open"),
      thread.status === "closed" ? "neutral" : "good"
    )
  );

  return item;
}

/**
 * Format activity time
 */
function formatActivityTime(timestamp) {
  if (!timestamp) return "Recently";

  try {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));

    if (diffHours < 1) return "Just now";
    if (diffHours < 24) return `${diffHours} hours ago`;
    if (diffHours < 48) return "Yesterday";

    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    });
  } catch (e) {
    return "Recently";
  }
}

/**
 * Render sidebar
 */
function renderSidebar(side, state) {
  // Account status card
  const accountCard = el("div", {
    style: {
      background: "linear-gradient(135deg, #0d539e 0%, #0a4380 100%)",
      borderRadius: "16px",
      padding: "24px",
      color: "white",
      marginBottom: "20px",
    },
  });

  accountCard.appendChild(
    el("div", {
      text: "ACCOUNT STATUS",
      style: {
        fontSize: "11px",
        fontWeight: "700",
        letterSpacing: "0.1em",
        opacity: "0.8",
        marginBottom: "12px",
      },
    })
  );

  accountCard.appendChild(
    el("div", {
      text: "Active",
      style: {
        fontSize: "28px",
        fontWeight: "900",
        marginBottom: "16px",
      },
    })
  );

  const details = [
    { label: "Client", value: state.clientId || "N/A" },
    { label: "Mode", value: state.isAdmin ? "Admin" : "Client" },
    { label: "User", value: state.user?.name || "N/A" },
  ];

  details.forEach((detail) => {
    const row = el("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        padding: "8px 0",
        borderTop: "1px solid rgba(255,255,255,0.1)",
        fontSize: "13px",
      },
    });

    row.appendChild(
      el("span", { text: detail.label, style: { opacity: "0.8" } })
    );

    row.appendChild(
      el("span", {
        text: escapeHtml(detail.value),
        style: { fontWeight: "600" },
      })
    );

    accountCard.appendChild(row);
  });

  side.appendChild(accountCard);

  // Quick links card
  const linksCard = el("div", {
    style: {
      background: "white",
      border: "1px solid #e5e7eb",
      borderRadius: "16px",
      padding: "20px",
      marginBottom: "20px",
    },
  });

  linksCard.appendChild(
    el("h3", {
      text: "Quick Links",
      style: {
        fontSize: "16px",
        fontWeight: "800",
        color: "#111827",
        marginBottom: "16px",
      },
    })
  );

  const links = [
    { text: "📝 New Request", action: "requests" },
    { text: "💳 Subscription", action: "subscription" },
    { text: "📊 Analytics", action: "analytics" },
    { text: "⚙️ Settings", action: "settings" },
  ];

  links.forEach((link, index) => {
    const linkEl = el("div", {
      text: link.text,
      style: {
        padding: "12px",
        borderRadius: "8px",
        cursor: "pointer",
        fontSize: "14px",
        fontWeight: "600",
        color: "#374151",
        marginBottom: index < links.length - 1 ? "8px" : "0",
        transition: "all 0.2s ease",
      },
    });

    linkEl.addEventListener("mouseenter", () => {
      linkEl.style.background = "#f0f9ff";
      linkEl.style.color = "#0d539e";
    });

    linkEl.addEventListener("mouseleave", () => {
      linkEl.style.background = "transparent";
      linkEl.style.color = "#374151";
    });

    linkEl.addEventListener("click", () => {
      console.log(`Navigate to ${link.action}`);
      // TODO: Implement tab navigation
    });

    linksCard.appendChild(linkEl);
  });

  side.appendChild(linksCard);

  // Help card
  const helpCard = el("div", {
    style: {
      background: "#fef3c7",
      border: "1px solid #fde047",
      borderRadius: "16px",
      padding: "20px",
    },
  });

  helpCard.appendChild(
    el("div", {
      text: "💬",
      style: { fontSize: "32px", marginBottom: "12px" },
    })
  );

  helpCard.appendChild(
    el("h3", {
      text: "Need Help?",
      style: {
        fontSize: "16px",
        fontWeight: "800",
        color: "#78350f",
        marginBottom: "8px",
      },
    })
  );

  helpCard.appendChild(
    el("p", {
      text: "Our support team is here to help you.",
      style: {
        fontSize: "13px",
        color: "#92400e",
        marginBottom: "12px",
        lineHeight: "1.5",
      },
    })
  );

  const helpBtn = button(
    state,
    "Contact Support",
    () => {
      console.log("Navigate to requests");
      // TODO: Navigate to requests tab
    },
    "solid"
  );

  helpBtn.style.width = "100%";
  helpBtn.style.background = "#f59e0b";
  helpBtn.style.borderColor = "#f59e0b";

  helpCard.appendChild(helpBtn);
  side.appendChild(helpCard);
}

/**
 * Show error
 */
function showError(container, message) {
  container.innerHTML = "";
  container.appendChild(
    el("div", {
      class: "wnq-alert wnq-alert-danger",
      html: `<strong>Error:</strong> ${escapeHtml(message)}`,
    })
  );
}