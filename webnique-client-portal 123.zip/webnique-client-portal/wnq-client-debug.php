<?php
/**
 * Plugin Name: WNQ Task Debug
 * Description: Debug helper - check task system status and create/update table
 * Version: 1.0
 */

// Show status in admin
add_action('admin_notices', function() {
    if (!current_user_can('manage_options')) return;
    
    global $wpdb;
    $table = $wpdb->prefix . 'wnq_tasks';
    
    // Check if table exists
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
    
    echo '<div class="notice notice-info" style="padding: 20px; background: white; border-left: 4px solid #0d539e;">';
    echo '<h2>🎯 WNQ Task System Status</h2>';
    
    // Table status
    if ($table_exists) {
        echo '<p style="font-size: 14px;">✅ Table exists: <code>' . $table . '</code></p>';
        
        // Check if new columns exist
        $columns = $wpdb->get_col("DESCRIBE $table");
        $has_task_type = in_array('task_type', $columns);
        $has_recurring = in_array('is_recurring', $columns);
        $has_archived = in_array('archived_at', $columns);
        
        echo '<h3>Column Status:</h3>';
        echo '<p>' . ($has_task_type ? '✅' : '❌') . ' <code>task_type</code> - Task categories</p>';
        echo '<p>' . ($has_recurring ? '✅' : '❌') . ' <code>is_recurring</code> - Recurring tasks</p>';
        echo '<p>' . ($has_archived ? '✅' : '❌') . ' <code>archived_at</code> - Archive system</p>';
        
        if (!$has_task_type || !$has_recurring || !$has_archived) {
            if (isset($_GET['wnq_add_task_columns'])) {
                $wpdb->query("ALTER TABLE $table ADD COLUMN IF NOT EXISTS task_type varchar(50) DEFAULT 'general' AFTER status");
                $wpdb->query("ALTER TABLE $table ADD COLUMN IF NOT EXISTS is_recurring tinyint(1) DEFAULT 0 AFTER notes");
                $wpdb->query("ALTER TABLE $table ADD COLUMN IF NOT EXISTS recurring_frequency varchar(50) DEFAULT NULL AFTER is_recurring");
                $wpdb->query("ALTER TABLE $table ADD COLUMN IF NOT EXISTS recurring_data longtext DEFAULT NULL AFTER recurring_frequency");
                $wpdb->query("ALTER TABLE $table ADD COLUMN IF NOT EXISTS archived_at datetime DEFAULT NULL AFTER completed_at");
                $wpdb->query("ALTER TABLE $table ADD COLUMN IF NOT EXISTS completion_count int(11) DEFAULT 0 AFTER archived_at");
                $wpdb->query("ALTER TABLE $table ADD COLUMN IF NOT EXISTS last_completed_date date DEFAULT NULL AFTER completion_count");
                
                echo '<p style="color: green; font-weight: bold;">✅ Columns added! Refresh page to see updated status.</p>';
            } else {
                echo '<p><a href="' . add_query_arg('wnq_add_task_columns', '1') . '" class="button button-primary">➕ Add Enhanced Features Columns</a></p>';
            }
        }
        
        // Count tasks
        $count = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE archived_at IS NULL");
        $archived_count = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE archived_at IS NOT NULL");
        echo '<hr>';
        echo '<p>📊 Active tasks: <strong>' . $count . '</strong></p>';
        echo '<p>📦 Archived tasks: <strong>' . $archived_count . '</strong></p>';
        
        // Show tasks
        if ($count > 0) {
            $tasks = $wpdb->get_results("SELECT id, title, status, priority, assigned_to, due_date FROM $table WHERE archived_at IS NULL LIMIT 10");
            echo '<h3>Recent Tasks:</h3>';
            echo '<table class="wp-list-table widefat" style="max-width: 900px;">';
            echo '<tr><th>ID</th><th>Title</th><th>Status</th><th>Priority</th><th>Assigned To</th><th>Due Date</th></tr>';
            foreach ($tasks as $task) {
                echo '<tr>';
                echo '<td>' . esc_html($task->id) . '</td>';
                echo '<td>' . esc_html($task->title) . '</td>';
                echo '<td>' . esc_html($task->status) . '</td>';
                echo '<td>' . esc_html($task->priority) . '</td>';
                echo '<td>' . esc_html($task->assigned_to ?: 'Unassigned') . '</td>';
                echo '<td>' . esc_html($task->due_date ?: 'No date') . '</td>';
                echo '</tr>';
            }
            echo '</table>';
        }
    } else {
        echo '<p style="color: red; font-weight: bold;">❌ Table does NOT exist: <code>' . $table . '</code></p>';
        
        // Create table button
        if (isset($_GET['wnq_create_task_table'])) {
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            
            $sql = "CREATE TABLE $table (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                title varchar(255) NOT NULL,
                description longtext DEFAULT NULL,
                status varchar(50) DEFAULT 'todo',
                task_type varchar(50) DEFAULT 'general',
                priority varchar(50) DEFAULT 'medium',
                assigned_to varchar(255) DEFAULT NULL,
                due_date date DEFAULT NULL,
                client_id varchar(100) DEFAULT NULL,
                attachments longtext DEFAULT NULL,
                notes longtext DEFAULT NULL,
                is_recurring tinyint(1) DEFAULT 0,
                recurring_frequency varchar(50) DEFAULT NULL,
                recurring_data longtext DEFAULT NULL,
                position int(11) DEFAULT 0,
                created_by bigint(20) DEFAULT NULL,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                completed_at datetime DEFAULT NULL,
                archived_at datetime DEFAULT NULL,
                completion_count int(11) DEFAULT 0,
                last_completed_date date DEFAULT NULL,
                
                PRIMARY KEY (id),
                KEY status (status),
                KEY task_type (task_type),
                KEY assigned_to (assigned_to),
                KEY priority (priority),
                KEY due_date (due_date),
                KEY is_recurring (is_recurring),
                KEY archived_at (archived_at)
            ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
            
            dbDelta($sql);
            
            echo '<p style="color: green; font-weight: bold;">✅ Table created! <a href="' . admin_url('admin.php?page=wnq-tasks') . '">Go to Tasks</a></p>';
        } else {
            echo '<p><a href="' . add_query_arg('wnq_create_task_table', '1') . '" class="button button-primary button-hero">Create Tasks Table Now</a></p>';
        }
    }
    
    // Check form handlers
    echo '<hr>';
    echo '<h3>Form Handler Status:</h3>';
    
    $save_handler = has_action('admin_post_wnq_save_task');
    $delete_handler = has_action('admin_post_wnq_delete_task');
    $ajax_status = has_action('wp_ajax_wnq_update_task_status');
    
    echo '<p>' . ($save_handler ? '✅' : '❌') . ' Save handler: <code>admin_post_wnq_save_task</code></p>';
    echo '<p>' . ($delete_handler ? '✅' : '❌') . ' Delete handler: <code>admin_post_wnq_delete_task</code></p>';
    echo '<p>' . ($ajax_status ? '✅' : '❌') . ' AJAX handler: <code>wp_ajax_wnq_update_task_status</code></p>';
    
    // Check files
    echo '<hr>';
    echo '<h3>File Status:</h3>';
    
    $task_model = file_exists(WP_PLUGIN_DIR . '/webnique-client-portal/includes/Models/Task.php');
    $tasks_admin = file_exists(WP_PLUGIN_DIR . '/webnique-client-portal/admin/TasksAdmin.php');
    
    echo '<p>' . ($task_model ? '✅' : '❌') . ' Task Model: <code>includes/Models/Task.php</code></p>';
    echo '<p>' . ($tasks_admin ? '✅' : '❌') . ' Tasks Admin: <code>admin/TasksAdmin.php</code></p>';
    
    if (!$task_model || !$tasks_admin) {
        echo '<p style="color: red; font-weight: bold;">⚠️ Missing files! Make sure to upload both files.</p>';
    }
    
    echo '</div>';
});