<?php
/**
 * SEO Model - FIXED VERSION
 * 
 * Task Structure:
 * - On-Page SEO: One-time tasks per client (from operations manual)
 * - Technical SEO: One-time tasks per client
 * - Local SEO: One-time tasks per client
 * - Off-Page SEO: One-time tasks per client
 * - Monthly Tasks: Recurring monthly tasks
 * 
 * @package WebNique Portal
 */

namespace WNQ\Models;

if (!defined('ABSPATH')) {
    exit;
}

final class SEO
{
    public static function createTables(): void
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        $table_seo = $wpdb->prefix . 'wnq_seo_tasks';
        $sql_seo = "CREATE TABLE IF NOT EXISTS $table_seo (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            client_id varchar(100) NOT NULL,
            service_type varchar(50) NOT NULL,
            task_group varchar(255),
            task_name varchar(255) NOT NULL,
            task_description text,
            status varchar(20) DEFAULT 'pending',
            completed_date datetime,
            notes text,
            is_recurring tinyint(1) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY client_service (client_id, service_type),
            KEY status (status)
        ) $charset_collate;";

        $table_reports = $wpdb->prefix . 'wnq_seo_reports';
        $sql_reports = "CREATE TABLE IF NOT EXISTS $table_reports (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            client_id varchar(100) NOT NULL,
            month_year varchar(7) NOT NULL,
            report_url varchar(500),
            keywords_tracked int DEFAULT 0,
            avg_position decimal(5,2),
            organic_traffic int DEFAULT 0,
            backlinks_added int DEFAULT 0,
            summary text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY client_month (client_id, month_year)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_seo);
        dbDelta($sql_reports);
    }

    public static function createTask(array $data): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        return (bool) $wpdb->insert($table, [
            'client_id' => $data['client_id'],
            'service_type' => $data['service_type'],
            'task_group' => $data['task_group'] ?? '',
            'task_name' => $data['task_name'],
            'task_description' => $data['task_description'] ?? '',
            'status' => $data['status'] ?? 'pending',
            'notes' => $data['notes'] ?? '',
            'is_recurring' => $data['is_recurring'] ?? 0,
        ]);
    }

    public static function updateTask(int $id, array $data): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        $update_data = [];
        $allowed_fields = ['task_name', 'task_description', 'status', 'notes', 'completed_date'];
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                $update_data[$field] = $data[$field];
            }
        }
        
        if (empty($update_data)) {
            return false;
        }
        
        return (bool) $wpdb->update($table, $update_data, ['id' => $id]);
    }

    public static function completeTask(int $id): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        return (bool) $wpdb->update($table, [
            'status' => 'completed',
            'completed_date' => current_time('mysql')
        ], ['id' => $id]);
    }

    public static function uncompleteTask(int $id): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        return (bool) $wpdb->update($table, [
            'status' => 'pending',
            'completed_date' => null
        ], ['id' => $id]);
    }

    public static function getTasksByClient(string $client_id, ?string $service_type = null): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        if ($service_type) {
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table WHERE client_id = %s AND service_type = %s ORDER BY task_group, id",
                $client_id,
                $service_type
            ), ARRAY_A);
        } else {
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table WHERE client_id = %s ORDER BY service_type, task_group, id",
                $client_id
            ), ARRAY_A);
        }
        
        return $results ?: [];
    }

    public static function deleteTask(int $id): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        return (bool) $wpdb->delete($table, ['id' => $id]);
    }

    public static function saveReport(array $data): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_reports';
        
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE client_id = %s AND month_year = %s",
            $data['client_id'],
            $data['month_year']
        ));
        
        if ($existing) {
            return (bool) $wpdb->update($table, [
                'report_url' => $data['report_url'] ?? '',
                'keywords_tracked' => $data['keywords_tracked'] ?? 0,
                'avg_position' => $data['avg_position'] ?? 0,
                'organic_traffic' => $data['organic_traffic'] ?? 0,
                'backlinks_added' => $data['backlinks_added'] ?? 0,
                'summary' => $data['summary'] ?? '',
            ], [
                'client_id' => $data['client_id'],
                'month_year' => $data['month_year']
            ]);
        } else {
            return (bool) $wpdb->insert($table, [
                'client_id' => $data['client_id'],
                'month_year' => $data['month_year'],
                'report_url' => $data['report_url'] ?? '',
                'keywords_tracked' => $data['keywords_tracked'] ?? 0,
                'avg_position' => $data['avg_position'] ?? 0,
                'organic_traffic' => $data['organic_traffic'] ?? 0,
                'backlinks_added' => $data['backlinks_added'] ?? 0,
                'summary' => $data['summary'] ?? '',
            ]);
        }
    }

    public static function getReport(string $client_id, string $month_year): ?array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_reports';
        
        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE client_id = %s AND month_year = %s",
            $client_id,
            $month_year
        ), ARRAY_A);
        
        return $result ?: null;
    }

    public static function getClientReports(string $client_id): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_reports';
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE client_id = %s ORDER BY month_year DESC",
            $client_id
        ), ARRAY_A);
        
        return $results ?: [];
    }

    public static function getServiceTypeProgress(string $client_id): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT 
                service_type,
                COUNT(*) as total,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
            FROM $table 
            WHERE client_id = %s
            GROUP BY service_type",
            $client_id
        ), ARRAY_A);
        
        return $results ?: [];
    }

    public static function getOverallProgress(string $client_id): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wnq_seo_tasks';
        
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(*) as total_tasks,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_tasks,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_tasks,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_tasks
            FROM $table 
            WHERE client_id = %s",
            $client_id
        ), ARRAY_A);
        
        $stats = $stats ?: ['total_tasks' => 0, 'completed_tasks' => 0, 'in_progress_tasks' => 0, 'pending_tasks' => 0];
        
        $stats['completion_percentage'] = $stats['total_tasks'] > 0 
            ? round(($stats['completed_tasks'] / $stats['total_tasks']) * 100, 1)
            : 0;
        
        return $stats;
    }

    // Initialize client SEO tasks (one-time per client)
    public static function initializeClientTasks(string $client_id): bool
    {
        // ON-PAGE SEO TASKS (from operations manual - Section 1-9)
        $onpage_tasks = [
            'Section 1: Standards Alignment' => [
                'Confirm "On-Page Only" scope',
                'Re-affirm non-negotiables (one keyword per page, intent-first, human-first)',
                'Confirm global standards (keyword usage, heading rules, URL rules)',
                'Assign roles (SEO Strategist, Writer/Editor, Web Builder, QA Reviewer)',
            ],
            'Section 2: Client Intake & Page Selection' => [
                'Complete client intake questionnaire',
                'Build full page inventory (indexable pages only)',
                'Classify every page by role (Primary/Supporting/Informational/Utility)',
                'Assign priority levels (P1/P2/P3)',
                'Map intent for each page (Learn/Compare/Take action)',
                'Apply "one page, one purpose" test',
                'Identify page exclusions',
            ],
            'Section 3: Keyword Selection & Mapping' => [
                'Define primary keyword for each page',
                'Define 3-8 supporting keywords per page',
                'Validate keyword criteria (relevance, intent match, clarity)',
                'Check and resolve cannibalization',
                'Lock keyword assignments',
            ],
            'Section 4: Page Structure & Content Framework' => [
                'Confirm "one page, one topic" for each page',
                'Create page structure outline (Title/H1/Intro/H2/H3/CTA)',
                'Write/review H1 (exactly one, includes keyword)',
                'Rewrite/approve introduction',
                'Build H2/H3 map',
                'Enforce writing standards (plain language, short paragraphs)',
                'Define CTAs',
            ],
            'Section 5: On-Page Optimization Checklist' => [
                'Optimize Title Tag (unique, descriptive, keyword included)',
                'Optimize H1 (one only, aligns with title)',
                'Optimize Meta Description (unique, accurate, intent-matching)',
                'Optimize URL Slug (short, readable, topic-focused)',
                'Optimize body content (keyword early, satisfies intent)',
                'Optimize headings hierarchy (H2/H3 logical)',
                'Add internal links (relevant, descriptive anchors)',
                'Image optimization (alt text, file naming)',
                'Readability pass',
            ],
            'Section 6: Internal Linking Strategy' => [
                'Apply internal linking principles',
                'Place links in high-value areas',
                'Enforce anchor text standards',
                'Link by page type (Service/Blog/Utility)',
                'QA internal links',
            ],
            'Section 7: Visual Content & Image Optimization' => [
                'Confirm every visual serves a purpose',
                'Ensure relevance + intent alignment',
                'Apply placement rules',
                'Write alt text for every image',
                'Check file names',
                'Prevent visual overload',
            ],
            'Section 8: QA & Completion Standards' => [
                'Perform QA after optimization',
                'Check purpose/intent → structure → metadata → content quality',
                'Document completion record',
                'Approval criteria check',
            ],
            'Section 9: Post-Launch Monitoring' => [
                'Verify live page rendering',
                'Verify on-page elements live',
                'Review search snippet appearance',
                'Reality vs intent reread',
                'Mark "On-Page SEO Fully Complete"',
            ],
        ];

        $technical_tasks = [
            'Site Speed & Performance' => [
                'Run PageSpeed Insights analysis',
                'Check Core Web Vitals scores',
                'Identify render-blocking resources',
                'Review JavaScript execution time',
            ],
            'Mobile Optimization' => [
                'Test mobile responsiveness',
                'Check mobile usability in GSC',
                'Verify touch elements are properly sized',
                'Test mobile page speed',
            ],
            'XML Sitemap & Robots.txt' => [
                'Update XML sitemap',
                'Verify sitemap submission in GSC',
                'Review robots.txt configuration',
                'Check sitemap is accessible',
            ],
            'Schema Markup' => [
                'Implement LocalBusiness schema',
                'Add Organization schema',
                'Validate schema with Rich Results Test',
                'Add breadcrumb schema',
            ],
            'Site Architecture' => [
                'Review URL structure',
                'Check internal linking depth',
                'Verify canonical tags',
                'Review site navigation structure',
            ],
        ];

        $local_tasks = [
            'Google Business Profile' => [
                'Complete GMB profile setup',
                'Add business photos (10-15 initial)',
                'Set up business categories',
                'Configure business hours',
                'Add service areas',
            ],
            'NAP Consistency' => [
                'Audit NAP across all citations',
                'Update NAP on website',
                'Verify NAP in schema markup',
                'Document NAP standard',
            ],
            'Initial Citations' => [
                'Build 10-15 core citations',
                'Submit to major directories',
                'Verify citation accuracy',
                'Document all citations',
            ],
            'Review Foundation' => [
                'Set up review monitoring',
                'Create review request system',
                'Document review response process',
            ],
            'Local Content Setup' => [
                'Create location-specific pages',
                'Set up service area pages',
                'Add local keywords to content',
                'Include local references',
            ],
        ];

        $offpage_tasks = [
            'Backlink Foundation' => [
                'Audit existing backlinks',
                'Identify initial link opportunities (20+)',
                'Create outreach template',
                'Set up backlink tracking system',
            ],
            'Content Partnerships' => [
                'Identify guest post opportunities (10+)',
                'Create guest post pitch templates',
                'Document partnership guidelines',
            ],
            'Directory Strategy' => [
                'Identify relevant directories (15-20)',
                'Create directory submission checklist',
                'Complete initial submissions',
            ],
            'Brand Monitoring Setup' => [
                'Set up brand mention monitoring',
                'Create mention tracking system',
                'Document response process',
            ],
            'Social Foundation' => [
                'Set up social profiles',
                'Create social posting schedule',
                'Link social to website',
            ],
        ];

        $all_service_types = [
            'onpage' => $onpage_tasks,
            'technical' => $technical_tasks,
            'local' => $local_tasks,
            'offpage' => $offpage_tasks,
        ];

        $success = true;
        foreach ($all_service_types as $service_type => $groups) {
            foreach ($groups as $task_group => $tasks) {
                foreach ($tasks as $task_name) {
                    $result = self::createTask([
                        'client_id' => $client_id,
                        'service_type' => $service_type,
                        'task_group' => $task_group,
                        'task_name' => $task_name,
                        'status' => 'pending',
                        'is_recurring' => 0,
                    ]);
                    if (!$result) {
                        $success = false;
                    }
                }
            }
        }
        
        return $success;
    }
}