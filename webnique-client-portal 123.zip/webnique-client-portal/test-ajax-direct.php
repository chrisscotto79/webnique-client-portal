<?php
/**
 * Direct AJAX Test - Upload to plugin root
 * 
 * Tests if the analytics AJAX is working at all
 * Visit: https://yoursite.com/wp-content/plugins/webnique-client-portal/test-ajax-direct.php
 */

// Load WordPress
require_once('../../../wp-load.php');

echo "<h1>Analytics AJAX Direct Test</h1>";

// Check if user is logged in
if (!is_user_logged_in()) {
    echo "<p style='color: red;'>❌ Not logged in. Please log into WordPress first.</p>";
    exit;
}

echo "<p>✅ Logged in as: " . wp_get_current_user()->user_login . "</p>";

// Test 1: Can we load the classes?
echo "<h2>Test 1: Loading Analytics Classes</h2>";
try {
    require_once __DIR__ . '/includes/Models/AnalyticsConfig.php';
    echo "<p>✅ AnalyticsConfig loaded</p>";
    
    require_once __DIR__ . '/includes/API/GoogleAnalytics.php';
    echo "<p>✅ GoogleAnalytics loaded</p>";
    
    require_once __DIR__ . '/includes/API/GoogleSearchConsole.php';
    echo "<p>✅ GoogleSearchConsole loaded</p>";
    
    require_once __DIR__ . '/includes/API/AnalyticsCache.php';
    echo "<p>✅ AnalyticsCache loaded</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error loading classes: " . $e->getMessage() . "</p>";
    exit;
}

// Test 2: Check if credentials exist
echo "<h2>Test 2: Checking Credentials</h2>";
try {
    $credentials = \WNQ\Models\AnalyticsConfig::getCredentials();
    if ($credentials) {
        echo "<p>✅ Credentials found</p>";
        echo "<p>Email: " . esc_html($credentials['email']) . "</p>";
        echo "<p>Project: " . esc_html($credentials['project_id']) . "</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ No credentials found in database</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}

// Test 3: Check client config
echo "<h2>Test 3: Checking Client Config</h2>";
try {
    $config = \WNQ\Models\AnalyticsConfig::getClientConfig('web-nique');
    if ($config) {
        echo "<p>✅ Client config found</p>";
        echo "<p>GA4 Property ID: " . esc_html($config['ga4_property_id']) . "</p>";
        echo "<p>Search Console URL: " . esc_html($config['search_console_url']) . "</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ No client config found</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}

// Test 4: Try to create GoogleAnalytics instance
echo "<h2>Test 4: Creating GoogleAnalytics Instance</h2>";
try {
    $ga = new \WNQ\API\GoogleAnalytics('web-nique');
    echo "<p>✅ GoogleAnalytics instance created</p>";
    
    // Test 5: Try to fetch data
    echo "<h2>Test 5: Fetching GA4 Data</h2>";
    echo "<p>Attempting to fetch overview stats (this may take 5-10 seconds)...</p>";
    
    $stats = $ga->getOverviewStats('7daysAgo', 'today');
    
    echo "<p>✅ <strong>SUCCESS! GA4 API is working!</strong></p>";
    echo "<pre>";
    print_r($stats);
    echo "</pre>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ GA4 API Error: " . $e->getMessage() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<hr>";
echo "<h2>Conclusion</h2>";
echo "<p>If you see '✅ SUCCESS! GA4 API is working!' above, the API works fine and the issue is JavaScript/AJAX.</p>";
echo "<p>If you see errors, the issue is with the PHP/API configuration.</p>";
?>