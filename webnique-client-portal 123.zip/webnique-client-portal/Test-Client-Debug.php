<?php
/**
 * DEBUG SCRIPT - Test Client Creation
 * 
 * Upload this to wp-content/ and visit it in your browser
 * URL: https://yoursite.com/wp-content/test-client-debug.php
 */

// Load WordPress
require_once('../wp-load.php');

// Load Client model
require_once('../wp-content/plugins/webnique-client-portal/includes/Models/Client.php');

use WNQ\Models\Client;

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Client Management Debug</h1>";
echo "<hr>";

// Test 1: Check if table exists
echo "<h2>Test 1: Check Database Table</h2>";
global $wpdb;
$table_name = $wpdb->prefix . 'wnq_clients';
$table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");

if ($table_exists) {
    echo "✅ Table exists: <code>$table_name</code><br>";
    
    // Show table structure
    $columns = $wpdb->get_results("DESCRIBE $table_name");
    echo "<details><summary>Table Structure (click to expand)</summary>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td>{$col->Field}</td>";
        echo "<td>{$col->Type}</td>";
        echo "<td>{$col->Null}</td>";
        echo "<td>{$col->Key}</td>";
        echo "<td>{$col->Default}</td>";
        echo "</tr>";
    }
    echo "</table></details>";
} else {
    echo "❌ Table does NOT exist: <code>$table_name</code><br>";
    echo "Run this SQL to create it:<br>";
    echo "<textarea style='width:100%;height:200px;'>";
    Client::createTable();
    echo "Table creation attempted. Refresh this page.";
    echo "</textarea>";
}

echo "<hr>";

// Test 2: Try to create a test client
echo "<h2>Test 2: Create Test Client</h2>";

$test_data = [
    'client_id' => 'test-debug-' . time(),
    'name' => 'Test Client',
    'email' => 'test-' . time() . '@example.com',
    'company' => 'Test Company',
    'status' => 'active',
    'tier' => 'website',
];

echo "<strong>Attempting to create client with data:</strong><br>";
echo "<pre>" . print_r($test_data, true) . "</pre>";

try {
    $result = Client::create($test_data);
    
    if ($result) {
        echo "✅ <strong>SUCCESS!</strong> Client created with ID: <code>$result</code><br>";
    } else {
        echo "❌ <strong>FAILED!</strong> Client::create() returned false<br>";
        
        // Check for database errors
        if ($wpdb->last_error) {
            echo "<strong>Database Error:</strong> " . $wpdb->last_error . "<br>";
        }
    }
} catch (Exception $e) {
    echo "❌ <strong>EXCEPTION:</strong> " . $e->getMessage() . "<br>";
}

echo "<hr>";

// Test 3: Get all clients
echo "<h2>Test 3: List All Clients</h2>";

try {
    $clients = Client::getAll();
    
    if (empty($clients)) {
        echo "No clients found in database.<br>";
    } else {
        echo "Found " . count($clients) . " client(s):<br>";
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Client ID</th><th>Name</th><th>Email</th><th>Status</th><th>Created</th></tr>";
        foreach ($clients as $client) {
            echo "<tr>";
            echo "<td>{$client['id']}</td>";
            echo "<td>{$client['client_id']}</td>";
            echo "<td>{$client['name']}</td>";
            echo "<td>{$client['email']}</td>";
            echo "<td>{$client['status']}</td>";
            echo "<td>{$client['created_at']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "❌ <strong>ERROR:</strong> " . $e->getMessage() . "<br>";
}

echo "<hr>";

// Test 4: Check form handler registration
echo "<h2>Test 4: Check Form Handlers</h2>";

$actions = [
    'admin_post_wnq_save_client',
    'admin_post_wnq_delete_client'
];

foreach ($actions as $action) {
    $has_action = has_action($action);
    if ($has_action) {
        echo "✅ Action registered: <code>$action</code><br>";
    } else {
        echo "❌ Action NOT registered: <code>$action</code><br>";
    }
}

echo "<hr>";
echo "<h3>Debug Complete</h3>";
echo "<p>If everything shows ✅ but form still doesn't work, the issue is in the form submission or redirect.</p>";
?>