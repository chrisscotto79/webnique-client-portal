<?php
/**
 * TasksAdmin - PREMIUM VERSION
 * 
 * Complete task management with:
 * - Working drag & drop with smooth animations
 * - User filtering system
 * - Beautiful modern UI
 * - Task categories (Client/WebNique/General)
 * - Countdown timers
 * - Archive system
 * - Enhanced stats
 * 
 * @package WebNique Portal
 */

namespace WNQ\Admin;

use WNQ\Models\Task;

if (!defined('ABSPATH')) {
    exit;
}

final class TasksAdmin
{
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addSubmenu'], 15);
        add_action('admin_enqueue_scripts', [self::class, 'enqueueAssets']);
    }

    public static function addSubmenu(): void
    {
        $capability = current_user_can('wnq_manage_portal') ? 'wnq_manage_portal' : 'manage_options';

        add_submenu_page(
            'wnq-portal',
            'Tasks',
            'Tasks',
            $capability,
            'wnq-tasks',
            [self::class, 'render']
        );
    }

    public static function enqueueAssets($hook): void
    {
        if ($hook !== 'webnique-portal_page_wnq-tasks') {
            return;
        }

        wp_enqueue_script('jquery-ui-draggable');
        wp_enqueue_script('jquery-ui-droppable');
        wp_enqueue_script('jquery-ui-sortable');
    }

    public static function render(): void
    {
        if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : 'kanban';
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';
        $task_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

        if ($action === 'edit' && $task_id) {
            self::renderEditForm($task_id);
            return;
        }

        if ($action === 'add') {
            self::renderAddForm();
            return;
        }

        switch ($view) {
            case 'calendar':
                self::renderCalendarView();
                break;
            case 'recurring':
                self::renderRecurringView();
                break;
            case 'archive':
                self::renderArchiveView();
                break;
            default:
                self::renderKanbanBoard();
                break;
        }
    }

    private static function renderKanbanBoard(): void
    {
        // Load clients
        $clients = [];
        if (file_exists(WNQ_PORTAL_PATH . 'includes/Models/Client.php')) {
            require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
            if (class_exists('WNQ\\Models\\Client')) {
                $clients = \WNQ\Models\Client::getAll();
            }
        }

        // Get filters
        $filter_type = isset($_GET['filter']) ? sanitize_text_field($_GET['filter']) : '';
        $filter_user = isset($_GET['user']) ? sanitize_text_field($_GET['user']) : '';

        // Get tasks
        $filters = [];
        if ($filter_type) {
            $filters['task_type'] = $filter_type;
        }
        if ($filter_user) {
            $filters['assigned_to'] = $filter_user;
        }
        $tasks = Task::getAll($filters);
        
        $counts = Task::getCountsByStatus();
        $type_counts = Task::getCountsByType();
        $overdue = Task::getOverdue();
        $this_week = Task::getDueThisWeek();

        // Group tasks by status
        $tasksByStatus = [
            'todo' => [],
            'in_progress' => [],
            'review' => [],
            'done' => [],
        ];

        foreach ($tasks as $task) {
            $status = $task['status'] ?? 'todo';
            if (isset($tasksByStatus[$status])) {
                $tasksByStatus[$status][] = $task;
            }
        }

        $team_members = [
            'christopher-scotto' => ['name' => 'Christopher Scotto', 'initials' => 'CS', 'color' => '#667eea'],
            'christopher-sanders' => ['name' => 'Christopher Sanders', 'initials' => 'CS', 'color' => '#f093fb'],
        ];

        // Count tasks by user
        $user_counts = [];
        foreach ($team_members as $id => $member) {
            $user_counts[$id] = 0;
            foreach ($tasks as $task) {
                if (($task['assigned_to'] ?? '') === $id) {
                    $user_counts[$id]++;
                }
            }
        }

        ?>
        <div class="wrap wnq-tasks-premium">
            <!-- Header Bar -->
            <div class="tasks-top-bar">
                <div class="tasks-branding">
                    <h1>📋 Task Management</h1>
                    <p class="subtitle">Drag & drop to organize your workflow</p>
                </div>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&action=add'); ?>" class="btn-new-task">
                    <span class="btn-icon">✨</span> New Task
                </a>
            </div>

            <!-- Navigation Tabs -->
            <div class="premium-tabs">
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=kanban'); ?>" class="tab-item active">
                    <span class="tab-icon">📊</span> Kanban
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=calendar'); ?>" class="tab-item">
                    <span class="tab-icon">📅</span> Calendar
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=recurring'); ?>" class="tab-item">
                    <span class="tab-icon">🔁</span> Recurring
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=archive'); ?>" class="tab-item">
                    <span class="tab-icon">📦</span> Archive
                </a>
            </div>

            <!-- Stats Dashboard -->
            <div class="stats-dashboard">
                <div class="stat-box stat-todo">
                    <div class="stat-icon">📝</div>
                    <div class="stat-content">
                        <div class="stat-value"><?php echo $counts['todo']; ?></div>
                        <div class="stat-label">To Do</div>
                    </div>
                </div>
                <div class="stat-box stat-progress">
                    <div class="stat-icon">🚀</div>
                    <div class="stat-content">
                        <div class="stat-value"><?php echo $counts['in_progress']; ?></div>
                        <div class="stat-label">In Progress</div>
                    </div>
                </div>
                <div class="stat-box stat-review">
                    <div class="stat-icon">👀</div>
                    <div class="stat-content">
                        <div class="stat-value"><?php echo $counts['review']; ?></div>
                        <div class="stat-label">Review</div>
                    </div>
                </div>
                <div class="stat-box stat-done">
                    <div class="stat-icon">✅</div>
                    <div class="stat-content">
                        <div class="stat-value"><?php echo $counts['done']; ?></div>
                        <div class="stat-label">Done</div>
                    </div>
                </div>
                <?php if (!empty($overdue)): ?>
                <div class="stat-box stat-overdue">
                    <div class="stat-icon">⚠️</div>
                    <div class="stat-content">
                        <div class="stat-value"><?php echo count($overdue); ?></div>
                        <div class="stat-label">Overdue</div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="stat-box stat-week">
                    <div class="stat-icon">📆</div>
                    <div class="stat-content">
                        <div class="stat-value"><?php echo count($this_week); ?></div>
                        <div class="stat-label">This Week</div>
                    </div>
                </div>
            </div>

            <!-- Filters Bar -->
            <div class="filters-bar">
                <div class="filter-section">
                    <span class="filter-title">Task Type:</span>
                    <div class="filter-buttons">
                        <a href="<?php echo admin_url('admin.php?page=wnq-tasks' . ($filter_user ? '&user=' . $filter_user : '')); ?>" 
                           class="filter-btn <?php echo empty($filter_type) ? 'active' : ''; ?>">
                            All <span class="badge"><?php echo array_sum($type_counts); ?></span>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=wnq-tasks&filter=client' . ($filter_user ? '&user=' . $filter_user : '')); ?>" 
                           class="filter-btn <?php echo $filter_type === 'client' ? 'active' : ''; ?>">
                            🏢 Client <span class="badge"><?php echo $type_counts['client']; ?></span>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=wnq-tasks&filter=webnique' . ($filter_user ? '&user=' . $filter_user : '')); ?>" 
                           class="filter-btn <?php echo $filter_type === 'webnique' ? 'active' : ''; ?>">
                            🏪 WebNique <span class="badge"><?php echo $type_counts['webnique']; ?></span>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=wnq-tasks&filter=general' . ($filter_user ? '&user=' . $filter_user : '')); ?>" 
                           class="filter-btn <?php echo $filter_type === 'general' ? 'active' : ''; ?>">
                            📝 General <span class="badge"><?php echo $type_counts['general']; ?></span>
                        </a>
                    </div>
                </div>

                <div class="filter-section">
                    <span class="filter-title">Team Member:</span>
                    <div class="filter-buttons">
                        <a href="<?php echo admin_url('admin.php?page=wnq-tasks' . ($filter_type ? '&filter=' . $filter_type : '')); ?>" 
                           class="filter-btn <?php echo empty($filter_user) ? 'active' : ''; ?>">
                            All <span class="badge"><?php echo count($tasks); ?></span>
                        </a>
                        <?php foreach ($team_members as $id => $member): ?>
                            <a href="<?php echo admin_url('admin.php?page=wnq-tasks&user=' . $id . ($filter_type ? '&filter=' . $filter_type : '')); ?>" 
                               class="filter-btn user-filter <?php echo $filter_user === $id ? 'active' : ''; ?>">
                                <span class="user-avatar" style="background: <?php echo $member['color']; ?>">
                                    <?php echo $member['initials']; ?>
                                </span>
                                <?php echo explode(' ', $member['name'])[0]; ?>
                                <span class="badge"><?php echo $user_counts[$id]; ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Kanban Board -->
            <div class="kanban-board-premium">
                <?php
                $columns = [
                    'todo' => ['icon' => '📝', 'title' => 'To Do', 'color' => '#94a3b8'],
                    'in_progress' => ['icon' => '🚀', 'title' => 'In Progress', 'color' => '#667eea'],
                    'review' => ['icon' => '👀', 'title' => 'Review', 'color' => '#f59e0b'],
                    'done' => ['icon' => '✅', 'title' => 'Done', 'color' => '#10b981'],
                ];

                foreach ($columns as $status => $col):
                ?>
                    <div class="kanban-column-premium" data-status="<?php echo esc_attr($status); ?>">
                        <div class="column-header-premium" style="border-bottom-color: <?php echo $col['color']; ?>">
                            <div class="column-title-group">
                                <span class="column-icon"><?php echo $col['icon']; ?></span>
                                <h3 class="column-title"><?php echo $col['title']; ?></h3>
                            </div>
                            <span class="column-badge" style="background: <?php echo $col['color']; ?>20; color: <?php echo $col['color']; ?>">
                                <?php echo count($tasksByStatus[$status]); ?>
                            </span>
                        </div>
                        <div class="column-tasks-premium" id="column-<?php echo esc_attr($status); ?>">
                            <?php if (empty($tasksByStatus[$status])): ?>
                                <div class="empty-column-state">
                                    <div class="empty-icon"><?php echo $col['icon']; ?></div>
                                    <p>No tasks yet</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($tasksByStatus[$status] as $task): ?>
                                    <?php self::renderPremiumTaskCard($task, $team_members, $clients, $status); ?>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <?php self::renderPremiumStyles(); ?>
        <?php self::renderPremiumScript(); ?>
        <?php
    }

    private static function renderPremiumTaskCard(array $task, array $team_members, array $clients, string $column_status): void
    {
        $priority = $task['priority'] ?? 'medium';
        $task_type = $task['task_type'] ?? 'general';
        $due_date = $task['due_date'] ?? null;
        $assignee_id = $task['assigned_to'] ?? '';
        $assignee = !empty($assignee_id) && isset($team_members[$assignee_id]) ? $team_members[$assignee_id] : null;

        // Get client name
        $client_name = '';
        if (!empty($task['client_id'])) {
            foreach ($clients as $client) {
                if ($client['client_id'] === $task['client_id']) {
                    $client_name = $client['name'];
                    break;
                }
            }
        }

        // Calculate countdown
        $countdown_html = '';
        $countdown_class = '';
        if ($due_date) {
            $today = strtotime('today');
            $due_timestamp = strtotime($due_date);
            $days_diff = floor(($due_timestamp - $today) / (60 * 60 * 24));

            if ($days_diff < 0 && $task['status'] !== 'done') {
                $countdown_html = '<span class="countdown-icon">⚠️</span> Overdue ' . abs($days_diff) . 'd';
                $countdown_class = 'countdown-overdue';
            } elseif ($days_diff === 0) {
                $countdown_html = '<span class="countdown-icon">🔥</span> Due today';
                $countdown_class = 'countdown-today';
            } elseif ($days_diff === 1) {
                $countdown_html = '<span class="countdown-icon">📅</span> Tomorrow';
                $countdown_class = 'countdown-soon';
            } elseif ($days_diff <= 3) {
                $countdown_html = '<span class="countdown-icon">📅</span> ' . $days_diff . ' days';
                $countdown_class = 'countdown-soon';
            } elseif ($days_diff <= 7) {
                $countdown_html = '<span class="countdown-icon">📅</span> ' . $days_diff . ' days';
                $countdown_class = 'countdown-normal';
            } else {
                $countdown_html = '<span class="countdown-icon">📅</span> ' . date('M j', $due_timestamp);
                $countdown_class = 'countdown-normal';
            }
        }

        // Priority colors
        $priority_colors = [
            'high' => '#dc2626',
            'medium' => '#f59e0b',
            'low' => '#3b82f6',
        ];
        $priority_color = $priority_colors[$priority] ?? '#6b7280';

        ?>
        <div class="task-card-premium" data-task-id="<?php echo esc_attr($task['id']); ?>" style="border-left-color: <?php echo $priority_color; ?>">
            <div class="task-card-header">
                <?php
                $type_badges = [
                    'client' => ['icon' => '🏢', 'label' => 'Client', 'bg' => '#dbeafe', 'color' => '#1e40af'],
                    'webnique' => ['icon' => '🏪', 'label' => 'WebNique', 'bg' => '#d1fae5', 'color' => '#065f46'],
                    'general' => ['icon' => '📝', 'label' => 'General', 'bg' => '#f3f4f6', 'color' => '#374151'],
                ];
                $type_info = $type_badges[$task_type] ?? $type_badges['general'];
                ?>
                <span class="task-type-tag" style="background: <?php echo $type_info['bg']; ?>; color: <?php echo $type_info['color']; ?>">
                    <?php echo $type_info['icon']; ?> <?php echo $type_info['label']; ?>
                </span>
                
                <div class="task-priority-indicator" style="background: <?php echo $priority_color; ?>" 
                     title="<?php echo ucfirst($priority); ?> priority"></div>
            </div>
            
            <h4 class="task-card-title"><?php echo esc_html($task['title']); ?></h4>
            
            <?php if (!empty($task['description'])): ?>
            <p class="task-card-description">
                <?php echo wp_trim_words(esc_html($task['description']), 12); ?>
            </p>
            <?php endif; ?>
            
            <?php if ($countdown_html): ?>
            <div class="task-countdown-badge <?php echo esc_attr($countdown_class); ?>">
                <?php echo $countdown_html; ?>
            </div>
            <?php endif; ?>

            <div class="task-card-footer">
                <div class="task-footer-left">
                    <?php if ($assignee): ?>
                        <div class="task-assignee-avatar" style="background: <?php echo $assignee['color']; ?>" 
                             title="<?php echo esc_attr($assignee['name']); ?>">
                            <?php echo $assignee['initials']; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($client_name): ?>
                        <span class="task-client-tag">
                            🏢 <?php echo esc_html($client_name); ?>
                        </span>
                    <?php endif; ?>
                </div>
                
                <div class="task-actions-dropdown">
                    <button class="task-menu-btn" onclick="toggleTaskMenu(<?php echo $task['id']; ?>)">⋮</button>
                    <div class="task-menu" id="task-menu-<?php echo $task['id']; ?>">
                        <a href="<?php echo admin_url('admin.php?page=wnq-tasks&action=edit&id=' . $task['id']); ?>">
                            ✏️ Edit
                        </a>
                        <?php if ($column_status === 'done'): ?>
                        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                            <?php wp_nonce_field('wnq_archive_task'); ?>
                            <input type="hidden" name="action" value="wnq_archive_task">
                            <input type="hidden" name="id" value="<?php echo esc_attr($task['id']); ?>">
                            <button type="submit">📦 Archive</button>
                        </form>
                        <?php endif; ?>
                        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                            <?php wp_nonce_field('wnq_delete_task'); ?>
                            <input type="hidden" name="action" value="wnq_delete_task">
                            <input type="hidden" name="id" value="<?php echo esc_attr($task['id']); ?>">
                            <button type="submit" onclick="return confirm('Delete this task?');" class="delete-btn">
                                🗑️ Delete
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    private static function renderArchiveView(): void
    {
        $archived_tasks = Task::getArchived();
        $archived_count = count($archived_tasks);

        ?>
        <div class="wrap wnq-tasks-premium">
            <div class="tasks-top-bar">
                <div class="tasks-branding">
                    <h1>📦 Archive</h1>
                    <p class="subtitle"><?php echo $archived_count; ?> archived tasks</p>
                </div>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks'); ?>" class="btn-new-task btn-secondary">
                    ← Back to Kanban
                </a>
            </div>

            <div class="premium-tabs">
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=kanban'); ?>" class="tab-item">
                    <span class="tab-icon">📊</span> Kanban
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=calendar'); ?>" class="tab-item">
                    <span class="tab-icon">📅</span> Calendar
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=recurring'); ?>" class="tab-item">
                    <span class="tab-icon">🔁</span> Recurring
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=archive'); ?>" class="tab-item active">
                    <span class="tab-icon">📦</span> Archive
                </a>
            </div>

            <?php if (empty($archived_tasks)): ?>
                <div class="empty-state-premium">
                    <div class="empty-icon-large">📦</div>
                    <h2>No Archived Tasks</h2>
                    <p>Completed tasks will appear here when archived</p>
                </div>
            <?php else: ?>
                <div class="archive-grid-premium">
                    <?php foreach ($archived_tasks as $task): ?>
                        <div class="archive-card-premium">
                            <div class="archive-card-header">
                                <?php
                                $types = [
                                    'client' => ['icon' => '🏢', 'label' => 'Client', 'bg' => '#dbeafe', 'color' => '#1e40af'],
                                    'webnique' => ['icon' => '🏪', 'label' => 'WebNique', 'bg' => '#d1fae5', 'color' => '#065f46'],
                                    'general' => ['icon' => '📝', 'label' => 'General', 'bg' => '#f3f4f6', 'color' => '#374151'],
                                ];
                                $type_info = $types[$task['task_type'] ?? 'general'];
                                ?>
                                <span class="task-type-tag" style="background: <?php echo $type_info['bg']; ?>; color: <?php echo $type_info['color']; ?>">
                                    <?php echo $type_info['icon']; ?> <?php echo $type_info['label']; ?>
                                </span>
                                <span class="archive-date-badge">
                                    📅 <?php echo date('M j, Y', strtotime($task['archived_at'])); ?>
                                </span>
                            </div>
                            
                            <h3 class="archive-card-title"><?php echo esc_html($task['title']); ?></h3>
                            
                            <?php if (!empty($task['description'])): ?>
                            <p class="archive-card-description">
                                <?php echo wp_trim_words(esc_html($task['description']), 20); ?>
                            </p>
                            <?php endif; ?>
                            
                            <div class="archive-card-meta">
                                <?php
                                $priority_badges = [
                                    'high' => ['icon' => '🔴', 'label' => 'High'],
                                    'medium' => ['icon' => '🟡', 'label' => 'Medium'],
                                    'low' => ['icon' => '🔵', 'label' => 'Low'],
                                ];
                                $priority_info = $priority_badges[$task['priority'] ?? 'medium'];
                                ?>
                                <span class="meta-badge">
                                    <?php echo $priority_info['icon']; ?> <?php echo $priority_info['label']; ?>
                                </span>
                                <?php if (!empty($task['assigned_to'])): ?>
                                <span class="meta-badge">
                                    👤 <?php echo esc_html(ucwords(str_replace('-', ' ', $task['assigned_to']))); ?>
                                </span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="archive-card-actions">
                                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                                    <?php wp_nonce_field('wnq_restore_task'); ?>
                                    <input type="hidden" name="action" value="wnq_restore_task">
                                    <input type="hidden" name="id" value="<?php echo esc_attr($task['id']); ?>">
                                    <button type="submit" class="btn-restore">
                                        ↩️ Restore
                                    </button>
                                </form>
                                
                                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                                    <?php wp_nonce_field('wnq_delete_task'); ?>
                                    <input type="hidden" name="action" value="wnq_delete_task">
                                    <input type="hidden" name="id" value="<?php echo esc_attr($task['id']); ?>">
                                    <button type="submit" onclick="return confirm('Permanently delete?');" class="btn-delete-archive">
                                        🗑️ Delete
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php self::renderPremiumStyles(); ?>
        <?php
    }

    private static function renderCalendarView(): void
    {
        ?>
        <div class="wrap wnq-tasks-premium">
            <div class="tasks-top-bar">
                <div class="tasks-branding">
                    <h1>📅 Calendar View</h1>
                    <p class="subtitle">Coming soon - Weekly task calendar</p>
                </div>
            </div>

            <div class="premium-tabs">
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=kanban'); ?>" class="tab-item">
                    <span class="tab-icon">📊</span> Kanban
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=calendar'); ?>" class="tab-item active">
                    <span class="tab-icon">📅</span> Calendar
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=recurring'); ?>" class="tab-item">
                    <span class="tab-icon">🔁</span> Recurring
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=archive'); ?>" class="tab-item">
                    <span class="tab-icon">📦</span> Archive
                </a>
            </div>

            <div class="empty-state-premium">
                <div class="empty-icon-large">📅</div>
                <h2>Calendar View</h2>
                <p>This feature is coming soon!</p>
            </div>
        </div>

        <?php self::renderPremiumStyles(); ?>
        <?php
    }

    private static function renderRecurringView(): void
    {
        ?>
        <div class="wrap wnq-tasks-premium">
            <div class="tasks-top-bar">
                <div class="tasks-branding">
                    <h1>🔁 Recurring Tasks</h1>
                    <p class="subtitle">Coming soon - Daily repeating tasks</p>
                </div>
            </div>

            <div class="premium-tabs">
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=kanban'); ?>" class="tab-item">
                    <span class="tab-icon">📊</span> Kanban
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=calendar'); ?>" class="tab-item">
                    <span class="tab-icon">📅</span> Calendar
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=recurring'); ?>" class="tab-item active">
                    <span class="tab-icon">🔁</span> Recurring
                </a>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks&view=archive'); ?>" class="tab-item">
                    <span class="tab-icon">📦</span> Archive
                </a>
            </div>

            <div class="empty-state-premium">
                <div class="empty-icon-large">🔁</div>
                <h2>Recurring Tasks</h2>
                <p>This feature is coming soon!</p>
            </div>
        </div>

        <?php self::renderPremiumStyles(); ?>
        <?php
    }

    private static function renderPremiumStyles(): void
    {
        ?>
        <style>
        /* Reset & Base */
        .wnq-tasks-premium { 
            margin: 20px 20px 20px 0; 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
        }
        .wnq-tasks-premium * { box-sizing: border-box; }

        /* Top Bar */
        .tasks-top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            padding: 24px 32px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3);
        }
        .tasks-branding h1 {
            margin: 0 0 4px;
            font-size: 32px;
            font-weight: 800;
            color: white;
            letter-spacing: -0.5px;
        }
        .subtitle {
            margin: 0;
            font-size: 15px;
            color: rgba(255, 255, 255, 0.9);
        }
        .btn-new-task {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 14px 28px;
            background: white;
            color: #667eea;
            font-weight: 700;
            font-size: 15px;
            border-radius: 12px;
            text-decoration: none;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            transition: all 0.2s;
        }
        .btn-new-task:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
        }
        .btn-icon {
            font-size: 18px;
        }
        .btn-secondary {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            backdrop-filter: blur(10px);
        }

        /* Premium Tabs */
        .premium-tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 24px;
            padding: 8px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }
        .tab-item {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            border-radius: 8px;
            text-decoration: none;
            color: #64748b;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s;
        }
        .tab-item:hover {
            background: #f8fafc;
            color: #334155;
        }
        .tab-item.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
        }
        .tab-icon {
            font-size: 16px;
        }

        /* Stats Dashboard */
        .stats-dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-box {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            transition: all 0.2s;
        }
        .stat-box:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
        }
        .stat-icon {
            font-size: 32px;
            flex-shrink: 0;
        }
        .stat-value {
            font-size: 32px;
            font-weight: 800;
            color: #1e293b;
            line-height: 1;
        }
        .stat-label {
            font-size: 13px;
            color: #64748b;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-top: 4px;
        }

        /* Filters Bar */
        .filters-bar {
            display: flex;
            flex-direction: column;
            gap: 16px;
            padding: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-bottom: 24px;
        }
        .filter-section {
            display: flex;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
        }
        .filter-title {
            font-size: 13px;
            font-weight: 700;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            flex-shrink: 0;
        }
        .filter-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        .filter-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            text-decoration: none;
            color: #475569;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s;
        }
        .filter-btn:hover {
            border-color: #cbd5e1;
            background: #f8fafc;
        }
        .filter-btn.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: transparent;
        }
        .filter-btn .badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 24px;
            height: 24px;
            padding: 0 8px;
            background: rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            font-size: 12px;
            font-weight: 700;
        }
        .filter-btn.active .badge {
            background: rgba(255, 255, 255, 0.25);
        }
        .user-avatar {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 28px;
            height: 28px;
            border-radius: 50%;
            color: white;
            font-size: 11px;
            font-weight: 700;
        }

        /* Kanban Board */
        .kanban-board-premium {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            min-height: 600px;
        }
        .kanban-column-premium {
            background: #f8fafc;
            border-radius: 12px;
            padding: 16px;
            min-height: 500px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        }
        .column-header-premium {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 3px solid;
        }
        .column-title-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .column-icon {
            font-size: 22px;
        }
        .column-title {
            margin: 0;
            font-size: 16px;
            font-weight: 800;
            color: #1e293b;
        }
        .column-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 28px;
            height: 28px;
            padding: 0 10px;
            border-radius: 14px;
            font-size: 13px;
            font-weight: 800;
        }
        .column-tasks-premium {
            min-height: 400px;
        }
        .column-tasks-premium.drag-over {
            background: rgba(102, 126, 234, 0.05);
            border-radius: 8px;
        }
        .empty-column-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 60px 20px;
            text-align: center;
        }
        .empty-icon {
            font-size: 48px;
            opacity: 0.5;
            margin-bottom: 12px;
        }
        .empty-column-state p {
            margin: 0;
            color: #94a3b8;
            font-size: 14px;
            font-weight: 600;
        }

        /* Task Card */
        .task-card-premium {
            background: white;
            border-left: 4px solid;
            border-radius: 10px;
            padding: 16px;
            margin-bottom: 12px;
            cursor: grab;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            transition: all 0.2s;
        }
        .task-card-premium:hover {
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
            transform: translateY(-2px);
        }
        .task-card-premium.ui-draggable-dragging {
            cursor: grabbing;
            opacity: 0.7;
            transform: rotate(3deg) scale(1.05);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
        }
        .task-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .task-type-tag {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .task-priority-indicator {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            flex-shrink: 0;
        }
        .task-card-title {
            margin: 0 0 8px;
            font-size: 15px;
            font-weight: 700;
            color: #1e293b;
            line-height: 1.4;
        }
        .task-card-description {
            margin: 0 0 12px;
            font-size: 13px;
            color: #64748b;
            line-height: 1.5;
        }
        .task-countdown-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 12px;
        }
        .countdown-overdue {
            background: #fee2e2;
            color: #991b1b;
        }
        .countdown-today {
            background: #fef3c7;
            color: #92400e;
        }
        .countdown-soon {
            background: #fef3c7;
            color: #92400e;
        }
        .countdown-normal {
            background: #e0f2fe;
            color: #075985;
        }
        .countdown-icon {
            font-size: 14px;
        }
        .task-card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 12px;
            border-top: 1px solid #f1f5f9;
        }
        .task-footer-left {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .task-assignee-avatar {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            color: white;
            font-size: 12px;
            font-weight: 700;
            border: 2px solid white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .task-client-tag {
            padding: 4px 8px;
            background: #f1f5f9;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
            color: #475569;
        }
        .task-actions-dropdown {
            position: relative;
        }
        .task-menu-btn {
            width: 32px;
            height: 32px;
            border: none;
            background: #f1f5f9;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            color: #64748b;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }
        .task-menu-btn:hover {
            background: #e2e8f0;
            color: #334155;
        }
        .task-menu {
            display: none;
            position: absolute;
            right: 0;
            top: 36px;
            min-width: 150px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
            z-index: 100;
            overflow: hidden;
        }
        .task-menu.active {
            display: block;
            animation: slideDown 0.2s ease;
        }
        .task-menu a,
        .task-menu button {
            display: block;
            width: 100%;
            padding: 10px 16px;
            border: none;
            background: none;
            text-align: left;
            text-decoration: none;
            color: #334155;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }
        .task-menu a:hover,
        .task-menu button:hover {
            background: #f8fafc;
        }
        .task-menu .delete-btn {
            color: #dc2626;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Archive */
        .archive-grid-premium {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
            gap: 20px;
        }
        .archive-card-premium {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            transition: all 0.2s;
        }
        .archive-card-premium:hover {
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
            transform: translateY(-2px);
        }
        .archive-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .archive-date-badge {
            font-size: 11px;
            color: #64748b;
            font-weight: 600;
        }
        .archive-card-title {
            margin: 0 0 8px;
            font-size: 17px;
            font-weight: 700;
            color: #1e293b;
        }
        .archive-card-description {
            margin: 0 0 12px;
            font-size: 14px;
            color: #64748b;
            line-height: 1.5;
        }
        .archive-card-meta {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-bottom: 16px;
        }
        .meta-badge {
            padding: 4px 10px;
            background: #f1f5f9;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            color: #475569;
        }
        .archive-card-actions {
            display: flex;
            gap: 8px;
            padding-top: 16px;
            border-top: 1px solid #f1f5f9;
        }
        .btn-restore,
        .btn-delete-archive {
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-restore {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .btn-restore:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }
        .btn-delete-archive {
            background: #fee2e2;
            color: #991b1b;
        }
        .btn-delete-archive:hover {
            background: #fecaca;
        }

        /* Empty State */
        .empty-state-premium {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 100px 20px;
            text-align: center;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }
        .empty-icon-large {
            font-size: 80px;
            opacity: 0.5;
            margin-bottom: 20px;
        }
        .empty-state-premium h2 {
            margin: 0 0 8px;
            font-size: 24px;
            color: #1e293b;
        }
        .empty-state-premium p {
            margin: 0;
            color: #64748b;
            font-size: 15px;
        }

        /* Responsive */
        @media (max-width: 1400px) {
            .kanban-board-premium {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        @media (max-width: 900px) {
            .kanban-board-premium {
                grid-template-columns: 1fr;
            }
            .stats-dashboard {
                grid-template-columns: repeat(2, 1fr);
            }
            .tasks-top-bar {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
            .filter-section {
                flex-direction: column;
                align-items: flex-start;
            }
        }
        </style>

        <script>
        function toggleTaskMenu(taskId) {
            const menu = document.getElementById('task-menu-' + taskId);
            const allMenus = document.querySelectorAll('.task-menu');
            allMenus.forEach(m => {
                if (m !== menu) m.classList.remove('active');
            });
            menu.classList.toggle('active');
        }

        // Close menus when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.task-actions-dropdown')) {
                document.querySelectorAll('.task-menu').forEach(m => m.classList.remove('active'));
            }
        });
        </script>
        <?php
    }

    private static function renderPremiumScript(): void
    {
        ?>
        <script>
        jQuery(document).ready(function($) {
            // Make task cards draggable
            $('.task-card-premium').draggable({
                revert: 'invalid',
                helper: 'clone',
                cursor: 'grabbing',
                opacity: 0.8,
                zIndex: 1000,
                start: function(event, ui) {
                    $(this).addClass('ui-draggable-dragging');
                    ui.helper.css({
                        'width': $(this).outerWidth(),
                        'transform': 'rotate(3deg) scale(1.05)'
                    });
                },
                stop: function() {
                    $(this).removeClass('ui-draggable-dragging');
                }
            });

            // Make columns droppable
            $('.column-tasks-premium').droppable({
                accept: '.task-card-premium',
                tolerance: 'pointer',
                over: function() {
                    $(this).addClass('drag-over');
                },
                out: function() {
                    $(this).removeClass('drag-over');
                },
                drop: function(event, ui) {
                    $(this).removeClass('drag-over');
                    
                    const $card = ui.draggable;
                    const taskId = $card.data('task-id');
                    const newStatus = $(this).parent().data('status');
                    const $targetColumn = $(this);
                    
                    // Remove empty state if exists
                    $targetColumn.find('.empty-column-state').remove();
                    
                    // Append card to new column
                    $card.css({top: 0, left: 0, position: 'relative'});
                    $targetColumn.append($card);
                    
                    // Update counts
                    updateColumnCounts();
                    
                    // AJAX update
                    $.post(ajaxurl, {
                        action: 'wnq_update_task_status',
                        task_id: taskId,
                        status: newStatus,
                        nonce: '<?php echo wp_create_nonce('wnq_task_nonce'); ?>'
                    }, function(response) {
                        if (response.success) {
                            // Show success feedback
                            showNotification('Task moved successfully', 'success');
                        } else {
                            // Revert on error
                            showNotification('Failed to update task', 'error');
                            setTimeout(() => location.reload(), 1000);
                        }
                    }).fail(function() {
                        showNotification('Network error', 'error');
                        setTimeout(() => location.reload(), 1000);
                    });
                }
            });

            function updateColumnCounts() {
                $('.kanban-column-premium').each(function() {
                    const count = $(this).find('.task-card-premium').length;
                    $(this).find('.column-badge').text(count);
                    
                    // Show/hide empty state
                    const $tasks = $(this).find('.column-tasks-premium');
                    if (count === 0 && !$tasks.find('.empty-column-state').length) {
                        const icon = $(this).find('.column-icon').text();
                        $tasks.append(
                            '<div class="empty-column-state">' +
                            '<div class="empty-icon">' + icon + '</div>' +
                            '<p>No tasks yet</p>' +
                            '</div>'
                        );
                    }
                });
            }

            function showNotification(message, type) {
                const colors = {
                    success: '#10b981',
                    error: '#dc2626'
                };
                
                const $notification = $('<div>')
                    .css({
                        position: 'fixed',
                        top: '20px',
                        right: '20px',
                        padding: '16px 24px',
                        background: colors[type],
                        color: 'white',
                        borderRadius: '12px',
                        fontWeight: '600',
                        fontSize: '14px',
                        boxShadow: '0 4px 16px rgba(0,0,0,0.2)',
                        zIndex: 10000,
                        animation: 'slideIn 0.3s ease'
                    })
                    .text(message)
                    .appendTo('body');
                
                setTimeout(() => {
                    $notification.fadeOut(300, () => $notification.remove());
                }, 3000);
            }
        });
        </script>

        <style>
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(100px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        </style>
        <?php
    }

    // Form rendering methods (keeping same as before)
    private static function renderAddForm(): void
    {
        ?>
        <div class="wrap wnq-tasks-premium">
            <div class="tasks-top-bar">
                <div class="tasks-branding">
                    <h1>✨ New Task</h1>
                    <p class="subtitle">Create a new task</p>
                </div>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks'); ?>" class="btn-new-task btn-secondary">
                    ← Back to Kanban
                </a>
            </div>
            <?php self::renderTaskForm(null); ?>
        </div>
        <?php
    }

    private static function renderEditForm(int $id): void
    {
        $task = Task::getById($id);
        if (!$task) wp_die('Task not found.');
        ?>
        <div class="wrap wnq-tasks-premium">
            <div class="tasks-top-bar">
                <div class="tasks-branding">
                    <h1>✏️ Edit Task</h1>
                    <p class="subtitle"><?php echo esc_html($task['title']); ?></p>
                </div>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks'); ?>" class="btn-new-task btn-secondary">
                    ← Back to Kanban
                </a>
            </div>
            <?php self::renderTaskForm($task); ?>
        </div>
        <?php
    }

    private static function renderTaskForm(?array $task): void
    {
        $is_edit = !empty($task);
        
        $clients = [];
        if (file_exists(WNQ_PORTAL_PATH . 'includes/Models/Client.php')) {
            require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
            if (class_exists('WNQ\\Models\\Client')) {
                $clients = \WNQ\Models\Client::getAll();
            }
        }

        $team_members = [
            'christopher-scotto' => 'Christopher Scotto',
            'christopher-sanders' => 'Christopher Sanders',
        ];

        ?>
        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" class="task-form-premium">
            <?php wp_nonce_field('wnq_save_task'); ?>
            <input type="hidden" name="action" value="wnq_save_task">
            <?php if ($is_edit): ?>
                <input type="hidden" name="id" value="<?php echo esc_attr($task['id']); ?>">
            <?php endif; ?>

            <div class="form-section-premium">
                <table class="form-table">
                    <tr>
                        <th><label for="title">Task Title *</label></th>
                        <td><input type="text" name="title" id="title" value="<?php echo esc_attr($task['title'] ?? ''); ?>" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="description">Description</label></th>
                        <td><textarea name="description" id="description" rows="5" class="large-text"><?php echo esc_textarea($task['description'] ?? ''); ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="task_type">Task Type</label></th>
                        <td>
                            <select name="task_type" id="task_type" class="regular-text">
                                <option value="general" <?php selected($task['task_type'] ?? 'general', 'general'); ?>>📝 General</option>
                                <option value="client" <?php selected($task['task_type'] ?? '', 'client'); ?>>🏢 Client Task</option>
                                <option value="webnique" <?php selected($task['task_type'] ?? '', 'webnique'); ?>>🏪 WebNique Task</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="status">Status</label></th>
                        <td>
                            <select name="status" id="status" class="regular-text">
                                <option value="todo" <?php selected($task['status'] ?? 'todo', 'todo'); ?>>To Do</option>
                                <option value="in_progress" <?php selected($task['status'] ?? '', 'in_progress'); ?>>In Progress</option>
                                <option value="review" <?php selected($task['status'] ?? '', 'review'); ?>>Review</option>
                                <option value="done" <?php selected($task['status'] ?? '', 'done'); ?>>Done</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="priority">Priority</label></th>
                        <td>
                            <select name="priority" id="priority" class="regular-text">
                                <option value="low" <?php selected($task['priority'] ?? '', 'low'); ?>>Low</option>
                                <option value="medium" <?php selected($task['priority'] ?? 'medium', 'medium'); ?>>Medium</option>
                                <option value="high" <?php selected($task['priority'] ?? '', 'high'); ?>>High</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="assigned_to">Assign To</label></th>
                        <td>
                            <select name="assigned_to" id="assigned_to" class="regular-text">
                                <option value="">Unassigned</option>
                                <?php foreach ($team_members as $id => $name): ?>
                                    <option value="<?php echo esc_attr($id); ?>" <?php selected($task['assigned_to'] ?? '', $id); ?>><?php echo esc_html($name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="due_date">Due Date</label></th>
                        <td><input type="date" name="due_date" id="due_date" value="<?php echo esc_attr($task['due_date'] ?? ''); ?>"></td>
                    </tr>
                    <?php if (!empty($clients)): ?>
                    <tr>
                        <th><label for="client_id">Client (Optional)</label></th>
                        <td>
                            <select name="client_id" id="client_id" class="regular-text">
                                <option value="">No client</option>
                                <?php foreach ($clients as $client): ?>
                                    <option value="<?php echo esc_attr($client['client_id']); ?>" <?php selected($task['client_id'] ?? '', $client['client_id']); ?>>
                                        <?php echo esc_html($client['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <th><label for="notes">Notes</label></th>
                        <td><textarea name="notes" id="notes" rows="4" class="large-text"><?php echo esc_textarea($task['notes'] ?? ''); ?></textarea></td>
                    </tr>
                </table>
            </div>

            <p class="submit">
                <button type="submit" class="button button-primary button-large">
                    <?php echo $is_edit ? '💾 Update Task' : '✨ Create Task'; ?>
                </button>
                <a href="<?php echo admin_url('admin.php?page=wnq-tasks'); ?>" class="button button-large">Cancel</a>
            </p>
        </form>

        <style>
        .form-section-premium {
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
        }
        </style>
        <?php
    }

    // Form handlers
    public static function handleSaveTask(): void
    {
        check_admin_referer('wnq_save_task');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $data = [
            'title' => sanitize_text_field($_POST['title'] ?? ''),
            'description' => wp_kses_post($_POST['description'] ?? ''),
            'status' => sanitize_text_field($_POST['status'] ?? 'todo'),
            'task_type' => sanitize_text_field($_POST['task_type'] ?? 'general'),
            'priority' => sanitize_text_field($_POST['priority'] ?? 'medium'),
            'assigned_to' => sanitize_text_field($_POST['assigned_to'] ?? ''),
            'due_date' => sanitize_text_field($_POST['due_date'] ?? ''),
            'client_id' => sanitize_text_field($_POST['client_id'] ?? ''),
            'notes' => wp_kses_post($_POST['notes'] ?? ''),
        ];

        $success = $id ? Task::update($id, $data) : Task::create($data);
        wp_redirect(admin_url('admin.php?page=wnq-tasks'));
        exit;
    }

    public static function handleDeleteTask(): void
    {
        check_admin_referer('wnq_delete_task');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        Task::delete($id);
        
        $redirect = isset($_POST['redirect']) ? sanitize_text_field($_POST['redirect']) : 'kanban';
        wp_redirect(admin_url('admin.php?page=wnq-tasks&view=' . $redirect));
        exit;
    }

    public static function handleArchive(): void
    {
        check_admin_referer('wnq_archive_task');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        Task::archive($id);
        wp_redirect(admin_url('admin.php?page=wnq-tasks'));
        exit;
    }

    public static function handleRestore(): void
    {
        check_admin_referer('wnq_restore_task');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        Task::restore($id);
        wp_redirect(admin_url('admin.php?page=wnq-tasks&view=archive'));
        exit;
    }

    public static function ajaxUpdateTaskStatus(): void
    {
        check_ajax_referer('wnq_task_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Insufficient permissions');

        $task_id = isset($_POST['task_id']) ? intval($_POST['task_id']) : 0;
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';

        if (!$task_id || !$status) wp_send_json_error('Invalid data');

        $success = Task::update($task_id, ['status' => $status]);
        $success ? wp_send_json_success() : wp_send_json_error('Failed');
    }
}