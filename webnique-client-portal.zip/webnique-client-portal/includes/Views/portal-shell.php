<?php
// This file intentionally contains a single function that returns the portal shell.

if (!defined('ABSPATH')) {
  exit;
}

function wnq_portal_shell_html(array $args = []): string
{
  $clientId = isset($args['client_id']) ? esc_attr((string) $args['client_id']) : '';
  $mode     = isset($args['mode']) ? esc_attr((string) $args['mode']) : 'client';

  return sprintf(
    '<div id="wnq-portal-root" data-client-id="%s" data-mode="%s"></div>',
    $clientId,
    $mode
  );
}
