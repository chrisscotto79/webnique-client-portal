<?php
/**
 * Analytics Admin - KEY EVENTS DASHBOARD
 * Beautiful UI for tracking conversions: phone, email, social, forms, contact views
 */

namespace WNQ\Admin;

use WNQ\Models\AnalyticsConfig;

if (!defined('ABSPATH')) exit;

final class AnalyticsAdmin
{
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addSubmenu'], 20);
        add_action('admin_enqueue_scripts', [self::class, 'enqueueAssets'], 999);
    }

    public static function addSubmenu(): void
    {
        $capability = current_user_can('wnq_manage_portal') ? 'wnq_manage_portal' : 'manage_options';
        add_submenu_page('wnq-portal', 'Analytics', 'Analytics', $capability, 'wnq-analytics', [self::class, 'render']);
    }

    public static function enqueueAssets($hook): void
    {
        if (!isset($_GET['page']) || $_GET['page'] !== 'wnq-analytics') return;
        wp_enqueue_script('jquery');
    }

    public static function render(): void
    {
        if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions.'));
        }

        $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : 'dashboard';
        
        switch ($view) {
            case 'settings':
                self::renderSettings();
                break;
            case 'clients':
                self::renderClientsManager();
                break;
            case 'edit-client':
                self::renderEditClient();
                break;
            default:
                self::renderDashboard();
                break;
        }
    }

    private static function renderDashboard(): void
    {
        $all_clients = AnalyticsConfig::getAllClients();
        $current_client_id = isset($_GET['client']) ? sanitize_text_field($_GET['client']) : '';
        
        if (empty($current_client_id) && !empty($all_clients)) {
            $current_client_id = $all_clients[0]['client_id'];
        }
        
        $config = $current_client_id ? AnalyticsConfig::getClientConfig($current_client_id) : null;
        $credentials = AnalyticsConfig::getCredentials();

        ?>
        <div class="wrap wnq-analytics-wrap">
            <h1>📊 Analytics Dashboard</h1>
            
            <?php if (empty($all_clients)): ?>
                <div class="notice notice-warning"><p><strong>No clients configured.</strong> <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=clients'); ?>">Add your first client →</a></p></div>
                <?php return; ?>
            <?php endif; ?>

            <?php if (!$credentials): ?>
                <div class="notice notice-error"><p><strong>⚠️ Service account not configured.</strong> <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=settings'); ?>">Configure now →</a></p></div>
                <?php return; ?>
            <?php endif; ?>

            <div class="wnq-analytics-header">
                <div class="wnq-client-selector">
                    <label><strong>Select Client:</strong></label>
                    <select id="client-selector">
                        <?php foreach ($all_clients as $client): ?>
                            <option value="<?php echo esc_attr($client['client_id']); ?>" <?php selected($client['client_id'], $current_client_id); ?>>
                                <?php echo esc_html($client['client_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=clients'); ?>" class="button">👥 Manage Clients</a>
                    <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=settings'); ?>" class="button">⚙️ Settings</a>
                </div>
            </div>

            <?php if ($config): ?>
                <div class="wnq-client-info">
                    <h3>📍 <?php echo esc_html($config['client_name']); ?></h3>
                    <p><strong>Website:</strong> <?php echo esc_html($config['website_url']); ?> | <strong>GA4:</strong> <code><?php echo esc_html($config['ga4_property_id']); ?></code></p>
                </div>

                <div class="wnq-data-controls">
                    <button type="button" id="wnq-refresh-data" class="button button-primary">🔄 Refresh Data</button>
                    <select id="wnq-date-range">
                        <option value="7">Last 7 Days</option>
                        <option value="30" selected>Last 30 Days</option>
                        <option value="90">Last 3 Months</option>
                        <option value="180">Last 6 Months</option>
                        <option value="365">Last Year</option>
                        <option value="730">Last 2 Years</option>
                    </select>
                </div>

                <div id="wnq-analytics-loading" class="wnq-loading"><p>⏳ Loading analytics data...</p></div>
                <div id="wnq-analytics-content" style="display: none;"></div>
            <?php endif; ?>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
        
        <script>
        window.wnqAnalytics = {
            ajaxUrl: '<?php echo admin_url('admin-ajax.php'); ?>',
            nonce: '<?php echo wp_create_nonce('wnq_analytics_nonce'); ?>',
            clientId: '<?php echo esc_js($current_client_id); ?>'
        };

        (function($) {
            let currentChart = null;

            $('#client-selector').on('change', function() {
                window.location.href = '<?php echo admin_url('admin.php?page=wnq-analytics'); ?>&client=' + $(this).val();
            });

            function loadData(days) {
                $('#wnq-analytics-loading').show();
                $('#wnq-analytics-content').hide();

                $.ajax({
                    url: wnqAnalytics.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'wnq_get_analytics_data',
                        nonce: wnqAnalytics.nonce,
                        client_id: wnqAnalytics.clientId,
                        date_range: days
                    },
                    success: function(resp) {
                        console.log('Response:', resp);
                        if (resp.success) {
                            renderData(resp.data, days);
                        } else {
                            showError(resp.data?.message || 'Failed to load data');
                        }
                    },
                    error: function(xhr) {
                        console.error('Error:', xhr);
                        showError('Error loading data');
                    },
                    complete: function() {
                        $('#wnq-refresh-data').prop('disabled', false).text('🔄 Refresh Data');
                    }
                });
            }

            function renderData(data, days) {
                const periodText = days === 7 ? '7 Days' : days === 30 ? '30 Days' : days === 90 ? '3 Months' : days === 180 ? '6 Months' : days === 365 ? '1 Year' : '2 Years';
                
                let html = '<div class="wnq-analytics-dashboard">';
                
                // Header Section
                html += '<div class="wnq-period-header">';
                html += '<h2>📈 Performance Overview</h2>';
                html += '<span class="period-badge">Last ' + periodText + '</span>';
                html += '</div>';
                
                // Traffic Overview Cards
                html += '<div class="wnq-stats-grid">';
                html += '<div class="wnq-stat-card visitors"><div class="stat-icon">👥</div><h3>Visitors</h3><div class="stat-value">' + (data.overview.total_users || 0).toLocaleString() + '</div></div>';
                html += '<div class="wnq-stat-card views"><div class="stat-icon">📄</div><h3>Page Views</h3><div class="stat-value">' + (data.overview.page_views || 0).toLocaleString() + '</div></div>';
                html += '<div class="wnq-stat-card sessions"><div class="stat-icon">🔄</div><h3>Sessions</h3><div class="stat-value">' + (data.overview.sessions || 0).toLocaleString() + '</div></div>';
                html += '<div class="wnq-stat-card bounce"><div class="stat-icon">📊</div><h3>Bounce Rate</h3><div class="stat-value">' + (data.overview.bounce_rate || 0).toFixed(1) + '%</div></div>';
                html += '</div>';
                
                // KEY EVENTS SECTION
                if (data.key_events && data.key_events.length > 0) {
                    html += '<div class="wnq-conversions-section">';
                    html += '<h2>🎯 Key Events & Conversions</h2>';
                    html += '<div class="wnq-conversions-grid">';
                    
                    // Phone Clicks
                    const phoneClicks = data.key_events.find(e => e.event_name === 'Track_Phone') || {count: 0};
                    html += '<div class="wnq-conversion-card phone">';
                    html += '<div class="conversion-icon">📞</div>';
                    html += '<div class="conversion-details">';
                    html += '<h3>Phone Clicks</h3>';
                    html += '<div class="conversion-value">' + (phoneClicks.count || 0).toLocaleString() + '</div>';
                    html += '<p class="conversion-label">Total calls initiated</p>';
                    html += '</div></div>';
                    
                    // Email Clicks
                    const emailClicks = data.key_events.find(e => e.event_name === 'Track_Email') || {count: 0};
                    html += '<div class="wnq-conversion-card email">';
                    html += '<div class="conversion-icon">✉️</div>';
                    html += '<div class="conversion-details">';
                    html += '<h3>Email Clicks</h3>';
                    html += '<div class="conversion-value">' + (emailClicks.count || 0).toLocaleString() + '</div>';
                    html += '<p class="conversion-label">Email links clicked</p>';
                    html += '</div></div>';
                    
                    // Social Clicks
                    const socialClicks = data.key_events.find(e => e.event_name === 'Click - Social') || {count: 0};
                    html += '<div class="wnq-conversion-card social">';
                    html += '<div class="conversion-icon">🌐</div>';
                    html += '<div class="conversion-details">';
                    html += '<h3>Social Clicks</h3>';
                    html += '<div class="conversion-value">' + (socialClicks.count || 0).toLocaleString() + '</div>';
                    html += '<p class="conversion-label">Social media engagement</p>';
                    html += '</div></div>';
                    
                    // Contact Page Views
                    const contactViews = data.key_events.find(e => e.event_name === 'Page View - Contact Page') || {count: 0};
                    html += '<div class="wnq-conversion-card contact">';
                    html += '<div class="conversion-icon">📝</div>';
                    html += '<div class="conversion-details">';
                    html += '<h3>Contact Page</h3>';
                    html += '<div class="conversion-value">' + (contactViews.count || 0).toLocaleString() + '</div>';
                    html += '<p class="conversion-label">Contact page views</p>';
                    html += '</div></div>';
                    
                    // Form Submissions (look for any form-related events)
                    const formSubmits = data.key_events.find(e => 
                        e.event_name.toLowerCase().includes('form') || 
                        e.event_name.toLowerCase().includes('submit') ||
                        e.event_name.toLowerCase().includes('contact')
                    ) || null;
                    
                    if (formSubmits && formSubmits.count > 0 && formSubmits.event_name !== 'Page View - Contact Page') {
                        html += '<div class="wnq-conversion-card form">';
                        html += '<div class="conversion-icon">📋</div>';
                        html += '<div class="conversion-details">';
                        html += '<h3>Form Submissions</h3>';
                        html += '<div class="conversion-value">' + (formSubmits.count || 0).toLocaleString() + '</div>';
                        html += '<p class="conversion-label">' + formSubmits.event_name + '</p>';
                        html += '</div></div>';
                    }
                    
                    html += '</div></div>';
                    
                    // All Events Table
                    html += '<div class="wnq-table-container">';
                    html += '<h2>📋 All Key Events</h2>';
                    html += '<table class="wp-list-table widefat fixed striped">';
                    html += '<thead><tr><th>Event Name</th><th>Count</th><th>Percentage</th></tr></thead>';
                    html += '<tbody>';
                    
                    const totalEvents = data.key_events.reduce((sum, e) => sum + e.count, 0);
                    data.key_events.forEach(event => {
                        const percentage = totalEvents > 0 ? ((event.count / totalEvents) * 100).toFixed(1) : 0;
                        html += '<tr>';
                        html += '<td><strong>' + event.event_name + '</strong></td>';
                        html += '<td>' + event.count.toLocaleString() + '</td>';
                        html += '<td><span style="display: inline-block; width: 60px; background: linear-gradient(90deg, #667eea 0%, #667eea ' + percentage + '%, #e2e8f0 ' + percentage + '%); height: 8px; border-radius: 4px; margin-right: 8px;"></span>' + percentage + '%</td>';
                        html += '</tr>';
                    });
                    
                    html += '</tbody></table>';
                    html += '</div>';
                } else {
                    html += '<div class="notice notice-warning" style="margin: 20px 0;"><p>No key events tracked yet. Make sure your GA4 events are set up correctly.</p></div>';
                }
                
                // Visitors Chart
                if (data.visitors_over_time && data.visitors_over_time.length > 0) {
                    html += '<div class="wnq-chart-container">';
                    html += '<h2>📈 Visitors Trend</h2>';
                    html += '<canvas id="visitors-chart"></canvas>';
                    html += '</div>';
                }
                
                // Traffic Sources & Top Pages Side by Side
                if (data.traffic_sources && data.traffic_sources.length > 0) {
                    html += '<div class="wnq-split-container">';
                    html += '<div class="wnq-table-container half">';
                    html += '<h2>🚀 Traffic Sources</h2>';
                    html += '<table class="wp-list-table widefat fixed striped">';
                    html += '<thead><tr><th>Channel</th><th>Sessions</th><th>%</th></tr></thead>';
                    html += '<tbody>';
                    data.traffic_sources.forEach(s => {
                        html += '<tr><td><strong>' + s.channel + '</strong></td><td>' + s.sessions.toLocaleString() + '</td><td>' + s.percentage + '%</td></tr>';
                    });
                    html += '</tbody></table>';
                    html += '</div>';
                
                    // Top Pages
                    if (data.top_pages && data.top_pages.length > 0) {
                        html += '<div class="wnq-table-container half">';
                        html += '<h2>📄 Top Pages</h2>';
                        html += '<table class="wp-list-table widefat fixed striped">';
                        html += '<thead><tr><th>Page</th><th>Views</th></tr></thead>';
                        html += '<tbody>';
                        data.top_pages.slice(0, 5).forEach(p => {
                            const displayPath = p.path.length > 40 ? p.path.substring(0, 40) + '...' : p.path;
                            html += '<tr><td><code>' + displayPath + '</code></td><td>' + p.views.toLocaleString() + '</td></tr>';
                        });
                        html += '</tbody></table>';
                        html += '</div>';
                    }
                    html += '</div>';
                }
                
                html += '</div>';
                
                $('#wnq-analytics-content').html(html).show();
                $('#wnq-analytics-loading').hide();
                
                // Render chart
                if (data.visitors_over_time && data.visitors_over_time.length > 0 && typeof Chart !== 'undefined') {
                    const ctx = document.getElementById('visitors-chart');
                    if (ctx) {
                        if (currentChart) currentChart.destroy();
                        currentChart = new Chart(ctx, {
                            type: 'line',
                            data: {
                                labels: data.visitors_over_time.map(d => d.date),
                                datasets: [{
                                    label: 'Visitors',
                                    data: data.visitors_over_time.map(d => d.users),
                                    borderColor: '#667eea',
                                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                                    tension: 0.4,
                                    fill: true,
                                    borderWidth: 3,
                                    pointRadius: 4,
                                    pointHoverRadius: 6,
                                    pointBackgroundColor: '#667eea',
                                    pointBorderColor: '#fff',
                                    pointBorderWidth: 2
                                }]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: true,
                                aspectRatio: 3,
                                plugins: { 
                                    legend: { display: false },
                                    tooltip: {
                                        backgroundColor: 'rgba(0,0,0,0.8)',
                                        padding: 12,
                                        titleFont: { size: 14 },
                                        bodyFont: { size: 13 },
                                        borderColor: '#667eea',
                                        borderWidth: 2
                                    }
                                },
                                scales: { 
                                    y: { 
                                        beginAtZero: true,
                                        grid: { color: 'rgba(0,0,0,0.05)' },
                                        ticks: { color: '#718096' }
                                    },
                                    x: {
                                        grid: { display: false },
                                        ticks: { color: '#718096' }
                                    }
                                }
                            }
                        });
                    }
                }
            }

            function showError(msg) {
                $('#wnq-analytics-content').html('<div class="notice notice-error"><p>' + msg + '</p></div>').show();
                $('#wnq-analytics-loading').hide();
            }

            $('#wnq-refresh-data').on('click', function() {
                $(this).prop('disabled', true).text('⏳ Loading...');
                loadData(parseInt($('#wnq-date-range').val()));
            });

            $('#wnq-date-range').on('change', function() {
                loadData(parseInt($(this).val()));
            });

            $(document).ready(function() {
                if (wnqAnalytics.clientId) loadData(30);
            });
        })(jQuery);
        </script>

        <style>
        .wnq-analytics-wrap { max-width: 1600px; margin: 0 auto; }
        .wnq-analytics-header { display: flex; justify-content: space-between; align-items: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 25px; margin: 20px 0; border-radius: 12px; box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3); }
        .wnq-analytics-header * { color: white !important; }
        .wnq-client-selector { display: flex; align-items: center; gap: 12px; }
        .wnq-client-selector label { font-weight: 600; font-size: 15px; }
        .wnq-client-selector select { padding: 10px 15px; font-size: 14px; min-width: 250px; border-radius: 8px; border: 2px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.9); color: #333 !important; }
        
        .wnq-client-info { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); padding: 20px 30px; margin: 20px 0; border-radius: 12px; color: white; box-shadow: 0 4px 15px rgba(240, 147, 251, 0.3); }
        .wnq-client-info h3 { margin: 0 0 8px; font-size: 24px; }
        .wnq-client-info p { margin: 0; opacity: 0.95; }
        
        .wnq-data-controls { background: white; padding: 20px; margin: 20px 0; border-radius: 12px; display: flex; gap: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
        .wnq-data-controls select { padding: 10px 15px; border-radius: 8px; border: 2px solid #e2e8f0; font-size: 14px; }
        
        .wnq-loading { background: white; padding: 60px; text-align: center; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
        
        .wnq-period-header { display: flex; justify-content: space-between; align-items: center; margin: 30px 0 20px; }
        .wnq-period-header h2 { margin: 0; font-size: 26px; color: #1a202c; }
        .period-badge { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 8px 20px; border-radius: 20px; font-weight: 600; font-size: 14px; }
        
        /* Traffic Overview Cards */
        .wnq-stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin: 20px 0; }
        .wnq-stat-card { background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); transition: transform 0.2s, box-shadow 0.2s; }
        .wnq-stat-card:hover { transform: translateY(-2px); box-shadow: 0 4px 20px rgba(0,0,0,0.12); }
        .wnq-stat-card .stat-icon { font-size: 32px; margin-bottom: 10px; }
        .wnq-stat-card h3 { margin: 0 0 10px; font-size: 13px; text-transform: uppercase; color: #718096; font-weight: 600; }
        .wnq-stat-card .stat-value { font-size: 36px; font-weight: bold; color: #1a202c; }
        
        /* Conversions Section */
        .wnq-conversions-section { margin: 40px 0; }
        .wnq-conversions-section h2 { font-size: 24px; margin-bottom: 20px; color: #1a202c; }
        .wnq-conversions-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin: 20px 0; }
        
        .wnq-conversion-card { background: white; border-radius: 12px; padding: 25px; display: flex; align-items: center; gap: 20px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); transition: all 0.3s; position: relative; overflow: hidden; }
        .wnq-conversion-card:hover { transform: translateY(-3px); box-shadow: 0 6px 25px rgba(0,0,0,0.15); }
        
        .wnq-conversion-card::before { content: ''; position: absolute; top: 0; right: 0; width: 100px; height: 100px; border-radius: 50%; opacity: 0.1; }
        .wnq-conversion-card.phone::before { background: #3182ce; }
        .wnq-conversion-card.email::before { background: #805ad5; }
        .wnq-conversion-card.social::before { background: #38b2ac; }
        .wnq-conversion-card.contact::before { background: #ed8936; }
        .wnq-conversion-card.form::before { background: #48bb78; }
        
        .wnq-conversion-card .conversion-icon { font-size: 48px; flex-shrink: 0; }
        .wnq-conversion-card .conversion-details { flex-grow: 1; }
        .wnq-conversion-card h3 { margin: 0 0 8px; font-size: 14px; text-transform: uppercase; color: #718096; font-weight: 600; }
        .wnq-conversion-card .conversion-value { font-size: 32px; font-weight: bold; color: #1a202c; margin-bottom: 4px; }
        .wnq-conversion-card .conversion-label { margin: 0; font-size: 13px; color: #a0aec0; }
        
        .wnq-chart-container, .wnq-table-container { background: white; padding: 30px; margin: 20px 0; border-radius: 12px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); }
        .wnq-chart-container h2, .wnq-table-container h2 { margin: 0 0 25px; font-size: 20px; color: #1a202c; }
        
        .wnq-split-container { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0; }
        .wnq-table-container.half { margin: 0; }
        
        @media (max-width: 1200px) { 
            .wnq-stats-grid { grid-template-columns: repeat(2, 1fr); } 
            .wnq-conversions-grid { grid-template-columns: repeat(2, 1fr); }
            .wnq-split-container { grid-template-columns: 1fr; }
        }
        @media (max-width: 768px) { 
            .wnq-stats-grid, .wnq-conversions-grid { grid-template-columns: 1fr; }
            .wnq-analytics-header { flex-direction: column; gap: 15px; }
        }
        </style>
        <?php
    }

    // CLIENTS MANAGER - Same as before
    private static function renderClientsManager(): void
    {
        $clients = AnalyticsConfig::getAllClients();
        $message = isset($_GET['msg']) ? sanitize_text_field($_GET['msg']) : '';
        
        ?>
        <div class="wrap">
            <h1>👥 Manage Analytics Clients</h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-analytics'); ?>" class="button">← Back to Dashboard</a>

            <?php if ($message === 'added'): ?>
                <div class="notice notice-success is-dismissible"><p>✅ Client added!</p></div>
            <?php elseif ($message === 'updated'): ?>
                <div class="notice notice-success is-dismissible"><p>✅ Client updated!</p></div>
            <?php elseif ($message === 'deleted'): ?>
                <div class="notice notice-success is-dismissible"><p>✅ Client deleted!</p></div>
            <?php elseif ($message === 'error'): ?>
                <div class="notice notice-error is-dismissible"><p>❌ An error occurred.</p></div>
            <?php endif; ?>

            <div class="wnq-form-card">
                <h2>➕ Add New Client</h2>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                    <?php wp_nonce_field('wnq_add_analytics_client'); ?>
                    <input type="hidden" name="action" value="wnq_add_analytics_client">
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="client_id">Client ID *</label></th>
                            <td>
                                <input type="text" name="client_id" id="client_id" class="regular-text" required placeholder="my-client-name">
                                <p class="description">Unique identifier (lowercase, no spaces)</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="client_name">Client Name *</label></th>
                            <td><input type="text" name="client_name" id="client_name" class="regular-text" required placeholder="My Client Name"></td>
                        </tr>
                        <tr>
                            <th><label for="ga4_property_id">GA4 Property ID *</label></th>
                            <td>
                                <input type="text" name="ga4_property_id" id="ga4_property_id" class="regular-text" required placeholder="properties/123456789">
                                <p class="description">Must start with "properties/"</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="website_url">Website URL *</label></th>
                            <td><input type="url" name="website_url" id="website_url" class="regular-text" required placeholder="https://example.com"></td>
                        </tr>
                    </table>
                    
                    <p class="submit"><button type="submit" class="button button-primary">Add Client</button></p>
                </form>
            </div>

            <div class="wnq-form-card">
                <h2>📋 Existing Clients (<?php echo count($clients); ?>)</h2>
                
                <?php if (empty($clients)): ?>
                    <p>No clients yet.</p>
                <?php else: ?>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Client Name</th>
                                <th>Website</th>
                                <th>GA4 Property</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($clients as $client): ?>
                                <tr>
                                    <td><strong><?php echo esc_html($client['client_name']); ?></strong></td>
                                    <td><?php echo esc_html($client['website_url']); ?></td>
                                    <td><code><?php echo esc_html($client['ga4_property_id']); ?></code></td>
                                    <td>
                                        <a href="<?php echo admin_url('admin.php?page=wnq-analytics&client=' . urlencode($client['client_id'])); ?>" class="button button-small">View Analytics</a>
                                        <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=edit-client&id=' . urlencode($client['client_id'])); ?>" class="button button-small">Edit</a>
                                        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                                            <?php wp_nonce_field('wnq_delete_analytics_client'); ?>
                                            <input type="hidden" name="action" value="wnq_delete_analytics_client">
                                            <input type="hidden" name="client_id" value="<?php echo esc_attr($client['client_id']); ?>">
                                            <button type="submit" class="button button-small" onclick="return confirm('Delete this client?');">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <style>
        .wnq-form-card { background: #fff; padding: 24px; border: 1px solid #ddd; border-radius: 4px; margin: 20px 0; }
        .wnq-form-card h2 { margin-top: 0; padding-bottom: 15px; border-bottom: 1px solid #ddd; }
        </style>
        <?php
    }

    // EDIT CLIENT
    private static function renderEditClient(): void
    {
        $client_id = isset($_GET['id']) ? sanitize_text_field($_GET['id']) : '';
        $client = AnalyticsConfig::getClientConfig($client_id);
        
        if (!$client) {
            wp_die('Client not found');
        }
        
        ?>
        <div class="wrap">
            <h1>✏️ Edit Client: <?php echo esc_html($client['client_name']); ?></h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=clients'); ?>" class="button">← Back to Clients</a>

            <div class="wnq-form-card">
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                    <?php wp_nonce_field('wnq_update_analytics_client'); ?>
                    <input type="hidden" name="action" value="wnq_update_analytics_client">
                    <input type="hidden" name="client_id" value="<?php echo esc_attr($client['client_id']); ?>">
                    
                    <table class="form-table">
                        <tr>
                            <th><label>Client ID</label></th>
                            <td>
                                <input type="text" value="<?php echo esc_attr($client['client_id']); ?>" class="regular-text" readonly>
                                <p class="description">Cannot be changed</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="client_name">Client Name *</label></th>
                            <td><input type="text" name="client_name" id="client_name" value="<?php echo esc_attr($client['client_name']); ?>" class="regular-text" required></td>
                        </tr>
                        <tr>
                            <th><label for="ga4_property_id">GA4 Property ID *</label></th>
                            <td>
                                <input type="text" name="ga4_property_id" id="ga4_property_id" value="<?php echo esc_attr($client['ga4_property_id']); ?>" class="regular-text" required>
                                <p class="description">Must start with "properties/"</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="website_url">Website URL *</label></th>
                            <td><input type="url" name="website_url" id="website_url" value="<?php echo esc_attr($client['website_url']); ?>" class="regular-text" required></td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary">Update Client</button>
                        <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=clients'); ?>" class="button">Cancel</a>
                    </p>
                </form>
            </div>
        </div>

        <style>
        .wnq-form-card { background: #fff; padding: 24px; border: 1px solid #ddd; border-radius: 4px; margin: 20px 0; }
        </style>
        <?php
    }

    // SETTINGS
    private static function renderSettings(): void
    {
        $credentials = AnalyticsConfig::getCredentials();
        $message = isset($_GET['msg']) ? sanitize_text_field($_GET['msg']) : '';
        
        ?>
        <div class="wrap">
            <h1>⚙️ Global Analytics Settings</h1>
            <a href="<?php echo admin_url('admin.php?page=wnq-analytics'); ?>" class="button">← Back to Dashboard</a>

            <?php if ($message === 'saved'): ?>
                <div class="notice notice-success is-dismissible"><p>✅ Settings saved!</p></div>
            <?php endif; ?>

            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" enctype="multipart/form-data">
                <?php wp_nonce_field('wnq_save_analytics_settings'); ?>
                <input type="hidden" name="action" value="wnq_save_analytics_settings">
                
                <div class="wnq-form-card">
                    <h2>🔐 Service Account (Shared)</h2>
                    <p>Upload your Google Cloud service account JSON file.</p>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="credentials_file">Service Account JSON</label></th>
                            <td>
                                <input type="file" name="credentials_file" id="credentials_file" accept=".json">
                                <?php if ($credentials): ?>
                                    <p class="description" style="color: #0d8a00;">✅ Current: <?php echo esc_html($credentials['email']); ?></p>
                                <?php else: ?>
                                    <p class="description" style="color: #dc3232;">⚠️ No credentials uploaded</p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit"><button type="submit" class="button button-primary">💾 Save Settings</button></p>
                </div>
            </form>

            <div class="wnq-form-card">
                <h2>📋 Setup Instructions</h2>
                <ol style="line-height: 2;">
                    <li><strong>Create Service Account:</strong> Google Cloud Console → Create service account → Download JSON</li>
                    <li><strong>Enable APIs:</strong> Enable "Google Analytics Data API"</li>
                    <li><strong>Upload Credentials:</strong> Upload JSON file above</li>
                    <li><strong>Grant Access:</strong> GA4: Admin → Property Access → Add <?php echo $credentials ? '<code>' . esc_html($credentials['email']) . '</code>' : 'service account'; ?> as Viewer</li>
                    <li><strong>Add Clients:</strong> Go to <a href="<?php echo admin_url('admin.php?page=wnq-analytics&view=clients'); ?>">Manage Clients</a></li>
                </ol>
            </div>
        </div>

        <style>
        .wnq-form-card { background: #fff; padding: 24px; border: 1px solid #ddd; border-radius: 4px; margin: 20px 0; }
        .wnq-form-card h2 { margin-top: 0; padding-bottom: 15px; border-bottom: 1px solid #ddd; }
        </style>
        <?php
    }

    // AJAX HANDLER
    public static function ajaxGetAnalyticsData(): void
    {
        try {
            check_ajax_referer('wnq_analytics_nonce', 'nonce');

            if (!current_user_can('manage_options') && !current_user_can('wnq_manage_portal')) {
                wp_send_json_error(['message' => 'Permission denied']);
            }

            $client_id = sanitize_text_field($_POST['client_id'] ?? '');
            $date_range = intval($_POST['date_range'] ?? 30);

            $config = AnalyticsConfig::getClientConfig($client_id);
            $credentials = AnalyticsConfig::getCredentials();

            if (!$config || !$credentials) {
                wp_send_json_error(['message' => 'Not configured']);
            }

            $token = self::getGoogleAccessToken($credentials['credentials']);
            $end_date = date('Y-m-d');
            $start_date = date('Y-m-d', strtotime("-{$date_range} days"));

            $data = [];

            // GA4 Data
            try {
                $data['overview'] = self::fetchOverviewStats($token, $config['ga4_property_id'], $start_date, $end_date);
                $data['visitors_over_time'] = self::fetchVisitorsOverTime($token, $config['ga4_property_id'], $start_date, $end_date);
                $data['traffic_sources'] = self::fetchTrafficSources($token, $config['ga4_property_id'], $start_date, $end_date);
                $data['top_pages'] = self::fetchTopPages($token, $config['ga4_property_id'], $start_date, $end_date);
                $data['key_events'] = self::fetchKeyEvents($token, $config['ga4_property_id'], $start_date, $end_date);
            } catch (\Exception $e) {
                $data['overview'] = ['total_users' => 0, 'page_views' => 0, 'sessions' => 0, 'bounce_rate' => 0];
                $data['visitors_over_time'] = [];
                $data['traffic_sources'] = [];
                $data['top_pages'] = [];
                $data['key_events'] = [];
            }

            wp_send_json_success($data);

        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }

    // Form Handlers
    public static function handleSaveSettings(): void
    {
        check_admin_referer('wnq_save_analytics_settings');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        if (isset($_FILES['credentials_file']) && $_FILES['credentials_file']['size'] > 0) {
            $file = $_FILES['credentials_file'];
            $json = file_get_contents($file['tmp_name']);
            $creds = json_decode($json, true);

            if ($creds && isset($creds['client_email']) && isset($creds['private_key'])) {
                AnalyticsConfig::saveCredentials($creds);
            }
        }

        delete_transient('wnq_ga_access_token');
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=settings&msg=saved'));
        exit;
    }

    public static function handleAddClient(): void
    {
        check_admin_referer('wnq_add_analytics_client');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $config = [
            'client_id' => sanitize_text_field($_POST['client_id']),
            'client_name' => sanitize_text_field($_POST['client_name']),
            'ga4_property_id' => sanitize_text_field($_POST['ga4_property_id']),
            'website_url' => esc_url_raw($_POST['website_url']),
            'timezone' => 'America/New_York'
        ];

        $result = AnalyticsConfig::saveClientConfig($config);
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=clients&msg=' . ($result ? 'added' : 'error')));
        exit;
    }

    public static function handleUpdateClient(): void
    {
        check_admin_referer('wnq_update_analytics_client');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $config = [
            'client_id' => sanitize_text_field($_POST['client_id']),
            'client_name' => sanitize_text_field($_POST['client_name']),
            'ga4_property_id' => sanitize_text_field($_POST['ga4_property_id']),
            'website_url' => esc_url_raw($_POST['website_url']),
            'timezone' => 'America/New_York'
        ];

        $result = AnalyticsConfig::saveClientConfig($config);
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=clients&msg=' . ($result ? 'updated' : 'error')));
        exit;
    }

    public static function handleDeleteClient(): void
    {
        check_admin_referer('wnq_delete_analytics_client');
        if (!current_user_can('manage_options')) wp_die('Insufficient permissions');

        $client_id = sanitize_text_field($_POST['client_id']);
        $result = AnalyticsConfig::deleteClient($client_id);
        wp_redirect(admin_url('admin.php?page=wnq-analytics&view=clients&msg=' . ($result ? 'deleted' : 'error')));
        exit;
    }

    // Data Fetching Methods
    private static function getGoogleAccessToken(array $credentials): string
    {
        $cached = get_transient('wnq_ga_access_token');
        if ($cached) return $cached;

        $now = time();
        $header = ['alg' => 'RS256', 'typ' => 'JWT'];
        $claim = [
            'iss' => $credentials['client_email'],
            'scope' => 'https://www.googleapis.com/auth/analytics.readonly',
            'aud' => 'https://oauth2.googleapis.com/token',
            'exp' => $now + 3600,
            'iat' => $now
        ];

        $segments = [
            self::base64UrlEncode(wp_json_encode($header)),
            self::base64UrlEncode(wp_json_encode($claim))
        ];
        $signing_input = implode('.', $segments);

        $signature = '';
        if (!openssl_sign($signing_input, $signature, $credentials['private_key'], 'SHA256')) {
            throw new \Exception('JWT signing failed');
        }

        $segments[] = self::base64UrlEncode($signature);
        $jwt = implode('.', $segments);

        $response = wp_remote_post('https://oauth2.googleapis.com/token', [
            'body' => ['grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion' => $jwt],
            'timeout' => 30
        ]);

        if (is_wp_error($response)) throw new \Exception('Token request failed');

        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!isset($body['access_token'])) {
            throw new \Exception('Token failed: ' . ($body['error_description'] ?? 'Unknown'));
        }

        $token = $body['access_token'];
        set_transient('wnq_ga_access_token', $token, 3000);
        return $token;
    }

    // FETCH KEY EVENTS - NEW METHOD
    private static function fetchKeyEvents(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'eventName']],
            'metrics' => [['name' => 'eventCount']],
            'dimensionFilter' => [
                'filter' => [
                    'fieldName' => 'eventName',
                    'inListFilter' => [
                        'values' => [
                            'Track_Phone',
                            'Track_Email',
                            'Click - Social',
                            'Page View - Contact Page',
                            'form_submit',
                            'submit_form',
                            'contact_form_submit'
                        ]
                    ]
                ]
            ],
            'orderBys' => [['metric' => ['metricName' => 'eventCount'], 'desc' => true]]
        ]);
        
        $events = [];
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $events[] = [
                    'event_name' => $row['dimensionValues'][0]['value'],
                    'count' => intval($row['metricValues'][0]['value'])
                ];
            }
        }
        return $events;
    }

    private static function fetchOverviewStats(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'metrics' => [
                ['name' => 'totalUsers'],
                ['name' => 'screenPageViews'],
                ['name' => 'sessions'],
                ['name' => 'bounceRate']
            ]
        ]);
        
        $m = $data['rows'][0]['metricValues'] ?? [];
        return [
            'total_users' => isset($m[0]) ? intval($m[0]['value']) : 0,
            'page_views' => isset($m[1]) ? intval($m[1]['value']) : 0,
            'sessions' => isset($m[2]) ? intval($m[2]['value']) : 0,
            'bounce_rate' => isset($m[3]) ? floatval($m[3]['value']) * 100 : 0
        ];
    }

    private static function fetchVisitorsOverTime(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'date']],
            'metrics' => [['name' => 'totalUsers'], ['name' => 'sessions']],
            'orderBys' => [['dimension' => ['dimensionName' => 'date']]]
        ]);
        
        $trends = [];
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $date = $row['dimensionValues'][0]['value'];
                $trends[] = [
                    'date' => substr($date, 0, 4) . '-' . substr($date, 4, 2) . '-' . substr($date, 6, 2),
                    'users' => intval($row['metricValues'][0]['value']),
                    'sessions' => intval($row['metricValues'][1]['value'])
                ];
            }
        }
        return $trends;
    }

    private static function fetchTrafficSources(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'sessionDefaultChannelGroup']],
            'metrics' => [['name' => 'sessions'], ['name' => 'totalUsers']],
            'orderBys' => [['metric' => ['metricName' => 'sessions'], 'desc' => true]],
            'limit' => 10
        ]);
        
        $sources = [];
        $total = 0;
        
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $total += intval($row['metricValues'][0]['value']);
            }
            foreach ($data['rows'] as $row) {
                $sessions = intval($row['metricValues'][0]['value']);
                $sources[] = [
                    'channel' => $row['dimensionValues'][0]['value'],
                    'sessions' => $sessions,
                    'users' => intval($row['metricValues'][1]['value']),
                    'percentage' => $total > 0 ? round(($sessions / $total) * 100, 1) : 0
                ];
            }
        }
        return $sources;
    }

    private static function fetchTopPages(string $token, string $property_id, string $start, string $end): array
    {
        $data = self::makeGARequest($token, $property_id, [
            'dateRanges' => [['startDate' => $start, 'endDate' => $end]],
            'dimensions' => [['name' => 'pagePath'], ['name' => 'pageTitle']],
            'metrics' => [['name' => 'screenPageViews'], ['name' => 'bounceRate']],
            'orderBys' => [['metric' => ['metricName' => 'screenPageViews'], 'desc' => true]],
            'limit' => 10
        ]);
        
        $pages = [];
        if (isset($data['rows'])) {
            foreach ($data['rows'] as $row) {
                $pages[] = [
                    'path' => $row['dimensionValues'][0]['value'],
                    'title' => $row['dimensionValues'][1]['value'] ?? 'Untitled',
                    'views' => intval($row['metricValues'][0]['value']),
                    'bounce_rate' => floatval($row['metricValues'][1]['value'] ?? 0) * 100
                ];
            }
        }
        return $pages;
    }

    private static function makeGARequest(string $token, string $property_id, array $body): array
    {
        $url = "https://analyticsdata.googleapis.com/v1beta/{$property_id}:runReport";
        
        $response = wp_remote_post($url, [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
            'body' => wp_json_encode($body),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) throw new \Exception('GA API failed');

        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);

        if ($code !== 200) {
            throw new \Exception('GA API error: ' . ($data['error']['message'] ?? 'Unknown'));
        }

        return $data;
    }

    private static function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
}