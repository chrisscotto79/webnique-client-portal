<?php
/**
 * Plugin Name: WebNique Client Portal
 * Description: Complete client management with portal, analytics, billing, tasks, and messaging
 * Version: 1.0.0
 * Author: WebNique
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Text Domain: webnique-portal
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WNQ_PORTAL_VERSION', '1.0.0');
define('WNQ_PORTAL_PATH', plugin_dir_path(__FILE__));
define('WNQ_PORTAL_URL', plugin_dir_url(__FILE__));

$plugin_file = WNQ_PORTAL_PATH . 'includes/Core/Plugin.php';

if (!file_exists($plugin_file)) {
    add_action('admin_notices', function() use ($plugin_file) {
        echo '<div class="notice notice-error"><p><strong>WebNique Portal Error:</strong> Core Plugin file not found</p></div>';
    });
    return;
}

require_once $plugin_file;

if (!class_exists('WNQ\\Core\\Plugin')) {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-error"><p><strong>WebNique Portal Error:</strong> Plugin class could not be loaded</p></div>';
    });
    return;
}

// ACTIVATION
register_activation_hook(__FILE__, function() {
    if (class_exists('WNQ\\Core\\Plugin')) {
        WNQ\Core\Plugin::activate();
    }
    
    // Create clients table
    $client_model = WNQ_PORTAL_PATH . 'includes/Models/Client.php';
    if (file_exists($client_model)) {
        require_once $client_model;
        if (class_exists('WNQ\\Models\\Client')) {
            \WNQ\Models\Client::createTable();
        }
    }
    
    // Create tasks table
    $task_model = WNQ_PORTAL_PATH . 'includes/Models/Task.php';
    if (file_exists($task_model)) {
        require_once $task_model;
        if (class_exists('WNQ\\Models\\Task')) {
            \WNQ\Models\Task::createTable();
        }
    }
    
    // Create analytics tables
    $analytics_config = WNQ_PORTAL_PATH . 'includes/Models/AnalyticsConfig.php';
    if (file_exists($analytics_config)) {
        require_once $analytics_config;
        if (class_exists('WNQ\\Models\\AnalyticsConfig')) {
            \WNQ\Models\AnalyticsConfig::createTables();
        }
    }
});

// DEACTIVATION
register_deactivation_hook(__FILE__, function() {
    if (class_exists('WNQ\\Core\\Plugin') && method_exists('WNQ\\Core\\Plugin', 'deactivate')) {
        WNQ\Core\Plugin::deactivate();
    }
    flush_rewrite_rules();
});

// INITIALIZE
add_action('plugins_loaded', function() {
    if (!class_exists('WNQ\\Core\\Plugin')) {
        return;
    }
    
    try {
        WNQ\Core\Plugin::init();
    } catch (Exception $e) {
        error_log('WebNique Portal Init Error: ' . $e->getMessage());
    }
}, 10);

// CLIENT HANDLERS
add_action('admin_post_wnq_save_client', function() {
    $clients_admin = WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
    if (file_exists($clients_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
        require_once $clients_admin;
        \WNQ\Admin\ClientsAdmin::handleSaveClient();
    }
});

add_action('admin_post_wnq_delete_client_from_clients', function() {
    $clients_admin = WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
    if (file_exists($clients_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
        require_once $clients_admin;
        \WNQ\Admin\ClientsAdmin::handleDeleteClient();
    }
});

add_action('admin_post_wnq_mark_paid', function() {
    $clients_admin = WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
    if (file_exists($clients_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Client.php';
        require_once $clients_admin;
        \WNQ\Admin\ClientsAdmin::handleMarkPaid();
    }
});

// TASK HANDLERS
add_action('admin_post_wnq_save_task', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::handleSaveTask();
    }
});

add_action('admin_post_wnq_delete_task', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::handleDeleteTask();
    }
});

add_action('admin_post_wnq_archive_task', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::handleArchive();
    }
});

add_action('admin_post_wnq_restore_task', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::handleRestore();
    }
});

add_action('admin_post_wnq_complete_recurring', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::handleCompleteRecurring();
    }
});

// ANALYTICS HANDLERS
add_action('admin_post_wnq_save_analytics_settings', function() {
    $analytics_admin = WNQ_PORTAL_PATH . 'admin/AnalyticsAdmin.php';
    if (file_exists($analytics_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/AnalyticsConfig.php';
        require_once $analytics_admin;
        \WNQ\Admin\AnalyticsAdmin::handleSaveSettings();
    }
});

add_action('admin_post_wnq_test_analytics_connection', function() {
    $analytics_admin = WNQ_PORTAL_PATH . 'admin/AnalyticsAdmin.php';
    if (file_exists($analytics_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/AnalyticsConfig.php';
        require_once $analytics_admin;
        \WNQ\Admin\AnalyticsAdmin::handleTestConnection();
    }
});

add_action('admin_post_wnq_clear_analytics_cache', function() {
    $analytics_admin = WNQ_PORTAL_PATH . 'admin/AnalyticsAdmin.php';
    if (file_exists($analytics_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/API/AnalyticsCache.php';
        require_once $analytics_admin;
        \WNQ\Admin\AnalyticsAdmin::handleClearCache();
    }
});

// AJAX HANDLERS
add_action('wp_ajax_wnq_update_task_status', function() {
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (file_exists($tasks_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/Task.php';
        require_once $tasks_admin;
        \WNQ\Admin\TasksAdmin::ajaxUpdateTaskStatus();
    }
});

add_action('wp_ajax_wnq_get_analytics_data', function() {
    $analytics_admin = WNQ_PORTAL_PATH . 'admin/AnalyticsAdmin.php';
    if (file_exists($analytics_admin)) {
        require_once WNQ_PORTAL_PATH . 'includes/Models/AnalyticsConfig.php';
        require_once WNQ_PORTAL_PATH . 'includes/API/GoogleAnalytics.php';
        require_once WNQ_PORTAL_PATH . 'includes/API/GoogleSearchConsole.php';
        require_once WNQ_PORTAL_PATH . 'includes/API/AnalyticsCache.php';
        require_once $analytics_admin;
        \WNQ\Admin\AnalyticsAdmin::ajaxGetAnalyticsData();
    }
});

// ADMIN MENU
add_action('admin_menu', function() {
    $capability = current_user_can('wnq_manage_portal') ? 'wnq_manage_portal' : 'manage_options';
    
    add_menu_page(
        'WebNique Portal',
        'WebNique Portal',
        $capability,
        'wnq-portal',
        'wnq_render_settings_page',
        'dashicons-chart-area',
        58
    );
    
    add_submenu_page('wnq-portal', 'Settings', 'Settings', $capability, 'wnq-portal', 'wnq_render_settings_page');
    add_submenu_page('wnq-portal', 'Clients', 'Clients', $capability, 'wnq-clients', 'wnq_render_clients_page');
    add_submenu_page('wnq-portal', 'Tasks', 'Tasks', $capability, 'wnq-tasks', 'wnq_render_tasks_page');
    add_submenu_page('wnq-portal', 'Analytics', 'Analytics', $capability, 'wnq-analytics', 'wnq_render_analytics_page');
    add_submenu_page('wnq-portal', 'Web Requests', 'Web Requests', $capability, 'wnq-web-requests', 'wnq_render_requests_page');
}, 10);

// RENDER FUNCTIONS
function wnq_render_settings_page() {
    if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    
    $version = WNQ_PORTAL_VERSION;
    wp_enqueue_style('wnq-admin-settings', WNQ_PORTAL_URL . 'assets/app/app.css', [], $version);
    wp_enqueue_script('wnq-admin-settings', WNQ_PORTAL_URL . 'assets/app/app.js', [], $version, true);
    
    add_filter('script_loader_tag', function ($tag, $handle, $src) {
        if ($handle !== 'wnq-admin-settings') return $tag;
        return '<script type="module" src="' . esc_url($src) . '"></script>';
    }, 10, 3);
    
    wp_localize_script('wnq-admin-settings', 'WNQ_ADMIN', [
        'restUrl' => esc_url_raw(rest_url('wnq/v1')),
        'nonce' => wp_create_nonce('wp_rest'),
        'isAdmin' => true,
        'ajaxUrl' => admin_url('admin-ajax.php'),
    ]);
    
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        <div id="wnq-admin-settings-root"></div>
    </div>
    <?php
}

function wnq_render_clients_page() {
    if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    
    $client_model = WNQ_PORTAL_PATH . 'includes/Models/Client.php';
    if (!file_exists($client_model)) {
        echo '<div class="wrap"><div class="notice notice-error"><p><strong>Error:</strong> Client model not found.</p></div></div>';
        return;
    }
    
    require_once $client_model;
    
    $clients_admin = WNQ_PORTAL_PATH . 'admin/ClientsAdmin.php';
    if (!file_exists($clients_admin)) {
        echo '<div class="wrap"><div class="notice notice-error"><p><strong>Error:</strong> ClientsAdmin not found.</p></div></div>';
        return;
    }
    
    require_once $clients_admin;
    \WNQ\Admin\ClientsAdmin::render();
}

function wnq_render_tasks_page() {
    if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    
    $task_model = WNQ_PORTAL_PATH . 'includes/Models/Task.php';
    if (!file_exists($task_model)) {
        echo '<div class="wrap"><div class="notice notice-error"><p><strong>Error:</strong> Task model not found.</p></div></div>';
        return;
    }
    
    require_once $task_model;
    
    $tasks_admin = WNQ_PORTAL_PATH . 'admin/TasksAdmin.php';
    if (!file_exists($tasks_admin)) {
        echo '<div class="wrap"><div class="notice notice-error"><p><strong>Error:</strong> TasksAdmin not found.</p></div></div>';
        return;
    }
    
    require_once $tasks_admin;
    \WNQ\Admin\TasksAdmin::render();
}

function wnq_render_analytics_page() {
    if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    
    $analytics_config = WNQ_PORTAL_PATH . 'includes/Models/AnalyticsConfig.php';
    if (!file_exists($analytics_config)) {
        echo '<div class="wrap"><div class="notice notice-error"><p><strong>Error:</strong> AnalyticsConfig model not found.</p></div></div>';
        return;
    }
    
    require_once $analytics_config;
    require_once WNQ_PORTAL_PATH . 'includes/API/GoogleAnalytics.php';
    require_once WNQ_PORTAL_PATH . 'includes/API/GoogleSearchConsole.php';
    require_once WNQ_PORTAL_PATH . 'includes/API/AnalyticsCache.php';
    
    $analytics_admin = WNQ_PORTAL_PATH . 'admin/AnalyticsAdmin.php';
    if (!file_exists($analytics_admin)) {
        echo '<div class="wrap"><div class="notice notice-error"><p><strong>Error:</strong> AnalyticsAdmin not found.</p></div></div>';
        return;
    }
    
    require_once $analytics_admin;
    \WNQ\Admin\AnalyticsAdmin::render();
}

function wnq_render_requests_page() {
    if (!current_user_can('wnq_manage_portal') && !current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    
    $version = WNQ_PORTAL_VERSION;
    
    wp_enqueue_style('wnq-admin-requests', WNQ_PORTAL_URL . 'assets/admin/requests-admin.css', [], $version);
    wp_enqueue_script('wnq-admin-requests', WNQ_PORTAL_URL . 'assets/admin/requests-admin.js', [], $version, true);
    
    add_filter('script_loader_tag', function ($tag, $handle, $src) {
        if ($handle !== 'wnq-admin-requests') return $tag;
        return '<script type="module" src="' . esc_url($src) . '"></script>';
    }, 10, 3);
    
    $current_user = wp_get_current_user();
    
    wp_localize_script('wnq-admin-requests', 'WNQ_ADMIN_CONFIG', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('wnq_admin_requests'),
        'restUrl' => esc_url_raw(rest_url('wnq/v1')),
        'user' => [
            'id' => get_current_user_id(),
            'name' => $current_user->display_name ?: $current_user->user_login,
            'email' => $current_user->user_email,
        ],
        'firebaseConfig' => [
            'apiKey' => 'AIzaSyDlN2rZlJYC0u1_mq9oEqApb1crQe-Nrk8',
            'authDomain' => 'webnique-client-portal.firebaseapp.com',
            'projectId' => 'webnique-client-portal',
            'storageBucket' => 'webnique-client-portal.firebasestorage.app',
            'messagingSenderId' => '174763137944',
            'appId' => '1:174763137944:web:2e6e6b3adb39b9ccc5a9ed',
        ],
    ]);
    
    ?>
    <div class="wrap wnq-admin-requests">
        <div id="wnq-admin-requests-root">
            <div style="padding: 40px; text-align: center;">
                <div class="wnq-spinner"></div>
                <p style="margin-top: 20px; color: #6b7280;">Loading requests...</p>
            </div>
        </div>
    </div>
    
    <style>
    .wnq-spinner {
        border: 3px solid #e5e7eb;
        border-top-color: #0d539e;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        animation: spin 0.8s linear infinite;
        margin: 0 auto;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    </style>
    <?php
}
