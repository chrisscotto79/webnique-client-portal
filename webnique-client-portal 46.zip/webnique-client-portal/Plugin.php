<?php
/**
 * Core Plugin Class
 * 
 * Main initialization and bootstrap for WebNique Client Portal
 * 
 * @package WebNique Portal
 */

namespace WNQ\Core;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Plugin
 * Handles plugin initialization and component loading
 */
final class Plugin
{
    /**
     * Initialize the plugin
     */
    public static function init(): void
    {
        // Load core classes
        self::loadCore();
        
        // Initialize admin area
        if (is_admin()) {
            self::initAdmin();
        }
        
        // Initialize public/frontend area
        self::initPublic();
        
        // Register REST API routes
        self::registerRestRoutes();
    }

    /**
     * Load core classes
     */
    private static function loadCore(): void
    {
        // Core functionality
        require_once WNQ_PORTAL_PATH . 'includes/Core/Permissions.php';
        require_once WNQ_PORTAL_PATH . 'includes/Core/Router.php';
        require_once WNQ_PORTAL_PATH . 'includes/Core/UserMeta.php';
        
        // Initialize permissions
        Permissions::init();
    }

    /**
     * Initialize admin area
     */
    private static function initAdmin(): void
    {
        // Load admin classes
        require_once WNQ_PORTAL_PATH . 'admin/AdminMenu.php';
        require_once WNQ_PORTAL_PATH . 'admin/AdminSettings.php';
        require_once WNQ_PORTAL_PATH . 'admin/RequestsAdmin.php';

        // Register admin pages
        \WNQ\Admin\AdminMenu::register();
        \WNQ\Admin\RequestsAdmin::register();
    }

    /**
     * Initialize public/frontend area
     */
    private static function initPublic(): void
    {
        // Load public classes
        require_once WNQ_PORTAL_PATH . 'public/Shortcode.php';
        
        // Register shortcode
        \WNQ\PublicSite\Shortcode::register();
    }

    /**
     * Register REST API routes
     */
    private static function registerRestRoutes(): void
    {
        // Load REST API controllers
        add_action('rest_api_init', function() {
            // Check if controllers exist before loading
            $controllers_path = WNQ_PORTAL_PATH . 'includes/Controllers/';
            
            if (file_exists($controllers_path)) {
                // Load all controller files
                $controllers = [
                    'DashboardController.php',
                    'SubscriptionController.php',
                    'AnalyticsController.php',
                    'MessagesController.php',
                    'SettingsController.php',
                    'ThreadsController.php',
                ];

                foreach ($controllers as $controller) {
                    $file = $controllers_path . $controller;
                    if (file_exists($file)) {
                        require_once $file;
                    }
                }

                // Register routes
                if (class_exists('WNQ\\Controllers\\DashboardController')) {
                    \WNQ\Controllers\DashboardController::register();
                }
                if (class_exists('WNQ\\Controllers\\SubscriptionController')) {
                    \WNQ\Controllers\SubscriptionController::register();
                }
                if (class_exists('WNQ\\Controllers\\AnalyticsController')) {
                    \WNQ\Controllers\AnalyticsController::register();
                }
                if (class_exists('WNQ\\Controllers\\MessagesController')) {
                    \WNQ\Controllers\MessagesController::register();
                }
                if (class_exists('WNQ\\Controllers\\SettingsController')) {
                    \WNQ\Controllers\SettingsController::register();
                }
                if (class_exists('WNQ\\Controllers\\ThreadsController')) {
                    \WNQ\Controllers\ThreadsController::register();
                }
            }
        });
    }

    /**
     * Plugin activation hook
     */
    public static function activate(): void
    {
        // Create custom capabilities
        $admin_role = get_role('administrator');
        if ($admin_role) {
            $admin_role->add_cap('wnq_manage_portal');
        }

        // Flush rewrite rules
        flush_rewrite_rules();

        // Log activation
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('WebNique Portal: Plugin activated');
        }
    }
    add_action('admin_menu', function() {
    add_menu_page(
        'TEST Menu',              // Page title
        'TEST Menu',              // Menu label
        'manage_options',         // Capability
        'wnq-test-menu',         // Menu slug
        function() {              // Callback
            echo '<div class="wrap">';
            echo '<h1>Test Menu Works!</h1>';
            echo '<p>If you see this, WordPress can create menus.</p>';
            echo '<p>The problem is in Plugin.php not calling AdminMenu::register()</p>';
            echo '</div>';
        },
        'dashicons-admin-generic', // Icon
        59                         // Position (right after where yours should be)
    );
}, 1);

    /**
     * Plugin deactivation hook
     */
    public static function deactivate(): void
    {
        // Flush rewrite rules
        flush_rewrite_rules();

        // Log deactivation
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('WebNique Portal: Plugin deactivated');
        }
    }
}