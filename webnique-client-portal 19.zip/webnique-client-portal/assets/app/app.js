// assets/app/app.js
import { initAppState } from "./modules/state.js";
import { mountShell } from "./modules/ui.js";

import { renderDashboard } from "./modules/tabs/dashboard.js";
import { renderSubscription } from "./modules/tabs/subscription.js";
import { renderAnalytics } from "./modules/tabs/analytics.js";
import { renderRequests } from "./modules/tabs/requests.js";
import { renderSettings } from "./modules/tabs/settings.js";

(function () {
  const root = document.getElementById("wnq-portal-root");
  if (!root) return;

  const state = initAppState(root);

  // Build outer shell + tabs container
  const shell = mountShell(root, state, {
    onTabChange: (key) => renderTab(key),
  });

  function renderTab(key) {
    shell.setActiveTab(key);

    // Clear the main area and render the selected tab
    shell.main.innerHTML = "";

    const map = {
      dashboard: renderDashboard,
      subscription: renderSubscription,
      analytics: renderAnalytics,
      requests: renderRequests,
      settings: renderSettings,
    };

    const fn = map[key] || renderDashboard;
    fn(shell.main, shell.side, state, shell);
  }

  renderTab("dashboard");
})();
