// assets/app/modules/api.js
export async function api(state, path, opts = {}) {
  if (!state.restBase || !state.nonce) throw new Error("Missing restUrl/nonce");

  const res = await fetch(`${state.restBase}${path}`, {
    credentials: "same-origin",
    ...opts,
    headers: {
      "X-WP-Nonce": state.nonce,
      ...(opts.headers || {}),
    },
  });

  const json = await res.json().catch(() => ({}));
  return { res, json };
}
