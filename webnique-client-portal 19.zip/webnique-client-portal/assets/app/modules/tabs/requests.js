// assets/app/modules/tabs/requests.js
import { el, pill, button, renderJson, escapeHtml } from "../ui.js";

const MOCK = {
  threads: [
    { id: "t_001", subject: "Homepage hero update request", status: "open", preview: "Swap hero image + update CTA", last: "Just now", unread: 2, priority: "normal" },
    { id: "t_002", subject: "Add service page: Emergency Pump Replacement", status: "open", preview: "SEO-first layout + FAQs", last: "2h ago", unread: 0, priority: "high" },
    { id: "t_003", subject: "Analytics question (GSC clicks drop)", status: "closed", preview: "Clicks dipped — quick checks?", last: "Yesterday", unread: 0, priority: "normal" },
  ],
  messages: {
    t_001: [
      { who: "client", name: "You", ts: "Today 4:12 PM", text: "Can we swap the homepage hero image and update the CTA copy to “Get a Free Demo”?" },
      { who: "wnq", name: "WebNique Team", ts: "Today 4:14 PM", text: "Yep — do you want CTA to go to contact form or booking link?" },
      { who: "client", name: "You", ts: "Today 4:16 PM", text: "Contact form for now. Booking later once we add Calendly." },
    ],
    t_002: [
      { who: "client", name: "You", ts: "Today 2:02 PM", text: "Need a new service page: Emergency Pump Replacement. SEO-first layout + FAQs." },
      { who: "wnq", name: "Support", ts: "Today 2:11 PM", text: "Any location modifiers to include (Sarasota/Bradenton/etc.)?" },
    ],
    t_003: [
      { who: "client", name: "You", ts: "Yesterday 9:40 AM", text: "Clicks dipped in GSC. Could be indexing/cannibalization. Any quick checks?" },
      { who: "wnq", name: "SEO", ts: "Yesterday 10:05 AM", text: "Check coverage, recent URL changes, internal linking shifts, and query/page overlap." },
    ],
  },
};

export function renderRequests(mainEl, sideEl, state) {
  mainEl.innerHTML = "";

  // side dev output stays available
  sideEl.innerHTML = "";
  const sideTitle = el("div", { text: "Output", style: { fontWeight: 900 } });
  const out = el("div", { style: { marginTop: "10px" } });
  sideEl.appendChild(sideTitle);
  sideEl.appendChild(out);
  if (state.store.lastOutput) renderJson(out, state.store.lastOutput);
  else out.innerHTML = `<div style="color:#64748b;">(actions will show JSON here)</div>`;

  let selectedId = MOCK.threads[0]?.id || null;

  const top = el("div", {
    style: { display: "flex", justifyContent: "space-between", gap: "12px", flexWrap: "wrap", marginBottom: "12px" },
  });

  const left = el("div");
  left.appendChild(el("div", { text: "Web Requests", style: { fontSize: "18px", fontWeight: 900 } }));
  left.appendChild(el("div", { text: "Threads + messages layout only (no sending yet).", style: { color: "#64748b", marginTop: "6px" } }));

  const right = el("div", { style: { display: "flex", gap: "10px", alignItems: "center" } });
  right.appendChild(pill("UI shell", "neutral"));
  right.appendChild(pill("no send", "neutral"));

  top.appendChild(left);
  top.appendChild(right);
  mainEl.appendChild(top);

  const shell = el("div", { style: { display: "grid", gridTemplateColumns: "360px 1fr", gap: "12px" } });
  mainEl.appendChild(shell);

  // Threads panel
  const threadsPanel = el("div", {
    style: { border: "1px solid rgba(2,6,23,0.10)", borderRadius: "14px", overflow: "hidden", background: "white", minHeight: "520px" },
  });

  const threadsHeader = el("div", {
    style: { padding: "12px", borderBottom: "1px solid rgba(2,6,23,0.08)", background: "rgba(2,6,23,0.02)" },
  });

  threadsHeader.appendChild(
    el("div", {
      style: { display: "flex", justifyContent: "space-between", alignItems: "center" },
      children: [el("div", { text: "Threads", style: { fontWeight: 900 } }), pill(`${MOCK.threads.length} total`)],
    })
  );

  const search = el("input", {
    type: "text",
    placeholder: "Search (UI only)…",
    style: { width: "100%", marginTop: "10px", padding: "10px 12px", borderRadius: "12px", border: "1px solid rgba(2,6,23,0.12)", outline: "none" },
  });
  threadsHeader.appendChild(search);

  const list = el("div", { style: { padding: "8px", display: "flex", flexDirection: "column", gap: "8px" } });

  function statusPill(s) {
    if (s === "open") return pill("open", "good");
    if (s === "closed") return pill("closed");
    return pill(s || "unknown");
  }

  function renderList(filter = "") {
    list.innerHTML = "";
    const f = filter.trim().toLowerCase();

    MOCK.threads
      .filter((t) => !f || t.subject.toLowerCase().includes(f) || t.preview.toLowerCase().includes(f))
      .forEach((t) => {
        const active = t.id === selectedId;

        const item = el("button", {
          type: "button",
          style: {
            textAlign: "left",
            width: "100%",
            padding: "12px",
            borderRadius: "12px",
            border: active ? `1px solid rgba(13,83,158,0.35)` : "1px solid rgba(2,6,23,0.10)",
            background: active ? "rgba(13,83,158,0.06)" : "white",
            cursor: "pointer",
          },
        });

        const row1 = el("div", { style: { display: "flex", justifyContent: "space-between", gap: "10px", alignItems: "center" } });
        row1.appendChild(el("div", { text: t.subject, style: { fontWeight: 900, fontSize: "13px" } }));
        row1.appendChild(statusPill(t.status));

        const row2 = el("div", { style: { color: "#64748b", fontSize: "12px", marginTop: "6px" }, text: t.preview });

        const row3 = el("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "10px" } });
        row3.appendChild(el("div", { style: { color: "#94a3b8", fontSize: "12px" }, text: t.last }));

        const meta = el("div", { style: { display: "flex", gap: "8px", alignItems: "center" } });
        if (t.unread) meta.appendChild(pill(`${t.unread} new`, "warn"));
        if (t.priority === "high") meta.appendChild(pill("high", "bad"));
        row3.appendChild(meta);

        item.appendChild(row1);
        item.appendChild(row2);
        item.appendChild(row3);

        item.addEventListener("click", () => {
          selectedId = t.id;
          renderList(search.value);
          renderConversation();
        });

        list.appendChild(item);
      });
  }

  search.addEventListener("input", () => renderList(search.value));

  threadsPanel.appendChild(threadsHeader);
  threadsPanel.appendChild(list);

  // Messages panel
  const convoPanel = el("div", {
    style: { border: "1px solid rgba(2,6,23,0.10)", borderRadius: "14px", overflow: "hidden", background: "white", minHeight: "520px", display: "flex", flexDirection: "column" },
  });

  const convoHeader = el("div", {
    style: { padding: "12px", borderBottom: "1px solid rgba(2,6,23,0.08)", background: "rgba(2,6,23,0.02)" },
  });

  const convoBody = el("div", { style: { padding: "12px", flex: "1", overflow: "auto", display: "flex", flexDirection: "column", gap: "10px" } });

  const composer = el("div", { style: { padding: "12px", borderTop: "1px solid rgba(2,6,23,0.08)", display: "flex", gap: "10px", alignItems: "center" } });

  const composerInput = el("input", {
    type: "text",
    placeholder: "Sending disabled (UI only)…",
    disabled: true,
    style: { flex: "1", padding: "10px 12px", borderRadius: "12px", border: "1px solid rgba(2,6,23,0.12)", background: "rgba(2,6,23,0.03)" },
  });

  const sendBtn = button(state, "Send", () => {}, "solid", true);

  composer.appendChild(composerInput);
  composer.appendChild(sendBtn);

  function bubble(msg) {
    const isClient = msg.who === "client";

    const box = el("div", {
      style: {
        alignSelf: isClient ? "flex-end" : "flex-start",
        maxWidth: "78%",
        padding: "10px 12px",
        borderRadius: "14px",
        border: "1px solid rgba(2,6,23,0.08)",
        background: isClient ? "rgba(13,83,158,0.08)" : "white",
      },
    });

    box.appendChild(el("div", { text: msg.text, style: { fontSize: "13px", lineHeight: "18px", fontWeight: 650 } }));

    const meta = el("div", {
      html: `${escapeHtml(msg.name)} · <span style="color:#64748b">${escapeHtml(msg.ts)}</span>`,
      style: { marginTop: "6px", fontSize: "12px", color: "#334155" },
    });

    box.appendChild(meta);
    return box;
  }

  function renderConversation() {
    convoHeader.innerHTML = "";

    const thread = MOCK.threads.find((t) => t.id === selectedId);
    if (!thread) {
      convoHeader.appendChild(el("div", { text: "No thread selected", style: { fontWeight: 900 } }));
      convoBody.innerHTML = "";
      return;
    }

    convoHeader.appendChild(
      el("div", {
        style: { display: "flex", justifyContent: "space-between", gap: "10px", flexWrap: "wrap", alignItems: "center" },
        children: [
          el("div", {
            html: `<div style="font-weight:900">${escapeHtml(thread.subject)}</div><div style="color:#64748b;font-size:12px;margin-top:4px">Last: ${escapeHtml(thread.last)}</div>`,
          }),
          el("div", { style: { display: "flex", gap: "8px", alignItems: "center" }, children: [statusPill(thread.status)] }),
        ],
      })
    );

    convoBody.innerHTML = "";
    const msgs = MOCK.messages[selectedId] || [];
    if (!msgs.length) {
      convoBody.appendChild(el("div", { text: "No messages yet.", style: { color: "#64748b" } }));
      return;
    }

    msgs.forEach((m) => convoBody.appendChild(bubble(m)));
    convoBody.scrollTop = convoBody.scrollHeight;
  }

  convoPanel.appendChild(convoHeader);
  convoPanel.appendChild(convoBody);
  convoPanel.appendChild(composer);

  shell.appendChild(threadsPanel);
  shell.appendChild(convoPanel);

  renderList("");
  renderConversation();
}
