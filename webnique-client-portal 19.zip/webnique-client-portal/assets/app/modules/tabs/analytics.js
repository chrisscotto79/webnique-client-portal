import { el } from "../ui.js";

export function renderAnalytics(mainEl) {
  mainEl.innerHTML = "";
  mainEl.appendChild(el("div", { text: "Analytics (UI shell) — GA4/GSC later.", style: { fontWeight: 900 } }));
}
