import { el } from "../ui.js";

export function renderSettings(mainEl) {
  mainEl.innerHTML = "";
  mainEl.appendChild(el("div", { text: "Settings (UI shell) — mapping + preferences later.", style: { fontWeight: 900 } }));
}
