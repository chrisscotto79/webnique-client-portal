import { el } from "../ui.js";

export function renderSubscription(mainEl) {
  mainEl.innerHTML = "";
  mainEl.appendChild(el("div", { text: "Subscription (UI shell) — Stripe later.", style: { fontWeight: 900 } }));
}
