import { el } from "../ui.js";

export function renderDashboard(mainEl) {
  mainEl.innerHTML = "";
  mainEl.appendChild(el("div", { text: "Dashboard (UI shell) — we’ll add real widgets later.", style: { fontWeight: 900 } }));
}
