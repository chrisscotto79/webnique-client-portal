// assets/app/modules/state.js
export function initAppState(root) {
  const PRIMARY = "#0d539e";

  return {
    primary: PRIMARY,
    clientId: root.getAttribute("data-client-id") || "",
    mode: root.getAttribute("data-mode") || "",
    restBase: window.WNQ_PORTAL?.restUrl || "",
    nonce: window.WNQ_PORTAL?.nonce || "",
    isAdmin: !!window.WNQ_PORTAL?.isAdmin,

    // shared store (for loaded client doc, etc.)
    store: {
      clientDoc: null,
      ping: null,
      lastOutput: null,
    },
  };
}
