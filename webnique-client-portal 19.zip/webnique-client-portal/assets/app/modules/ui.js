// assets/app/modules/ui.js
export function el(tag, props = {}, children = []) {
  const node = document.createElement(tag);
  Object.entries(props).forEach(([k, v]) => {
    if (k === "class") node.className = v;
    else if (k === "html") node.innerHTML = v;
    else if (k === "text") node.textContent = v;
    else if (k === "style") Object.assign(node.style, v);
    else node.setAttribute(k, v);
  });
  children.forEach((c) => node.appendChild(c));
  return node;
}

export function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

export function pill(text, tone = "neutral") {
  const bg =
    tone === "good" ? "rgba(16,185,129,0.12)" :
    tone === "warn" ? "rgba(245,158,11,0.14)" :
    tone === "bad"  ? "rgba(239,68,68,0.12)" :
    "rgba(2,6,23,0.06)";

  const border =
    tone === "good" ? "rgba(16,185,129,0.28)" :
    tone === "warn" ? "rgba(245,158,11,0.28)" :
    tone === "bad"  ? "rgba(239,68,68,0.28)" :
    "rgba(2,6,23,0.10)";

  return el("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      padding: "6px 10px",
      borderRadius: "999px",
      background: bg,
      border: `1px solid ${border}`,
      fontSize: "12px",
      lineHeight: "12px",
      whiteSpace: "nowrap",
    },
    html: text,
  });
}

export function button(state, label, onClick, variant = "outline", disabled = false) {
  const base = {
    padding: "10px 14px",
    borderRadius: "12px",
    border: "1px solid rgba(2,6,23,0.12)",
    background: "white",
    cursor: disabled ? "not-allowed" : "pointer",
    fontWeight: 800,
    opacity: disabled ? 0.55 : 1,
    userSelect: "none",
  };

  const primaryOutline = {
    border: `1px solid rgba(13,83,158,0.30)`,
    color: state.primary,
  };

  const solid = {
    background: state.primary,
    border: `1px solid ${state.primary}`,
    color: "white",
  };

  const style =
    variant === "solid" ? { ...base, ...solid } :
    variant === "primary" ? { ...base, ...primaryOutline } :
    base;

  const btn = el("button", { type: "button", style });
  btn.textContent = label;

  if (disabled) btn.disabled = true;
  else btn.addEventListener("click", onClick);

  return btn;
}

export function renderJson(outEl, json) {
  outEl.innerHTML = "";
  outEl.appendChild(
    el("pre", {
      style: {
        whiteSpace: "pre-wrap",
        background: "rgba(2,6,23,0.04)",
        padding: "12px",
        borderRadius: "12px",
        maxHeight: "520px",
        overflow: "auto",
        border: "1px solid rgba(2,6,23,0.08)",
      },
      html: escapeHtml(JSON.stringify(json, null, 2)),
    })
  );
}

export function mountShell(root, state, { onTabChange }) {
  root.innerHTML = "";

  const wrap = el("div", {
    style: {
      fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif",
      color: "#0f172a",
      maxWidth: "1200px",
      margin: "0 auto",
      padding: "18px 14px",
    },
  });

  // header
  const header = el("div", {
    style: {
      border: "1px solid rgba(2,6,23,0.10)",
      borderRadius: "16px",
      padding: "16px",
      background: "white",
      marginBottom: "14px",
    },
  });

  const titleRow = el("div", {
    style: { display: "flex", justifyContent: "space-between", gap: "12px", flexWrap: "wrap" },
  });

  const left = el("div");
  left.appendChild(el("div", { text: "WebNique Client Portal", style: { fontSize: "26px", fontWeight: 900 } }));

  const meta = el("div", {
    style: { marginTop: "6px", color: "#64748b", display: "flex", gap: "10px", flexWrap: "wrap" },
  });
  meta.appendChild(pill(`Client ID: <b>${state.clientId || "(none)"}</b>`));
  meta.appendChild(pill(`Mode: <b>${state.mode || "(none)"}</b>`));
  left.appendChild(meta);

  const status = el("div", { style: { display: "flex", alignItems: "center", gap: "10px" } });
  const statusPill = pill("ready", "good");
  status.appendChild(statusPill);

  titleRow.appendChild(left);
  titleRow.appendChild(status);
  header.appendChild(titleRow);

  // tabs
  const tabsRow = el("div", { style: { marginTop: "14px", display: "flex", gap: "10px", flexWrap: "wrap" } });
  const tabs = [
    ["dashboard", "Dashboard"],
    ["subscription", "Subscription"],
    ["analytics", "Analytics"],
    ["requests", "Web Requests"],
    ["settings", "Settings"],
  ];

  const tabButtons = new Map();

  function setActiveTab(key) {
    tabButtons.forEach((btn, k) => {
      btn.style.borderColor = k === key ? `rgba(13,83,158,0.45)` : "rgba(2,6,23,0.12)";
      btn.style.background = k === key ? "rgba(13,83,158,0.06)" : "white";
      btn.style.color = k === key ? state.primary : "#0f172a";
    });
  }

  tabs.forEach(([key, label]) => {
    const btn = button(state, label, () => onTabChange(key), "primary");
    btn.style.borderColor = "rgba(2,6,23,0.12)";
    btn.style.color = "#0f172a";
    btn.style.background = "white";
    tabButtons.set(key, btn);
    tabsRow.appendChild(btn);
  });

  header.appendChild(tabsRow);

  // grid
  const grid = el("div", { style: { display: "grid", gridTemplateColumns: "repeat(12, 1fr)", gap: "14px" } });

  const main = el("div", { style: { gridColumn: "span 8" } });
  const side = el("div", { style: { gridColumn: "span 4" } });

  const mainCard = el("div", {
    style: {
      border: "1px solid rgba(2,6,23,0.10)",
      borderRadius: "16px",
      padding: "16px",
      background: "white",
      minHeight: "520px",
    },
  });

  const sideCard = el("div", {
    style: {
      border: "1px solid rgba(2,6,23,0.10)",
      borderRadius: "16px",
      padding: "16px",
      background: "white",
    },
  });

  main.appendChild(mainCard);
  side.appendChild(sideCard);

  grid.appendChild(main);
  grid.appendChild(side);

  wrap.appendChild(header);
  wrap.appendChild(grid);
  root.appendChild(wrap);

  return {
    main: mainCard,
    side: sideCard,
    setActiveTab,
    statusPill,
  };
}
